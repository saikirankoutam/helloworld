({
    
    doInit: function(component, event, helper) {                      
        var forecastTimeline = parseInt($A.get("$Label.c.MonthlyOrder_Forecast_timeline"));
        component.set("v.spinner", true);
        var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        var today = new Date();
        today.setDate(today.getDate() + forecastTimeline);
        var month = today.getMonth();
        var monthName = months[month];
        var year = today.getFullYear();
        component.set("v.month", month);
        var findMonth = component.find(month);
        $A.util.removeClass(findMonth, 'disable');
        $A.util.addClass(findMonth, 'activetab'); 
        component.set("v.year", year);
        var halfyear = year.toString();
        component.set("v.halfyear", halfyear.slice(2));
        component.set("v.monthName", monthName);
        component.set("v.monthNameHalf", monthName.slice(0,3));
        
        var f1 = today;
        f1.setMonth(f1.getMonth() + 1);
        var fmonth1 = f1.getMonth();
        var fyear1 = f1.getFullYear();
        fyear1 = fyear1.toString();
        var fmonthfull1 = months[fmonth1];
        
        var f2 = today;
        f2.setMonth(f2.getMonth() + 1);
        var fmonth2 = f2.getMonth();
        var fyear2 = f2.getFullYear();
        fyear2 = fyear2.toString();
        var fmonthfull2 = months[fmonth2];
        
        var f3 = today;
        f3.setMonth(f3.getMonth() + 1);
        var fmonth3 = f3.getMonth();
        var fyear3 = f3.getFullYear();
        fyear3 = fyear3.toString();
        var fmonthfull3 = months[fmonth3];
        
        var f4 = today;
        f4.setMonth(f4.getMonth() + 1);
        var fmonth4 = f4.getMonth();
        var fyear4 = f4.getFullYear();
        fyear4 = fyear4.toString();
        var fmonthfull4 = months[fmonth4];
        
        var f5 = today;
        f5.setMonth(f5.getMonth() + 1);
        var fmonth5 = f5.getMonth();
        var fyear5 = f5.getFullYear();
        fyear5 = fyear5.toString();
        var fmonthfull5 = months[fmonth5];
        
        var f6 = today;
        f6.setMonth(f6.getMonth() + 1);
        var fmonth6 = f6.getMonth();
        var fyear6 = f6.getFullYear();
        fyear6 = fyear6.toString();
        var fmonthfull6 = months[fmonth6];
        
        component.set("v.fMonth1", fmonthfull1);
        component.set("v.fMonth2", fmonthfull2);
        component.set("v.fMonth3", fmonthfull3);
        component.set("v.fMonth4", fmonthfull4);
        component.set("v.fMonth5", fmonthfull5);
        component.set("v.fMonth6", fmonthfull6);
        component.set("v.fMonthhalf1", fmonthfull1.slice(0,3));
        component.set("v.fMonthhalf2", fmonthfull2.slice(0,3));
        component.set("v.fMonthhalf3", fmonthfull3.slice(0,3));
        component.set("v.fMonthhalf4", fmonthfull4.slice(0,3));
        component.set("v.fMonthhalf5", fmonthfull5.slice(0,3));
        component.set("v.fMonthhalf6", fmonthfull6.slice(0,3));
        component.set("v.fyear1", fyear1);
        component.set("v.fyear2", fyear2);
        component.set("v.fyear3", fyear3);
        component.set("v.fyear4", fyear4);
        component.set("v.fyear5", fyear5);
        component.set("v.fyear6", fyear6);
        component.set("v.fyearhalf1", fyear1.slice(2));
        component.set("v.fyearhalf2", fyear2.slice(2));
        component.set("v.fyearhalf3", fyear3.slice(2));
        component.set("v.fyearhalf4", fyear4.slice(2));
        component.set("v.fyearhalf5", fyear5.slice(2));
        component.set("v.fyearhalf6", fyear6.slice(2));
        helper.getItemProducts(component, event, helper);
        helper.getForecast1(component, event, helper);
        helper.getDemoProducts(component, event, helper);
        helper.getFirmOrder(component, event, helper);
        helper.getDealerobjective(component, event, helper);
        helper.getVariantList(component, event, helper);
        
    },
    onApprove : function(component, event, helper) {
        
        var orderid = component.get("v.orderId");
        var action = component.get("c.orderReview");
        action.setParams({
            "orderId" : orderid,
            "reviewType" : "Approve"
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                helper.showSuccessToast(component);
                component.set("v.editMonthlyOrder",false);
            }
        });
        $A.enqueueAction(action);
    },  
    onReject : function(component, event, helper) {
        var validity = component.find("rejectionReason").get("v.validity");
        component.find("rejectionReason").reportValidity();
        var orderid = component.get("v.orderId");
        console.log('Order Id >>>>>>>'+orderid);
        if(validity.valid)
        {
            var action = component.get("c.orderReview");
            action.setParams({
                "orderId" : orderid,
                "reviewType" : "Reject",
                "rejectReason" : component.find("rejectionReason").get("v.value")
            });
            
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    helper.showErrorToast(component);
                    component.set("v.editMonthlyOrder",false);
                }
            });
            $A.enqueueAction(action);
        }
    },
    openModal : function(component, event, helper) {
        document.getElementById("myModal").style.display = "block"; 
    },
    closeModal : function(component, event, helper) {
        document.getElementById("myModal").style.display = "none"; 
    },
    
    changeSE21Div : function(component, event, helper) {
        if(!component.get("v.CitreonSE21Div"))
        {
            component.set("v.CitreonC84Div", false);
            component.set("v.CitreonSE21Div", true);
            component.set("v.carType", component.get("v.model1"));
        }else
        {
            component.set("v.CitreonSE21Div", false);
        }
    },
    
    changeC84Div : function(component, event, helper) {
        if(!component.get("v.CitreonC84Div"))
        {
            component.set("v.CitreonSE21Div", false);
            component.set("v.CitreonC84Div", true);
            component.set("v.carType", component.get("v.model2"));
        }else
        {
            component.set("v.CitreonC84Div", false);
        }
    },
     
    
    
     
})
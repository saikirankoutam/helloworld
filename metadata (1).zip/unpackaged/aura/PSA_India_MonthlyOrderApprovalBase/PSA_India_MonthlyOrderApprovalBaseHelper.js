({
    getFirmOrder : function(component, event, monthName) {debugger;
        var action = component.get("c.fetchFirmOrder");
        action.setParams({
            "orderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                if(value != null)
                {
                    component.set("v.orderId", value.Id);
                    component.set("v.OrderStatus", value.Status);
                    component.set("v.OrderReviewStatus", value.PSA_Review_Status__c);
                    component.set("v.dealerName", value.Account.Name);
                    component.set("v.dealerCode", value.Account.Dealer_Code__c);
                    component.set("v.C84Qty", value.C84_Total_Qty__c);
                    component.set("v.SE21Qty", value.SE21_Total_Qty__c);
                    var items = value.OrderItems;
                    var productIds = component.get("v.productList");                  
                    var quantities = [];
                    if(productIds != null)
                        for(var i=0; i<productIds.length; i++)
                            quantities.push(0);
                    for(var i=0; i<items.length; i++)
                    {
                        var index = productIds.indexOf(items[i].Product2.Id);
                        quantities.splice(index,1,items[i].Quantity);
                    }
                    component.set("v.quantityList",quantities);       
                }
            }
            component.set("v.spinner", false);
            
        });
        $A.enqueueAction(action);
    },
    
    
    showErrorToast : function(cmp) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": "Order has been Rejected",
            "type": "error"
        });
        toastEvent.fire(); 
    },
    
    showSuccessToast : function(cmp){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": "Order has been Approved.",
            "type": "success"
        });
        toastEvent.fire();  
    },
    
    getItemProducts : function(component, event, helper) {
        var months1 = [];
        var months2 = [];
        var year1 = component.get("v.year");
        var year2 = year1+1;
        months1.push(component.get("v.monthName"));
        
        for(var i=1; i<7; i++)
        {
            var year = "v.fyear"+i;
            var month = "v.fMonth"+i;
            if(component.get(year) == year1)
                months1.push(component.get(month));
            else
                months2.push(component.get(month));
        }   
        var action = component.get("c.getLineItemProducts");
        action.setParams({
            "months1": months1,
            "months2": months2,
            "year1": year1,
            "year2": year2,
            "orderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var CitreonSE21ItemList = [];
                var CitreonC84ItemList = [];
                var productList = [];
                var items = value;
                for(var i=0; i<items.length; i++)
                {
                    productList.push(items[i].Product2.Id);
                    if(items[i].Product2.PSA_Brand__c == component.get("v.model2"))
                        CitreonC84ItemList.push(items[i]);
                    else if(items[i].Product2.PSA_Brand__c == component.get("v.model1"))
                        CitreonSE21ItemList.push(items[i]);
                }
                component.set("v.productList", productList);
                component.set("v.CitreonSE21ItemList", CitreonSE21ItemList);
                component.set("v.CitreonC84ItemList", CitreonC84ItemList);
            }
        });
        $A.enqueueAction(action); 
    },
    
    getDemoProducts : function(component, event, helper) {
        var months1 = [];
        var months2 = [];
        var year1 = component.get("v.year");
        var year2 = year1+1;
        months1.push(component.get("v.monthName"));
        var orderTypes = [];
        var demoItems = [];
        var SE21demoItems = [];
        var C84demoItems = [];
        for(var i=1; i<7; i++)
        {
            var year = "v.fyear"+i;
            var month = "v.fMonth"+i;
            if(component.get(year) == year1)
                months1.push(component.get(month));
            else
                months2.push(component.get(month));
        }   
        var action = component.get("c.getDemoItemProducts");
        action.setParams({
            "months1": months1,
            "months2": months2,
            "year1": year1,
            "year2": year2,
            "orderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                
                for(var key in value)
                {
                    var items = value[key];
                    if(typeof items != 'undefined' && items != null)
                        for(var i=0; i<items.length; i++)
                        {
                            if(items[i].Product2.PSA_Brand__c == component.get("v.model2"))
                                C84demoItems.push(items[i]);
                            else if(items[i].Product2.PSA_Brand__c == component.get("v.model1"))
                                SE21demoItems.push(items[i]);
                        }
                }
                
                component.set("v.C84demoItems", C84demoItems);
                component.set("v.SE21demoItems", SE21demoItems);
                
                
            }
        });
        $A.enqueueAction(action);
    },
    
    
    getForecast1 : function(component, event, helper) {
        var action = component.get("c.fetchForecastOrder");
        action.setParams({
            "Month": component.get("v.monthName"),
            "year": component.get("v.year"),
            "fMonth1": component.get("v.fMonth1"),
            "fMonth2": component.get("v.fMonth2"),
            "fMonth3": component.get("v.fMonth3"),
            "fMonth4": component.get("v.fMonth4"),
            "fMonth5": component.get("v.fMonth5"),
            "fMonth6": component.get("v.fMonth6"),
            "fyear1": component.get("v.fyear1"),
            "fyear2": component.get("v.fyear2"),
            "fyear3": component.get("v.fyear3"),
            "fyear4": component.get("v.fyear4"),
            "fyear5": component.get("v.fyear5"),
            "fyear6": component.get("v.fyear6"),
            "orderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var fValues = value['fValues'];
                component.set("v.demomapFirm",value['demoItemMapFirm']);
                component.set("v.demofmap1",value['demoItemMap1']);
                component.set("v.demofmap2",value['demoItemMap2']);
                component.set("v.demofmap3",value['demoItemMap3']);
                component.set("v.demofmap4",value['demoItemMap4']);
                component.set("v.demofmap5",value['demoItemMap5']);
                component.set("v.demofmap6",value['demoItemMap6']);
                component.set("v.fmap1",fValues['fItemMap1']);
                component.set("v.fmap2",fValues['fItemMap2']);
                component.set("v.fmap3",fValues['fItemMap3']);
                component.set("v.fmap4",fValues['fItemMap4']);
                component.set("v.fmap5",fValues['fItemMap5']);
                component.set("v.fmap6",fValues['fItemMap6']);
                var fmap = fValues['fItemMap7'];
                if(fmap != null)
                    for(var key in fmap)
                    {
                        component.set("v.f1SE21Qty", fmap["f1SE21"]!=null?fmap["f1SE21"]:0);
                        component.set("v.f2SE21Qty", fmap["f2SE21"]!=null?fmap["f2SE21"]:0);
                        component.set("v.f3SE21Qty", fmap["f3SE21"]!=null?fmap["f3SE21"]:0);
                        component.set("v.f4SE21Qty", fmap["f4SE21"]!=null?fmap["f4SE21"]:0);
                        component.set("v.f5SE21Qty", fmap["f5SE21"]!=null?fmap["f5SE21"]:0);
                        component.set("v.f6SE21Qty", fmap["f6SE21"]!=null?fmap["f6SE21"]:0);
                        component.set("v.f1C84Qty", fmap["f1C84"]!=null?fmap["f1C84"]:0);
                        component.set("v.f2C84Qty", fmap["f2C84"]!=null?fmap["f2C84"]:0);
                        component.set("v.f3C84Qty", fmap["f3C84"]!=null?fmap["f3C84"]:0);
                        component.set("v.f4C84Qty", fmap["f4C84"]!=null?fmap["f4C84"]:0);
                        component.set("v.f5C84Qty", fmap["f5C84"]!=null?fmap["f5C84"]:0);
                        component.set("v.f6C84Qty", fmap["f6C84"]!=null?fmap["f6C84"]:0);
                    }  
            }
        });
        $A.enqueueAction(action);
    },
    
    getDealerobjective : function(component, event, helper) {
        var action = component.get("c.getdealerobjectiverecord");
        action.setParams({
            "orderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.delearobjective", value);
                component.set("v.orderLimit", value.orderLimit);
                var achSE21Qty = Number.isFinite(component.get("v.SE21Qty"))?component.get("v.SE21Qty"):0;
                var achC84Qty = Number.isFinite(component.get("v.C84Qty"))?component.get("v.C84Qty"):0;
                var achQty = Number.isFinite((achSE21Qty+achC84Qty)/(value.sc21total+value.C84total)*100)? (achSE21Qty+achC84Qty)/(value.sc21total+value.C84total)*100:0;
                component.set("v.achSE21Qty", parseInt(Number.isFinite(component.get("v.SE21Qty")/value.sc21total*100)?component.get("v.SE21Qty")/value.sc21total*100:0));
                component.set("v.achC84Qty", parseInt(Number.isFinite(component.get("v.C84Qty")/value.C84total*100)?component.get("v.C84Qty")/value.C84total*100:0));
                component.set("v.achQty", parseInt(achQty));
            }
            component.set("v.spinner", false);
            
        });
        $A.enqueueAction(action);  
        
    }, 
    
    getPreviousRecommendationms1 : function(component, event, helper, monthList) {
        var action = component.get("c.fetchPreviousOrderValues");
        action.setParams({
            "month": component.get("v.monthName"),
            "year": component.get("v.year"),
            "orderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.previousValues", value);
            }
        });
        $A.enqueueAction(action);  
    },
    
    
    getPreviousRecommendationms2 : function(component, event, helper, monthList) {
        var action = component.get("c.fetchPreviousOrderValues2");
        action.setParams({
            "month": component.get("v.monthName"),
            "year": component.get("v.year"),
            "orderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS") {
                var value = response.getReturnValue();debugger;
                var SE21 = 0;
                var C84 = 0;
                for(var i=0; i<value.length; i++)
                {
                    var val = value[i];
                    var month = val.PSA_Month_Year_Order__c;
                    var monthName = month.slice(0,3);
                    var year = val.Order_Year__c;
                    var halfyear = year.toString();
                    var Integer = monthList.indexOf(monthName+"'"+halfyear)+1;
                    var row1 = "r1c"+Integer;
                    document.getElementById(row1).innerHTML = val.SE21_Total_Qty__c;
                    var row2 = "r2c"+Integer;
                    document.getElementById(row2).innerHTML = val.C84_Total_Qty__c;
                    
                    SE21 +=val.SE21_Total_Qty__c;
                    C84 +=val.C84_Total_Qty__c;
                }
                document.getElementById("r1c13").innerHTML = (SE21/12).toFixed(0);
                document.getElementById("r2c13").innerHTML = (C84/12).toFixed(0);
            }
        });
        $A.enqueueAction(action);  
    },
    
    getPreviousRecommendationms3 : function(component, event, helper) {
        var action = component.get("c.fetchClosingStockValues");
        action.setParams({
            "orderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS") {
                var value = response.getReturnValue();
                document.getElementById("r1c14").innerHTML = 0;
                document.getElementById("r2c14").innerHTML = 0;
                document.getElementById("r1c15").innerHTML = value["sc21"];
                document.getElementById("r2c15").innerHTML = value["c84"];
                document.getElementById("r1c16").innerHTML = value["sc21AI"];
                document.getElementById("r2c16").innerHTML = value["c84AI"];
            }
        });
        $A.enqueueAction(action);  
    },
    
    getVariantList : function(component, event, helper) {
        debugger;
        var action = component.get("c.fetchCarVariants");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.variantList", value);
            }
            
        });
        $A.enqueueAction(action);  
    }
})
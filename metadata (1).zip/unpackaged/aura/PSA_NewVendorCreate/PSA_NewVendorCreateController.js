({
    
    doInit: function(component, event, helper) {
        var action = component.get("c.getStateval");
        action.setCallback(this, function(response) {
        component.set("v.StateList", response.getReturnValue());
    		});
        
        var action1 = component.get("c.fetchSupplierTypePicklist");
        action1.setCallback(this, function(response) {
        component.set("v.SupplierList", response.getReturnValue());
    		});
      $A.enqueueAction(action);
        $A.enqueueAction(action1);
     },  
    
     getdistrict : function(component, event, helper){
         debugger;
        var selectstate = component.find("state").get("v.value");
        var action = component.get("c.getdistrictmethod");
        action.setParams({ 
            "selState" : selectstate,
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.districtList", response.getReturnValue());
                component.find("district").set("v.value", "--None--");
                console.log('response.getReturnValue()'+response.getReturnValue())
            }
        });
        $A.enqueueAction(action);	
    }, 
   
    validate  : function(component, event, helper) {
        var inp = component.find("Pincode2").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(inp))
            component.find("Pincode2").set("v.value", inp.substring(0, inp.length - 1));
    },
    telvalidate  : function(component, event, helper) {
        var telinp = component.find("TelephoneNo").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(telinp))
            component.find("TelephoneNo").set("v.value", telinp.substring(0, telinp.length - 1));
    },
    mobvalidate  : function(component, event, helper) {
        var mobinp = component.find("MobileNo").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(mobinp))
            component.find("MobileNo").set("v.value", mobinp.substring(0, mobinp.length - 1));
    },
    
    CheckLength : function(component, event, helper) {
        debugger;
        var val = component.find("Pincode2").get("v.value");
        if(val.length > 6){
            console.log('Input pincode  >>>>>'+val);
            val.slice(0,6);
            val;
            var pinco = component.get("v.pincode");
            component.set("v.pincode",val);
            var pin = component.get("v.pincode");
            console.log('pincode after substring  >>>>>'+pin);
        }
    },
    validateNum :function(component, event, helper){
        var keycode = event.keycode;
        if(keycode>48 && keycode<57)
            return true;
        else return false;
    },
    cancelSaveRecord : function(component, event, helper){
        // component.set("v.curView", "baseView" );
        // component.set("v.listvendor", true);
        component.set("v.newvendor", false);
        var eventListPage = component.getEvent("displayListPageVendors");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
    handleSaveVendor: function(component, event, helper) {
        
        if(helper.validateVendorForm(component)) {
            var supplierType=component.find("supplierType").get("v.value");
            var supplierName = component.find("supplierName").get("v.value");
            var contactPerson = component.find("contactPerson").get("v.value");
         // var vendorAddressline1 = component.find("vendorAddressline1").get("v.value");
         // var vendorAddressline2 = component.find("vendorAddressline2").get("v.value");            
         // var branchName = component.find("branchName").get("v.value");
         // var accountNumber = component.find("accountNumber").get("v.value");
            var addressline1 = component.find("addressline1").get("v.value");
            var addressline2 = component.find("addressline2").get("v.value");
            var district=component.find("district").get("v.value");
            var state=component.find("state").get("v.value");
            var country=component.find("country").get("v.value");
            var Pincode2 = component.find("Pincode2").get("v.value");
            var MobileNo = component.find("MobileNo").get("v.value");
            var TelephoneNo = component.find("TelephoneNo").get("v.value");
            var Emailid = component.find("Emailid").get("v.value");
            var Website = component.find("Website").get("v.value");
            var bankName = component.find("bankName").get("v.value");
            var accountName = component.find("accountName").get("v.value");
            var branchcode = component.find("branchcode").get("v.value");
            var IFSCCode = component.find("IFSCCode").get("v.value");
            var gstno = component.find("GSTno").get("v.value");
            var tinno = component.find("TINno").get("v.value");
            var panno = component.find("PANno").get("v.value");
            var active= component.get("v.active");
            var action = component.get("c.SaveVendor"); 
            //var active=component.find("Active").get("v.value");
            action.setParams({
                "suppType"  : supplierType,
                "supName"   : supplierName,
                "conPer"    : contactPerson,
                "addL1" 	: addressline1,
                "addL2" 	: addressline2,
                "dist"      : district,
                "sta"		: state,
                "count"		: country,
                "pinCo"	    : Pincode2,
                "mobNo"     : MobileNo,
                "telNo"  	: TelephoneNo,
                "emaid"  	: Emailid,
                "wesite"  	: Website,
                "bank"      : bankName,
                "account"   : accountName,
                "branch"	: branchcode,
                "ifsc"      : IFSCCode,
                "cstn"      : gstno,
                "tinn"  	: tinno,
                "pann"      : panno,
                "active"    : active,
                "recordid"  : '',
                
            });
            action.setCallback(this, function(response) {
                var state=response.getState();
                console.log('save status  >>>>'+state);
                if(state  === "SUCCESS"){
                    var Message= $A.get("$Label.c.Vendor_Creation");
                    helper.showSuccessToast(component,event,Message);                   
                    
                    var eventListPage = component.getEvent("displayListPageVendors");
                    eventListPage.setParams({"listPage" : true });
                    eventListPage.fire();
                }
                if(state  === "ERROR"){
                    var toast = $A.get("e.force:showToast");
                    if(toast){
                        toast.setParams({
                            "title": "Error",
                            "message": result.getError()[0].message
                        });
                    }
                    toast.fire();
                } 
                
            });
            $A.enqueueAction(action); 
        }
    },
    oncancel:function(component, event, helper) {
        
        var supplierType=component.find("supplierType").set("v.value","");
          component.find("supplierName").set("v.value","");
           component.find("contactPerson").set("v.value","");
         //  component.find("vendorAddressline1").set("v.value","");
        //component.find("vendorAddressline2").set("v.value","");            
         //  component.find("branchName").set("v.value","");
         // component.find("accountNumber").set("v.value","");
          component.find("addressline1").set("v.value","");
          component.find("addressline2").set("v.value","");
          component.find("district").set("v.value","");
         component.find("state").set("v.value","");
         component.find("country").set("v.value","");
         component.find("Pincode2").set("v.value","");
         component.find("MobileNo").set("v.value","");
         component.find("TelephoneNo").set("v.value","");
         component.find("Emailid").set("v.value","");
         component.find("Website").set("v.value","");
         component.find("bankName").set("v.value","");
         component.find("accountName").set("v.value","");
         component.find("branchcode").set("v.value","");
         component.find("IFSCCode").set("v.value","");
         component.find("GSTno").set("v.value","");
         component.find("TINno").set("v.value","");
         component.find("PANno").set("v.value","");
        
        component.set("v.supplierTypeErrorMsg","");
        component.set("v.supplierErrorMsg","");
        component.set("v.CpErrorMsg","");  
        component.set("v.add1ErrorMsg","");
        component.set("v.add2ErrorMsg","");
        component.set("v.DistrictErrorMsg","");
        component.set("v.StateErrorMsg","");
        component.set("v.CountryErrorMsg","");
        component.set("v.pincodeErrorMsg","");        
        component.set("v.mobilenoErrorMsg","");
        component.set("v.TelephoneErrorMsg","");
        component.set("v.emailErrorMsg","");
        component.set("v.websiteErrorMsg","");
        component.set("v.bankNameErrorMsg","");
        component.set("v.AccountErrorMsg","");
        component.set("v.BranchErrorMsg","");
        component.set("v.ifscErrorMsg","");
        component.set("v.cstnoErrorMsg","");
        component.set("v.tinnoErrorMsg","");
        component.set("v.pannoErrorMsg","");  
        component.set("v.active",true);
        
    }
   
    
})
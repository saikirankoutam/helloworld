({
    doInit : function(component, event, helper) {
        var reportid = $A.get("$Label.c.PSA_PartsSales_Report"); 
        var reporturl;
        reporturl = '/dmsindia/s/report/'+reportid;    
        component.set("v.reportlink",reporturl);
          var rid = $A.get("$Label.c.PSA_Sales_Report"); 
        var report;
        report = '/dmsindia/s/report/'+rid;    
        component.set("v.report",report);
    }
})
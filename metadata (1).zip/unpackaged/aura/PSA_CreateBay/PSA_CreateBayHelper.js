({
    validatePartForm : function(component, event, helper){
        debugger;
        var isValid = true;
        var BayNum = component.find("BayNum").get("v.value");
       // var BayName = component.find("BayName").get("v.value");
        var Baydesc = component.find("Baydesc").get("v.value");
        var Baytype = component.find("Baytype").get("v.value");
         var active =component.find("checkbox").get("v.value");
        
        
        component.set("v.baynumberErrmsg",'');
        $A.util.removeClass(BayNum,"disp-block");
        $A.util.addClass(BayNum,"disp-none");
        /*component.set("v.BaynameErrmsg",'');
        $A.util.removeClass(BayName,"disp-block");
        $A.util.addClass(BayName,"disp-none");*/
        component.set("v.BaydescErrorMsg",'');  
        $A.util.removeClass(Baydesc,"disp-block");
        $A.util.addClass(Baydesc,"disp-none");
        component.set("v.BaytypeErrmsg",'');
        $A.util.removeClass(Baytype,"disp-block");
        $A.util.addClass(Baytype,"disp-none");
        
        if(BayNum == 'undefined'|| BayNum == '' || BayNum == null){
            isValid = false;
            component.set("v.baynumberErrmsg",'This is a required field');
            $A.util.removeClass(BayNum,"disp-none");
            $A.util.addClass(BayNum,"disp-block");
        }
      /*  if(BayName =='undefined'|| BayName == '' || BayName == null){
            component.set("v.BaynameErrmsg",'This is a required field');
            $A.util.removeClass(BayName,"disp-none");
            $A.util.addClass(BayName,"disp-block");
            isValid = false;
        }*/
        if(Baydesc =='undefined'|| Baydesc == '' || Baydesc == null){
            component.set("v.BaydescErrorMsg",'This is a required field');
            $A.util.removeClass(Baydesc,"disp-none");
            $A.util.addClass(Baydesc,"disp-block");
            isValid = false;
        }
        if(Baytype == '--None--'|| Baytype == '' || Baytype == null){
            component.set("v.BaytypeErrmsg",'This is a required field');
            $A.util.removeClass(Baytype,"disp-none");
            $A.util.addClass(Baytype,"disp-block");
            isValid = false;
        }
        
        return isValid;
    },           
    mastertable:function(component,event){
         
          var action = component.get('c.getBaymasterlist');
        	action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
               	component.set("v.baycount", records.length);                
                var pageSize = component.get("v.pageSize");
                component.set("v.Baylist", records);
                 component.set("v.totalSize", component.get("v.Baylist").length);
                    component.set("v.start",0);
                    component.set("v.end",pageSize-1);
                    var paginationList = [];
                    if(response.getReturnValue().length < pageSize){
                        paginationList=response.getReturnValue();
                    }
                    else{
                        for(var i=0; i< pageSize; i++){
                            paginationList.push(response.getReturnValue()[i]); 
                        } 
                    }
                    
                    component.set('v.paginationList', paginationList);
                	this.helperMethodPagination(component, event, '1');
                 
            }
        });
        $A.enqueueAction(action);
         
     },
     mastertablerefresh:function(component,event){
        this.mastertable(component, event); 
         
     },
    
    saverequest:function(component,event){
        debugger;
        
        var BayNum = component.find("BayNum").get("v.value");
       // var BayName = component.find("BayName").get("v.value");
        var Baydesc = component.find("Baydesc").get("v.value");
        var Baytype = component.find("Baytype").get("v.value");
        var active =component.find("checkbox").get("v.value");
      //var active =component.get("v.credlimit");
        var inactive=component.find("inactivecheckbox").get("v.value");
       
        var action = component.get("c.createBaymethod");
        debugger;
        action.setParams({
            "baynumber": BayNum,
          //  "Bname": BayName,
            "Bdesc" : Baydesc,
            "Btype": Baytype,
            "active":active,
            "inactive":inactive
            
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
          var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
              
                if(storeResponse==''||storeResponse==null || storeResponse=='undefined')
                {
                   
                    this.showErrorToast(component,event);
                /*document.getElementById("myModal").style.display = "none";
                component.find("BayNum").set("v.value", "");
            
                component.find("Baydesc").set("v.value", "");
                component.find("Baytype").set("v.value", "--None--");
                component.find("Bayview").set("v.value", "");
                component.find("checkbox").set("v.value", false);*/
                }
                else{
                var Message= $A.get("$Label.c.Bay_Created_Successfully");
                this.showSuccessToast(component,event,Message);
                
                document.getElementById("myModal").style.display = "none";
                 this.mastertable(component, event);
                }
            }
            else{
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Failed!",
                    "message": "Failed to Create Bay",
                    "type": "failed"
                });
                toastEvent.fire();
                document.getElementById("myModal").style.display = "none";
                component.find("BayNum").set("v.value", "");
               
                component.find("Baydesc").set("v.value", "");
                component.find("Baytype").set("v.value", "--None--");
                component.find("Bayview").set("v.value", "");
                 component.find("checkbox").set("v.value", false);
            }
            
        });
        $A.enqueueAction(action);
    },
    
    showErrorToast : function(component, event){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": "Duplicate bay number. Bay not created",
            "type": "error"
        });
        toastEvent.fire();  
    },
    
    
    
    
    
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    
    helperMethodPagination : function(component, event, pageNumber){
        var pageSize = component.get("v.pageSize");//Number Of Row Per Page
        var totalpage=Math.ceil(component.get("v.Baylist").length/pageSize);//Number Of Total Pages
        var   paginationPageNumb=[];
        var cont=1;
        /*---Pagination Logic Start--*/
         if(pageNumber<=7){ 
            
            for(var i=1; i<= totalpage; i++){
              
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
                  paginationPageNumb.push(i);
            }
            
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
               paginationPageNumb.push(i);
           
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }
        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    },
    
    
})
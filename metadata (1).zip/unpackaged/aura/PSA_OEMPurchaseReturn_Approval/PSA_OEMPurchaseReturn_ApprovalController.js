({
    invoiceChanges : function(component, event, helper) {
        component.set('v.submitdiasable',false);
        var selectedrec=component.get("v.invoiceRecord");
        var invoidid=selectedrec.PSA_Invoice__c;
        var oemid=selectedrec.Id;
        if(invoidid==null || invoidid== '' || invoidid== 'undefined'){
            component.set('v.remarksdisable',true);
            component.set('v.returnlist',null);
            component.find('invoiceDate').set('v.value','');
            component.find('dealerName').set('v.value','');
            component.find('dealerCode').set('v.value','');
            component.find('dealerLocation').set('v.value','');
            component.find('dealerLocation').set('v.value','');
            component.find('ReturnReqDate').set('v.value','');
            component.find('returnStatus').set('v.value','');
            component.find('invoiceValue').set('v.value','');
            component.find('totalInvoiceValue').set('v.value','');
            component.find('totalTaxValue').set('v.value','');
            component.find('retInvValue').set('v.value','');
            component.find('returntaxableValue').set('v.value','');
            component.find('totalReturnInvValue').set('v.value','');
            component.find('dealerRemark').set('v.value','');
            component.find('reasonForReturn').set('v.value','');
            component.find('approverComments').set('v.value','');
            component.find('ReturnInvNum').set('v.value','');
            component.find('ReturnInvDate').set('v.value','');
            component.find('approvedBy').set('v.value','');
            component.find('approvalStatus').set('v.value','');
            component.set('v.submitdisable',true);
        }else{
               component.set('v.submitdisable',false);
               component.set('v.remarksdisable',false)
               component.find('invoiceDate').set('v.value',selectedrec.PSA_Invoice__r.PSA_Invoice_Date__c);
               component.find('dealerName').set('v.value',selectedrec.PSA_Invoice__r.PSA_Account__r.Name);
               component.find('dealerCode').set('v.value',selectedrec.PSA_Invoice__r.PSA_Account__r.Dealer_Code__c);
               component.find('dealerLocation').set('v.value',selectedrec.PSA_Invoice__r.PSA_Account__r.BillingCity);
               component.find('invoiceValue').set('v.value',selectedrec.PSA_Invoice__r.Invoice_Amount__c);
               component.find('totalInvoiceValue').set('v.value',selectedrec.PSA_Invoice__r.Tax_Amount__c);
               component.find('totalTaxValue').set('v.value',selectedrec.PSA_Invoice__r.Material_Value__c);
               //component.find('ReturnInvNum').set('v.value',selectedrec.);
               //component.find('ReturnInvDate').set('v.value',selectedrec.);
               //component.find('ReturnReqDate').set('v.value',selectedrec.CreatedDate);
               component.find('returnStatus').set('v.value',selectedrec.PSA_OEM_Purchase_Return__c);
               component.find('retInvValue').set('v.value',selectedrec.PSA_Taxable_Value__c);
               component.find('returntaxableValue').set('v.value',selectedrec.PSA_Total_tax__c);
               component.find('totalReturnInvValue').set('v.value',selectedrec.PSA_Total_Invoice_Value__c);
               //component.find('dispatchDate').set('v.value',selectedrec.PSA_Dispatch_Date__c);
               component.find('reasonForReturn').set('v.value',selectedrec.PSA_Return_Reason__c);
              //component.find('transporter').set('v.value',selectedrec.PSA_Transporter__c);
              //component.find('shipAdvNumber').set('v.value',selectedrec.PSA_Shipment_Advice_Number__c);
              component.find('dealerRemark').set('v.value',selectedrec.PSA_Dealer_Remarks__c);
              //component.find('psaRemarks').set('v.value',selectedrec.PSA_OEM_Purchase_Remarks__c);
              component.find('approverComments').set('v.value',selectedrec.PSA_Approver_Comments__c);
              var status = selectedrec.PSA_Approval_Status__c;
             /* if(status == 'Approved' || status == 'Rejected'){
                component.set('v.remarksdisable',true);}
            else{component.set('v.remarksdisable',false);}*/
            helper.returnlistfetch(component,event,oemid);
		}
      },

    approveOEMPurchaseReturn : function(component, event, helper) {
        if(helper.validateMandateFields(component, event, helper)){
        var selectedrec=component.get("v.invoiceRecord");
        var invoidid=selectedrec.PSA_Invoice__c;
        var oemid=selectedrec.Id;
        //var psaRemarks  = component.find('psaRemarks').get('v.value');
        //helper.approveOEMPurchaseReturn(component,event,invoidid,oemid,psaRemarks);
        var approverComments  = component.find('approverComments').get('v.value');
        helper.approveOEMPurchaseReturn(component,event,invoidid,oemid,approverComments);
        }
    },
        rejectOEMPurchaseReturn : function(component, event, helper) {
        if(helper.validateMandateFields(component, event, helper)){
        var selectedrec=component.get("v.invoiceRecord");
        var invoidid=selectedrec.PSA_Invoice__c;
        var oemid=selectedrec.Id;
        //var psaRemarks  = component.find('psaRemarks').get('v.value');
        var approverComments  = component.find('approverComments').get('v.value');
        //helper.rejectOEMPurchaseReturn(component,event,invoidid,oemid,psaRemarks);
        helper.rejectOEMPurchaseReturn(component,event,invoidid,oemid,approverComments);
        }
    },
    clearErrors : function(component, event, helper)
    {
     if(component.find('approverComments').get('v.value')!=''||component.find('approverComments').get('v.value')!='undefined'||component.find('approverComments').get('v.value')!=null)
      {
         component.set("v.ApproverCommentsErrorMsg",'');
      }
    },
})
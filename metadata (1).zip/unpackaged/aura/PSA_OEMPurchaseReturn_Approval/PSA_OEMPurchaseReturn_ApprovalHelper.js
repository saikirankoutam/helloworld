({
    returnlistfetch : function(component,event,oemid) {
        var action = component.get("c.fetchreturnrecord");
        action.setParams({ 
            "oempurchaseid" : oemid
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                component.set('v.returnlist',storeResponse); 
            }
        });
        $A.enqueueAction(action);
    },
    approveOEMPurchaseReturn : function(component, event,invoidid,oemid,approverComments) {
        var action = component.get('c.approveoemrecords');
        action.setParams({ 
            "invoiceid" : invoidid,
            "purchaseid" : oemid,
            "remarks" : approverComments
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS" && storeResponse!=null) {
                component.set('v.submitdisable',true);
                component.set('v.remarksdisable',true);
                //component.find('ReturnInvNum').set('v.value',storeResponse.Name);
                //component.find('ReturnInvDate').set('v.value',storeResponse.PSA_Return_Approved_Date__c);
                component.find('approvedBy').set('v.value',storeResponse.PSA_Approved_By__r.Name);
                component.find('approvalStatus').set('v.value',storeResponse.PSA_Approval_Status__c);
                this.Suceestoast(component, event,'OEM Purchase return is Approved.');
            }
            else
            {
               this.ErrorToast(component, event,'The Purchase return could not be approved.Please try after sometime or Contact System administrator!'); 
            }
        });
        $A.enqueueAction(action);
    },
    
    rejectOEMPurchaseReturn : function(component, event,invoidid,oemid,approverComments) {
        var action = component.get("c.rejectOEMRecords");
        action.setParams({ 
            "invoiceid" : invoidid,
            "purchaseid" : oemid,
            "remarks" : approverComments
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                component.set('v.submitdisable',true);
                component.set('v.remarksdisable',true);
                component.find('approvedBy').set('v.value',storeResponse.PSA_Approved_By__r.Name);
                component.find('approvalStatus').set('v.value',storeResponse.PSA_Approval_Status__c);
                this.Suceestoast(component, event,'OEM Purchase return is Rejected.');
            }
        });
        $A.enqueueAction(action);
    },
    Suceestoast : function(component, event, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "Success",
            "message": message
        });
        toastEvent.fire();
    },
        ErrorToast : function(component, event, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "Error",
            "message": message
        });
        toastEvent.fire();
    },
    
 validateMandateFields : function(component, event, helper){
    var isValid = true;
    var varapproverComments=component.find('approverComments').get('v.value');
    component.set("v.ApproverCommentsErrorMsg",'');
    $A.util.removeClass(varapproverComments,"disp-block");
    $A.util.addClass(varapproverComments,"disp-none");
    if(varapproverComments == 'undefined'|| varapproverComments == '' || varapproverComments == null){
      isValid = false;
      component.set("v.ApproverCommentsErrorMsg",'This is a required field');
      $A.util.removeClass(varapproverComments,"disp-none");
      $A.util.addClass(varapproverComments,"disp-block");
     }
return isValid;
},
    
})
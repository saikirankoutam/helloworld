({
    onTabSelect : function(component, event, helper) {
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
      /*  if(['porder', 'wholesale', 'grnreg', 'stock','avail','fund','retail'].includes(id))
            var activate = component.find("vecreport");
        else
            deactivate.push("vecreport");
            */
        
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
        
        
        component.set("v.newMonthlyOrder", false);
        component.set("v.editMonthlyOrder", false);
        component.set("v.newDailyOrder", false);
        component.set("v.editDailyOrder", false);
    },
    
	monthlyOrder : function(component, event, helper) {
		component.set("v.dailyOrder", false);
		component.set("v.monthlyOrder", true);
        var dailyOrder = component.find("dailyOrder");
        $A.util.removeClass(dailyOrder, "active");
        var monthlyOrder = component.find("monthlyOrder");
        $A.util.addClass(monthlyOrder, "active");
        component.set("v.newMonthlyOrder", false);
        component.set("v.editMonthlyOrder", false);
	},
    
    dailyOrder : function(component, event, helper) {
		component.set("v.monthlyOrder", false);
		component.set("v.dailyOrder", true);
        var dailyOrder = component.find("dailyOrder");
        $A.util.addClass(dailyOrder, "active");
        var monthlyOrder = component.find("monthlyOrder");
        $A.util.removeClass(monthlyOrder, "active");
    },
    CreateNewPurchaseOrder : function(component, event, helper) {
    	component.set("v.newMonthlyOrder", true);
    },
    CreateNewDailyOrder : function(component, event, helper) {
    	component.set("v.newDailyOrder", true);
    },
    
    handlemonthlyOrderIdPass : function(component, event, helper) {
        var currentMonthlyOrderId = event.getParam("currentMonthlyOrderId");
        component.set("v.currentMonthlyOrderId", currentMonthlyOrderId);
    	component.set("v.editMonthlyOrder", true);
    },
     handleDailyOrderIdPass : function(component, event, helper) {
        var currentMonthlyOrderId = event.getParam("currentMonthlyOrderId");
        component.set("v.currentMonthlyOrderId", currentMonthlyOrderId);
    	component.set("v.editDailyOrder", true);
    },
    handlevalidateMenu : function(component, event, helper) {
        debugger;
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        var defaultItem = event.getParam("defaultItem");
        console.log("validationItem -- "+validationItem+"::"+defaultItem);
        if (defaultItem) {
        	component.set("v.currTab", validationItem);            
        }
    },
 navigatetodashboard : function(component, event, helper) {
     
     component.set('v.currTab','Dashboard');
 }
})
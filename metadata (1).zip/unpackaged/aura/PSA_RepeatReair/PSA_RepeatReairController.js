({
    doInit : function(component, event, helper) {
        helper.repeatRepairOrderload(component, event);	
    }
})
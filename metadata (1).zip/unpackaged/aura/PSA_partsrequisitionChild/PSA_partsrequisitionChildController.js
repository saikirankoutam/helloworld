({
	 validationCheck : function(component,event,helper){
        var checkbox=component.find('chkbox').get('v.value');
         var isvalid=true;
        if(checkbox){
            var sbins = component.find('quantity').get('v.value');
            component.set("v.quanityerrmsg",'');
            $A.util.removeClass(sbins,"disp-block");
            $A.util.addClass(sbins,"disp-none");
            if(sbins == 'undefined'|| sbins == '' || sbins == null){
                isvalid=false;
                component.set("v.quanityerrmsg",'This is a required field');
                $A.util.removeClass(sbins,"disp-none");
                $A.util.addClass(sbins,"disp-block");
            } 
        }
         return isvalid;
    },
    
    inputchange : function(component,event,helper){
         var part=component.get('v.part');
         var partquanity=part.requiredquantity;
         var req=component.find('quantity').get('v.value');
         var roid = component.get("v.repairordid");
         var partno = component.get("v.part.partnum");
         component.set("v.quanityerrmsg",'');
            $A.util.removeClass(req,"disp-block");
            $A.util.addClass(req,"disp-none");
         if(req>partquanity){
              //component.set("v.quanityerrmsg",'Please enter Requisition Qty less than Required Qty');
                helper.showtoast(component, event,"Requisition Qty should not be greater than Required Qty!");
                $A.util.removeClass(req,"disp-none");
                $A.util.addClass(req,"disp-block");
             component.find('quantity').set('v.value',null);            
         }
         else if(req > 0){
             var action = component.get("c.fetchlitemActualqty");
             action.setParams({
                 "repairorderid" : roid,
                 "partnumber" : partno
             });
             action.setCallback(this, function(response){
                 var state = response.getState();
                 if (state === "SUCCESS") {
                     var totalrequistionval = response.getReturnValue();
                     if(parseInt(totalrequistionval+req) > partquanity){
                         component.find('quantity').set('v.value', '');
                         helper.showtoast(component, event,"Requisition qty should not be greater than part qty!");
                     }
                     
                 }
             });
             $A.enqueueAction(action);
         }
         /*
         if(req<=0){
              //component.set("v.quanityerrmsg",'please enter Requisition Qty. greater than Zero');
                helper.showtoast(component, event,"please enter Requisition Qty greater than Zero!");
                $A.util.removeClass(req,"disp-none");
                $A.util.addClass(req,"disp-block");
             component.find('quantity').set('v.value',null);
             
         }*/
         
     },
    
    checkchange : function(component,event,helper){
        var checkbox=component.find('chkbox').get('v.value');
        if(checkbox){
             component.set('v.disablefields',false);
        }else{
              component.set('v.disablefields',true);
              component.set("v.quanityerrmsg",'');
            component.find('quantity').set('v.value','');
        }
    },
    	preventalphabets : function(component, event, helper){
         var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
        
    }
})
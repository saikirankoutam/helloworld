({
    doInit : function(component,event,helper){
        var status=component.get('v.invoicestatus');
        if(status=='Approved' || status=='Rejected'){
        var NDP = component.get('v.invoicedetailrecord.NDP');
        var CGST = component.get('v.invoicedetailrecord.CGST');
        var SGST = component.get('v.invoicedetailrecord.SGST');
        var req=component.get('v.invoicedetailrecord.returnQuantity');
        var taxableValueVar = NDP*req;
        var totaltaxVar = Math.round((taxableValueVar*(parseInt(CGST)+parseInt(SGST)))/100);
        var totalInvoiceValueVar = taxableValueVar+totaltaxVar;
        component.find('taxableValue').set('v.value',taxableValueVar);
        component.find('totalTax').set('v.value',totaltaxVar);
        component.find('totalInvoiceValue').set('v.value',totalInvoiceValueVar);
        }
        
    },
    checkchange : function(component,event,helper){
        var checkbox=component.find('chkbox').get('v.value');
        if(checkbox){
            component.set('v.disablefields',false);
        }else{
            component.set('v.disablefields',true);
            component.set("v.quanityerrmsg",'');
            component.find('returnQuantity').set('v.value','');
            component.find('taxableValue').set('v.value','');
            component.find('totalTax').set('v.value','');
            component.find('totalInvoiceValue').set('v.value','');
        }
    },
    onChangeReturnQuantity : function(component,event,helper){
        var clearTaxevent=component.getEvent('clearTaxAmount');
        clearTaxevent.fire();
        
        var req=component.find('returnQuantity').get('v.value');
        var invoicedetailrecord=component.get('v.invoicedetailrecord');
        var invoicequanity=invoicedetailrecord.invoiceQuanity;
        component.set("v.quanityerrmsg",'');
        $A.util.removeClass(req,"disp-block");
        $A.util.addClass(req,"disp-none");
        if(req>invoicequanity){
            component.set("v.quanityerrmsg",'Return Qty cannot exceed Invoiced Qty');
            $A.util.removeClass(req,"disp-none");
            $A.util.addClass(req,"disp-block");
            component.find('returnQuantity').set('v.value',null);
            component.find('taxableValue').set('v.value',null);
            component.find('totalTax').set('v.value',null);
            component.find('totalInvoiceValue').set('v.value',null);
        }
          else if(req <= 0){
            component.set("v.quanityerrmsg",'Return Qty should be greater than Zero ');
            $A.util.removeClass(req,"disp-none");
            $A.util.addClass(req,"disp-block");
            component.find('returnQuantity').set('v.value',null);
            component.find('taxableValue').set('v.value',null);
            component.find('totalTax').set('v.value',null);
            component.find('totalInvoiceValue').set('v.value',null);
        }
            else{
                var NDP = component.get('v.invoicedetailrecord.NDP');
                var CGST = component.get('v.invoicedetailrecord.CGST');
                var SGST = component.get('v.invoicedetailrecord.SGST');
                var taxableValueVar = NDP*req;
                var totaltaxVar = Math.round((taxableValueVar*(parseInt(CGST)+parseInt(SGST)))/100);
                var totalInvoiceValueVar = taxableValueVar+totaltaxVar;
                component.find('taxableValue').set('v.value',taxableValueVar);
                component.find('totalTax').set('v.value',totaltaxVar);
                component.find('totalInvoiceValue').set('v.value',totalInvoiceValueVar);
            }
    },
    validationCheck : function(component,event,helper){
        var checkbox=component.find('chkbox').get('v.value');
        var isvalid=true;
        if(checkbox){
            var sbins = component.find('returnQuantity').get('v.value');
            component.set("v.quanityerrmsg",'');
            $A.util.removeClass(sbins,"disp-block");
            $A.util.addClass(sbins,"disp-none");
            if(sbins == 'undefined'|| sbins == '' || sbins == null){
                isvalid=false;
                component.set("v.quanityerrmsg",'This is a required field');
                $A.util.removeClass(sbins,"disp-none");
                $A.util.addClass(sbins,"disp-block");
            } 
        }
        return isvalid;
    },
        preventalphabets : function(component, event, helper){
        var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
    }
    
})
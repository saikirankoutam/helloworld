({
    Doinit : function(component, event, helper) {
        helper.fetchorderitem(component, event);
        helper.getDealerInfo(component, event);
        helper.fetchorder(component, event);
        helper.getOrderInfo(component, event);
        helper.invoiceDetailList(component, event);
        helper.getloginuserInfo(component,event);
    },
    Cancel: function(component, event, helper) {
        helper.listPageHelper(component, event);
    },
       onoemreject:function(component, event, helper){
           debugger;
    var OrderId = component.get("v.orderId");
      var remarks = component.find("remarks").get("v.value");
       component.set("v.remarkserrmsg",'');
        $A.util.removeClass(remarks,"disp-block");
        $A.util.addClass(remarks,"disp-none");
        if(remarks == 'undefined'|| remarks == '' || remarks == null){
            component.set("v.remarkserrmsg",'This is a required field');
            $A.util.removeClass(remarks,"disp-none");
            $A.util.addClass(remarks,"disp-block");
        }else{
        var action = component.get("c.fetchOemApprove");  
        action.setParams({
            "orderid" : component.get("v.orderId"),
            "remarks" : remarks,
             "reviewType" : "Reject"
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {       
                var Message= $A.get("$Label.c.PSA_OEM_Order_Rejected");
                helper.showErrorToast(component,event,Message);               
                var rows = response.getReturnValue();
                 var compEvent = component.getEvent("displayList");
                 compEvent.setParams({"listPage" : false });
                 compEvent.fire();
            }
            
        });
        $A.enqueueAction(action);
            }
    },
        onoemApprove:function(component, event, helper){
        debugger;
       var OrderId = component.get("v.orderId");
        var remarks = component.find("remarks").get("v.value");
            component.set("v.remarkserrmsg",'');
        $A.util.removeClass(remarks,"disp-block");
        $A.util.addClass(remarks,"disp-none");
        if(remarks == 'undefined'|| remarks == '' || remarks == null){
            component.set("v.remarkserrmsg",'This is a required field');
            $A.util.removeClass(remarks,"disp-none");
            $A.util.addClass(remarks,"disp-block");
        }else{
        var action = component.get("c.fetchOemApprove");    
        action.setParams({
            "orderid" : component.get("v.orderId"),
            "remarks" : remarks,
             "reviewType" : "Approve"
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {       
                var Message= $A.get("$Label.c.PSA_OEM_Order_Approved");
                helper.showSuccessToast(component,event,Message);               
                var rows = response.getReturnValue();
                 var compEvent = component.getEvent("displayList");
                 compEvent.setParams({"listPage" : false });
                 compEvent.fire();
            }
            if (state === "ERROR") { 
                
                var Message= 'SAP Server is not available to realese PO';
                helper.showErrorToast(component,event,Message); 
            }
        });
        $A.enqueueAction(action);
        }
    },
   
    Edit: function(component, event, helper) {  
        var ord = component.get("v.orderitemlist");
         var orderid = component.get("v.orderId"); 
        var eventListPage = component.getEvent("displayEditOEMpage");
        eventListPage.setParams({"Id" : orderid , "ordlist1" :ord });
        eventListPage.fire();
    },
    resubmit: function(component, event, helper) {
          var OrderId = component.get("v.orderId");
        
         var action = component.get("c.oemapproval");    
        action.setParams({
            "orderid" : component.get("v.orderId")            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {   
                var Message= $A.get("$Label.c.Local_PO_Resubmit");
                helper.showSuccessToast(component,event,Message);                 
               var rows = response.getReturnValue();
                 var compEvent = component.getEvent("displayListPageOEM");
                 compEvent.setParams({"listPage" : true });
                 compEvent.fire(); 
            }
        });
        $A.enqueueAction(action);

    },
/*    handleNext : function(component, event, helper) { 
        debugger;
        var nextInvoice = component.get("v.nextinvoiceId");       
        var prvINV = component.get("v.previnvoiceId");
        var invoiceList = component.get("v.invoiceDeatilList");
        if(nextInvoice !== null)
        {
            var action = component.get("c.getoeminvoicedetails");
            action.setParams({
                "invoiceId" : nextInvoice
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    console.log('invoiceList in sucess  >>>>'+  JSON.stringify(invoiceList));
                    var storeResponse = response.getReturnValue();
                    component.set("v.InvoicePartsList", storeResponse);
                    component.set("v.Invoice",storeResponse[0]);
                    var totalinvoiceamount = 0;
                    for(var i=0;i<storeResponse.length;i++){
                        totalinvoiceamount +=storeResponse[i].Invoice_Amount__c;
                    }
                    
                    component.set("v.totalinvamount",totalinvoiceamount);
                    
                    for(var i=0;i<invoiceList.length;i++){
                        console.log('invoiceList[i] in sucess  >>>>'+  JSON.stringify(invoiceList[i]));
                        console.log('nextInvoice before for  >>>>'+  nextInvoice);
                        if(nextInvoice === invoiceList[i].Id){
                            if(i !== (invoiceList.length-1) ){
                                console.log('nextInvoice before for  >>>>'+  JSON.stringify(invoiceList[i+1]));
                                console.log('nextInvoice in match for  >>>>'+  nextInvoice);
                                nextInvoice =  invoiceList[i+1].Id;
                                
                            }
                            else{
                                component.set("v.isLastPage", true);
                            }
                            if(i !== 0 ){
                                prvINV =  invoiceList[i-1].Id;
                                component.set("v.isFirstPage", false);
                            }
                            break;
                        }
                    }         
                    console.log('Next Invoice  >>>>'+  nextInvoice);
                    console.log('Previous Invoice  >>>>'+  prvINV);
                    component.set("v.nextinvoiceId",nextInvoice);
                    component.set("v.previnvoiceId",prvINV);
                    
                }
                
            });
            $A.enqueueAction(action);
            component.set("v.showInvoiceList", false);
            component.set("v.showInvoicePartsList", true);
            
        }  
    },
    
    handlePrev : function(component, event, helper) {  
        debugger;
        var nextInvoice = component.get("v.nextinvoiceId");
        var prvINV = component.get("v.previnvoiceId");
        var invoiceList = component.get("v.invoiceDeatilList");
        component.set("v.isFirstPage", true);
        component.set("v.isLastPage", false);
        if(prvINV !== null)
        {
            var action = component.get("c.getoeminvoicedetails");
            action.setParams({
                "invoiceId" : prvINV
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                    component.set("v.InvoicePartsList", storeResponse);
                    component.set("v.Invoice",storeResponse[0]);
                    var totalinvoiceamount = 0;
                    for(var i=0;i<storeResponse.length;i++){
                        totalinvoiceamount +=storeResponse[i].Invoice_Amount__c;
                    }
                    
                    component.set("v.totalinvamount",totalinvoiceamount);
                    component.set("v.nextinvoiceId",prvINV);
                    for(var i=0;i<invoiceList.length;i++){
                        if(prvINV === invoiceList[i].Id){
                            if(i !== (invoiceList.length-1) ){
                                prvINV =  invoiceList[i-1].Id;
                                alert('prvINV'+prvINV);
                            }
                            
                            component.set("v.isFirstPage", true);
                            component.set("v.isLastPage", false);
                            
                            break;
                        }
                    } 
                    
                    component.set("v.previnvoiceId",prvINV);
                }
                
            });
            $A.enqueueAction(action);
            component.set("v.showInvoiceList", false);
            component.set("v.showInvoicePartsList", true);
            
        }  
    }, */
    handleClick: function (component, event, helper) {
        debugger;
        var invoiceId = event.target.id;        
       var invoiceList = component.get("v.invoiceDeatilList");
        component.set("v.showInvoiceList", false);
        component.set("v.showInvoicePartsList", true);
      /*  var nextInvoice;
        var prvINV;
        for(var i=0;i<invoiceList.length;i++){
            if(invoiceId == invoiceList[i].Id){
                if(i != (invoiceList.length-1) ){
                    nextInvoice =  invoiceList[i+1].Id;
                }
                if(i != 0 ){
                    prvINV =  invoiceList[i-1].Id;
                }
            }
        } 
        if(nextInvoice==null){
            component.set("v.isLastPage", true);
            
        }
        if(prvINV==null){
            component.set("v.isFirstPage", true);
            
        }
        component.set("v.previnvoiceId",prvINV);
        component.set("v.invoiceId",invoiceId);
        component.set("v.nextinvoiceId",nextInvoice); */
        var action = component.get('c.getoeminvoicedetails');
        action.setParams({
            "invoiceId" : invoiceId
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log('Parts List >>>>>>'+JSON.stringify(storeResponse));
                component.set("v.InvoicePartsList", storeResponse);
                component.set("v.Invoice",storeResponse[0]);
                var totalinvoiceamount = 0;
                var invoicerec=storeResponse[0];
                var taxamount=invoicerec.PSA_Invoiceid__r.Tax_Amount__c;
               
                var gstamount=taxamount/2;
                component.set('v.CGSTAmount',gstamount);
                component.set('v.SGSTAmount',gstamount);
                for(var i=0;i<storeResponse.length;i++){
                    totalinvoiceamount +=storeResponse[i].Invoice_Amount__c;
                }
                 helper.currencytowordformat(component, event,totalinvoiceamount);
               // component.set("v.totalinvamount",totalinvoiceamount);
                
            }
        });
        
        $A.enqueueAction(action);
        console.log('Next Invoice from Origin >>>>'+  nextInvoice);
        console.log('Previous Invoice  from Origin  >>>>'+  prvINV);       
        
    },
    showInvoiceList: function (component, event, helper) {
        component.set("v.showInvoiceList", true);
        component.set("v.showInvoicePartsList", false);
    },
    
    onTabSelect : function(component, event, helper) {            
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");         
    },
     canceltolistview : function(component, event, helper) { 
         component.getEvent('navigatetooemreviewparts').fire();
     }
})
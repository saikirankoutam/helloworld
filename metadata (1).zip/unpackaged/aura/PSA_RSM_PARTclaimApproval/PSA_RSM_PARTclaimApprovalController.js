({
    Vehiclechanges : function(component, event, helper) {
        component.set('v.submitdiasable',false);
         component.set('v.attachEnable',false);
        var selectedrec=component.get("v.vehiclRecord");
        var claimid=selectedrec.Id;
        if(claimid==null || claimid== '' || claimid== 'undefined'){
            component.find('grnnumber').set('v.value','');
            component.find('Branchcode').set('v.value','');
            component.find('dealercode').set('v.value','');
            component.find('claimnumber').set('v.value','');
            component.find('status').set('v.value','');
            component.find('claimtype').set('v.value','');
            component.find('dealerremarks').set('v.value','');
            component.find('tptname').set('v.value','');
            component.find('invvlaue').set('v.value','');
            component.find('approvedby').set('v.value','');
            component.find('appcomments').set('v.value','');
            component.set('v.submitdiasable',true);
            component.set('v.claimlist',null);
            component.set('v.tablevisible',false); 
            component.set('v.attachurl',''); 
               component.set('v.attachEnable',true);
        }else{
              component.find('status').set('v.value',selectedrec.Approval_Status__c);
            component.set('v.tablevisible',true);  
            helper.claimlistfetch(component, event,claimid);
            helper.fetchdocumenturl(component, event,claimid);
        }
    },
    Approved : function(component, event, helper) {
          
        helper.partclaimsave(component, event,'Approved');
        
    },
    reject : function(component, event, helper) {
     
      helper.partclaimsave(component, event,'Rejected');
        
    },
     viewAttachment : function(component, event, helper) {
        var attachment=component.get('v.attachurl');
        var pdfurl ='../PSA_ViewAttachment?Id='+attachment;
         window.open(pdfurl,"_blank","width=600, height=550"); 
        
    },
   /* refresh : function(component, event, helper) {
        component.find('grnnumber').set('v.value','');
        component.find('Branchcode').set('v.value','');
        component.find('dealercode').set('v.value','');
        component.find('approvedby').set('v.value','');
        component.find('status').set('v.value','');
        component.find('claimnumber').set('v.value','');
        component.find('claimdate').set('v.value','');
        component.find('status').set('v.value','');
        component.set('v.submitdiasable',true);
        var childCmp = component.find("pillclear");
        childCmp.clearpill(); 
        component.set('v.tablevisible',false);   
    } */
    

    
})
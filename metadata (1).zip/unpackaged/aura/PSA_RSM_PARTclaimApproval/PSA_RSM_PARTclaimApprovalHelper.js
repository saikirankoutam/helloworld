({
    claimlistfetch : function(component, event,claimid) {
        var action = component.get("c.fetchclaimrecord");
        action.setParams({ 
            "partclaimid" : claimid
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                component.set('v.claimlist',storeResponse);  
                            }
        });
        $A.enqueueAction(action);
    },
    fetchdocumenturl : function(component, event,claimid) {
        var action = component.get("c.fetchdocumenturl");
        action.setParams({ 
            "partclaimid" : claimid
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                console.log('response.getReturnValue()'+response.getReturnValue());
                component.set('v.attachurl',storeResponse);  
            }
        });
        $A.enqueueAction(action);
    },
    partclaimsave : function(component, event,claimstatus) {
        var comments=component.find('appcomments').get('v.value');
         component.set("v.commentserrmsg",'');
        $A.util.removeClass(comments,"disp-block");
        $A.util.addClass(comments,"disp-none");
        if(comments =='' || comments==null || comments=='undefined'){
            component.set("v.commentserrmsg",'this is required field');
            $A.util.removeClass(comments,"disp-none");
            $A.util.addClass(comments,"disp-block");   
        }else{ 
          
            var selectedrec=component.get("v.vehiclRecord");
            var claimid=selectedrec.Id;
            var claimtype=selectedrec.PSA_Claim_type__c;
            var invid=selectedrec.PSA_Invoice__c;
            var action = component.get("c.updateclaimrecord");
            action.setParams({ 
                "partclaimid" : claimid,
                "invoiceid" :invid,
                "appcomments" : comments,
                "partclaimstatus" :claimstatus,
                "claimtype" :claimtype
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
                  component.set('v.submitdiasable',true);
                if (state === "SUCCESS") {
                    component.find('approvedby').set('v.value',storeResponse.Approved_By__c);
                    component.find('status').set('v.value',storeResponse.Approval_Status__c);
                    var message='part claim request'+ '  '+ claimstatus;
                    var messtype;
                    if(claimstatus=='Approved'){
                        messtype="Success"; 
                    }else{
                        messtype="Error";
                    }
                    this.Successmessage(component, event,message,messtype);
                }
            });
            $A.enqueueAction(action);	
        }
    },
    Successmessage : function(component, event,message,messtype) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": messtype,
            "message": message
        });
        toastEvent.fire();
    },
})
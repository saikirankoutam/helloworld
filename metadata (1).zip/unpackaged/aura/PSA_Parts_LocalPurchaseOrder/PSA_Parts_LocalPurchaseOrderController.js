({
    CreateNewPurchaseOrder : function(component, event, helper) {
        component.set("v.CurrOrderAmount", 0.0);
        component.set("v.gstfinalAmount", 0.0);
        component.set("v.totalincludingTax", 0.0);
        component.set("v.OrderId", undefined);
        component.set("v.newLocalPOrder", true);
        component.set("v.listLocalPOrder", false);
    },
    handledisplayListPage : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.listLocalPOrder", true);
            component.set("v.newLocalPOrder", false);
            
            
        }
    }, 
    handledisplayListLocal : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        var status = event.getParam("CNFStatus");
        if(listPage){
            component.set("v.listLocalPOrder", true);
            component.set("v.newLocalPOrder", false);
            component.set("v.OrderStaus", status);
            
            
        }
    }, 
    handlemonthlyOrderIdPass : function(component, event, helper) {
        var currentMonthlyOrderId = event.getParam("currentMonthlyOrderId");
        var CNFStatus = event.getParam("CNFStatus");
        component.set("v.OrderId", currentMonthlyOrderId);
        component.set("v.OrderStaus", CNFStatus);
        component.set("v.newLocalPOrder", true);
        component.set("v.listLocalPOrder", false);
    },
    posearchOrderLPO : function(component, event, helper) {
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        console.log("" + event.getSource().get("v.value"));
         component.set("v.invoice",pot) ;
        
         if(pot == null || pot == 'undefined' || pot==""){
            var childCmp = component.find("partsreceiptinvoicesId");
            childCmp.getinvoices();
        }
        else{ 
        var orderType = "Parts";
        var action = component.get('c.getOrders');
        action.setParams({
            'orderType' : orderType,
            'ponumber' : pot
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                console.log("Inside "+state);
                component.set("v.orders", records);
              
            }
        });
        $A.enqueueAction(action);
        }
    },
    
    doInit : function(component, event, helper) {
        
    },
    getPartreceiptsCount : function(component, event, helper){
        var receiptscount = event.getParam("Id");
        component.set("v.partSupplierCount",receiptscount);
       
    }
    
})
({
	      showSuccessToast : function(component,event,message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    validateTradeForm:function(component, event, helper){
    debugger;
          var isValid = true;
        var bookingdate=component.get("v.dateord");
       
         var warstdate=component.find("Warstartdate").get("v.value");
        
          var warendate=component.find("Warenddate").get("v.value");
          var exwarstdate=component.find("ExWarstartdate").get("v.value");
          var exwarendate=component.find("ExWarenddate").get("v.value");
          var contname=component.find("ContractName").get("v.value");
          var servicestdate=component.find("Servicestartdate").get("v.value");
          var servicendate=component.find("Serviceenddate").get("v.value");
         component.set("v.wendateerrormsg",'');
        $A.util.removeClass(warendate,"disp-block");
        $A.util.addClass(warendate,"disp-none");
         component.set("v.exwendaterrormsg",'');
        $A.util.removeClass(exwarendate,"disp-block");
        $A.util.addClass(exwarendate,"disp-none");
         component.set("v.servicendaterrormsg",'');
        $A.util.removeClass(servicendate,"disp-block");
        $A.util.addClass(servicendate,"disp-none");
        component.set("v.exwarstartdaterrormsg",'');
        $A.util.removeClass(exwarstdate,"disp-block");
        $A.util.addClass(exwarstdate,"disp-none");
         component.set("v.servicestartdaterrormsg",'');
        $A.util.removeClass(servicestdate,"disp-block");
        $A.util.addClass(servicestdate,"disp-none");
          component.set("v.warstartdaterrormsg",'');
        $A.util.removeClass(warstdate,"disp-block");
        $A.util.addClass(warstdate,"disp-none");
        if(warstdate>warendate){
            component.set("v.wendateerrormsg",'Warranty EndDate should be greater than Warranty StartDate');
            $A.util.removeClass(warendate,"disp-none");
            $A.util.addClass(warendate,"disp-block");
            isValid = false;
            }
         if(exwarstdate>exwarendate){
            component.set("v.exwendaterrormsg",'Extended Warranty EndDate should be greater than Extended Warranty StartDate');
            $A.util.removeClass(exwarendate,"disp-none");
            $A.util.addClass(exwarendate,"disp-block");
            isValid = false;
            }
         if(servicestdate>servicendate){
            component.set("v.servicendaterrormsg",'Service Contract EndDate should be greater than Service Contract StartDate');
            $A.util.removeClass(servicendate,"disp-none");
            $A.util.addClass(servicendate,"disp-block");
            isValid = false;
            }
         if((warstdate>exwarstdate)|| (warendate>exwarstdate)){
            component.set("v.exwarstartdaterrormsg",'Extended Warranty StartDate should be greater than  date of Warranty ');
            $A.util.removeClass(servicestdate,"disp-none");
            $A.util.addClass(servicestdate,"disp-block");
            isValid = false;
            }
         /*if(exwarstdate>servicestdate){
            component.set("v.servicestartdaterrormsg",'Service Contract startDate should be greater than Extended Warranty StartDate');
            $A.util.removeClass(exwarstdate,"disp-none");
            $A.util.addClass(exwarstdate,"disp-block");
            isValid = false;
            }*/
          if(bookingdate>warstdate){
            component.set("v.warstartdaterrormsg",'Warranty startDate should be greater than Booking Date');
            $A.util.removeClass(warstdate,"disp-none");
            $A.util.addClass(warstdate,"disp-block");
            isValid = false;
            }
        if(bookingdate>servicestdate){
            component.set("v.servicestartdaterrormsg",'Service Contract startDate should be greater than Booking Date');
            $A.util.removeClass(servicestdate,"disp-none");
            $A.util.addClass(servicestdate,"disp-block");
            isValid = false;
            }
         return isValid;
       },
         Servicedetail:function(component,event, helper){
            var Ordid=component.get("v.orderId");  
         var action = component.get("c.fetchServiceinInfo");
         action.setParams({
             "Orderid": Ordid,   
         });
        action.setCallback(this, function (response) {
            var state = response.getState();
              if (state === "SUCCESS") {    
            var storeResponse = response.getReturnValue(); 
                 
            if(storeResponse==null||storeResponse==''||storeResponse=='undefined')
            {
              component.set("v.disableFields",false);  
            }
            var wstdate = storeResponse.PSA_Warranty_Start_Date__c;
            var wendate = storeResponse.PSA_Warranty_End_Date__c;
            var exwstdate = storeResponse.PSA_Extended_Warranty_Start_date__c;
            var exwendate = storeResponse.PSA_Extended_Warranty_End_date__c;
            var cstdate = storeResponse.StartDate;
            var cendate = storeResponse.EndDate;
            var name = storeResponse.Name;
                    var exwarName = storeResponse.PSA_Extended_Warranty_Name__c;
                    var exwarendmileage = storeResponse.PSA_Extended_Warranty_End_Mileage__c;
                    var servendmileage = storeResponse.PSA_Service_Contract_End_Mileage__c;
                  component.set("v.Warstartdate",wstdate);
                  component.set("v.Warenddate",wendate);
                  component.set("v.ExWarstartdate",exwstdate);
                  component.set("v.ExWarenddate",exwendate);
                  component.set("v.ContractName",name);
                  component.set("v.Servicestartdate",cstdate);
                  component.set("v.Serviceenddate",cendate); 
                  
                  component.set("v.exwarName",exwarName);
                  component.set("v.exwarendmileage",exwarendmileage);
                  component.set("v.servendmileage",servendmileage);
                  component.set("v.disableSave",true);
                  
            }
        });
        $A.enqueueAction(action);  
    },
    checkBookingStatus : function(component, event){
    debugger;
         var bookingid=component.get("v.orderId");
         var action = component.get("c.checkBookingStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
       action.setCallback(this, function (response) {
            var state = response.getState();
              if (state === "SUCCESS")   
            {
                 var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.disableEdit",true);
                component.set("v.disableSave",true);
                }
            }
        });
        $A.enqueueAction(action);	    
	 
},
    checkVDNStatus : function(component, event){
    debugger;
         var bookingid=component.get("v.orderId");
         var action = component.get("c.checkVDNStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
       action.setCallback(this, function (response) {
            var state = response.getState();
              if (state === "SUCCESS")   
            {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.disableEdit",true);
                component.set("v.disableSave",true);
                }
            }
        });
        $A.enqueueAction(action);	    
	 
}
 })
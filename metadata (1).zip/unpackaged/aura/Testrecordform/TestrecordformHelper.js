({
	 showSuccessToast : function(component, event, helper){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": "Customer Successfully created",
            "type": "success"
        });
        toastEvent.fire();  
    },
})
({
    
    doInit: function(component, event, helper) {
          var action = component.get("c.loadacc");
        action.setCallback(this, function(response) {
        component.set("v.accrecId", response.getReturnValue());
           
     // alert('recrdtypeid'+test);
       });
      $A.enqueueAction(action);
     },  
     onCreditLimit: function(component, event, helper){
         debugger;
		 var selected = event.getSource().get("v.label");
          component.set("v.credLimit",selected);
		},
    
       handleSave: function(component, event, helper) {
        
      //  if(helper.validateVendorForm(component)) 
            
            var custSeg = component.find("CustSeg").get("v.value");
            var custId = component.find("custId").get("v.value");
            var fname = component.find("Fname").get("v.value");
            var lName = component.find("Lname").get("v.value");
            var gender = component.find("gender").get("v.value");
            var occupation = component.find("occ").get("v.value");
            var institution = component.find("institute").get("v.value");
            var organisation = component.find("org").get("v.value");
            var gst = component.find("gst").get("v.value");
            var uin = component.find("uin").get("v.value");
            var pan = component.find("pan").get("v.value");
            var addr1 = component.find("addressline1").get("v.value");
            var addr2 = component.find("addressline2").get("v.value");
            var district = component.find("city").get("v.value");
            var state = component.find("state").get("v.value");
            var country = component.find("country").get("v.value");
            var pincode = component.find("pin").get("v.value");
            var phone = component.find("phno").get("v.value");
            var alternateph = component.find("altphno").get("v.value");
            var actstatus = component.find("activestatus").get("v.value");
        	var crdLimit = component.get("v.credLimit");  
    		var email = component.find("email").get("v.value");
           var creditlimit = component.find("limit").get("v.value");
            var recId=component.get("v.accrecId");
            var action = component.get("c.CreateCustomer"); 
            action.setParams({
                "Seg"   	: custSeg,
                "CustId"    : custId,
                "Fname" 	:fname,
                "Lname" 	:lName,
                "gender"    :gender,
                "occupation":occupation,
                "institue"  :institution,
                "org"      	:organisation,
                "gst" 		: gst,
                "uin" 		: uin,
                "Pan"	    : pan,
                "Addr1"  	: addr1,
                "Addr2"     : addr2,
                "City"  	: district,
                "State"  	: state,
                "Country"   : country,
                "Pin"  		: pincode,
                "Phone"     : phone,
                 "AltPhone" : alternateph,
                "Email"     : email,
                "yesno"  	: crdLimit,
                "Credit"	:creditlimit,
                "RectypeId" : recId,
                "activestatus" :actstatus,
                
            });
            action.setCallback(this, function(response) {
                var state=response.getState();
                console.log('save status  >>>>'+state);
                if(state  === "SUCCESS"){
                   // var Message= $A.get("$Label.c.Vendor_Creation");
                    helper.showSuccessToast(component, event, helper);                   
                    
                   // var eventListPage = component.getEvent("displayListPageVendors");
                    //eventListPage.setParams({"listPage" : true });
                    //eventListPage.fire();
                }
                if(state  === "ERROR"){
                    var toast = $A.get("e.force:showToast");
                    if(toast){
                        toast.setParams({
                            "title": "Error",
                            "message": result.getError()[0].message
                        });
                    }
                    toast.fire();
                } 
                
            });
            $A.enqueueAction(action); 
        
    }
    
    
    
    
    
    
    
    })
({
	doInit : function(component, event, helper) {
        var action = component.get('c.getAccountRegion');
		action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();            
                component.set("v.accountRegion", records);
            }
        });
        $A.enqueueAction(action);
	},
    
    	getStatesList : function(component, event, helper) {
        var region = component.find("regionName").get("v.value");
        var action = component.get("c.getAccountBillingState");
        action.setParams({ 
            "region" : region
        });
		action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();            
                component.set("v.accountStates", records);
            }
        });
        $A.enqueueAction(action);
	},
        getCitiesList : function(component, event, helper) {
        var region = component.find("regionName").get("v.value");
        var state = component.find("stateName").get("v.value");  
        var action = component.get("c.getAccountBillingCity");
        action.setParams({ 
            "region" : region,
            "state"  : state
        });
		action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();            
                component.set("v.accountCities", records);
            }
        });
        $A.enqueueAction(action);
	}
})
({
	getDealerInfo : function(component, event){
        var action = component.get("c.fetchDealerInfo");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log('dealer Info >>>>'+JSON.stringify(storeResponse));
                component.set("v.dealerInfo", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    validateRequired: function(component, event) {
        debugger;
        var isvalid=true;
        var selectedrec=component.get("v.vehicleid");
  
      //  var vehicleid=selectedrec.Id;
        if(selectedrec == 'undefined'|| selectedrec == '' || selectedrec == null){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error",
                "message": "please select invoice number",
                "type": "Error"
            });
            toastEvent.fire();
            isValid = false;
            
        }
        return isvalid;   
    },
    saverequest: function(component, event) {
        debugger; 
       // var selectedrec=component.get("v.vehicleid");
       var vehicleid=component.get("v.vehicleid");
         var invoicevalue=component.get("v.Invoicevalue");
        var action = component.get('c.updateinventory');
        action.setParams({
            "vehcleid": vehicleid,
            "invoicevalue":invoicevalue
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                component.set("v.vehiclRecord",storeResponse);
                component.set("v.submitinvisable",true);
                var Message= 'GRN Cancelled. Inventory updated';
                this.showSuccessToast(component,event,Message);
            }
            else{
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Failed!",
                    "message": "The GRN could not be cancelled.Please try after sometime or Contact System administrator!",
                    "type": "failed"
                });
                toastEvent.fire();
            }
            
        });
        $A.enqueueAction(action);    
    },
      showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
})
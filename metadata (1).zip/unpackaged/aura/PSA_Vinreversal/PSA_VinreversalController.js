({
    doInit: function(component, event, helper) {
        helper.getDealerInfo(component, event);
    },
    Vehiclechanges : function(component, event, helper) {
        var selectedrec=component.get("v.vehiclRecord");
        var ordernumver=selectedrec.PSA_Invoice_number__c;
        var status=selectedrec.PSA_Request_Status__c;
        if(ordernumver == 'undefined' || ordernumver =='' || ordernumver == null) 
        {    
            component.set("v.Invoicevalue",'');
            component.set('v.tax1','');
            component.set('v.tax2','');
            component.set('v.tax3','');
            component.set('v.igstamount','');
            component.find('vinnumber').set('v.value','');
            component.find('invdate').set('v.value','');
            component.find('rdate').set('v.value','');
            component.find('returnstatus').set('v.value','');
            component.find('Dname').set('v.value','');
            component.find('dcode').set('v.value','');
             component.find('dlocation').set('v.value','');
             component.set("v.submitinvisable",false);
            
            
        }else{
            var dealerlocation=selectedrec.Sales_Order__r.PSA_Order__r.Account.BillingCity;
            var Branchcode=selectedrec.Sales_Order__r.PSA_Order__r.Account.PSA_Branch_Code__c;
            var branchlocation=selectedrec.Sales_Order__r.PSA_Order__r.Account.BillingCity;
            var tax=selectedrec.Sales_Order__r.PSA_Order_Item__r.PSA_CGST__c;
            var tax1=5;
            var tax2=5;
            var tax3=tax1+tax2;
            var igstamount=tax+tax;
            var netdelarprice=selectedrec.Sales_Order__r.PSA_Order_Item__r.UnitPrice;
            var invoicevalue=tax+netdelarprice+tax;
            
            component.set('v.tax1',tax1);
            component.set('v.tax2',tax2);
            component.set('v.tax3',tax3);
            component.set('v.igstamount',igstamount);
            component.set("v.Invoicevalue",invoicevalue);
            if(status=='Completed'){
                component.set("v.submitinvisable",true);
            }else{
                component.set("v.submitinvisable",false);
                
            }
        }
    },
    Save : function(component, event, helper) {
        if (helper.validateRequired(component, event)) {
            helper.saverequest(component,event)
        }  
    },
     Cancel : function(component, event, helper) {
         var navigation=component.getEvent('navigatetodashboard');
         navigation.fire();  
     }
})
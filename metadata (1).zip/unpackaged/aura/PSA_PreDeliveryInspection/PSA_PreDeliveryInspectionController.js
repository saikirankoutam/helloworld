({
    
     doInit: function(component, event, helper) 
    {
        
      var action = component.get("c.getPDIcheckVdn");
       var bookingid=component.get("v.bookingorderid");
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var orderno=value;
                //var vdnstatusdis=value.PSA_VDN_check__c;
              component.set("v.savedis",orderno);
                 }
             var satus=component.get("v.savedis");
        if(satus==true){
            component.find("123button").set("v.disabled",true);
            component.set("v.disablePrint",true);
        }
      helper.getpredeliveryInspection(component, event, helper);
        });
      $A.enqueueAction(action);
        helper.checkBookingStatus(component, event, helper);	
	     helper.getRegDetails(component, event, helper);	
        /* var satus=component.get("v.savedis");
               if(satus==true){
            component.find("123button").set("v.disabled",true);
        }*/
		
	},
 
    handleSave: function(component, event, helper) {
        debugger;
        var reqidstatus=component.get("v.preReq");
       if(reqidstatus==null || reqidstatus=='' || reqidstatus=="undefined")
       {
          if(helper.validateRequestForm(component, event, helper)) { 
        var reqStatus = component.find("status").get("v.value");
        // var deliveryDt = component.find("delvryDt").get("v.value");
         var requestDt = component.find("reqDt").get("v.value");
        // var revisedDt = component.find("revDt").get("v.value");
         var dueDate = component.find("dueDt").get("v.value");
         var remarks = component.find("rmks").get("v.value");
         var assigned = component.find("assgnTo").get("v.value");
         var bookingid=component.get("v.bookingorderid");
         var action = component.get("c.CreatePDIRequest");
              
               action.setParams({
                   "Status"   	: reqStatus,
                  // "Delivery" 	: deliveryDt,
                   "Request"	: requestDt,
                   //"Revised"	: revisedDt,
                   "DueDt"		: dueDate,
                   "Remark"		: remarks,
                   "AssignTo"	: assigned,
                   "booknum"	: bookingid,
                    
               });
               action.setCallback(this, function(response) {
                   var result=response.getState();
                   console.log('save status  >>>>'+result);
                   if(result  === "SUCCESS"){
                       var reqNo = response.getReturnValue();
                      component.set("v.disablePrint",false);
                           if(reqNo=='' || reqNo==null || reqNo=='undefined'){
                               helper.showErrorToast(component, event, helper);
                               
                           }else{ 
                               helper.showSuccessToast(component, event, helper);
                               component.set("v.PDIreqId",reqNo);
                               component.set("v.disable",true);
                               component.find("123button").set("v.disabled",true);
                           }
                       
                          
                   }

                
            });
               $A.enqueueAction(action); 
               
           }
       
        else{
           
        }
       }
        else{
            
            helper.updatepreinspectionList(component, event, helper);
        }   
    },
     predeliveryInspectionpdf :  function(component, event, helper) {
         debugger;
        var bookingid=component.get("v.bookingorderid");
        
         var action = component.get("c.getpdiId");
         action.setParams({
                "booknum" :bookingid
            });
        
          action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                var pdiId=storeResponse.Id;
                alert(pdiId);
                //component.set("v.pdiRequest",pdiId);
                 var pdfurl ='../PSA_PDIpdf?id='+pdiId;
        window.open(pdfurl,"_blank", "width=600, height=550");
            }
           
                     });
               $A.enqueueAction(action);  
    },
    
    predeliverypdf :  function(component, event, helper) {  
         var bookingid=component.get("v.bookingorderid");
          var pdfurl ='../CitroenPDIrequestPDF?id='+bookingid;
        window.open(pdfurl,"_blank", "width=600, height=550");
    },
    preventalphabets : function(component, event, helper){
        var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
    }
        
        
    
})
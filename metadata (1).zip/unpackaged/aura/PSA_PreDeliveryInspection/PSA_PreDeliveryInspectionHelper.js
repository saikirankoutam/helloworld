({
    
    getpredeliveryInspection: function(component, event, helper){
       
        var bookingid=component.get("v.bookingorderid");
         var action = component.get("c.getpredevileryInspectionlist");
         action.setParams({
                "booknum" :bookingid
            });
        
          action.setCallback(this, function(response){
            var state = response.getState();
              
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                
                debugger;
                if(storeResponse.length >= 1)
                {
                   
                var reqnum=storeResponse[0].PSA_PDI_Request_Id__c;
                component.set("v.preReq",reqnum);
                var reqStatus = storeResponse[0].PSA_PDI_Status__c;
                var deliveryDt = storeResponse[0].PSA_Planned_Delivery_Date__c;
                var requestDt = storeResponse[0].PSA_Planned_Request_Date__c;
                var revisedDt = storeResponse[0].PSA_Revised_Delivery_Date__c;
                var dueDate = storeResponse[0].PSA_PDI_Due_Date__c;
                var remarks = storeResponse[0].PSA_Remarks__c;
                var assigned = storeResponse[0].PSA_Assigned_To__c;
                    component.set("v.PDIreqId",reqnum);
                    component.set("v.status",reqStatus);
                    //component.set("v.plannedDt",deliveryDt);
                    component.set("v.plannedReqDt",requestDt);
                  //  component.set("v.revDelDt",revisedDt);
                    component.set("v.duepdiDt",dueDate);
                    component.set("v.remark",remarks);
                    component.set("v.assign",assigned);
                    component.set("v.disablePrint",false);
                }
				else
                {
                     component.set("v.disablePrint",true);
                    component.set("v.PDIreqId","");
                    component.set("v.status","");
                   // component.set("v.plannedDt","");
                    component.set("v.plannedReqDt","");
                   // component.set("v.revDelDt","");
                    component.set("v.duepdiDt","");
                    component.set("v.remark","");
                    component.set("v.assign","");
                    
                }
                
                
               }
        });
        $A.enqueueAction(action);
    },

	 showSuccessToast : function(component, event, helper){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": "Request Successfully created",
            "type": "success"
        });
        toastEvent.fire();  
    },
     showErrorToast : function(component, event, helper){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": "Request not created",
            "type": "error"
        });
        toastEvent.fire();  
    },
    
    updatepreinspectionList:function(component, event, helper)
    { 
        debugger;
        if(this.validateRequestForm(component, event, helper)) { 
         var reqidstatus=component.get("v.preReq");
        
         var reqStatus = component.find("status").get("v.value");
       //  var deliveryDt = component.find("delvryDt").get("v.value");
         var requestDt = component.find("reqDt").get("v.value");
       //  var revisedDt = component.find("revDt").get("v.value");
         var dueDate = component.find("dueDt").get("v.value");
         var remarks = component.find("rmks").get("v.value");
         var assigned = component.find("assgnTo").get("v.value");
         var bookingid=component.get("v.bookingorderid");
         var action = component.get("c.updateinspection"); 
               action.setParams({
                   "Status"   	: reqStatus,
                  // "Delivery" 	: deliveryDt,
                   "Request"	: requestDt,
                  // "Revised"	: revisedDt,
                   "DueDt"		: dueDate,
                   "Remark"		: remarks,
                   "AssignTo"	: assigned,
                   "reqid"		:reqidstatus,
                   "booknum"	:bookingid,
                    
               });
               action.setCallback(this, function(response) {
                   var result=response.getState();
                   console.log('save status  >>>>'+result);
                   if(result  === "SUCCESS"){
                         this.showSuccessToast(component, event, helper);
                         component.find("123button").set("v.disabled",true);
                       
                           }
                   
                   
                     });
               $A.enqueueAction(action); 
    }
               
           },
    
    

     validateRequestForm : function(component, event)
    {
        debugger;
        var isValid = true;
        var reqStatus = component.find("status").get("v.value");
       // var deliveryDt = component.find("delvryDt").get("v.value");
        var requestDt = component.find("reqDt").get("v.value");
      //  var revisedDt = component.find("revDt").get("v.value");
        var dueDate = component.find("dueDt").get("v.value");
       // var remarks = component.find("rmks").get("v.value");
       // var assigned = component.find("assgnTo").get("v.value");
        component.set("v.statusErrorMsg",'');
        $A.util.removeClass(reqStatus,"disp-block");
        $A.util.addClass(reqStatus,"disp-none");
        component.set("v.requestErrorMsg",'');
        $A.util.removeClass(requestDt,"disp-block");
        $A.util.addClass(requestDt,"disp-none");
         component.set("v.dueErrorMsg",'');
        $A.util.removeClass(dueDate,"disp-block");
        $A.util.addClass(dueDate,"disp-none");
        /* component.set("v.revisedErrorMsg",'');
        $A.util.removeClass(revisedDt,"disp-block");
        $A.util.addClass(revisedDt,"disp-none");
         */
        /* component.set("v.marksErrorMsg",'');
        $A.util.removeClass(remarks,"disp-block");
        $A.util.addClass(remarks,"disp-none");*/
        /* component.set("v.assignedtoErrorMsg",'');
        $A.util.removeClass(assigned,"disp-block");
        $A.util.addClass(assigned,"disp-none");*/
        
        /* if(deliveryDt == 'undefined'|| deliveryDt == '' || deliveryDt == null){
            isValid = false;
            component.set("v.plannedErrorMsg",'This is a required field');
            $A.util.removeClass(deliveryDt,"disp-none");
            $A.util.addClass(deliveryDt,"disp-block");
        }
         */
         if(reqStatus == 'undefined'|| reqStatus == '' || reqStatus == null || reqStatus =="--None--"){
            isValid = false;
            component.set("v.statusErrorMsg",'This is a required field');
            $A.util.removeClass(reqStatus,"disp-none");
            $A.util.addClass(reqStatus,"disp-block");
        }
 		if(requestDt == 'undefined'|| requestDt == '' || requestDt == null){
            isValid = false;
            component.set("v.requestErrorMsg",'This is a required field');
            $A.util.removeClass(requestDt,"disp-none");
            $A.util.addClass(requestDt,"disp-block");
        }
        if(dueDate == 'undefined'|| dueDate == '' || dueDate == null){
            isValid = false;
            component.set("v.dueErrorMsg",'This is a required field');
            $A.util.removeClass(dueDate,"disp-none");
            $A.util.addClass(dueDate,"disp-block");
        }
       /* if(remarks == 'undefined'|| remarks == '' || remarks == null){
            isValid = false;
            component.set("v.marksErrorMsg",'This is a required field');
            $A.util.removeClass(remarks,"disp-none");
            $A.util.addClass(remarks,"disp-block");
        }*/
        /*if(assigned == 'undefined'|| assigned == '' || assigned == null){
            isValid = false;
            component.set("v.assignedtoErrorMsg",'This is a required field');
            $A.util.removeClass(assigned,"disp-none");
            $A.util.addClass(assigned,"disp-block");
        }*/
        return isValid;
    },
    
    predeliveryreqId: function(component, event)
    {
        var bookingid=component.get("v.bookingorderid");
        
         var action = component.get("c.getpdiId");
         action.setParams({
                "booknum" :bookingid
            });
        
          action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                var pdiId=storeResponse.Id;
                
                component.set("v.pdiRequest",pdiId);
                
            }
           
                     });
               $A.enqueueAction(action);    
    },
    checkBookingStatus : function(component, event){
    debugger;
         var bookingid=component.get("v.bookingorderid");
         var action = component.get("c.checkDeliveryStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.disablePrint",true);
                component.set("v.disableSave",true);
                }
            }
        });
        $A.enqueueAction(action);	    
	 
},
getRegDetails : function(component, event){
    debugger;
         var bookingid=component.get("v.bookingorderid");
         var action = component.get("c.getregistration");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
           if (state == "SUCCESS") 
            {
                var value = response.getReturnValue();
                
                component.set("v.plannedDt",value[0].PSA_PlannedDelivery__c);
                component.set("v.revDelDt",value[0].PSA_RevisedDate__c);
              
            }
        });
        $A.enqueueAction(action);	    
	 
},
})
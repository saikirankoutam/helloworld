({
    recordChanges : function(component, event, helper) {
        var selectedrec=component.get("v.selectedLookUpRecord");
        var dealername=selectedrec.Name;
        var dealerlocation=selectedrec.BillingCity;
        var Branchcode=selectedrec.PSA_Branch_Code__c;
        var branchlocation=selectedrec.BillingCity;
        var dealid=selectedrec.Id;
        if(dealername =='undefined' || dealername =='' || dealername == null) 
        {   
            component.set("v.dealername",true);
            component.set("v.dealername1",false);
            component.set("v.invoice",false);
            component.set("v.dealercode",true);
            component.set("v.dealercode1",false);
            component.set("v.dealerdnonependency",true);
            component.set("v.dealerlocation",'');
            component.set("v.Branchcode",'');
            component.set("v.Branchlocation",'');
            component.set("v.Delarid",'');
            component.set("v.Invoicevalue",'');
            component.set("v.vehiclRecord",'');
        }else{
            component.set("v.dealername",true);
            component.set("v.dealername1",false);
            component.set("v.invoice",false);
            component.set("v.dealercode",false);
            component.set("v.dealercode1",true);
            component.set("v.dealerdnonependency",false);
            component.set("v.dealerlocation",dealerlocation);
            component.set("v.Branchcode",Branchcode);
            component.set("v.Branchlocation",branchlocation);
            component.set("v.Delarid",dealid);
            
        }
    },
    delaercodeChanges : function(component, event, helper) {
        var selectedrec=component.get("v.selectedLookUpRecordcode");
        var dealername=selectedrec.Name;
        var dealerlocation=selectedrec.BillingCity;
        var Branchcode=selectedrec.PSA_Branch_Code__c;
        var branchlocation=selectedrec.BillingCity;
        var dealid=selectedrec.Id;
        if(dealername =='undefined' || dealername =='' || dealername == null) 
        {   
            component.set("v.dealername",true);
            component.set("v.dealername1",false);
            component.set("v.invoice",false);
            component.set("v.dealercode",true);
            component.set("v.dealercode1",false);
            component.set("v.dealerdnonependency",true);
            component.set("v.dealerlocation",'');
            component.set("v.Branchcode",'');
            component.set("v.Branchlocation",'');
            component.set("v.Delarid",'');
            component.set("v.Invoicevalue",'');
            component.set("v.vehiclRecord",'');
        }else{
            component.set("v.dealername",false);
            component.set("v.dealername1",true);
            component.set("v.invoice",false);
            component.set("v.dealercode",true);
            component.set("v.dealercode1",false);
            component.set("v.dealerdnonependency",false);
            component.set("v.dealerlocation",dealerlocation);
            component.set("v.Branchcode",Branchcode);
            component.set("v.Branchlocation",branchlocation);
            component.set("v.Delarid",dealid);
            
        }
    },
    Vehiclechanges : function(component, event, helper) {
        var selectedrec=component.get("v.selectedvehiclRecord");
        var ordernumver=selectedrec.PSA_Invoice_number__c;
        if(ordernumver == 'undefined' || ordernumver =='' || ordernumver == null) 
        {   
            component.set("v.dealername",true);
            component.set("v.dealername1",false);
            component.set("v.invoice",false);
            component.set("v.dealercode",true);
            component.set("v.dealercode1",false);
            component.set("v.dealerlocation",'');
            component.set("v.Branchcode",'');
            component.set("v.Branchlocation",'');
            component.set("v.Invoicevalue",'');
            component.set("v.vehiclRecord",'');
            component.find('sonumber').set('v.value','Sundar');
        }else{
            var dealerlocation=selectedrec.Sales_Order__r.PSA_Order__r.Account.BillingCity;
            var Branchcode=selectedrec.Sales_Order__r.PSA_Order__r.Account.PSA_Branch_Code__c;
            var branchlocation=selectedrec.Sales_Order__r.PSA_Order__r.Account.BillingCity;
            var tax=selectedrec.Sales_Order__r.PSA_Order_Item__r.PSA_CGST__c;
            var netdelarprice=selectedrec.Sales_Order__r.PSA_Order_Item__r.UnitPrice;
            var invoicevalue=tax+netdelarprice;
            component.set("v.vehiclRecord",selectedrec);
            component.set("v.dealername",false);
            component.set("v.dealername1",false);
            component.set("v.invoice",true);
            component.set("v.dealercode",false);
            component.set("v.dealercode1",false);
            component.set("v.dealerlocation",dealerlocation);
            component.set("v.Branchcode",Branchcode);
            component.set("v.Branchlocation",branchlocation);
            component.set("v.Invoicevalue",invoicevalue);
            
        }
        
    },
    Vehiclechanges1 : function(component, event, helper) {
        var selectedrec=component.get("v.selectedvehiclRecord1");
        var ordernumver=selectedrec.PSA_Invoice_number__c;
        if(ordernumver == 'undefined' || ordernumver =='' || ordernumver == null) 
        {   
            component.set("v.dealerlocation",'');
            component.set("v.Branchcode",'');
            component.set("v.Branchlocation",'');
            component.set("v.Invoicevalue",'');
            component.set("v.vehiclRecord",'');
             
          
        }else{
            var dealerlocation=selectedrec.Sales_Order__r.PSA_Order__r.Account.BillingCity;
            var Branchcode=selectedrec.Sales_Order__r.PSA_Order__r.Account.PSA_Branch_Code__c;
            var branchlocation=selectedrec.Sales_Order__r.PSA_Order__r.Account.BillingCity;
            var tax=selectedrec.Sales_Order__r.PSA_Order_Item__r.PSA_CGST__c;
            var netdelarprice=selectedrec.Sales_Order__r.PSA_Order_Item__r.UnitPrice;
            var invoicevalue=tax+netdelarprice;
            component.set("v.vehiclRecord",selectedrec);
            component.set("v.dealerlocation",dealerlocation);
            component.set("v.Branchcode",Branchcode);
            component.set("v.Branchlocation",branchlocation);
            component.set("v.Invoicevalue",invoicevalue);
            
        }
        
    },
    Save : function(component, event, helper) {
        if (helper.validateRequired(component, event)) {
            helper.saverequest(component,event)
        }  
    }
})
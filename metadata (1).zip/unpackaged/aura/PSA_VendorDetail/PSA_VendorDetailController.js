({
    editRecordHandler : function(component, event, helper) {
	component.set("v.curView", "editView");
    },
    
    cancelRecord : function(component, event, helper){
    
        var eventListPage = component.getEvent("displayListPageVendorsView");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
    onRecordUpdated : function(component) {
    setTimeout($A.getCallback(function () { 
        console.log('reloaded');
        component.find("recordLoader").reloadRecord(true);
                                       
    })); 
},
})
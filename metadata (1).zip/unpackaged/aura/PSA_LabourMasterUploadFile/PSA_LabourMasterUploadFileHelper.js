({
     MAX_FILE_SIZE: 4500000, //Max file size 4.5 MB 
     CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
    
	    uploadHelper: function(component, event) {
   
        var fileInput = component.find("fuploader").get("v.files");
        var file = fileInput[0];
        var self = this;
       if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }
        
        var objFileReader = new FileReader();
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
            self.uploadProcess(component, file, fileContents);
        });
        
        objFileReader.readAsDataURL(file);
    },
        errorToast : function(component, event, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": message
        });
        toastEvent.fire();
    },
    showSuccessToast : function(component, event, message) {
    var toastEvent = $A.get("e.force:showToast");
    toastEvent.setParams({
        "type": "Success",
         "message": message
    });
    toastEvent.fire();
    },
    uploadProcess: function(component, file, fileContents) {
        var startPosition = 0;
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
        uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        debugger;
        var getchunk = fileContents.substring(startPosition, endPosition);
        //var selectyr = component.set("v.yearFile");
       //  var selectyr = '2019';
        var action = component.get("c.saveLabourMasterFile");
        action.setParams({
            parentId: component.get("v.parentId"),
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId,
        });
        
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            var isvalid = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS" && isvalid === "Uploaded Successfully") {
                     var message='File Uploaded Successfully';
                    this.showSuccessToast(component, event, message);
                var eventListPage = component.getEvent("cancelObjFileUpload");
                eventListPage.setParams({"listpage" : false,"CNFStatus" : "uploaded"});
                eventListPage.fire();
                var fileName = 'No File Selected..';
         		component.set("v.fileName", fileName);
        		component.set("v.errorMessage","");
               // component.set("v.showError",true);
               // component.set("v.errorMessage",isvalid);
                
            }
           else if (state === "SUCCESS" && isvalid == "No Data") {
             
                // component.set("v.showError",true);
               // component.set("v.errorMessage",isvalid);
              var message='No Data in the Uploaded File';
          this.errorToast(component, event, message);
                var eventListPage = component.getEvent("cancelObjFileUpload");
                eventListPage.setParams({"listpage" : false,"CNFStatus" : "uploaded"});
                eventListPage.fire();
                var fileName = 'No File Selected..';
         		component.set("v.fileName", fileName);
        		component.set("v.errorMessage","");
         }
           else if (state === "INCOMPLETE") {
                alert("From server: " + response.getReturnValue());
            } else if (state === "ERROR") {
                var errors = response.getError();
                component.set("v.showError",true);
                component.set("v.errorMessage",errors[0].message);
            } 
        });
        // enqueue the action
        $A.enqueueAction(action);
    }
})
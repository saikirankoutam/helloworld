({
        doInit : function(component, event, helper) {
    },
 	    handleFilesChange: function(component, event, helper) {
        var fileName = 'No File Selected..';
        fileName = event.getSource().get("v.files")[0]['name'];   
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
         if(ext == "csv" || ext == "CSV") {
            component.set("v.fileName", fileName);
            component.set("v.showSavebtn",false);
         }else{
             helper.errorToast(component, event, 'Upload only CSV file');
              component.set("v.showSavebtn",true);
              component.set("v.fileName", fileName);    
         }
    },
        handleCancel: function(component, event, helper) {
         var fileName = 'No File Selected..';
         component.set("v.fileName", fileName);
        component.set("v.errorMessage","");
        var eventListPage = component.getEvent("cancelObjFileUpload");
        eventListPage.setParams({"listpage" : false});
        eventListPage.fire();
    },
        handleSave: function(component, event, helper) {
        component.set("v.errorMessage",'');
        if (component.find("fuploader").get("v.files").length > 0) {
             component.set("v.showSavebtn",true);
            helper.uploadHelper(component, event);
        } else {
            alert('Please Select a Valid File');
        }
    },
})
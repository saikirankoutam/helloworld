({
    doInit : function(component, event, helper) {
        helper.checkJobAct(component,event);
        helper.getRepairOrderDetails(component, event);
        helper.getInvoiceOrderDetails(component, event);
        helper.getworkorderlineitem(component,event);
        helper.getlaborcharges(component,event);
        helper.getcustomercomments(component,event);
        helper.checkROStatus(component,event);
        helper.getinvoice(component,event);
         helper.checkWarrantySb(component, event);

    },
    sdfx :function(component,event,helper)
    {
        debugger;
     var abc = component.get('v.nocheckboxval');
       if(abc)
        {
            component.set('v.nocheckboxval',true);
            component.set('v.yescheckboxval',false);
        }
        else{
            component.set('v.yescheckboxval',true);
            component.set('v.nocheckboxval',false);
            var open= component.get('v.yescheckboxval');
            if(open)
            {
              component.set("v.isModalOpen", true);
            }
            
        }
       
    },
    
   /* 
    *  :function(component, event, helper) {
     helper.createinvoice(component,event,'Insurance');
    },*/
    openmodel :function(component, event, helper) {
        debugger;

              var abc = component.get('v.yescheckboxval');
      if(abc)
        {
             component.set("v.isModalOpen", true);
             component.set('v.yescheckboxval',true);
             component.set('v.nocheckboxval',false);
        var action = component.get("c.customerWaiting");
        var recid = component.get("v.repairOrderId");
        action.setParams({
            "recordId" : recid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                 }
        });
        $A.enqueueAction(action);
        }
        else{
            component.set('v.nocheckboxval',true);
            component.set('v.yescheckboxval',false);
            }
    },
    closeInsurance :function(component, event, helper) {
    component.set("v.isModalOpen", false);
    component.set('v.nocheckboxval',true);
    component.set('v.yescheckboxval',false);
            
    },
    generateInsurance :function(component, event, helper) {
       // component.set("v.war",false);
      helper.createinvoice(component,event,'Insurance');
    },
    preinvoicepdf :  function(component, event, helper) {
       
        var checkPreInvoice=component.get("v.profom");
         var isValid = true;
         var comment = component.find("comment").get("v.value");
         component.set("v.commentErrMsg",'');
         $A.util.removeClass(comment,"disp-block");
         $A.util.addClass(comment,"disp-none");
            if( comment== '--None--' || comment==''|| comment=='undefined'|| comment==null){
             isValid = false;
             component.set("v.commentErrMsg",'This is a required field to generate Proforma Invoice');
             $A.util.removeClass(comment,"disp-none");
             $A.util.addClass(comment,"disp-block");
         }
        if(checkPreInvoice)
        {
            var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": "Please Complete All Job Card Activities",
            "type": "error"
        });
        toastEvent.fire();  
        }
        else if(isValid){
        component.set("v.disYes",false);
        component.set("v.disNo",false);
        var action = component.get("c.proformabutton");
        var recid = component.get("v.repairOrderId");
        action.setParams({
            "recordId" : recid,
            "comment"  : comment
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                  }
             helper.createinvoice(component,event,'Customer Paid');
           // component.set("v.discomment",false)
        });
         $A.enqueueAction(action);
        }
       },
    
    Warrantypdf:function(component, event, helper) {
        
        helper.createinvoice(component,event,'Warranty');
    },
    actualinvoicepdf:function(component, event, helper) {
        debugger;
       var records=component.get("v.Pdlist");
       var labourRecords= component.get("v.labourchargelist");   
        var workorders=records[0].WorkOrderLineItems;
        var count=0;
        var insu=false;
        var war=false;
       var x;
        for(x in workorders){
            if(workorders[x].Issue_Type__c=='Insurance') {
                 component.set("v.insu", false);
                 insu=true;
                
            }
           
            }     
        var action = component.get("c.customerbutton");
        var recid = component.get("v.repairOrderId");
        action.setParams({
            "recordId" : recid,
            "insu":insu,
            "war":war
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS")
            {
                var storeResponse = response.getReturnValue();
            }
        });
        $A.enqueueAction(action);
       
         var recordId = component.get("v.repairOrderId");
        var pdfurl ='../PSA_InvoicePDF?id='+recordId;
        window.open(pdfurl,"_blank", "width=600, height=550"); 
          helper.createinvoice(component,event,'Internal');
   },
    saveinvoice:function(component, event, helper) {
     
        //helper.createinvoice(component,event); 
    },
    changeStatus:function(component, event, helper)
    {
        debugger;
        var eventListPage = component.getEvent("displayListPageParts1");
        eventListPage.setParams({"StatusService" : "Closed" });
        eventListPage.fire();
        component.set("v.isModalOpen", false);
         var action = component.get("c.updatestatusclosed");
        var recid = component.get("v.repairOrderId");
        action.setParams({
            "recordId" : recid,
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            //alert(state);
            if (state === "SUCCESS") {
                helper.sendCustomerinvoice(component,event,helper);
                component.set("v.cus",false);
                component.set("v.disYes",true);
                component.set("v.disNo",true);
                component.set("v.predis",true);
                component.set("v.discomment",true)
                 }
          
        });
        $A.enqueueAction(action);
        var valid=false;
        var validPart=component.get("v.checkWarranty");
        
        var labourRecords= component.get("v.labourchargelist");   
        var x;
        for(x in labourRecords){
           if(labourRecords[x].PSA_Issue_Type__c=='Warranty') {
               valid=true;
               
                 break;
              } 
        
        }  
 
      if(validPart || valid)
            {
                
        var action1 = component.get("c.updateSubstatusclosed");
        var recid = component.get("v.repairOrderId");
        action1.setParams({
            "recordId" : recid  
        });
        action1.setCallback(this, function(response){
            var state = response.getState();
            
            if (state == "SUCCESS") 
            {
                
        var eventListPage1 = component.getEvent("displayListPagePartsSubStatus");
        eventListPage1.setParams({"subStatus" : "Claim Pending" });
        eventListPage1.fire();   
            }
          
            
        });
        $A.enqueueAction(action1);
        }
    },
    getDiscountPervalue :function(component, event, helper){
         var selectvariant = component.find("discper").get("v.value");
    },
    
    Savediscounts : function(component, event, helper){
        var action = component.get("c.updatediscountsonlineitems");
        var recid = component.get("v.repairOrderId");
        action.setParams({
            "recordId" : recid,
            "discount" : component.find("discpercent").get("v.value"),
            "partwolineitems" : component.get("v.wolineitemlist"),
            "labourwolineitems" : component.get("v.labourchargelist")
        });
        action.setCallback(this, function(response){
            var state = response.getState();            
            if (state === "SUCCESS") 
            {
                component.set("v.repairOrderDetails.PSA_Discount__c", response.getReturnValue());
            	helper.getworkorderlineitem(component,event);
        		helper.getlaborcharges(component,event);
                helper.showSuccessToast(component, event, 'Discount saved successfully!');            
            }
        });
        $A.enqueueAction(action);
    },		        
    
    updatepartdiscounts : function(component, event, helper){
        var headerdiscount = component.get("v.repairOrderDetails.PSA_Discount__c");
        var wolineitems = component.get("v.wolineitemlist");
        var discountlist = [];
        for(var i=0; i<wolineitems.length; i++){
            if(wolineitems[i].Issue_Type__c == "Customer Paid"){
                wolineitems[i].Discount = headerdiscount;
                discountlist.push(wolineitems[i]);
            }
            else{
                discountlist.push(wolineitems[i]);
            }
        }
        component.set("v.wolineitemlist", discountlist);
        
        var wolineitemslabour = component.get("v.labourchargelist");
        var discountlistlabour = [];
        for(var j=0; j<wolineitemslabour.length; j++){
            if(wolineitemslabour[j].PSA_Issue_Type__c == "Customer Paid"){
                wolineitemslabour[j].Labor_Discount__c = headerdiscount;
                discountlistlabour.push(wolineitemslabour[j]);
            }
            else{
                discountlistlabour.push(wolineitemslabour[j]);
            }
        }
        component.set("v.labourchargelist", discountlistlabour);
    }
/*var check=component.get("v.war");
                if(!check)
                {
                 component.set("v.war", false);
                 war=true;   
                }
                */
})
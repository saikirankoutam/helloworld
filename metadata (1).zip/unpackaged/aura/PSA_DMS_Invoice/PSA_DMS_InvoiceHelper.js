({
    getRepairOrderDetails : function(component, event){
        debugger;
        var action = component.get("c.getRepairOrderDetailsMethod");
        var recid = component.get("v.repairOrderId");
        action.setParams({
            "recordId" : recid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.repairOrderDetails", storeResponse);
                //component.set("v.repairOrderDetails.PSA_Discount__c", storeResponse.PSA_Discount__c);
                if(storeResponse.PSA_customer_button__c==true)
                {
                    component.set("v.insu", false);
                }
               
                
                 if(storeResponse.Invoice_amount_yes__c==true)
                {
                    component.set("v.disYes", true);
                    component.set("v.disNo", true);
                    component.set('v.yescheckboxval',true);
                    component.set('v.nocheckboxval',false);
                    component.set("v.cus", false);
                }
                
                        }
        });
        $A.enqueueAction(action);
    },
    getInvoiceOrderDetails : function(component, event){
        debugger;
        var action = component.get("c.getAfterSaleInvoiceDetails");
        var recid = component.get("v.repairOrderId");
        action.setParams({
            "recordId" : recid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                for(var i=0;i<storeResponse.length;i++)
                {   
                if(storeResponse[i].PSA_Invoice_Type__c=='Customer Paid')
                {
                  component.set("v.customdat", storeResponse[i].Date__c);  
                    component.set("v.custominv", storeResponse[i].Name); 
                }
                if(storeResponse[i].PSA_Invoice_Type__c=='Insurance')
                {
                    component.set("v.insudat", storeResponse[i].Date__c); 
                    component.set("v.insuinv", storeResponse[i].Name); 
                }
                if(storeResponse[i].PSA_Invoice_Type__c=='Warranty')
                {
                    component.set("v.warrdat", storeResponse[i].Date__c); 
                    component.set("v.warrinv", storeResponse[i].Name); 
                }
                }
                
            }
        });
        $A.enqueueAction(action);
    },
     getcustomercomments : function(component, event) {
         var workorderid = component.get("v.repairOrderId");  
         var action = component.get('c.fetchcomments');
          action.setParams({ 
                "workorderid" : workorderid
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var  values= response.getReturnValue();
                component.set("v.custcomment",values);
            });
            $A.enqueueAction(action);
 },
    
    getworkorderlineitem : function(component, event) {
        var workorderid = component.get("v.repairOrderId");       
        var action = component.get('c.fetchProductCode');
        var partTax=0;
        var discValue=0;
        var CGSTW=0;
        var SGSTW=0;
        var partsTotal=0;
        var discv=0;
        var partsTaxTotal=0;
        action.setParams({ "workid" : workorderid });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                if(records.length > 0){
                    component.set("v.displaytable",true);
                   // component.set("v.custcomment",records.PSA_Customer_Comments__c);
                    component.set("v.Pdlist", records);
                    component.set("v.wolineitemlist", records[0].WorkOrderLineItems);
                    for(var i=0;i<records.length;i++){
                         
                      
                       for(var i=0;i<records[0].WorkOrderLineItems.length;i++){
                            
                      if(records[0].WorkOrderLineItems[i].Issue_Type__c=='Warranty') 
                      {
                          component.set("v.checkWarranty", true);
                       } 
                            if(records[0].WorkOrderLineItems[i].PSA_Issued_Total_Price__c=='undefined' || records[0].WorkOrderLineItems[i].PSA_Issued_Total_Price__c==null)
                            {
                                partTax+=0;
                            }
                            
                            else
                                partTax+=records[0].WorkOrderLineItems[i].PSA_Issued_Total_Price__c;
                        	
                             if(records[0].WorkOrderLineItems[i].PSA_Issued_Taxable_Value__c=='undefined' || records[0].WorkOrderLineItems[i].PSA_Issued_Taxable_Value__c==null)
                            {
                                partsTaxTotal+=0;
                            }
                            
                            else
                                partsTaxTotal+=records[0].WorkOrderLineItems[i].PSA_Issued_Taxable_Value__c;
                        	 
                           
                            if(records[0].WorkOrderLineItems[i].PSA_CGST__c=='undefined' || records[0].WorkOrderLineItems[i].PSA_CGST__c==null)
                            {
                                CGSTW=CGSTW+0;
                            }
                            else
                              CGSTW=CGSTW+records[0].WorkOrderLineItems[i].PSA_CGST__c;
                            
                             if(records[0].WorkOrderLineItems[i].PSA_SGST__c=='undefined' || records[0].WorkOrderLineItems[i].PSA_SGST__c==null)
                            {
                                SGSTW=SGSTW+0;
                            }
                            else
                              SGSTW=SGSTW+records[0].WorkOrderLineItems[i].PSA_SGST__c;
                            
                            if(records[0].WorkOrderLineItems[i].PSA_Issued_Total_Amount__c=='undefined' || records[0].WorkOrderLineItems[i].PSA_Issued_Total_Amount__c==null)
                            {
                                partsTotal=partsTotal+0;
                            }
                            else
                              partsTotal=partsTotal+records[0].WorkOrderLineItems[i].PSA_Issued_Total_Amount__c;
                        
                             if(records[0].WorkOrderLineItems[i].PSA_Discount_amount__c=='undefined' || records[0].WorkOrderLineItems[i].PSA_Discount_amount__c==null)
                            {
                               discv=discv+0;
                            }
                            else
                              discv=discv+records[0].WorkOrderLineItems[i].PSA_Discount_amount__c;
                      
                        }
                    }
                    var partsCgst=(partTax/100)*CGSTW;
                    var partsSGST=(partTax/100)*SGSTW;
                   
                    component.set("v.partsTaxableAmount",partTax);
                    component.set("v.partsCgst",partsTaxTotal/2);
                    component.set("v.partsSGST",partsTaxTotal/2)
                    component.set("v.partsTotal",partsTotal);
                    component.set("v.discv",discv);
                  //   component.set("v.return3",discValue);
                    
                   // alert(component.get("v.return3"));
                }
                console.log('rec>>>>'+JSON.stringify(response.getReturnValue()));
              }   
        });
        $A.enqueueAction(action);
    },
     getlaborcharges : function(component, event) {
        var workorderid = component.get("v.repairOrderId"); 
        var action = component.get('c.fetchlaborcharges');
        var d=0;
       var CGST=0;
       var SGST=0;
       var labourTotal=0;
       var discvl=0;
       var taxableVal=0;
         
        action.setParams({ "workid" : workorderid });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();               
                component.set("v.labourchargelist", records);                
                console.log(component.get("v.labourchargelist"));
               
                    for(var i=0;i<records.length;i++){  
                        if(records[i].Taxable_Value__c=='undefined' || records[i].Taxable_Value__c==null)
                        {
                            d=d+0;
                        }
                        else{
                            d+=(records[i].Taxable_Value__c);
                        }
                            
                      if(records[i].PSA_Price_excl_Tax__c=='undefined' || records[i].PSA_Price_excl_Tax__c==null){
                            taxableVal=taxableVal+0;
                            
                      }else{
                            
                            taxableVal+=(records[i].PSA_Price_excl_Tax__c);
                      }
                        
                     if(records[i].PSA_CGST__c=='undefined' || records[i].PSA_CGST__c==null){
                           CGST=CGST+0;
                        }else
                            CGST=CGST+(records[i].PSA_CGST__c);
                        
                        
                        if(records[i].PSA_SGST__c=='undefined' || records[i].PSA_SGST__c==null){
                           SGST=SGST+0;
                        }else
                            SGST=SGST+(records[i].PSA_SGST__c);
                        
                        if(records[i].Total_Amount__c=='undefined' || records[i].Total_Amount__c==null){
                           labourTotal=labourTotal+0;
                        }else
                         //   alert(records[i].Total_Amount__c);
                            labourTotal=labourTotal+records[i].Total_Amount__c;
                       
                        
                        if(records[i].PSA_Discounted_Value__c=='undefined' || records[i].PSA_Discounted_Value__c==null){
                           discvl=discvl+0;
                        }else
                            
                            discvl=discvl+records[i].PSA_Discounted_Value__c;
                        
                        }
                var dis= component.get("v.discv");
                var partTotal=component.get("v.partsTotal");
                var totalDiscount=dis+discvl;
                var roundoff=partTotal+labourTotal;
                var grandTotal=Math.round(roundoff);
                var labourCGST=(d/2);
                var labourSGST=(d/2);
                component.set("v.labourTaxableAmount",taxableVal);
                component.set("v.labourCGST",labourCGST);
                component.set("v.labourSGST",labourSGST);
                component.set("v.labourTotal",labourTotal);
                component.set("v.totalDiscount",totalDiscount);
                component.set("v.roundoff",roundoff);
                component.set("v.grandTotal",grandTotal);
               
            } 
            
            
            
        });
        $A.enqueueAction(action);
    },
  //  createinvoice:function(component, event,type) {
        createinvoice:function(component, event,type) { 
        debugger;
        var workorderid = component.get("v.repairOrderId"); 
        var invtype = 'Pre Invoice';
        var action = component.get('c.createinvoice');
       action.setParams({ 
            "workid" : workorderid,
            "invoicetype":invtype,
            "remarks" : null,
            "issuetype" : type
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            var records =response.getReturnValue();  
            if(state == 'SUCCESS') {
                console.log('createdinvoice>'+JSON.stringify(records));
                //var Message= $A.get("$Label.c.PSA_Invoice_Created_Successfully");
               // this.showSuccessToast(component,event,Message);
                this.getinvoice(component,event);
                this.getRepairOrderDetails(component,event);
                if(type=='Warranty'){
                  var recordId = component.get("v.repairOrderId");
                  var pdfurl ='../PSA_WarrantyInvoice?id='+recordId;
                  window.open(pdfurl,"_blank", "width=600, height=550");
                }
                if(type=='Customer Paid')
                {
                    var recordId = component.get("v.repairOrderId");
                    var pdfurl ='../PSA_ProformaInvoice?id='+recordId;
                    window.open(pdfurl,"_blank", "width=600, height=550"); 
                    this.createinvoiceattachment(component,event);
                    component.set("v.discomment",true)
                }
                if(type=='Insurance'){
                     var recordId = component.get("v.repairOrderId");
                     var pdfurl ='../PSA_InsuranceInvoice?id='+recordId;
                     window.open(pdfurl,"_blank", "width=600, height=550");
                }
               this.getInvoiceOrderDetails(component,event);
            }
            
        });
        $A.enqueueAction(action);
    },
    createinvoiceattachment:function(component, event) {
        debugger;               
        var workorderid = component.get("v.repairOrderId");       
        var action = component.get('c.sendinvoiceAttachement');
        action.setParams({ 
            "recordId" : workorderid           
        });
        action.setCallback(this, function(response){
            var state = response.getState();
           // var records =response.getReturnValue();  
            if(state == 'SUCCESS') {
               var toastEvent = $A.get("e.force:showToast");
               toastEvent.setParams({
            "title": "Success!",
            "message": "Invoice Details Email sent Successfully",
            "type": "success"               
           });
                toastEvent.fire(); 
            }
        });
        $A.enqueueAction(action);
    },

    sendCustomerinvoice:function(component, event) {
        debugger;               
        var workorderid = component.get("v.repairOrderId");       
        var action = component.get('c.sendCustomerinvoiceAttachement');
        action.setParams({ 
            "recordId" : workorderid           
        });
        action.setCallback(this, function(response){
            var state = response.getState();
           // var records =response.getReturnValue();  
            if(state == 'SUCCESS') {
               var toastEvent = $A.get("e.force:showToast");
               toastEvent.setParams({
            "title": "Success!",
            "message": "Customer Invoice Details Email sent Successfully",
            "type": "success"               
           });
                toastEvent.fire(); 
            }
        });
        $A.enqueueAction(action);
    },
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
  
    showerrorToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "error"
        });
        toastEvent.fire();  
    },
    
    getinvoice:function(component, event) {
        debugger;
        var workorderid = component.get("v.repairOrderId"); 
        var action = component.get('c.getrepairorderinvoice');
        
        action.setParams({ "workid" : workorderid });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();                 
                component.set("v.invoicedetails", records);
                console.log('records from Invoice  >>>>>>>>>'+JSON.stringify(records));
                //component.set("v.totallaborcharges", records[0].Total_Labor_Charges__c);
                var LaborGST = component.get("v.invoicedetails.Labor_GST__c"); 
                var partsGST = component.get("v.invoicedetails.Parts_GST__c"); 
                var totalGST = LaborGST +partsGST;
                component.set("v.TotalGST",totalGST);
                
            }
            
        });
        $A.enqueueAction(action);
        
    },
    validateworkorderlineitem: function(component,event,helper){
        debugger;
        //   this.getworkorderlineitem(component,event);
        var workitems = component.get("v.linelist");
        console.log('workitems'+workitems);
        
        var issueqty = 0;
        var qty =0;
        for(var i=0; i<workitems.length; i++)
        {   qty = workitems[i].Quantity;
         //alert('qty'+qty);
         issueqty =workitems[i].PSA_Issued_Quantity__c;
        // alert('issueqty'+ issueqty);
         if(issueqty =='undefined' ||issueqty == null){
             var Message = 'Parts not issued';
             this.showerrorToast(component,event,Message);                      
         }
         else{
             this.createinvoice(component,event);
         }
        }
    },
    checkJobAct:function(component, event) {
        debugger;
        
        var workorderid = component.get("v.repairOrderId"); 
        var action = component.get('c.checkJobActivity');
        
        action.setParams({ "workid" : workorderid });
        action.setCallback(this, function(response){
            var state = response.getState();
           
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
               // alert(records);
                 component.set("v.profom",records);
           }
            
        });
        $A.enqueueAction(action);
    },
    checkROStatus : function(component, event){
    debugger;
          var workorderid = component.get("v.repairOrderId"); 
         var action = component.get("c.checkROStatus");
        
        action.setParams({
                "workorderid" :workorderid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.discomment",true);
                component.set("v.predis",true);
                }
            }
        });
        $A.enqueueAction(action);	    
	 
},
    checkWarrantySb : function(component, event){
        debugger;
        var action = component.get("c.checkWarrantySb");
        var recid = component.get("v.repairOrderId");
        action.setParams({
            "recordId" : recid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state == "SUCCESS")
            {
                var storeResponse = response.getReturnValue();
                
                if(storeResponse==true)
                {
                    component.set("v.war", true);
                 }
                else
                {component.set("v.war", false);}
            }
        });
        $A.enqueueAction(action);
    },
    
})
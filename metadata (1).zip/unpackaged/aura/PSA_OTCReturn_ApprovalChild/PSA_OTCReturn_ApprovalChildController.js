({
   doInit : function(component, event, helper) {
       debugger;
        var ProductInstance= component.get("v.ProductInstance"); 
        var listprice = ProductInstance.unitprice;
        var taxable=ProductInstance.totalTaxablebg;
        var taxValue=ProductInstance.totalTaxbg;
        var totalInvoice=ProductInstance.totalInvoiceValuebg;
        var returnqty =component.find("retqty").get("v.value");
        var invqty = component.find("invqty").get("v.value"); 
        var cgst=ProductInstance.cgsts;
        var sgst=ProductInstance.sgsts;
                             
              
           
             component.set("v.totalTax", taxValue);
          // component.set("v.ProductInstance.totalTax", parseFloat(totaltax));         
             component.set("v.totalInvoiceValue", totalInvoice);
             component.set("v.taxablevalue", taxable);
           if(parseInt(returnqty)>0 && returnqty!=null){
              var totalInvoiceValue= component.get("v.totalInvoiceValue");
              
               
               
              var Totalreturnvalue=(parseInt(totalInvoiceValue)/parseInt(invqty));
              var returnTaxable = (parseInt(taxable)/parseInt(invqty))*parseInt(returnqty);
              var returnGst = (parseInt(taxValue)/parseInt(invqty))*parseInt(returnqty);
              //Totalreturnvalue=  Math.round(Totalreturnvalue);
             returnTaxable= Math.round(returnTaxable);
             returnGst=  Math.round(returnGst);
             
            component.set("v.totalreturnvalue", Math.round(Totalreturnvalue*parseInt(returnqty))); 
            component.set("v.ProductInstance.totalGst", parseFloat(returnGst));
               
            component.set("v.ProductInstance.totalTax", parseFloat(returnTaxable));
            component.set("v.ProductInstance.totalInvoiceValue",Math.round(Totalreturnvalue*parseInt(returnqty)) );
               var compEvent = component.getEvent("calcOTC");
               compEvent.fire();
           }}
})
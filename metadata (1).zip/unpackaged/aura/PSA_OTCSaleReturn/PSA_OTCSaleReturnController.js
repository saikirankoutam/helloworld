({
    doInit : function(component, event, helper) {
    helper.getCustomeLookUpQuery(component,event);
  
    },
    recordChanges : function(component, event, helper) {
      debugger;
        var selectedrec=component.get("v.selectedLookUpRecord");    
        var invoicenumber =selectedrec.Id;
       
   
        
        if(invoicenumber == 'undefined' || invoicenumber =='' || invoicenumber == null){ 
            
            component.set("v.Parttableshow",false);
            component.set("v.OTCCustomername",'');
            component.set("v.OTCCustomerid",'');
            component.set("v.OTCCustomerGST",''); 
            component.set("v.partexecutive",'');
            component.set("v.InvoiceDate",'');
            component.find("reterefno").set("v.value",'');
            component.set("v.totalTax",'');
            component.set("v.totalGst", '');
            component.set("v.apperrmsg", '');
            component.set("v.totalreturnValue", '');
            component.find("reasonret").set("v.value",'');
            component.set("v.returnReson",'');
            component.set("v.remarkss",'');
            component.find("returndate").set("v.value",'');
            component.set("v.disableAll", false);
            component.set("v.printbutton", true);
            component.set("v.disfields", false);
            component.set("v.childrq", false);
            component.set("v.otcid",null);
            component.find("retapprovedby").set("v.value",'');
            component.set("v.partsList", null); 
            component.find("retstatus").set("v.value",'');
            component.find("approvalcomm").set("v.value",'');
           
            
     }else{ 

            var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");   	
            var Invoiceid = selectedrec.Id; 
            var Invoicedate = selectedrec.PSA_Invoice_Date__c;
          
           
            component.set("v.InvoiceId",Invoiceid);
            component.set("v.Parttableshow",true);  
            component.find("returndate").set("v.value",today);
            var wsd=$A.localizationService.formatDate(Invoicedate, "dd/MM/yyyy");
            component.set("v.InvoiceDate",wsd);
            helper.fetchotcetunitem(component, event);
             
            
        
            
        }
    },
   
    submit:function(component, event, helper){  
         var selectedlist=[];
        
         var returnlist=component.get('v.partsList');
        for(var i=0; i<returnlist.length; i++){
             
            if(returnlist[i].checked){
              
                selectedlist.push(returnlist[i]);}
        }
        
              if(selectedlist.length>0) {
                  
             helper.submitaction(component,event, helper,selectedlist);
        }else{
            helper.showErrorToast(component, event,'Please select atleast one part number for Return');
        }
    
       
   },
    refresh:function(component,event,helper){
         var childCmp = component.find("invno");
        childCmp.clearpill(); 
    },
     GenerateInvoice : function(component, event, helper) {
     debugger;
        var Orderid = component.get("v.OrderId");  
         
        var action = component.get("c.getorder");        
        action.setParams({
            "orderid" : Orderid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var lineid =''
                var storeResponse = response.getReturnValue();
                for(var i = 0; i < storeResponse.length; i++){
                    lineid =storeResponse[0].Id;
                    
                }
                if(storeResponse.length>0){
                    var recordId = event.target.id;               
                    var pdfurl ='../PSA_OTCReturnInvoice?Id='+lineid;
               
                    window.open(pdfurl,"_blank","width=600, height=550"); 
                }
                 else{
                     var Message= 'Order Not Found';
                    helper.showErrorToast(component,event,Message);
            	}
            }
          
          });
         $A.enqueueAction(action);
     },
    triggerCalc:function(component, event, helper){
       
        var PartsSelListEdit = component.get("v.partsList");
        var i;
       
        var totalTax = 0;
        var totalGst = 0;
        var totalInvoiceValue = 0;
        for(i in PartsSelListEdit)
        {
            var rec = PartsSelListEdit[i];
         
                        
           if(rec.checked && rec.retqty!= null)
           {
           totalGst=rec.totalGst+totalGst;
           totalTax = rec.totalTax+totalTax;
           totalInvoiceValue = rec.totalInvoiceValue+totalInvoiceValue;
                
           }
          
            
        }
        component.set("v.totalGst", totalGst);
        component.set("v.totalTax", totalTax);
        component.set("v.totalreturnValue", totalInvoiceValue);
    },

})
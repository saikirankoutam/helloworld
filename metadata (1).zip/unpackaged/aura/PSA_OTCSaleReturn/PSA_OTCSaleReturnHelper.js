({
    fetchotcetunitem : function(component, event) {
      
        debugger; 
          var action = component.get("c.getOtcReturn");
      action.setParams({
            "rid" : component.get("v.InvoiceId"),
});
        action.setCallback(this, function(response){
            var state = response.getState();
            var resultd=response.getReturnValue();
            
           if(resultd == 'undefined' || resultd =='' || resultd == null)
           { 
           this.fetchotcorderitem(component, event);  
           }
        else 
        {               
        component.set("v.otcdata",response.getReturnValue());
        var resultd=response.getReturnValue();
        var otid= resultd.Id;
        var app=resultd.PSA_Approval_Info__c;
        var  reretrun=resultd.Reason_for_Return__c;
        var  reref=resultd.Return_Reference_No__c;
        var  remarkss=resultd.Remarks__c;
        var  apprComm=resultd.PSA_Approval_Comments__c;
        var  apprBy=resultd.Return_Approved_by__c;
        var  rejStatus=resultd.PSA_Approval_Info__c;
        
             component.set("v.returnReson",reretrun);
             component.set("v.remarkss",remarkss);
             component.set("v.reref",reref);
             component.set("v.otcid",otid);
             component.set("v.apprComm",apprComm);
            component.set("v.apprBy",apprBy);
            component.set("v.rejStatus",rejStatus);
                
                if(resultd.PSA_Approval_Info__c=='Approved')
                {
                    component.set("v.disableAll", true);
                    component.set("v.childrq", true);
                    component.set("v.printbutton", false);
                    component.set("v.disfields", true);
                    
                }
               

                this.fetchotcorderitem(component, event);
               
            }
            
        });
        $A.enqueueAction(action); 
    },
    
  fetchotcorderitem : function(component, event) {
      
        debugger;  
        var action = component.get("c.getinvoiceitems");
        var Invoiceid = component.get("v.InvoiceId"); 
        var  otcid= component.get("v.otcid");
        action.setParams({
            "invoiceid" : component.get("v.InvoiceId"),
            "otcid"     :otcid
        });
        action.setCallback(this, function(response){
            var state = response.getState(); 
           
            if (state === "SUCCESS") {               
                var rows = response.getReturnValue();
                
                component.set("v.partsList", rows); 
                  for(var i=0;i<rows.length;i++){
                            var ordid = rows[i].orderid; 
                        }                    
                component.set("v.OrderId",ordid);            
                console.log(component.get("v.OrderId"));     
            }
            this.getorderinfo(component,event); 
        });
            $A.enqueueAction(action);
        },
    

    getorderinfo:function(component,event){
        debugger;
      var action = component.get("c.getinvoice");
      var OrderId = component.get("v.OrderId");   
        action.setParams({
            "orderid" : component.get("v.OrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {               
                var rows = response.getReturnValue();
                
                if(rows.PSA_Order__r.RecordType.Name=='CoDealer')
                {
                 
                  var cusname = rows.PSA_Order__r.Account.Name;
                  var Partex= rows.PSA_Order__r.PSA_Part_Sale_Executive__c;  
                  var customerid = rows.PSA_Order__r.Account.DMS_Customer_ID__c;
                  
                }
                else{
                      var customerid = rows.PSA_Order__r.OTC_Customer__r.DMS_Customer_ID__c;
                      var cusname = rows.PSA_Order__r.OTC_Customer__r.Name;
                      var Partex= rows.PSA_Order__r.PSA_Part_Sale_Executive__c;
                     
                }
               
                component.set("v.OTCCustomerid", customerid);
                component.set("v.OTCCustomername", cusname);
                component.set("v.partexecutive",Partex);
               // component.set("v.custState",custState);
            }
        });
        $A.enqueueAction(action);  
    },
    validateqty: function(component,event,helper){
        debugger;   
        var isvalid =true;
        var partlist= component.get("v.partsList");       
        for(var i=0; i<partlist.length; i++) { 
            var returnqty = partlist[i].retqty; 
            var physicalqty = partlist[i].availableqty;
          if(returnqty > physicalqty){
                var Message = 'Return Qty is Exceeded1';
                this.showErrorToast(component,event,Message); 
                isvalid=false;
            }
            if(parseInt(returnqty) <0){
                var Message = 'Return Qty must be Greater than Zero';
                this.showErrorToast(component,event,Message); 
                isvalid=false;
            }
            return isvalid;  
        }
        
    },
    submitaction:function(component,event,helper,selectedlist){
       if (this.validatePartForm(component, event)) { 
       var otcid=component.get("v.otcid");
       var partlist= component.get("v.partsList"); 
       var InvoiceId = component.get("v.InvoiceId");
       
       var retdate = component.find("returndate").get("v.value");
       
      
       var retrefno = component.find("reterefno").get("v.value");
       var retapproved = component.find("retapprovedby").get("v.value");
       var retreason = component.find("reasonret").get("v.value");
       var remarks = component.find("remarks").get("v.value");
      
        var finalvalidity=true;
        var isvalid=true;
        var childCmp = component.find("otcReturnchild");
                if(childCmp.length){
            for(var i=0; i<childCmp.length; i++){
                debugger;
                isvalid=childCmp[i].checkValidationparts();
                if(!isvalid)
                finalvalidity=false;
            }
                
        } else{
            isvalid=childCmp.checkValidationparts();
        }
     if(finalvalidity && isvalid){  
         debugger;
       var action = component.get("c.createOtcReturn");    
        action.setParams({
            "returnpartlist" : selectedlist,
            "invoiceid":InvoiceId,
            "retdate":retdate,
            "retrefno":retrefno,
            "retapproved":retapproved,
            "retreason":retreason,
            "remarks":remarks,
            "otcreturnid":otcid
        });
        action.setCallback(this, function(response){   
            debugger;
            var state = response.getState();
         
            if (state === "SUCCESS") {   
                var Message= "OTC-Sale Return Placed Successfully ";
                this.showSuccessToast(component,event,Message);
                var rows = response.getReturnValue();
                component.set("v.disableAll", true);
                component.set("v.childrq",true);
                //component.set("v.partsList", rows);   
               component.set("v.disfields", true);

            }       
        });    
        $A.enqueueAction(action); 
        }
       }
    },
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    showErrorToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "Error"
        });
        toastEvent.fire();  
    },
        getCustomeLookUpQuery : function(component, event)
    {
        debugger;
		var  listStatus  = component.get("v.statuslist");
        var query='select id,Name,PSA_Invoice_Date__c,OTC_Sale_Return__c,Otc_Invoice_Number__c from PSA_Invoice__c where (OTC_Sale_Return__c = False or PSA_Approval_Info__c In ';
        query+=listStatus+' AND RecordTypeId=';
        var action = component.get("c.getRecordTypeID");
           action.setCallback(this, function(response){
                var state = response.getState();
                var recordtypeid = response.getReturnValue();
                if (state === "SUCCESS") {
                var newString = '\''+ recordtypeid + '\''; 
                    
                query+=newString +' AND PSA_Account__r.Id=';
                //component.set('v.customquery',query); 
                }
               this.getAccountLookUpQuery(component, event,query);
            });
            $A.enqueueAction(action);
        
        
    },
    getAccountLookUpQuery : function(component, event,query)
    {
		
       var action = component.get("c.getAccountID");
           action.setCallback(this, function(response){
                var state = response.getState();
                var recordtypeid = response.getReturnValue();
                if (state === "SUCCESS") {
                var newString = '\''+ recordtypeid + '\'';  
                query+=newString+' AND Name LIKE: searchKey order by createdDate DESC limit 5';
                component.set('v.customquery',query); 
        //alert(query);
        }  
            });
            $A.enqueueAction(action);
        
    },
    validatePartForm : function(component, event, helper){
         
        debugger;
        var isValid = true;
        var cname = component.find("reasonret").get("v.value");
        component.set("v.apperrmsg",'');
        $A.util.removeClass(cname,"disp-block");
        $A.util.addClass(cname,"disp-none");
       if( cname=='--None--'|| cname == '' ||  cname== null){
            component.set("v.apperrmsg",'This is a required field');
            $A.util.removeClass(cname,"disp-none");
            $A.util.addClass(cname,"disp-block");
            isValid = false;
        } 
       return isValid;       
    },
    delearinfo: function(component,event) {
        var action = component.get("c.dealerbillingstate");       
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set('v.dealerstate',storeResponse);
            }
        });
        $A.enqueueAction(action);  
    },
    checkState: function(component,event) {
        var action = component.get("c.custbillingstate"); 
        var Invoiceid = component.get("v.InvoiceId");   
        action.setParams({
            "orderid" : Invoiceid
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                var dealerstate = component.get("v.dealerstate");
               if(storeResponse==dealerstate)
               {
                   component.set('v.withinstate',true);
               }
                else{
                    component.set('v.withinstate',false);
                }
            }
        });
        $A.enqueueAction(action);  
    }
})
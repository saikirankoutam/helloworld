({
    editLocalpartRecord : function(component, event, helper) {
        debugger;        
	     component.set("v.curView", "editView");
    },
     cancelLocalpartRecord : function(component, event, helper){      
        var eventListPage = component.getEvent("displayListPagePartsView");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
})
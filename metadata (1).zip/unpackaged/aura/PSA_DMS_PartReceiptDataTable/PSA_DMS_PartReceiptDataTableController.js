({
	doInit : function(component, event, helper) {
        
     //   var receiptType = component.get("v.receiptType");
        
        var action = component.get('c.getPartReceipts');
        	action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.receipts", records);
            }
        });
        $A.enqueueAction(action);
    },
    
    onclickPO : function(component, event, helper) {
    var target = event.getSource().get('v.value');
        var compEvent = component.getEvent("PartReceiptIdPass");
       
        compEvent.setParams({"Id" : target });
        
    	compEvent.fire();
}
})
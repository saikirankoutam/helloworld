({
    getPartsInfo : function(component, event, helper) {
        debugger;
        var action = component.get("c.getPartDetails");
        action.setParams({
            "recordId" : component.get("v.recordId")
        });       
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                for(var i=0;i<storeResponse.length;i++){
                    var maingrp = storeResponse[i].PSA_Local_Parts_Master__r.PSA_Main_Group__c;
                    var subgrp = storeResponse[i].PSA_Local_Parts_Master__r.PSA_Sub_Group__c;
                    var partnumb = storeResponse[i].PSA_Local_Parts_Master__r.PSA_Part_Number__c;
                    var bnd = storeResponse[i].PSA_Local_Parts_Master__r.PSA_Brand__c;
                    var qty = storeResponse[i].PSA_Quantity__c;
                    var partdesc = storeResponse[i].PSA_Local_Parts_Master__r.PSA_Part_Description__c;
                    var hsnce = storeResponse[i].PSA_Local_Parts_Master__r.PSA_HSN_Code__c;
                    var uomeas = storeResponse[i].PSA_Local_Parts_Master__r.PSA_Units__c;
                    var qtyper = storeResponse[i].PSA_Local_Parts_Master__r.PSA_Quantity_Per_Vehicle__c;
                    var satype = storeResponse[i].PSA_Local_Parts_Master__r.Sale_Type__c;
                }
                
                component.set("v.mainGroup", maingrp);
                component.set("v.subgroup", subgrp);
                component.set("v.partnum", partnumb);
                component.set("v.bran", bnd);
                component.set("v.qty", qty);
                component.set("v.partdesc", partdesc);
                component.set("v.hsncde", hsnce);
                component.set("v.uomeasure", uomeas);
                component.set("v.qtyperveh", qtyper);
                component.set("v.saltype", satype);
                
            }
        });
        $A.enqueueAction(action);
    },
    validateEditPartForm : function(component, event, helper){
        debugger;
        var isValid = true;
        var igstcde = component.find("IGST").get("v.value");
    //    var cgstcde = component.find("CGST").get("v.value");
   //     var sgstcde = component.find("SGST").get("v.value");
        var purcpric = component.find("Purchasepri").get("v.value");
        var sellprice = component.find("Sellingpri").get("v.value");
        var ratperUni = component.find("rateperUnit").get("v.value");
       
        component.set("v.rateperunitErrMsg",'');
        $A.util.removeClass(ratperUni,"disp-block");
        $A.util.addClass(ratperUni,"disp-none");
        component.set("v.igstErrMsg",'');
        $A.util.removeClass(igstcde,"disp-block");
        $A.util.addClass(igstcde,"disp-none");    
        component.set("v.purchasepriceErrMsg",'');
        $A.util.removeClass(purcpric,"disp-block");
        $A.util.addClass(purcpric,"disp-none");
        component.set("v.sellPriceErrorMsg",'');
        $A.util.removeClass(sellprice,"disp-block");
        $A.util.addClass(sellprice,"disp-none");
        
        if(igstcde == 'undefined'|| igstcde == '' || igstcde == null){
            component.set("v.igstErrMsg",'This is a required field');
            $A.util.removeClass(igstcde,"disp-none");
            $A.util.addClass(igstcde,"disp-block");
            isValid = false;
        }       
   
        if(purcpric == 'undefined'|| purcpric == '' || purcpric == null){
            component.set("v.purchasepriceErrMsg",'This is a required field');
            $A.util.removeClass(purcpric,"disp-none");
            $A.util.addClass(purcpric,"disp-block");
            isValid = false;
        }
        if(sellprice == 'undefined'|| sellprice == '' || sellprice == null){
            component.set("v.sellPriceErrorMsg",'This is a required field');
            $A.util.removeClass(sellprice,"disp-none");
            $A.util.addClass(sellprice,"disp-block");
            isValid = false;
        }
        if(ratperUni =='undefined'|| ratperUni == '' || ratperUni == null){
            component.set("v.rateperunitErrMsg",'This is a required field');
            $A.util.removeClass(ratperUni,"disp-none");
            $A.util.addClass(ratperUni,"disp-block");
            isValid = false;
        }
        return isValid;
    },
     successToast : function(component, event, Message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();
    },
})
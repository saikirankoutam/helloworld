({
    doInit : function(component, event, helper) {
        debugger;
        var invoicevalue=component.get('v.invoice');
        helper.rotable(component,event);
       /* if(invoicevalue=='' || invoicevalue==null || invoicevalue=='undefined'){
            
        }else{
            var x;
            var pagination=[];
            var paginationList=component.get('v.paginationList');
            for(x in paginationList){
                var workordernumber=paginationList[x].WorkOrderNumber; 
                var workordernumber1=paginationList[x].Asset.Account.Client_Id__c; 
                var workordernumber2=paginationList[x].Asset.Vehicle_Plate_Number__c; 
                var workordernumber3=paginationList[x].Asset.PSA_VIN__c; 
               
                
                            
            }
            component.set('v.paginationList',pagination);
            
            
        }*/
        
    },
    
    repairsview : function(component, event, helper) {
        debugger;
        var target = event.getSource().get('v.value');
        
        var repairEvent = component.getEvent("RepairOrderIdPass");
        repairEvent.setParams({"Id" : target });
        
        repairEvent.fire();
        
    },  
    
    
    next : function(component, event, helper)
    { //Pagination Next Button Click
        var rolist = component.get("v.repairorders");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = rolist.slice(end+1,end+pageSize+1);//Slicing List as page number
        start = start + pageSize;
        end = end + pageSize;
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var rolist = component.get("v.repairorders");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = rolist.slice(start-pageSize,start);//Slicing List as page number
        start = start - pageSize;
        end = end - pageSize;
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
        //Pagination Number Button Click
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var repairlist = component.get("v.repairorders");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = repairlist.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    },
    
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.rotable(component, event);
    },
    
    
    
})
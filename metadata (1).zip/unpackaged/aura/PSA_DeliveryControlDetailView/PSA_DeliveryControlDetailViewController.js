({
    doInit : function(component, event, helper) {
        debugger;
       
        var prevTab = component.get("v.RecordId");
        var action = component.get("c.getVdn");
        var record=component.get("v.RecordId");
        action.setParams({
            "orderId" : component.get("v.RecordId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var orderno=value;
                //var vdnstatusdis=value.PSA_VDN_check__c;
                component.set("v.vdnCheck",orderno);
                
            }
            helper.getbookinginfo(component,event,helper);
            helper.fetchVehicleDetails(component,event,helper);
            helper.getcustomerinfo(component, event, helper);
            helper.fordeliverychecklist(component, event, helper);
            // helper.getVdncheck(component, event, helper);
        });
        $A.enqueueAction(action);
        
        
    },
    onTabSelect : function(component, event, helper) {
        var target = event.currentTarget;
        var pdistatus = component.get("v.pdistatus");
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
         component.set("v.currTab", id);
            var activate = component.find(id);
            var deactivate = component.find(prevTab);
            $A.util.removeClass(deactivate, "active");
            $A.util.addClass(activate, "active");

       /* if(id =='DeliveryChecklist'){
            if(pdistatus){
                component.set("v.currTab", id);
                var activate = component.find(id);
                var deactivate = component.find(prevTab);
                $A.util.removeClass(deactivate, "active");
                $A.util.addClass(activate, "active");
            }
        }else{}*/
                   
        
        
    },
    handlevalidateMenu : function(component, event, helper) {
        debugger;
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        var defaultItem = event.getParam("defaultItem");
        console.log("validationItem -- "+validationItem+"::"+defaultItem);
        if (defaultItem) {
            component.set("v.currTab", validationItem);            
        }
    },
    handlepdiCheck :function(component, event, helper) {
        helper.fordeliverychecklist(component, event, helper);
    }
    
})
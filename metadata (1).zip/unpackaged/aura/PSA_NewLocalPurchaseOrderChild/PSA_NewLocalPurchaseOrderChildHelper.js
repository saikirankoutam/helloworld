({
    getPartsList : function(component, event) {
     //  alert('hi');
       var action=component.get('c.getPartsAssociationrecords');
        action.setCallback(this, function(response) {
            var responsevalue=response.getReturnValue();
           // alert(responsevalue);
            component.set('v.PartsList',responsevalue);
            //component.set('v.multifactor',responsevalue[0].PSA_Multiplication_Factor__c );
         //  component.set('v.multifactor',2 );
        });
        $A.enqueueAction(action);
    },
    showError : function(component, event, Message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": Message
        });
        toastEvent.fire();
        component.set("v.spinner", false);
    },
     
})
({
    vehicledata : function(component, event, helper) {
        
       /* component.set("v.spinner", true);
        var receiptType = component.get("v.receiptType");
        
        var action = component.get('c.getVehicleReceipts');
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.receipts", records);
                component.set("v.spinner", false);
            }else{
                component.set("v.spinner", false);
            }
        });
        $A.enqueueAction(action);*/
        
    debugger;
    var receiptType = component.get("v.receiptType");
    var action = component.get('c.getVehicleReceipts');
    
    action.setCallback(this, function(response){
        var state = response.getState();
        if(state == 'SUCCESS') {
            var records =response.getReturnValue();
            component.set("v.invoicescount", records.length);
            
            console.log('Local PO records'+JSON.stringify(records));
            component.set("v.receipts", records);
            component.set("v.totalSize", component.get("v.receipts").length);
            component.set("v.start",0);
            var pageSize = component.get("v.pageSize");
            component.set("v.end",pageSize-1);
            var paginationList = [];
            if(response.getReturnValue().length < pageSize){
                paginationList=response.getReturnValue();
            }
            else{
                for(var i=0; i< pageSize; i++){
                    paginationList.push(response.getReturnValue()[i]); 
                } 
            }
            
            component.set('v.paginationList', paginationList);
            if(response.getReturnValue().length==0){
                component.set('v.norecords', true);
            }
            this.helperMethodPagination(component, event,'1');
            
            component.set("v.spinner", false);
             
        }
        component.set("v.spinner", false);
    });
    $A.enqueueAction(action);
    
    
    },
	listPageHelper : function(component,event) {
        var target = event.getSource().get('v.value');
        var vehiclerec = component.get('v.vehicleid') ;
        var vehid=vehiclerec.Id;
        var compEvent = component.getEvent("vehicleReceiptIdPass");
        compEvent.setParams({"Id" : target,"currentOrderId" : vehid});
    	compEvent.fire();
		
	},
    helperMethodPagination : function(component, event, pageNumber){
        var pageSize = component.get("v.pageSize");//Number Of Row Per Page
        var totalpage=Math.ceil(component.get("v.receipts").length/pageSize);//Number Of Total Pages
        var   paginationPageNumb=[];
        var cont=1;
        /*---Pagination Logic Start--*/
 if(pageNumber<=7){ 
            
            for(var i=1; i<= totalpage; i++){
              
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
                  paginationPageNumb.push(i);
            }
            
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
               paginationPageNumb.push(i);
           
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }
        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    },
})
({
    tabSelected: function(component,event,helper) {
        debugger;
        var tabclick = component.get("v.selTabId");
        if(tabclick == "tab1"){
            component.set("v.listpartrequest","true");
            component.set("v.newpartrequest","false");
            component.set("v.partviewform","false");
        }
        if(tabclick == "tab2"){
            component.set("v.listvendor","true");
            component.set("v.newVendor","false");
            component.set("v.newvendorform","false");
        }
        
    },
    onTabSelect : function(component, event, helper) {
        
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
        
    },
})
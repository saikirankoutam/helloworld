({
    getCaseRecord : function(component, event, helper) { 
        var action = component.get("c.fetchCaseRecord");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue() != null)
                {
                    component.set("v.caseRecord", response.getReturnValue());
                    var value = response.getReturnValue();
                    if(value.PSA_ASM_Validation__c == "Pending"){
                     this.fetchcyclecountrecords(component, event,value.Id);
                      
                    }
                }
                helper.getfilterParts(component, event, helper); 
            }
        });
        $A.enqueueAction(action);	
    },
    getStatusPicklistValues : function(component, event, helper) { 
        var action = component.get("c.fetchStatusPicklistValues");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.statusList", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);	
    },
     getdelaerlocation : function(component, event, helper) { 
        var action = component.get("c.dealerlocation");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.find('inventoryLocation').set('v.value',response.getReturnValue());
            }
        });
        $A.enqueueAction(action);	
    },
    getValidationPicklistValues : function(component, event, helper) { 
        var action = component.get("c.fetchValidationPicklistValues");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.validationList", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);	
    },
    
    getABCPicklistValues : function(component, event, helper) { 
        var action = component.get("c.fetchABCPicklistValues");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.abcList", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);	
    },
    
    getPartCategoryPicklistValues : function(component, event, helper) { 
        var action = component.get("c.fetchPartCategoryPicklistValues");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.partCategoryList", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);	
    },
    
    getfilterParts : function(component, event, helper) {
        var abc = component.find("abc").get("v.value");
        var partCategory = component.find("partCategory").get("v.value");
        var fms = component.find("fms").get("v.value");
        var supplier = component.find("supplier").get("v.value");
        var action = component.get("c.fetchfilteredParts");
        var stage= component.get("v.stage");
        action.setParams({
            "abcVal": abc,
            "partCategoryVal": partCategory,
            "fmsVal": fms,
            "supplierVal": supplier
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.inventoryPartsList", response.getReturnValue());
                this.paginationimplention(component, event, helper);
                
            }
        });
        $A.enqueueAction(action);	
    },
    createCase : function(component, event, helper) { 
        debugger;
        var inventoryPartsList = component.get("v.selectedpartsList");
        var paginationlist = component.get("v.paginationList");
        var selectedPartsList = [];
        var wrapperlist=[];
        var caseRecord = component.get("v.caseRecord");
        var selectParts = false;
        var inv;
       var allValid =true; /*component.find('checkValidity').reduce(function (validSoFar, inputCmp) {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true); */
        var inventorymap = new Map();
        if(inventoryPartsList.length !=0){
            for(inv in inventoryPartsList){
                if(inventoryPartsList[inv].checked == true)
                {
                    selectParts = true;
                    selectedPartsList.push(inventoryPartsList[inv].id);
                    wrapperlist.push(inventoryPartsList[inv]);
                    inventorymap.set(inventoryPartsList[inv].id, inventoryPartsList[inv]);
                }
            } 
        }
        for(inv in paginationlist){
            if(paginationlist[inv].checked == true)
            {
                selectParts = true;
                selectedPartsList.push(paginationlist[inv].id);
                wrapperlist.push(paginationlist[inv]);
                inventorymap.set(paginationlist[inv].id, paginationlist[inv]);
            }
        }
        component.set('v.wrapperList',wrapperlist);
        component.set("v.inventorymap", inventorymap);
        if(allValid && selectParts)
        {
            var action = component.get("c.createCaseRecord");
            action.setParams({
                "inventoryPartsList": selectedPartsList,
                "caseRecord": caseRecord
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var value = response.getReturnValue();
                    var caseRecord = component.get("v.caseRecord");
                    caseRecord.Id = value[0].Case__r.Id;
                    caseRecord.CaseNumber = value[0].Case__r.CaseNumber;
                    caseRecord.Cycle_count_number__c = value[0].Case__r.Cycle_count_number__c;
                    caseRecord.PSA_ASM_Validation__c = value[0].Case__r.PSA_ASM_Validation__c;
                    component.set("v.caseRecord", caseRecord);
                    component.set("v.cycleCountList", value);
                    component.set("v.stage", 'stage2');
                    
                }
            });
            $A.enqueueAction(action);	
        }else{
            helper.showError(component, event, helper, "Please select Inventory Parts list and complete all the required fields");
        }
        
    },
    
    showError : function(component, event, helper, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
        component.set("v.spinner", false);
    },
    showSuccess : function(component, event, helper, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "success",
            "message": msg
        });
        toastEvent.fire();
    },
    
    
    updateCylceCount : function(component, event, helper) {
        var cycleCountComp = component.find("cycleCountComp");
        if(cycleCountComp.length == 1)
            cycleCountComp.validationCheckMethod();
        else
        {
            var x;
            for(x in cycleCountComp)
                cycleCountComp[x].validationCheckMethod();
        }
        var valid = true;
        var cycleCountList = component.get("v.cycleCountList");
        var x;
        for(x in cycleCountList)
        {
            if(cycleCountList[x].PSA_Physical_stock__c == null || cycleCountList[x].PSA_Physical_stock__c == "" || cycleCountList[x].PSA_Physical_stock__c < 0)
                valid = false;
            if(cycleCountList[x].PSA_Remarks__c == null || cycleCountList[x].PSA_Remarks__c == "")
                valid = false;
        }
        helper.submitRecord(component, event, helper);
    },
    
    checkCountMatch : function(component, event, helper) {
        var inventorymap = component.get("v.inventorymap");
        var valid = true;
        var cycleCountList = component.get("v.cycleCountList");
        var c;
        for(c in cycleCountList)
        {
            var record = inventorymap.get(c.Dealer_Inventory__r.Id);
            if(record.avlStock != c.PSA_Physical_stock__c)
                valid = false;
        }
        return valid;
    },
    Pagination :function(component, event,pageNumber){
        debugger;
        var pageSize = component.get("v.pageSize");
        var totalpage=Math.ceil(component.get("v.inventoryPartsList").length/pageSize);
        var   paginationPageNumb=[];
        var cont=1;
        if(pageNumber<7){
            for(var i=1; i<= totalpage; i++){
                paginationPageNumb.push(i);
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
            }
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
                paginationPageNumb.push(i);
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }
        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    },
    paginationimplention : function(component, event, helper) {
        var response=component.get('v.inventoryPartsList');
        var pageSize = component.get("v.pageSize");
        component.set("v.totalSize", component.get("v.inventoryPartsList").length);
        component.set("v.start",0);
        component.set("v.end",pageSize-1);
        var paginationList = [];
        if(response.length < pageSize){
            paginationList=response;
        }
        else{
            for(var i=0; i< pageSize; i++){
                paginationList.push(response[i]); 
            } 
        }
        
        component.set('v.paginationList', paginationList);
        if(response.length==0){
            component.set('v.norecords', true);
        }
        this.Pagination(component, event,'1');
        component.set("v.spinner", false);
        
    },
    getupdatelist :function(component, event,pagelist,updatelist){
        var inv;
        var invmap;
        var wraplist=[];
        var inventorymap = new Map();
        if(updatelist.length !=0){
            for(inv in updatelist){
                inventorymap.set(updatelist[inv].id, updatelist[inv]);
            }
        } 
        for(inv in pagelist){
            inventorymap.set(pagelist[inv].id, pagelist[inv]);
        }
        for(invmap of inventorymap.values()){
            wraplist.push(invmap);
        }
        component.set('v.selectedpartsList',wraplist);
    },
     fetchcyclecountrecords :function(component, event,caseid){
         var action = component.get("c.fetchinventorycyclecoundlist");
          action.setParams({
                "caserecordid": caseid, 
            });
         action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.cycleCountList", response.getReturnValue());
                component.set('v.disablefields',true);
                component.set("v.stage", "stage2");
            }
        });
        $A.enqueueAction(action);	
         
     },
})
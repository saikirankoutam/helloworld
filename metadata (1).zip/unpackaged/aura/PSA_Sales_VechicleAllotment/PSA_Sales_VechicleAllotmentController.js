({
    
    doInit : function(component, event, helper) {
        
        var ord=component.get('v.orderid');
        //alert(ord)
        if(ord=='' || ord==null|| ord=='undefined'){
       
       component.set('v.customerrecord',orderrecord);
       component.set('v.orderitemrecord',null);
       component.find('alltaction').set('v.value',null);
       component.set('v.Allotmentrecord',null);
       component.set('v.Assetrecord',null);
       component.set('v.searchdisable',true);
       component.set('v.Vehiclereceiptrecords',null);
                
        }else{
        helper.IntialLoading(component, event);
        helper.checkBookingStatus(component, event, helper);
        helper.checkInvoicedStatus(component, event, helper);
        }
    },
    search : function(component, event, helper) {  
        var itemrecord=component.get('v.orderitemrecord');
        var action = component.get("c.getInventoryItems");
        action.setParams({ 
            "itemrecord" :itemrecord
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var  vehiclelst=  response.getReturnValue();
                if(vehiclelst=='undefined'||vehiclelst==''||vehiclelst==null){
                  helper.Showtoastmessage(component, event,'No vechile Found with the Combination','error'); 
                }
                else{
                component.set('v.Vehiclereceiptrecords',vehiclelst);
                component.set('v.Submitdisable',false);
                    }
            }
        });
        $A.enqueueAction(action);
    },
    
    
    requisitionchange : function(component, event, helper) {
        var allocationtype=  component.find('alltaction').get('v.value');
        if(allocationtype=='Deallocate'){
            var allotment=component.get('v.Allotmentrecord'); 
            if(allotment==null || allotment==undefined ){
                helper.Showtoastmessage(component, event,'No Allotted records for this order','Error');
            }else{
                document.getElementById("myModal").style.display = "block";
            }  
        }
    },
    Submit : function(component, event, helper) { 
        var x;
        var count=0;
        var vehiclerecord;
        var receiptlist=component.get('v.Vehiclereceiptrecords');
        for(x in receiptlist){
            if(receiptlist[x].Vehicle_Allotted__c == true){
                vehiclerecord=receiptlist[x];
                count+=1;
                
            }
        }
        if(count==0){
            helper.Showtoastmessage(component, event,'Please Select  Any one vehicle record','Error');
        }else if(count>1){
            helper.Showtoastmessage(component, event,'please select only one vehicle record','Error');
        }else if(count==1){
            helper.submitrecord(component, event,vehiclerecord);
            
        }
        
    },
    closeModal : function(component, event, helper) { 
        document.getElementById("myModal").style.display = "none";
    },
    ondeallocate : function(component, event, helper) {
        debugger;
        var allotment=component.get('v.Allotmentrecord'); 
        var action = component.get("c.DeleteAllocaterecord");
        action.setParams({ 
            "AllotmentId" :allotment.Id
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") { 
                
                helper.Showtoastmessage(component, event,'Vehicle De-Allocated Successfully','Success');
                component.set('v.Vehiclereceiptrecords',null);
                component.set('v.searchdisable',false);
                component.find('alltnumb').set('v.value','');
                component.find('alltdate').set('v.value','');
                component.set('v.Allotmentrecord',null);
                document.getElementById("myModal").style.display = "none";
                helper.IntialLoading(component, event);
            }
        });
        $A.enqueueAction(action); 
    }
    
})
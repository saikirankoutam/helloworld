({
    Showtoastmessage : function(component, event,msg,type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": type,
            "message": msg
        });
        toastEvent.fire();
    },
    IntialLoading : function(component, event) {
        var actionlist=[];
        var orderid= component.get('v.orderid');
        var action = component.get("c.Allotmentrecord");
        action.setParams({ 
            "orderId" :orderid
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var  InventoryItems=  response.getReturnValue();
                var orderrecord=InventoryItems.orderrecord;
                component.set('v.customerrecord',orderrecord);
                component.set('v.orderitemrecord',InventoryItems.itemrec);
                var Allotement=orderrecord.Allotments__r;
                if(Allotement !=undefined || Allotement!=''){
                    component.find('alltaction').set('v.value',Allotement[0].PSA_Action__c);
                    component.set('v.Allotmentrecord',Allotement[0]);
                    component.set('v.Assetrecord',InventoryItems.Assetrecord);
                    component.set('v.searchdisable',true);
                    component.set('v.Vehiclereceiptrecords',InventoryItems.vrlist);
                    var  allotmentrecord=Allotement[0];
                    if(allotmentrecord.PSA_Action__c=='Allocate' || allotmentrecord.PSA_Action__c=='Reallocate' ){
                        actionlist.push('None');
                        actionlist.push('Deallocate');  
                       
                    }else{
                         actionlist.push('Reallocate');
                         component.set('v.searchdisable',false); 
                         component.set('v.Allotmentrecord',null);
                         component.set('v.Submitdisable',false);
                        
                    }
                }else{
                    component.set('v.searchdisable',false); 
                    actionlist.push('Allocate');
                }
                component.set('v.actionlist',actionlist);
                var checkUser=component.get('v.checkUser');
                  if(checkUser)
                  {
                     component.set('v.searchdisable',true);
                     component.set('v.Submitdisable',true);
                  }
            }
            
        });
        $A.enqueueAction(action);
    },
    submitrecord : function(component, event,vehiclerecord) {
        var orderid= component.get('v.orderid');
        var itemrecord=component.get('v.orderitemrecord');
        var action = component.get("c.Reallocatevehiclerecord");
        action.setParams({ 
            "orderId" :orderid,
            "productrecord" :itemrecord,
            "receiptrec" :vehiclerecord
            
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                this.IntialLoading(component, event);
                component.set('v.Submitdisable',true);
                this.Showtoastmessage(component, event,'Vehicle Allocated Successfully','Success');
            }
            
        });
        $A.enqueueAction(action);
    },
    checkBookingStatus : function(component, event){
    debugger;
         var bookingid=component.get('v.orderid');
         var action = component.get("c.checkBookingStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
               var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.searchdisable",true);
                component.set("v.Submitdisable",true);
                component.set("v.searchPickdisable",true);
                }
            }
        });
        $A.enqueueAction(action);	    
	 
},
     checkInvoicedStatus : function(component, event){
    debugger;
         var bookingid=component.get('v.orderid');
         var action = component.get("c.checkInvoiceStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                 var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.searchdisable",true);
               
                }
                
            }
        });
        $A.enqueueAction(action);	    
	 
}
})
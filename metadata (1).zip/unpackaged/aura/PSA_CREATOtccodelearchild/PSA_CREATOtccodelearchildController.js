({
    doInit : function(component, event, helper) { 
        component.set("v.itemrecord.totalBasicValue", 0);
        component.set("v.itemrecord.totalTax", 0);
        component.set("v.itemrecord.totalInvoiceValue", 0);
        var product=component.get('v.itemrecord.Product2.PSA_Part_Number__c');
        var stocklist=component.get('v.stocklist');
        for(var x in stocklist){
            
            if(stocklist[x].PSA_Product__r.PSA_Part_Number__c==product){
                component.set('v.currentstock',stocklist[x].PSA_Current_Stock__c);
                component.set('v.Avlstock',stocklist[x].PSA_Quantity__c);
                
            }
            
        }
        
        var avlqty=component.get('v.Avlstock');
        if(avlqty==0){
            component.set('v.qtydisabled',true);
        }
        var cgst=intemrecord.Product2.PSA_CGST__c;
        var sgst=intemrecord.Product2.PSA_SGST__c;
        component.set('v.igst',parseInt(cgst)+parseInt(sgst));
    },
    qtychange:function(component, event, helper){
        component.set("v.quanityerrmsg",'');
        var intemrecord=component.get('v.itemrecord');
        var invqty = component.find("invqty").get("v.value");       
        var listprice = intemrecord.UnitPrice;
        var physicalqty = intemrecord.Quantity; 
        var isvalid=true;
        var avlqty=component.get('v.Avlstock');
        if(invqty>avlqty){
            isvalid=false;
            component.find("invqty").set("v.value",'');
            helper.showErrorToast(component,event,'Qty less than or equal  to Avialble Qty');
            
        }
        if(invqty>physicalqty && isvalid)
        {                   
            helper.showErrorToast(component,event,'Qty less than or equal  to Req qty');
            component.find("invqty").set("v.value",0);
            component.set("v.itemrecord.totalBasicValue", 0);
            component.set("v.itemrecord.totalDiscountValue", 0);
            
            component.set("v.itemrecord.totalTax", 0);
            component.set("v.itemrecord.totalInvoiceValue", 0);
            component.set("v.totalTax", 0);
            component.set("v.taxablevalue", 0);
            component.set("v.totalInvoiceValue",0);
        }else if(invqty >0 && isvalid)
        {   
            var discountpercentage=10;
            var discountval = 0;
            var cgst=intemrecord.Product2.PSA_CGST__c;
            var sgst=intemrecord.Product2.PSA_SGST__c;
            var netdealerprice = invqty*listprice;  
            discountval = (netdealerprice*discountpercentage)/100;
            discountval=Math.round(discountval);
            var taxableValue = netdealerprice-discountval;
            var totaltax = Math.round((taxableValue*cgst/100 + taxableValue*sgst/100));
            component.set("v.totalTax", totaltax);
            
            component.set("v.totalInvoiceValue", parseFloat(taxableValue)+parseFloat(totaltax));
            component.set("v.taxablevalue", taxableValue);
            component.set("v.itemrecord.totalDiscountValue", discountval);
            component.set("v.itemrecord.totalBasicValue", netdealerprice);
            component.set("v.itemrecord.totalTax", parseFloat(totaltax));
            component.set("v.itemrecord.totalInvoiceValue", parseFloat(taxableValue)+parseFloat(totaltax));
        }
        if(invqty ='' ||invqty == 0 || invqty==null ||invqty<0){        
            component.set("v.totalTax", 0);
            component.set("v.taxablevalue", 0);
            component.set("v.totalInvoiceValue",0);
            component.set("v.itemrecord.totalBasicValue", 0);
            component.set("v.itemrecord.totalTax", 0);
            component.set("v.itemrecord.totalInvoiceValue", 0);
            component.set("v.itemrecord.totalDiscountValue", 0);
            
        }
        var compEvent = component.getEvent("calcOTCcodealer");
        compEvent.fire();
    },
    handleValidation:function(component, event,helper){
        
        var  isvalid=true;
        var disable=component.get('v.qtydisabled');
        if(!disable){
            var invqty = component.find("invqty").get("v.value");
            component.set("v.quanityerrmsg",'');
            $A.util.removeClass(invqty,"disp-block");
            $A.util.addClass(invqty,"disp-none");
            if(invqty ='' ||invqty == 0  ||invqty=='undefined' || invqty==null){ 
                isvalid=false;
                component.set("v.quanityerrmsg",'This is Required field');
                $A.util.removeClass(invqty,"disp-none");
                $A.util.addClass(invqty,"disp-block");
                
            }
        }
        return isvalid;
        
    }
})
({
    fetchPickLists: function(component, event) {
        
        var action = component.get("c.fetchdeliverylocationPicklist");
        action.setCallback(this, function(response) {
        component.set("v.locdel", response.getReturnValue());
    		});
        $A.enqueueAction(action);
       
     },  
    
     validatePartForm : function(component, event, helper){
       
        var isValid = true;
         var insud=component.get("v.register");
         var regeffct = component.get("v.effect");
         var  type1  = component.find("type1").get("v.value");
          if(type1==''|| type1=='undefined'|| type1==null){
           type1 =insud.PSA_Registration_Type1__c;              
          }
        // alert(regeffct);
        /*var  registby = component.find("resisterby").get("v.value");
         if(type1=='Permanent'){
           registby =insud.PSA_Registration_By__c;              
          }
        
        var  type2  = component.find("type2").get("v.value");
          if(type2==''|| type2=='undefined'|| type2==null){
           type2 =insud.PSA_Registration_Type2__c;              
          }
        var  resstatus  = component.find("resstatus").get("v.value");
         if(resstatus==''|| resstatus=='undefined'|| resstatus==null){
           resstatus =insud.PSA_Registration_Status__c;      
              
          }
        var  location  = component.find("location").get("v.value"); 
         if(location==''|| location=='undefined'|| location==null){
           location =insud.PSA_Delivery_Location__c;              
          }
        var  place  = component.find("resplace").get("v.value");
        */
       //  var   regdat = component.find("regdat").get("v.value");
        var  num = component.find("num").get("v.value");
         
       // var  address = component.find("address").get("v.value");
       var  plan = component.find("plan").get("v.value");
      //  var   revised = component.find("revise").get("v.value");
       // var   insight = component.find("insight").get("v.value");
       // var now = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD"); 
       // regdat = $A.localizationService.formatDate(regdat, "dd/MM/yyyy"); 
        //plan = $A.localizationService.formatDate(plan, "dd/MM/yyyy");
        //revised = $A.localizationService.formatDate(revised, "dd/MM/yyyy");
         
       /* component.set("v.rgstbyErrMsg",'');
        $A.util.removeClass(registby,"disp-block");
        $A.util.addClass(registby,"disp-none");
        component.set("v.type1ErrMsg",'');
        $A.util.removeClass(type1,"disp-block");
        $A.util.addClass(type1,"disp-none");
        component.set("v.type2ErrMsg",'');
        $A.util.removeClass(type2,"disp-block");
        $A.util.addClass(type2,"disp-none");
        component.set("v.statusErrMsg",'');
        $A.util.removeClass(resstatus,"disp-block");
        $A.util.addClass(resstatus,"disp-none");
        component.set("v.delocErrMsg",'');
        $A.util.removeClass(location,"disp-block");
        $A.util.addClass(location,"disp-none");
        component.set("v.placeErrMsg",'');
        $A.util.removeClass(place,"disp-block");
        $A.util.addClass(place,"disp-none");
        
        component.set("v.addErrMsg",'');
        $A.util.removeClass(address,"disp-block");
        $A.util.addClass(address,"disp-none");
       
          component.set("v.insightErrMsg",'');
        $A.util.removeClass(insight,"disp-block");
        $A.util.addClass(insight,"disp-none");*/
        
      /*   component.set("v.rdErrMsg",'');
        $A.util.removeClass(regdat,"disp-block");
        $A.util.addClass(regdat,"disp-none");*/
        component.set("v.numErrMsg",'');
        $A.util.removeClass(num,"disp-block");
        $A.util.addClass(num,"disp-none");
         component.set("v.planErrMsg",'');
        $A.util.removeClass(plan,"disp-block");
        $A.util.addClass(plan,"disp-none");
         
       /* component.set("v.revisedErrMsg",'');
        $A.util.removeClass(revised,"disp-block");
        $A.util.addClass(revised,"disp-none");*/
         
        /* if( registby== '--None--' || registby==''|| registby=='undefined'|| registby==null){
            isValid = false;
            component.set("v.rgstbyErrMsg",'This is a required field');
            $A.util.removeClass(registby,"disp-none");
            $A.util.addClass(registby,"disp-block");
        }
         if( type1== '--None--' || type1==''|| type1=='undefined'|| type1==null){
            isValid = false;
            component.set("v.type1ErrMsg",'This is a required field');
            $A.util.removeClass(type1,"disp-none");
            $A.util.addClass(type1,"disp-block");
        }
         if( type2== '--None--' || type2==''|| type2=='undefined'|| type2==null){
            isValid = false;
            component.set("v.type2ErrMsg",'This is a required field');
            $A.util.removeClass(type2,"disp-none");
            $A.util.addClass(type2,"disp-block");
        }
          if( resstatus== '--None--' || resstatus==''|| resstatus=='undefined'|| resstatus==null){
            isValid = false;
            component.set("v.statusErrMsg",'This is a required field');
            $A.util.removeClass(resstatus,"disp-none");
            $A.util.addClass(resstatus,"disp-block");
        }
         if( location== '--None--' || location==''|| location=='undefined'|| location==null){
            isValid = false;
            component.set("v.delocErrMsg",'This is a required field');
            $A.util.removeClass(location,"disp-none");
            $A.util.addClass(location,"disp-block");
        }*/

        /*if(registby == 'undefined'|| registby == '' || registby == null){
            component.set("v.rgstbyErrMsg",'This is a required field');
            $A.util.removeClass(registby,"disp-none");
            $A.util.addClass(registby,"disp-block");
            isValid = false;
        }
        if(type1 == 'undefined'|| type1 == '' || type1 == null){
            component.set("v.type1ErrMsg",'This is a required field');
            $A.util.removeClass(type1,"disp-none");
            $A.util.addClass(type1,"disp-block");
            isValid = false;
        }
         
          if(type2 == 'undefined'|| type2 == '' || type2 == null){
            component.set("v.type2ErrMsg",'This is a required field');
            $A.util.removeClass(type2,"disp-none");
            $A.util.addClass(type2,"disp-block");
            isValid = false;
        }*/
         /* if(place == 'undefined'|| place == '' || place == null){
            component.set("v.placeErrMsg",'This is a required field');
            $A.util.removeClass(place,"disp-none");
            $A.util.addClass(place,"disp-block");
            isValid = false;
        }*/
         /*if( regdat =='undefined'|| regdat == '' || regdat == null){
             component.set("v.rdErrMsg",'This is a required field');
             $A.util.removeClass(regdat,"disp-none");
             $A.util.addClass(regdat,"disp-block");
             isValid = false;
         } 
         else{
             if(regdat < regeffct){
             component.set("v.rdErrMsg",'Registration Date should not be less than booking Date ');
             $A.util.removeClass(regdat,"disp-none");
             $A.util.addClass(regdat,"disp-block");
             isValid = false;
             }*/
        /* else{
             if(regdat<now)
             {
                 component.set("v.rdErrMsg",'Registration Date should not be less than Current Date ');
                 $A.util.removeClass(regdat,"disp-none");
                 $A.util.addClass(regdat,"disp-block");
                 isValid = false;
             }}*/
         
         if(type1=='Permanent'){
          if(num == 'undefined'|| num == '' || num == null){
            component.set("v.numErrMsg",'This is a required field when type is permanent');
            $A.util.removeClass(num,"disp-none");
            $A.util.addClass(num,"disp-block");
            isValid = false;
          }
         }
         /* if(address == 'undefined'|| address == '' || address == null){
            component.set("v.addErrMsg",'This is a required field');
            $A.util.removeClass(address,"disp-none");
            $A.util.addClass(address,"disp-block");
            isValid = false;
        }*/
        /*  if(plan == 'undefined'|| plan == '' || plan == null){
            component.set("v.planErrMsg",'This is a required field');
            $A.util.removeClass(plan,"disp-none");
            $A.util.addClass(plan,"disp-block");
            isValid = false;
        }
       
         if(revised == 'undefined'|| revised == '' || revised == null){
            component.set("v.revisedErrMsg",'This is a required field');
            $A.util.removeClass(revised,"disp-none");
            $A.util.addClass(revised,"disp-block");
            isValid = false;
        }*/
          if( plan =='undefined'|| plan == '' || plan == null){
            component.set("v.planErrMsg",'This is a required field');
            $A.util.removeClass(plan,"disp-none");
            $A.util.addClass(plan,"disp-block");
            isValid = false;
        }
          else
          {if(plan < regeffct){
              component.set("v.planErrMsg",'Planned Date  should not be less than booking Date ');
            $A.util.removeClass(plan,"disp-none");
            $A.util.addClass(plan,"disp-block");
            isValid = false;
          }}
        /*else{
        if(plan<now)
        {
            component.set("v.planErrMsg",'Planned Date should be less than Current Date ');
            $A.util.removeClass(plan,"disp-none");
            $A.util.addClass(plan,"disp-block");
            isValid = false;
        }}*/
      /* if( revised=='undefined'|| revised == '' || revised == null){
            component.set("v.revisedErrMsg",'This is a required field');
            $A.util.removeClass(revised,"disp-none");
            $A.util.addClass(revised,"disp-block");
            isValid = false;
        }
         else{
             if(revised < regeffct){
              component.set("v.revisedErrMsg",'Revise Date  should not be less than booking Date ');
            $A.util.removeClass(revised,"disp-none");
            $A.util.addClass(revised,"disp-block");
            isValid = false;
             }}*/
        /*else{
        if(revised<now)
        {
            component.set("v.revisedErrMsg",'Revised Date should not be less than Current Date');
            $A.util.removeClass(revised,"disp-none");
            $A.util.addClass(revised,"disp-block");
           
            isValid = false;
        }
        }*/
         
         
         
         /* if(insight == 'undefined'|| insight == '' || insight == null){
            component.set("v.insightErrMsg",'This is a required field');
            $A.util.removeClass(insight,"disp-none");
            $A.util.addClass(insight,"disp-block");
            isValid = false;
        }*/
             return isValid;
    },
         
	fetchRegistrationdetails : function(component, event, helper){
        debugger;
            //var recordid=component.get('v.recordId');
          var action = component.get("c.getRegistrationDetails");
        var book=component.get("v.bookingId");
          
            action.setParams({ 
                "recordid" : book
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var  values= response.getReturnValue();
                this.fetchcustomer(component, event, helper,values);
               component.set("v.effect",values.PSA_Booking_ID__r.EffectiveDate);
                //alert(values.PSA_Booking_ID__r.EffectiveDate);
                    component.set("v.regist",values.PSA_Registration_Date__c);
                //alert(values.PSA_Registration_Date__c);
              
               component.set('v.register',values[0]);
                if(values.Id==null||values.Id==''||values.Id=='undefined'){
              insud.PSA_Communicate_Revise_date__c=false;
                    component.set("v.register", values);
                
                    
               }
                else{
                component.set("v.InsuranceID",values.Id);
               // component.set("v.disableFields",true);
                component.set("v.register", response.getReturnValue());
                component.set("v.disName1",values.PSA_Registration_Type1__c); 
                component.set("v.regBy", values.PSA_Registration_By__c);
                component.set("v.regTypeone", values.PSA_Registration_Type1__c);
                component.set("v.regTypeTwo", values.PSA_Registration_Type2__c);
                component.set("v.regStatus", values.PSA_Registration_Status__c);
                component.set("v.changeReason", values.PSA_Change_Delivery__c);
                component.set("v.regDeloc", values.PSA_Delivery_Location__c);
                    component.set("v.disableSave",true);
                      }
            });
            $A.enqueueAction(action);	
     },
     showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
     MAX_FILE_SIZE: 4500000,
    CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
    uploadHelper: function(component, event,parentid) {
        debugger;
        var fileInput = component.find("fileId").get("v.files");
        var file = fileInput[0];
        var self = this;
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }
        var objFileReader = new FileReader();
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
            self.uploadProcess(component, file, fileContents,parentid);
        });
        objFileReader.readAsDataURL(file);
    },
    checkfilesize: function(component, event) {
        var fileInput = component.find("fileId").get("v.files");
        var file = fileInput[0];
        var self = this;
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }else{
            component.set('v.fileName',file.name);
        }
        var objFileReader = new FileReader();
        
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
        });
        
        objFileReader.readAsDataURL(file);
    },
    errorToast : function(component, event, Message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": Message
        });
        toastEvent.fire();
    },
    uploadProcess: function(component, file, fileContents,parentid) {
        var startPosition = 0;
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '',parentid);
    },
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId,parentid) {
        var getchunk = fileContents.substring(startPosition, endPosition);
        var action = component.get("c.saveChunk");
        
        action.setParams({
            parentId: parentid,
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
        action.setCallback(this, function(response) {
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.submitdiasable',true);
                this.Successmessage(component, event);
            }
            
        });
        $A.enqueueAction(action);
    },
    fetchcustomer : function(component, event, helper,values){
        var action1 = component.get("c.gettinGCustomeriD");
        var book=component.get("v.bookingId");
        action1.setParams({ 
            "recordid" : book
        });
        action1.setCallback(this, function (response) {
            var state = response.getState();
            var  valuesd= response.getReturnValue();
           // component.set("v.custName",valuesd.PSA_Customer_Account__r.Name);
            component.set("v.forcusthome",valuesd.PSA_Customer_Account__r.PersonMailingStreet);
            component.set("v.forcustoff",valuesd.PSA_Customer_Account__r.BillingStreet);
            var addressWrap='';
            if(valuesd.Account.BillingStreet !='undefined' && valuesd.Account.BillingStreet  !='' && valuesd.Account.BillingStreet  !=null)
                {
                    addressWrap= valuesd.Account.BillingStreet +',' ; 
                }
            if(valuesd.Account.BillingCity !='undefined' && valuesd.Account.BillingCity  !='' && valuesd.Account.BillingCity  !=null)
                {
                    addressWrap=addressWrap+valuesd.Account.BillingCity +',' ;  
                }
             if(valuesd.Account.BillingState !='undefined' && valuesd.Account.BillingState  !='' && valuesd.Account.BillingState  !=null)
                {
                    addressWrap= addressWrap+valuesd.Account.BillingState +',' ;  
                }
             
            if(valuesd.Account.BillingPostalCode !='undefined' && valuesd.Account.BillingPostalCode  !='' && valuesd.Account.BillingPostalCode  !=null)
                {
                    addressWrap=addressWrap+valuesd.Account.BillingPostalCode +','  ; 
                }
            component.set("v.fordealadd",addressWrap);
           
            
             
        });
        $A.enqueueAction(action1);
        
    },
    
    
     checkVDNstatus : function(component, event, helper){
     var action = component.get("c.getcheckVdn");
       var book=component.get("v.bookingId");
        action.setParams({
            "orderId" : book,
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.disableEdit",true);
                //component.set("v.disableSave",true);
                }                
            }
               
     
        });
      $A.enqueueAction(action);
        
    },
    
    fetchReasonChangePicklist: function(component, event) {
       var action = component.get("c.fetchReasonChangePicklist");
        action.setCallback(this, function(response) {
        component.set("v.reasonChangePickList", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     },  
    
    fetchRegstatusPicklist: function(component, event) {
        var action = component.get("c.fetchRegstatusPicklist");
        action.setCallback(this, function(response) {
        component.set("v.statusreg", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
     fetchRegbyPicklist: function(component, event) {
        var action = component.get("c.fetchRegbyPicklist");
        action.setCallback(this, function(response) {
        component.set("v.byreg", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
     fetchtypePicklist: function(component, event) {
        var action = component.get("c.fetchtypePicklist");
        action.setCallback(this, function(response) {
        component.set("v.typone", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
     fetchtypeUsePicklist: function(component, event) {
        var action = component.get("c.fetchtypeUsePicklist");
        action.setCallback(this, function(response) {
        component.set("v.typuse", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
    checkBookingStatus : function(component, event){
    debugger;
         var bookingid=component.get('v.bookingId');
         var action = component.get("c.checkBookingStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.disableEdit",true);
                //component.set("v.disableSave",true);
                }
            }
        });
        $A.enqueueAction(action);	    
	 
},
     fetchdocumenturl : function(component, event,helper) {
         var bookingid=component.get('v.bookingId');
        var action = component.get("c.fetchdocumenturl");
        action.setParams({ 
            "bookingId" : bookingid
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                console.log('response.getReturnValue()'+response.getReturnValue());
                component.set('v.attachurl',storeResponse); 
                var attachment= storeResponse;
                 var pdfurl ='../PSA_viewRcfile?Id='+attachment;
                 window.open(pdfurl,"_blank","width=600, height=550"); 
            }
        });
        $A.enqueueAction(action);
    },
   
})
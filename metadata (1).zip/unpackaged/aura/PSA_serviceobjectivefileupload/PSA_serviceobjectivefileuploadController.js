({    
    doInit : function(component, event, helper) {
        //component.find("yearselectfile").set("v.yearSelectedupload",2019);
        //alert("In INIT"+component.get("v.yearSelectedupload")); 
        helper.getYears(component, event, helper);

    },
    handleSave: function(component, event, helper) {
        component.set("v.errorMessage",'');
        if (component.find("fuploader").get("v.files").length > 0) {
             component.set("v.showSavebtn",true);
            helper.uploadHelper(component, event);
        } else {
            alert('Please Select a Valid File');
        }
    },
    
     getSelectedYearupload : function(component, event, helper) {
          component.set("v.spinner", true);
        var selectyr = component.find("yearselectfile").get("v.value");
        component.set("v.yearSelectedupload", selectyr);
          component.set("v.spinner", false);
         
     },
    handleFilesChange: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName", fileName);
        component.set("v.showSavebtn",false);
    },
    
    handleCancel: function(component, event, helper) {
         var fileName = 'No File Selected..';
         component.set("v.fileName", fileName);
        component.set("v.errorMessage","");
        var eventListPage = component.getEvent("cancelObjFileUpload");
        eventListPage.setParams({"listpage" : false});
        eventListPage.fire();
    },
     downloadCsv : function(component,event,helper){        
        var stockData = component.get("v.objectiveReclist"); 
        var csv = helper.convertArrayOfObjectsToCSV(component,stockData);   
        if (csv == null){return;} 
        var hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_self'; // 
        hiddenElement.download = 'service objectives.csv';  
        document.body.appendChild(hiddenElement); 
        hiddenElement.click(); 
    },
    
    
})
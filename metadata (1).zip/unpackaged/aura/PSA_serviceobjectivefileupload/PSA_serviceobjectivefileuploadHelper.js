({
    MAX_FILE_SIZE: 4500000, //Max file size 4.5 MB 
    CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
    
    uploadHelper: function(component, event) {
   
        var fileInput = component.find("fuploader").get("v.files");
        var file = fileInput[0];
        var self = this;
       if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }
        
        var objFileReader = new FileReader();
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            
            fileContents = fileContents.substring(dataStart);
            self.uploadProcess(component, file, fileContents);
        });
        
        objFileReader.readAsDataURL(file);
    },
    
    uploadProcess: function(component, file, fileContents) {
        var startPosition = 0;
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
    
     getYears : function(component, event, helper)  {
            component.set('v.norecords', false);
            var action = component.get('c.getObjectiveyears');
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(" State **** "+state);
                if(state == 'SUCCESS') {
                    var records =response.getReturnValue();            
                    component.set("v.yearlist", records);
                    /*Set Default Year as Current Year - Nancy*/
                    component.set("v.yearSelectedupload",$A.localizationService.formatDate(new Date(), "YYYY"));                }
            });
            $A.enqueueAction(action);
        },
    
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        
        component.set("v.spinner", true);
        debugger;
        var getchunk = fileContents.substring(startPosition, endPosition);
        //var selectyr = component.set("v.yearFile");
        //  var selectyr = '2019';
        var selectyr = component.get("v.yearSelectedupload");
        var action = component.get("c.saveObjectiveFile");
        action.setParams({
            parentId: component.get("v.parentId"),
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId,
            year :selectyr
        });
        
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            var isvalid = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS" && isvalid === "Uploaded Successfully") {
              
                var eventListPage = component.getEvent("cancelObjFileUpload");
                eventListPage.setParams({"listpage" : false,"CNFStatus" : "uploaded"});
                eventListPage.fire();
                var fileName = 'No File Selected..';
         		component.set("v.fileName", fileName);
        		component.set("v.errorMessage","");
               // component.set("v.showError",true);
               // component.set("v.errorMessage",isvalid);
                
            }
           else if (state === "SUCCESS" && isvalid != "Uploaded Successfully") {
                 component.set("v.showError",true);
                component.set("v.errorMessage",isvalid);
         }
           else if (state === "INCOMPLETE") {
                alert("From server: " + response.getReturnValue());
            } else if (state === "ERROR") {
                var errors = response.getError();
                component.set("v.showError",true);
                component.set("v.errorMessage",errors[0].message);
            } 
            
        component.set("v.spinner", false);
        });
        // enqueue the action
        $A.enqueueAction(action);
    },
     convertArrayOfObjectsToCSV : function(component,objectRecords){
        var csvStringResult, counter, keys, columnDivider, lineDivider;
        if (objectRecords == null || !objectRecords.length) {
            return null;
        }
        columnDivider = ',';
        lineDivider =  '\n'; 
        keys = ['Dealercode','Dealername','Location','Servicetype','variant','Jan','Feb','mar','apr','may','june','july','aug','sep','oct','nov','dec'];
        
        csvStringResult = '';
     csvStringResult += ['Dealer code','Dealer Name','Location','Service type','Dectription','Jan','Feb','Mar','Apr','May','June','July','Aug','Sep','Oct','Nov','Dec'];
        csvStringResult += lineDivider;
        
        for(var i=0; i < objectRecords.length; i++){   
            counter = 0;           
            for(var sTempkey in keys) {
                var skey = keys[sTempkey] ;  
                if(counter > 0){ 
                    csvStringResult += columnDivider; 
                }
                if(objectRecords[i][skey] != undefined ){
                         csvStringResult += '"'+ objectRecords[i][skey]+'"';
                }else{
                    csvStringResult += '"'+ '' +'"';
                }
                
                counter++;
                
            } 
            csvStringResult += lineDivider;
        }       
        return csvStringResult;        
    },
})
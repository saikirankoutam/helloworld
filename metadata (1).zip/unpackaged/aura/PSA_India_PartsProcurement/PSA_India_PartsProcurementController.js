({
    
	onTabSelect : function(component, event, helper) {
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
        if(id='OEM Review Parts'){
            component.set('v.LabourMasterDetailView',false);
        }
      
    },
        handleLabourIdPass : function(component, event, helper) {    
        var Labid = event.getParam("OemId");
        component.set("v.LabourMasterId", Labid);
        component.set("v.LabourMasterDetailView", true);
    },
       backtolistviewpage : function(component, event, helper) {
        var lmdvbool = event.getParam("listPage");
        component.set("v.LabourMasterDetailView", lmdvbool);
    },
      backetooemreview : function(component, event, helper) {
           component.set("v.currTab", 'OEM Review Parts');
        component.set("v.LabourMasterDetailView", false);
    },
    handlevalidateMenu : function(component, event, helper) {
        debugger;
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        console.log('validationItem@@@@@@@@@'+validationItem);
        component.set("v."+validationItem, validation);
        component.set("v.currTab",validationItem);
      var defaultItem = event.getParam("defaultItem");
      //  console.log("validationItem -- "+validationItem+"::"+defaultItem);
       if (defaultItem) {
       component.set("v.currTab", validationItem);            
      }
    }    
})
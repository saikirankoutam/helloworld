({
    
     dummy : function(component, event, helper) {
        helper.currencytowordformat(component, event);
    },
    Doinit: function (component, event, helper) {
        debugger;
        
        var invoiceId = component.get("v.OEMinvoiceId");
        //alert(invoiceId);
	var action = component.get('c.getoeminvoicedetails');
        action.setParams({
            "invoiceId" : invoiceId
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
              
                var storeResponse = response.getReturnValue();
                 // alert(storeResponse);
                console.log('Parts List >>>>>>'+JSON.stringify(storeResponse));
                component.set("v.InvoicePartsList", storeResponse);
                component.set("v.Invoice",storeResponse[0]);
                var totalinvoiceamount = 0;
                var invoicerec=storeResponse[0];
                var taxamount=invoicerec.PSA_Invoiceid__r.Tax_Amount__c;
               
                var gstamount=taxamount/2;
                component.set('v.CGSTAmount',gstamount);
                component.set('v.SGSTAmount',gstamount);
                for(var i=0;i<storeResponse.length;i++){
                    totalinvoiceamount +=storeResponse[i].Invoice_Amount__c;
                }
                 helper.currencytowordformat(component, event,totalinvoiceamount);
               // component.set("v.totalinvamount",totalinvoiceamount);
                
            }
        });
        
        $A.enqueueAction(action);
           
    },
      cancelSaveRecord : function(component, event){
        var eventListPage = component.getEvent("displayinvoiceListPageParts");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
        
})
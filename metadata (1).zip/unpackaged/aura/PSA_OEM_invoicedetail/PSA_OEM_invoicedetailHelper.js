({
	 currencytowordformat : function(component, event, totalvalue){
         var action = component.get("c.currencytoword");
            action.setParams({
                "invoiceamount" : Math.round(totalvalue)
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                     component.set("v.totalinvamount",storeResponse);
                }
            });
            $A.enqueueAction(action);
         
    },
    
   
})
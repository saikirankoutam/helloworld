({
	doInit : function(component, event, helper) {
		
         var action = component.get("c.fetchvendorAssNames");
        
        	action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.VendorList", records);
            }
        });
        $A.enqueueAction(action);
    },
    ONVendor : function(component, event, helper) {
         var target = event.getSource().get('v.value');
        var compEvent = component.getEvent("monthlyOrderIdPass");
        compEvent.setParams({"currentMonthlyOrderId" : target });
    	compEvent.fire();
        
    }

})
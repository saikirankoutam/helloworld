({
    doInit : function(component, event, helper) {
        helper.requisitionnumberload(component, event);	
    },
    reqnumberchange : function(component, event, helper) {
        component.set('v.newreq',false);
        
        var reqnumber=component.find('reqnumber').get('v.value');
        var action = component.get("c.fetchpartreqrecords");
        action.setParams({
            "reqnumber" : reqnumber
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var rows = response.getReturnValue();
                component.set('v.reqrecords',rows);
                component.set('v.detailreq',true);
            }
        });
        $A.enqueueAction(action);
    },
    createnewreq : function(component, event, helper) {
        var cmpTarget = component.find('subbtn');
        component.set('v.detailreq',false);
        component.set('v.reqrecords',null);
        component.set('v.subdisable',false);
        
        component.find('reqnumber').set('v.value','None');
        var repairid=component.get("v.repairOrderId");
        var action = component.get("c.fetchlitemrecords");
        action.setParams({
            "repairorderid" : repairid
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                $A.util.removeClass(cmpTarget,'disablebtn');
                var rows = response.getReturnValue();
                component.set('v.Reqlist',rows);
                component.set('v.newreq',true);
            }
        });
        $A.enqueueAction(action);
    },
    Submitreq : function(component, event, helper) {
        var cmpTarget = component.find('subbtn');
        var selectedlist=[];
        var requestlist=component.get('v.Reqlist');
        for(var i=0; i<requestlist.length; i++){
            if(requestlist[i].checked)
                selectedlist.push(requestlist[i]);
        }
        if(selectedlist.length>0){
             //$A.util.addClass(cmpTarget,'disablebtn');
            helper.createrequision(component, event,selectedlist);
        }else{
            helper.ErrorToast(component, event,'Please select atleast one part number for Requisition');
        }
    },
    closereq : function(component, event, helper) {
          component.set('v.detailreq',false);
        component.set('v.newreq',false);
        
    }
})
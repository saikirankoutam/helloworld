({
	requisitionnumberload : function(component, event) {
        var action = component.get("c.fetchrequisitionrecords");
            action.setParams({
                "wokorderid" : component.get("v.repairOrderId")
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set('v.Reqnumbers',response.getReturnValue());
                }
            });
            $A.enqueueAction(action);
	},
    createrequision : function(component, event,selectedlist) {
        var isvalid = true;
      var finalvalidity=true;
        var childCmp = component.find("cycleCountComp");
        if(childCmp.length){
            for(var i=0; i<childCmp.length; i++){
                isvalid=childCmp[i].validationCheckMethod();
                if(!isvalid)
                finalvalidity=false;
            }
                
        } else{
            isvalid=childCmp.validationCheckMethod();
        }
        if(finalvalidity && isvalid ){
         var cmpTarget = component.find('subbtn');
         $A.util.addClass(cmpTarget,'disablebtn');
         var action = component.get("c.createrquistionrecords");
            action.setParams({
                "wrapperlist" : selectedlist
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set('v.newreq',false);
                    this.requisitionnumberload(component, event);
                    this.Suceestoast(component, event,'Requisition record created Successfully');
                }
            });
            $A.enqueueAction(action);
    }
    },
    Suceestoast : function(component, event, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "Success",
            "message": message
        });
        toastEvent.fire();
    },
    ErrorToast : function(component, event, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "Error",
            "message": message
        });
        toastEvent.fire();
    },
})
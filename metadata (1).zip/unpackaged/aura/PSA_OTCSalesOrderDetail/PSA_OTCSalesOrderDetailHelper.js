({
	  fetchotcorderitem : function(component, event) {
        debugger;  
        var action = component.get("c.getPOtitems");
        var OrderId = component.get("v.OrderId");   
         // alert(OrderId);
        action.setParams({
            "orderid" : component.get("v.OrderId")            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {               
                var rows = response.getReturnValue();
                component.set("v.partsList", rows);                
            }
        });
        $A.enqueueAction(action);
    },
     getotcorderinfo : function(component, event) {
        debugger;  
        var action = component.get("c.getorderinfo");
        var OrderId = component.get("v.OrderId");        
        action.setParams({
            "orderid" : component.get("v.OrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {               
                var rows = response.getReturnValue();
                component.set("v.Orderinfo", rows);  
                
            }
        });
        $A.enqueueAction(action);
    },
    getinvoiceinfo : function(component, event) {
        debugger;  
        var action = component.get("c.getinvoice");
        var OrderId = component.get("v.OrderId");        
        action.setParams({
            "orderid" : component.get("v.OrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {               
                var rows = response.getReturnValue();
                component.set("v.invoiceinfo", rows);  
                
            }
        });
        $A.enqueueAction(action);
    },
    showErrorToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "Error"
        });
        toastEvent.fire();  
    },

})
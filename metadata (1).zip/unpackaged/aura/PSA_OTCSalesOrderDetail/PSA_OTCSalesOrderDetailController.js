({
	 doinit : function(component, event, helper) {
        debugger;
		helper.fetchotcorderitem(component, event);
        helper.getotcorderinfo(component, event); 
        helper.getinvoiceinfo(component,event);
	},
     GenerateInvoice : function(component, event, helper) {
     debugger;
        var Orderid = component.get("v.OrderId");         
        var action = component.get("c.getorder");        
        action.setParams({
            "orderid" : Orderid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var lineid =''
                var storeResponse = response.getReturnValue();
                for(var i = 0; i < storeResponse.length; i++){
                    lineid =storeResponse[0].Id;
                    
                }
                if(storeResponse.length>0){
                    var recordId = event.target.id;               
                    var pdfurl ='../PSA_OTCSaleCustomerInvoice?Id='+lineid;
                    window.open(pdfurl,"_blank","width=600, height=550"); 
                }
                 else{
                     var Message= 'Order Not Found';
                    helper.showErrorToast(component,event,Message);
            	}
            }
          
          });
         $A.enqueueAction(action);
     }
})
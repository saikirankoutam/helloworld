({
    showToast : function(component, event, helper) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            type : 'Error',
            message:'Value should not be greater than Order Limit',
           
        });
        toastEvent.fire();
    },
    showErrorToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "Error"
        });
        toastEvent.fire();  
    },
	getdisablebuttons : function(component,event,helper) {
        debugger;
        var yearsel = component.get("v.yearSelectedchild");
        var disableallMonths;
        var today = new Date();
        var fullYear =today.getFullYear();
        var nextYear = today.getFullYear()+1;
        var month = today.getMonth();
        var dateto = today.getDate();
        if(yearsel == "option"){
            yearsel = fullYear;
        }
        
        if(yearsel == fullYear){
            if(dateto >20){
                 month = month+3;
            }
            else{
            month = month+2;
            }
        }
        if(yearsel == nextYear && month <11){
            month = 0;
        }
        if(yearsel == nextYear && month >=11){
             if(dateto >20){
                  month = 2;
             }
            else{
            month = 1;
            }
        }
        
        for( var i=0; i<=month;i++){
            if(i==1) component.set("v.JanButton", true);
            if(i==2) component.set("v.FebButton", true);
            if(i==3) component.set("v.MarButton", true);
            if(i==4) component.set("v.AprButton", true);
            if(i==5) component.set("v.MayButton", true);
            if(i==6) component.set("v.JunButton", true);
            if(i==7) component.set("v.JulButton", true);
            if(i==8) component.set("v.AugButton", true);
            if(i==9) component.set("v.SepButton", true);
            if(i==10) component.set("v.OctButton", true);
            if(i==11) component.set("v.NovButton", true);
            if(i==12) component.set("v.DecButton", true);
            
        }

	},
   
})
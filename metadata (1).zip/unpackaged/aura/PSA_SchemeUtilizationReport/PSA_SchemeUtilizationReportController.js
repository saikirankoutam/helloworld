({
    doInit : function(component, event, helper) {
        var reportid = $A.get("$Label.c.Scheme_Utilization_Report"); 
        var reporturl;
        reporturl = '/dmsindia/s/report/'+reportid;    
        component.set("v.reportlink",reporturl);
    }
})
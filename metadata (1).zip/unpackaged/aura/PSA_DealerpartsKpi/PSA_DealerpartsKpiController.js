({
	doInit: function(component, event, helper) {
         helper.targetsrecords(component,event);
         helper.stockrecords(component,event);
         helper.Vorrecords(component,event);
	}
})
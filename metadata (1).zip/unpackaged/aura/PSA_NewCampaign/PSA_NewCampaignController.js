({
    doInit : function(component, event, helper) { 
        helper.CampaignActionPicklist(component, event, helper) ;  
        helper.createObjectData(component, event);
    },
    removeDeletedRow: function(component, event, helper) {
        var index = event.getParam("indexVar");
        var AllRowsList = component.get("v.PartsSelListEdit");
        if(index!=0){
            AllRowsList.splice(index, 1);
        }
        component.set("v.PartsSelListEdit", AllRowsList);
    },
    Save: function(component, event, helper) {
        if (helper.validatePartForm(component, event)) {
            var cname =component.find("cname").get('v.value');
            var ctype =component.find("ctype").get('v.value');
            var sdate =component.find("sdate").get('v.value');
            var edate =component.find("edate").get('v.value'); 
            var action = component.get("c.saveCampOrderItems");
            action.setParams({
                "ListOrderItem" : component.get('v.PartsSelListEdit'),
                "cname":cname,
                "ctype": ctype,
                "sdate":  sdate,
                "edate" : edate
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var Message= 'Campaign Order created successfully';
                    helper.showSuccessToast(component,event,Message);
                    helper.listPageHelper(component, event);
                }
            });
            $A.enqueueAction(action);
        }
      
    },
    
    cancelSaveRecord: function(component, event, helper) {
        helper.listPageHelper(component, event);     
    },
    
    Displaylistpage: function(component, event, helper) {
        
        helper.listPageHelper(component, event);
    },
    addNewRow: function(component, event, helper) {
        helper.createObjectData(component, event);
    },	
    cssaction: function(component, event, helper) {
        var cmpDivsb = component.find('onblurdiv');
        $A.util.addClass(cmpDivsb, 'local-table1'); 
        
    },
    cssremoveaction: function(component, event, helper) {
        var cmpTarget = component.find('onblurdiv');
        $A.util.removeClass(cmpTarget, 'local-table1');
    }, 
    cssnewaction: function(component, event, helper) {
        var cmpnewDivsb = component.find('newdiv');
        $A.util.addClass(cmpnewDivsb, 'local-table1');  
    },
    cssnewremoveaction: function(component, event, helper) {
        var cmpTarget = cmp.find('newdiv');
        $A.util.removeClass(cmpTarget, 'local-table1');
    }, 
    onStatusChange: function(component, event, helper){
        var selected = event.getSource().getLocalId();
        component.set('v.Action',selected);
        
    },
    cancelSaveRecord : function(component, event, helper){
        var eventListPage = component.getEvent("displayListPageParts");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
})
({
  CampaignActionPicklist : function(component, event){      
       var action = component.get("c.fetchCampaignActionPicklist");
        action.setCallback(this, function(response) {
        component.set("v.cType", response.getReturnValue());
    		});
        var action1 = component.get("c.fetchCampaignTypePicklist");
        action1.setCallback(this, function(response) {
        component.set("v.cAction", response.getReturnValue());
    		});
        $A.enqueueAction(action);
        $A.enqueueAction(action1);
       
  },  
    createObjectData: function(component, event) {
        var RowItemList = component.get("v.PartsSelListEdit");
        RowItemList.push({
            'sobjectType ': 'orderitem',
            'PSA_Part_Number__c':'',
            'Quantity':'',
            'Product2Id':'',
            'Id':'',
            'Description': '',
            'UnitPrice' :''
        });
        component.set("v.PartsSelListEdit", RowItemList);
       
    },
    listPageHelper : function(component, event){
        var eventListPage = component.getEvent("displayListPageParts");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },    
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    showError : function(component, event, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
        component.set("v.spinner", false);
      //   component.set("v.Potyperrormsg",'This is a required field');
   
    },
    validatePartForm : function(component, event, helper){
        debugger;
        var isValid = true;
        var isValidchild = true;
        var cname = component.find("cname").get("v.value");
        var ctype = component.find("ctype").get("v.value");
        var sdate = component.find("sdate").get("v.value");
        var edate = component.find("edate").get("v.value");
        var now = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD"); 
        component.set("v.cnameerrmsg",'');
        $A.util.removeClass(cname,"disp-block");
        $A.util.addClass(cname,"disp-none");
        component.set("v.ctypeerrmsg",'');  
        $A.util.removeClass(ctype,"disp-block");
        $A.util.addClass(ctype,"disp-none");
        component.set("v.sdateerrmsg",'');
        $A.util.removeClass(sdate,"disp-block");
        $A.util.addClass(sdate,"disp-none");
        component.set("v.edateerrmsg",'');
        $A.util.removeClass(edate,"disp-block");
        $A.util.addClass(edate,"disp-none");
        if( cname=='--None--'|| cname == '' ||  cname== null){
            component.set("v.cnameerrmsg",'This is a required field');
            $A.util.removeClass(cname,"disp-none");
            $A.util.addClass(cname,"disp-block");
            isValid = false;
        } 
        if(ctype =='--None--'||  ctype== '' ||  ctype== null){
            component.set("v.ctypeerrmsg",'This is a required field');
            $A.util.removeClass(ctype,"disp-none");
            $A.util.addClass(ctype,"disp-block");
            isValid = false;
        }
        
         if( sdate=='--None--'|| sdate == '' || sdate == null){
            component.set("v.sdateerrmsg",'This is a required field');
            $A.util.removeClass(sdate,"disp-none");
            $A.util.addClass(sdate,"disp-block");
            isValid = false;
        }
        else{
        if(sdate<now)
        {
            component.set("v.sdateerrmsg",'Start Date should be Greater than or Equal to Current Date');
            $A.util.removeClass(sdate,"disp-none");
            $A.util.addClass(sdate,"disp-block");
            isValid = false;
        }}
       if( edate=='--None--'|| edate == '' || edate == null){
            component.set("v.edateerrmsg",'This is a required field');
            $A.util.removeClass(edate,"disp-none");
            $A.util.addClass(edate,"disp-block");
            isValid = false;
        }
        else{
        if(edate<sdate)
        {
            component.set("v.edateerrmsg",'End Date should be Greater than or Equal to Start Date');
            $A.util.removeClass(edate,"disp-none");
            $A.util.addClass(edate,"disp-block");
           
            isValid = false;
        }
        }
        var checking=true;
        var childCmp = component.find("PSA_NewLocalPurchaseOrderChild");   
        if(childCmp.length){
            for(var i=0; i<childCmp.length; i++){
                isValidchild = childCmp[i].checkValidationparts();
               
          if(isValidchild)
          {}else{ checking=false; break;}
            }
        }
            
        else
        {
            isValidchild = childCmp.checkValidationparts();
        }
        
        
        if(isValidchild && checking && isValid)
        {
           return true;
        }
        else {return false;}
    },

})
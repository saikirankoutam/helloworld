({
	 getCarNames : function(component, event) {
        
        var action = component.get("c.getCarMethod");
       
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.carList", response.getReturnValue());
             }
        });
        $A.enqueueAction(action);
        
    },
})
({
    
    doInit: function(component, event, helper) {
      //  helper.getCarNames(component, event);
    },
    
    getVariant : function(component, event, helper){
   
    var selectvalmodel = component.find("modelname").get("v.value");
  	var action = component.get("c.getCarVariant");
        action.setParams({ 
            "selModel" : selectvalmodel,
         });
        action.setCallback(this, function(a) {
             component.set("v.VariantList", a.getReturnValue());
           });
        $A.enqueueAction(action);	
	},
    
  AddNewRow : function(component, event, helper){
     
     var compEvent = component.getEvent('AddRowEvt');
       var prodnameval = component.get("v.OrderItemInstance.Product2.Name");
     //   var variantval = component.get("v.OrderItemInstance.Variant__c");
        var quantval = component.get("v.OrderItemInstance.Quantity");
    //   var fuelval = component.get("v.OrderItemInstance.Fuel__c");
       
			compEvent.setParams({
        		"prodnameevt" : prodnameval,
                 "quantityevt" : quantval
            //   "variantnameevt" : variantval,
             //   "fuelValevt" : fuelval
        
        });
        compEvent.fire();
       },
          
    AddNewBlankRow : function(component, event, helper){
   		  var compEvent = component.getEvent('AddRowEvt');
         compEvent.fire();
       },
    
    removeRow : function(component, event, helper){
           var ratePerUnit = component.get("v.prodvalue");
        component.getEvent("DeleteRowEvt").setParams({
            "indexVar" : component.get("v.rowIndex"),
            "deleteAmount" : ratePerUnit}).fire();
     }, 
   getProductPrice : function(component, event, helper) {
        debugger;
        var quant = component.find("Quantity").get("v.value");
        var prodid = component.find("prodid").get("v.value");
        console.log(" **** prodid ****"+prodid);
        var action = component.get("c.getProductPricemethod");
        action.setParams({ 
            "productId" : prodid
        });
        action.setCallback(this, function(a) {
            var state = a.getState();
            console.log(" state ---"+state);
            if (state === "SUCCESS") {
                var storeResponse = a.getReturnValue();
                for(var i=0;i<storeResponse.length;i++){
                    var unitpri = storeResponse[i].UnitPrice;
                    var selectedprodprice = quant*unitpri;
                    var curr = component.find("Totalcurrval").get("v.value");
                    var Diffamnt = selectedprodprice - curr;
                    if(Diffamnt != "0" && curr != "0"){
                        var eventListPage = component.getEvent("deleteOrderAmountMonthlyBase");
                        eventListPage.setParams({"OrderAmountcurr" : curr});
                        eventListPage.fire();
                        component.find("Totalcurrval").set("v.value", selectedprodprice);
						//component.set('v.prodvalue',selectedprodprice);
                        var eventListPage = component.getEvent("getOrderAmountMonthlyBase");
                        eventListPage.setParams({"OrderAmountcurr" : selectedprodprice});
                        eventListPage.fire();
                    }
                    if(curr == "0"){
                        component.find("Totalcurrval").set("v.value", selectedprodprice);
                        var eventListPage = component.getEvent("getOrderAmountMonthlyBase");
                        eventListPage.setParams({"OrderAmountcurr" : selectedprodprice});
                        eventListPage.fire();
                    }
                }
            }
        });
        $A.enqueueAction(action);
        
    },   
    
    
})
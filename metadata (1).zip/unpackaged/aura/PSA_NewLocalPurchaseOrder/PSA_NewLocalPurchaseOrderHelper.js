({
    createObjectData: function(component, event) {
        var RowItemList = component.get("v.PartsSelListEdit");
        RowItemList.push({
            'sobjectType ': 'PSA_Local_Parts_Order_Item__c',
            'PSA_Part_Number__c':'',
            'PSA_Total_Amount__c':'',
            'id':''
        });
        component.set("v.PartsSelListEdit", RowItemList);
    },
     EditSave: function(component, event, helper) {
        debugger;
        
     //  var childCmp = component.find("PSA_NewLocalPurchaseOrderChild");
        var ordid=component.get("v.OrderId");
        var errors = component.get("v.errors");
         var termsCond = component.find("terms").get("v.value");
        //var actionselect=component.get('v.Actions');
  
        var isvalid = true;
        var childCmp = component.find("PSA_NewLocalPurchaseOrderChild1");
        if(childCmp.length)
            for(var i=0; i<childCmp.length; i++){
                isvalid = childCmp[i].checkValidationparts();
          if(!isvalid){
                return isvalid;
                }
                }
        else
             isvalid = childCmp.checkValidationparts();
        //  var finalValidity = true;
    /*    if(childCmp.length)
            for(var i=0; i<childCmp.length; i++)
           childCmp[i].checkValidationparts();
        //  var isValid = childCmp[i].checkValidationparts();
        //  finalValidity = finalValidity && isValid;
        
        else
           childCmp.checkValidationparts();
        //  finalValidity = finalValidity && isValid;*/
        if ( this.validateRequired1(component, event) && isvalid)  {  
            var action = component.get("c.updateOrderItems");
            var save=component.get('v.savetype');
            //alert(save);
            action.setParams({
                "ListOrderItem" : component.get('v.PartsSelListEdit'),
                "orderid":ordid,
                "action" :save,
                "termsCond" :termsCond
     
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var Message= 'Local PO Updated Successfully';
                    this.showSuccessToast(component,event,Message);
                    // component.set("v.selectedStep", 'Confirm');
                    var storeResponse = response.getReturnValue();
                    if (state === "SUCCESS") {
                        var storeResponse = response.getReturnValue();
                        for(var i=0;i<storeResponse.length;i++){
                            var ordid = storeResponse[i].id;
                            var totAmt = storeResponse[i].Total_Order_Amount_Parts__c;
                            var ordNumber = storeResponse[i].OrderNumber;
                            var currreviewStatus = storeResponse[i].PSA_Review_Status__c;
                        }
                        component.set("v.CurrOrderAmount", totAmt);
                        component.set("v.OrderNumber", ordNumber);
                        component.set("v.OrderId", ordid);
                        //  component.set("v.newLocalPOrder", true);
                        this.listPageHelper(component, event);
                    }
                }
            });
            $A.enqueueAction(action);
        }
        /*else
        {
            var Message= $A.get("$Label.c.Local_Purchase_Order_Error");
            this.showError(component,event,Message);
        }*/
    },

    statusvalidate:function(component,event){       
        debugger;
        var OrderId = component.get("v.OrderId");
        var action = component.get("c.getlocalpostatus");    
        action.setParams({
            "orderid" : component.get("v.OrderId")            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") { 
                var rows = response.getReturnValue();
                console.log('user Info >>>>'+JSON.stringify(rows));              
                component.set("v.EditPO",true);                   
                
            }
        });
        $A.enqueueAction(action);
        
    },
    supplierName :function(component, event){
         var action = component.get("c.getsupName");
          action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log('dealer Info >>>>'+JSON.stringify(storeResponse));
                component.set("v.supplierName1", storeResponse);
               
            }
        });
        $A.enqueueAction(action);
    },
    getDealerInfo : function(component, event){
        var action = component.get("c.fetchDealerInfo");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log('dealer Info >>>>'+JSON.stringify(storeResponse));
                component.set("v.dealerInfo", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    getVendorNames : function(component, event){
        debugger;
        var action = component.get("c.fetchvendorAssNames");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.dealerList", storeResponse);
                //component.find("InputSelectDynamic").set("v.options", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    validateRequired: function(component, event) {
        debugger;
        var isValid = true;
        var poval=component.find("localpotype").get("v.value");
        if(poval=='Local PO'){
        var vendname = component.find("vendorname").get("v.value");
        component.set("v.vendorErrorMsg",'');
        $A.util.removeClass(vendname,"disp-block");
        $A.util.addClass(vendname,"disp-none");
        if(vendname == 'undefined'|| vendname == "--None--" || vendname == null){
            component.set("v.vendorErrorMsg",'This is a required field');
            $A.util.removeClass(vendname,"disp-none");
            $A.util.addClass(vendname,"disp-block");
             //var Message= $A.get("$Label.c.Local_Purchase_Order_Error");
            //this.showError(component,event,Message);
            isValid = false;  
        }
        }
       /* else{
            var suppname = component.find("vendornamec").get("v.value");
        component.set("v.vendorErrorMsg",'');
        $A.util.removeClass(vendname,"disp-block");
        $A.util.addClass(vendname,"disp-none");
        if(suppname == 'undefined'|| suppname == "--None--" || suppname == null){
            component.set("v.vendorErrorMsg",'This is a required field');
            $A.util.removeClass(suppname,"disp-none");
            $A.util.addClass(suppname,"disp-block");
             var Message= $A.get("$Label.c.Local_Purchase_Order_Error");
            this.showError(component,event,Message);
            isValid = false;  
        }
        }*/
       return isValid;
    },
    validateRequired1: function(component, event) {
        debugger;
        var isValid = true; 
        return isValid;
    },
    listPageHelper : function(component, event){
        var eventListPage = component.getEvent("displayListPageParts");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },    
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
      showToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    showError : function(component, event, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
        component.set("v.spinner", false);
    },
    getOrderAmountfunction : function(component, event){
        debugger;
        var recid = component.get("v.OrderId");
        
        if(recid != undefined){
            var action = component.get("c.getOrderAmount");
            action.setParams({
                "recordId" : component.get("v.OrderId")
            });       
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                    console.log('Order Info after record creation>>>>'+JSON.stringify(storeResponse));
                    //getting order and vendor details by orderId
                    component.set("v.orderInfo", storeResponse);
                    var orderCreatedDateTime = new Date(storeResponse.CreatedDate);
                    var modifiedDate = orderCreatedDateTime.toISOString().slice(0,10);
                    storeResponse.CreatedDate  = modifiedDate;
                    var approval=storeResponse.Status__c;
                
                    var totAmt = storeResponse.Total_Order_Amount_Parts__c;
                    var gstamt = storeResponse.PSA_GST__c;
                    var netamt = storeResponse.PSA_Net_Amount__c;
                    var step=component.get("v.selectedStep");
                    /*if(storeResponse.Status__c=='Draft'){
                    component.find('Hold').set('v.value',true);
                    component.set("v.disableradiobutton", true);
                    }
                    if(storeResponse.Status__c=='Waiting for Approval')
                    {
                    component.find('Release').set('v.value',true);  
                    component.set("v.disableradiobutton", true);
                    }*/
                    
                    /* if(storeResponse.PSA_PoType__c=='Co-Dealer')
                     {
                         component.set("v.disVar",false);
                     }
                    else{
                        component.set("v.disVar",true) ;
                    }*/
                    var potp=storeResponse.PSA_PoType__c;
                    if(potp=='Co-Dealer')
                         {
                         component.set("v.disVaredit",false);
                     }
                    else{
                        component.set("v.disVaredit",true) ;
                    }
                    
                    component.set("v.CurrOrderAmount", totAmt);
                    component.set("v.gstfinalAmount", gstamt);
                    component.set("v.totalincludingTax", netamt);
                var step=component.get("v.selectedStep");
              //  alert(step);
                }
            });
            $A.enqueueAction(action);
        }
    },
    localsave: function(component, event,helper) {
       debugger;
      var isvalid = true;
        var childCmp = component.find("PSA_NewLocalPurchaseOrderChild");
        if(childCmp.length){
            for(var i=0; i<childCmp.length; i++){
                isvalid = childCmp[i].checkValidationparts();
        if(!isvalid){
                return isvalid;
                }
                }
            }
        else
             isvalid = childCmp.checkValidationparts();
        if (this.validateRequired(component, event) && isvalid) { 
            console.log('PartsSelList--> '+ JSON.stringify(component.get("v.PartsSelList")));
   			var input = component.find('localpotype').get('v.value');
            if(input=='Local PO'){
            var vendorId = component.find("vendorname").get("v.value");
            //alert(vendorId);
        }
        else{
            var partNamerecord = component.get("v.selectedLookUpRecord");
           var vendorId=partNamerecord.Id;
          // var vendorId = component.get("v.codealersuppid");
         //var vendorId ='';
            //alert(vendorId);  
        }
            debugger;
            
            var poNumber = component.find("poNumber").get("v.value");
            
           var termsCond = component.find("terms").get("v.value");
          
            var potyp = component.find("localpotype").get("v.value");
           var savetype=component.get('v.savetype');
            var action = component.get("c.saveOrderItems");
            action.setParams({
                "ListOrderItem" : component.get('v.PartsSelListEdit'),
                "recTypeid" :'PSA_Parts_Service',
                "vendId" :vendorId,
                "PONumber":poNumber,
                "PoType" :potyp,
              "termsCondtns" :termsCond,
                 "action" :savetype
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var Message= $A.get("$Label.c.Local_Purchase_Order_Success");
                    this.showSuccessToast(component,event,Message);
                    // component.set("v.selectedStep", 'Confirm');
                    var storeResponse = response.getReturnValue();
                   
                    if (state === "SUCCESS") {
                        var storeResponse = response.getReturnValue();
                        for(var i=0;i<storeResponse.length;i++){
                            var ordid = storeResponse[i].id;
                        
                            var totAmt = storeResponse[i].Total_Order_Amount_Parts__c;
                            var ordNumber = storeResponse[i].OrderNumber;
                       
                        }
                        component.set("v.CurrOrderAmount", totAmt);
                        component.set("v.OrderNumber", ordNumber);
                        component.set("v.OrderId", ordid);
                        //   component.set("v.newLocalPOrder", true);
                        this.listPageHelper(component, event);
                    }
                }
                
            });
            $A.enqueueAction(action);
        }
      /*  else
        {
            var Message= $A.get("$Label.c.Local_Purchase_Order_Error");
            helper.showError(component,event,Message);
        }*/
    },
      getloginuserInfo : function(component, event){
        
        var action = component.get("c.fetchLoginUserDetails");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                var username=storeResponse.Name;
                component.set("v.loginuser",username);
                console.log('user Info >>>>'+JSON.stringify(storeResponse));
                if(storeResponse.PSA_Community_Role__c =='Head Aftersales'){
                    component.set("v.RSMlogin", true);
                      
                }
               
            }
        });
        $A.enqueueAction(action);
    },
    
})
({
    doInit: function(component, event, helper) {
        debugger;
       
        helper.createObjectData(component, event, helper);
        helper.getDealerInfo(component, event, helper);
        helper.getVendorNames(component, event, helper);
        helper.getOrderAmountfunction(component, event, helper);
         helper.getloginuserInfo(component,event);
       // helper.supplierName(component, event, helper);
        component.set("v.newLocalPOrder", true);
        //   helper.statusvalidate(component,event); 
    },
    recordChanges: function(component, event, helper) {
        debugger;
         var partNamerecord = component.get("v.selectedLookUpRecord");
           var supcode=partNamerecord.Dealer_Code__c;
          if(supcode == "undefined" || supcode == '' || supcode == null){    
        component.set("v.codealersuppname", '--None--');
          }
        else
        { 
         var suppname=partNamerecord.Name;
           // var suppid=partNamerecord.Id;
     
       component.set("v.codealersuppname", suppname);
            // component.set("v.codealersuppid", suppid);
      
        
        }  
    },
      onStatusChange: function(component, event, helper){
         
		 var selected = event.getSource().get("v.label");
        // alert(selected);
          component.set("v.Actions",selected);
		},
     	/*	onStatusChange: function(component, event, helper){
			var selected = event.getSource().getLocalId();
         	component.set('v.Action',selected);

		},*/

    handleCurrentEstimate : function(component, event, helper) {
        debugger;
        var ordNewAmt = event.getParam("OrderAmountcurr");
        var ordAmt = component.get("v.CurrOrderAmount");
        var FinalAmt = parseFloat(ordAmt)+parseFloat(ordNewAmt);
        var taxNewAmt = event.getParam("excludingAmountcurr");
        var taxAmt = component.get("v.gstfinalAmount");
        var gstfinalamt =parseFloat(taxAmt)+parseFloat(taxNewAmt);
        component.set("v.CurrOrderAmount",FinalAmt);
        component.set("v.gstfinalAmount",gstfinalamt);
        component.set("v.totalincludingTax",parseFloat(gstfinalamt)+parseFloat(FinalAmt));
    },
    handleremoveEstimate : function(component, event, helper) {
        debugger;
        var ordNewAmt = event.getParam("OrderAmountcurr");
        var ordAmt = component.get("v.CurrOrderAmount");
        var FinalAmt = parseInt(ordAmt) - parseInt(ordNewAmt);
       // alert('parent final amount'+FinalAmt);
        var taxNewAmt = event.getParam("excludingAmountcurr");
        var taxAmt = component.get("v.gstfinalAmount");
        var gstfinalamt =parseInt(taxAmt)-parseInt(taxNewAmt);
        component.set("v.CurrOrderAmount",FinalAmt);
        component.set("v.gstfinalAmount",gstfinalamt);
        component.set("v.totalincludingTax",parseFloat(FinalAmt) + parseFloat(gstfinalamt));
    },
    checkduplicatesaction :function(component, event, helper){
        var partNamecheck = event.getParam("OrderAmountcurr");
        
        var partnamechecklist = component.get("v.partnamechecklist");
        var isvalid=false;
        var obj=[];
        for(var i=0;i<partnamechecklist.length;i++){
            if(partNamecheck == partnamechecklist[i]){ 
                
            }else{
                
                isvalid=true; 
            }
        }
        if(isvalid){
            
            obj.push(partnamechecklist);
            obj.push(partNamecheck);
            component.set("v.partnamechecklist",obj);
        }
        
        
    },
    getPartRec :function(component, event, helper){
        debugger;
        var dealerList = component.get("v.dealerList");
        var vendname = component.find("vendorname").get("v.value");
        component.set("v.vendorErrorMsg",'');
        $A.util.removeClass(vendname,"disp-block");
        $A.util.addClass(vendname,"disp-none");
        
        for(var i=0;i<dealerList.length;i++){
            var vendorId = component.find("vendorname").get("v.value");
            
            if(vendorId === dealerList[i].PSA_Vendor__r.Id)
            {
                var vendorCode = dealerList[i].PSA_Vendor__r.PSA_Vendor_Code__c;
                break; 
            }
        }
        component.set("v.VendCode",vendorCode);
    },
    removeCurrentEstimate : function(component, event, helper) {
        debugger;
        var ordNewAmt = event.getParam("OrderAmountcurr");
        var ordAmt = component.get("v.CurrOrderAmount");
        var FinalAmt = parseInt(ordAmt) - parseInt(ordNewAmt);
        component.set("v.CurrOrderAmount",FinalAmt);
        var taxNewAmt = event.getParam("excludingAmountcurr");
        var taxAmt = component.get("v.gstfinalAmount");
        if(taxNewAmt >= taxAmt){
            var gstfinalamt =parseInt(taxNewAmt)-parseInt(taxAmt);
        }
        else{
            var gstfinalamt =parseInt(taxAmt)-parseInt(taxNewAmt);
        }
        component.set("v.gstfinalAmount",gstfinalamt);
    },   
    EditLocalPoHandler:function(component, event, helper) {
        component.set("v.selectedStep",'Edit');
        component.set("v.disableradiobutton",false);
        var action = component.get("c.getPOtitems");
        action.setParams({
            "orderid" : component.get('v.OrderId')
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.PartsSelListEdit", response.getReturnValue());
                
            };
        });
        $A.enqueueAction(action);
        
    },
  /*  Save: function(component, event, helper) {
        helper.localsave(component, event,helper);
        
    },
    CreatePO: function(component, event, helper) {
        helper.localsave(component, event,helper);
        
    },*/
    
       Save: function(component, event, helper) {
       component.set("v.savetype","Save");
        helper.localsave(component, event,helper); 
    
   },
     ESave: function(component, event, helper) {
       component.set("v.savetype","Save");
        helper.EditSave(component, event,helper); 
    
   },
    
    ESubmitforapproval:function(component, event, helper) {
       component.set("v.savetype","Submit");
        helper.EditSave(component, event,helper); 
    
   },
    Submitforapproval:function(component, event, helper) {
        debugger;
        
       component.set("v.savetype","Submit");
        helper.localsave(component, event,helper); 
    
   },
    
    
    
    

    Cancel: function(component, event, helper) {
        
        component.set("v.selectedStep", 'Draft');
        helper.listPageHelper(component, event);
    },
    Displaylistpage: function(component, event, helper) {
        
        helper.listPageHelper(component, event);
    },
    addNewRow: function(component, event, helper) {
        helper.createObjectData(component, event);
    },
    getPOType :function(component, event, helper){ 
        debugger;
        var input = component.find('localpotype').get('v.value');
        component.set('v.PoType11111', input);
        //const Type  = input
        if (input !== 'Local PO') {
            component.set("v.disVariant", false);
            component.set("v.Ventype", true); 
            component.set("v.VenName", true);
             component.set("v.disVar", false);
          
            component.find('vendortype').set('v.value','--None--');
        } else {
            component.set("v.disVariant", true);
            component.set("v.Ventype", false); 
              component.set("v.disVar", true);
            component.set("v.VenName", false);
            component.find('vendortype').set('v.value','Dealer Vendor');
            
            
        }
    },
    // function for delete the row 
    removeDeletedRow: function(component, event, helper) {
        var index = event.getParam("indexVar");
        var delAmt = event.getParam("deleteAmount");
        var ordAmt = component.get("v.CurrOrderAmount");
        var FinalAmt = parseInt(ordAmt)- parseInt(delAmt);
        component.set("v.CurrOrderAmount",FinalAmt);
        var delgstAmt = event.getParam("deleteGSTAmount");
        var ordgstAmt = component.get("v.gstfinalAmount");
        var FinalgstAmt = parseInt(ordgstAmt)- parseInt(delgstAmt);
        component.set("v.gstfinalAmount",FinalgstAmt);
        component.set("v.totalincludingTax",parseInt(FinalgstAmt)+parseInt(FinalAmt));
        var AllRowsList = component.get("v.PartsSelListEdit");
        AllRowsList.splice(index, 1);
        component.set("v.PartsSelListEdit", AllRowsList);
    },
    partnumRow: function(component, event, helper) {
        debugger;
        var delAmt = event.getParam("deleteAmount");
        var ordAmt = component.get("v.CurrOrderAmount");
        var FinalAmt = parseInt(ordAmt)- parseInt(delAmt);
       // alert(FinalAmt);
        component.set("v.CurrOrderAmount",FinalAmt);
        var delgstAmt = event.getParam("deleteGSTAmount");
        var ordgstAmt = component.get("v.gstfinalAmount");
        var FinalgstAmt = parseInt(ordgstAmt)- parseInt(delgstAmt);
        component.set("v.gstfinalAmount",FinalgstAmt);
        component.set("v.totalincludingTax",parseInt(FinalgstAmt)+parseInt(FinalAmt));
        var AllRowsList = component.get("v.PartsSelList");
        AllRowsList.splice(index, 1);
        component.set("v.PartsSelList", AllRowsList);
    },
    
})
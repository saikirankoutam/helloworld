({
    sortData: function (cmp, fieldName, sortDirection) {
        var data = cmp.get("v.orders");
        var reverse = sortDirection !== 'asc';
        data.sort(this.sortBy(fieldName, reverse))
        cmp.set("v.orders", data);
    },
    sortBy: function (field, reverse, primer) {
        var key = primer ?
            function(x) {return primer(x[field])} :
        function(x) {return x[field]};
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    },
    dataloading: function (component, event) {
        component.set("v.spinner", true);        
        var action = component.get('c.getOrderStatus');      
        
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
              
                component.set("v.orders", records);
                component.set("v.spinner", false);
                component.set("v.invoicescount", records.length);                
                var pageSize = component.get("v.pageSize");
                component.set("v.receipts", records);
                component.set("v.totalSize", component.get("v.orders").length);
                component.set("v.start",0);
                component.set("v.end",pageSize-1);
                var paginationList = [];
                if(response.getReturnValue().length < pageSize){
                    paginationList=response.getReturnValue();
                }
                else{
                    for(var i=0; i< pageSize; i++){
                        paginationList.push(response.getReturnValue()[i]); 
                    } 
                }
                
                component.set('v.paginationList', paginationList);
                this.helperMethodPagination(component, event, '1');
                
                
                // helper.sortData(component, component.get("v.sortedBy"), component.get("v.sortedDirection"));
            }else{
                component.set("v.spinner", false);
            }  
        });
        $A.enqueueAction(action);
    },
    wrapperdataloading: function (component, event, helper) {  
        var action = component.get('c.getOrderStatuswrapper');      
        
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.orderwrapper", records);
                
                // helper.sortData(component, component.get("v.sortedBy"), component.get("v.sortedDirection"));
            }else{
                //  component.set("v.spinner", false);
            }  
        });
        $A.enqueueAction(action);
    },
    convertArrayOfObjectsToCSV : function(component,objectRecords){
        // declare variables
        var csvStringResult, counter, keys, columnDivider, lineDivider;
        
        // check if "objectRecords" parameter is null, then return from function
        if (objectRecords == null || !objectRecords.length) {
            return null;
        }
        // store ,[comma] in columnDivider variabel for sparate CSV values and 
        // for start next line use '\n' [new line] in lineDivider varaible  
        columnDivider = ',';
        lineDivider =  '\n'; 
        // in the keys valirable store fields API Names as a key 
        // this labels use in CSV file header  
        //   keys = ['PSA_SO_Status__c','PSA_VIN_Number__c','PSA_Truck_Number__c','PSA_Lorry_Receipt_Number__c','PSA_Planned_Invoice_Date__c','PSA_Invoice_Date__c','PSA_Order_Item__r.PSA_Variant__c'];
        keys = ['SOStaus','SOnumber','VINNumber','Model','Variant','TruckNumber','LRNumber','PONumber','POType','PlandeCOMDate','invoicedate'];
        
        csvStringResult = '';
        csvStringResult += keys.join(columnDivider);
        csvStringResult += lineDivider;
        
        for(var i=0; i < objectRecords.length; i++){   
            counter = 0;           
            for(var sTempkey in keys) {
                var skey = keys[sTempkey] ;  
                // add , [comma] after every String value,. [except first]
                if(counter > 0){ 
                    csvStringResult += columnDivider; 
                }                  
                csvStringResult += '"'+ objectRecords[i][skey]+'"';                
                /* if(typeof objectRecords[i][skey] === 'object'){
                csvStringResult += '"'+ objectRecords[i][skey].OrderNumber+'"'+'"'+ objectRecords[i][skey].PSA_Variant__c+'"';
               
            	}else{
                csvStringResult += '"'+ objectRecords[i][skey]+'"';
            }*/
                counter++;
                
            } 
            csvStringResult += lineDivider;
        }       
        // return the CSV formate String 
        return csvStringResult;        
    },
    helperMethodPagination : function(component, event, pageNumber){
        var pageSize = component.get("v.pageSize");//Number Of Row Per Page
        var totalpage=Math.ceil(component.get("v.orders").length/pageSize);//Number Of Total Pages
        var   paginationPageNumb=[];
        var cont=1;
        /*---Pagination Logic Start--*/
        if(pageNumber<=7){ 
            
            for(var i=1; i<= totalpage; i++){
              
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
                  paginationPageNumb.push(i);
            }
            
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
               paginationPageNumb.push(i);
           
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }
        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    },
    fetchvariantvalue : function(component, event,variant){
        var action = component.get('c.productvariantPicklistValues');      
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.variantList", records);
                component.find('variant').set('v.value',variant);
                
            }  
        });
        $A.enqueueAction(action);
    },
    getColour : function(component, event, selectvariant,selectvalmodel,painttype,extcolor){
        var initload=component.get('v.initload');
        var action = component.get("c.getCarColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : painttype
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.ExtcolourList", response.getReturnValue());
                if(initload){
                    component.find('extcolor').set('v.value',extcolor);
                }
            }
        });
        $A.enqueueAction(action);
    },
    getIntcolourList : function(component, event, selectvalmodel,selectvariant,painttype,color,trimtype,intcolor){
        var initload=component.get('v.initload');
        var action = component.get("c.getCarIntColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : painttype,
            "selColour" : color,
            "selIntTrim" : trimtype
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.intcolourList", response.getReturnValue());
                if(initload){
                    component.find('Intcolor').set('v.value',intcolor);
                }
            }
        });
        $A.enqueueAction(action);	 
    },
    updatesaleorder : function(component, event){
       if(this.validationCheck(component, event)){
        var extcolor=component.find('extcolor').get('v.value');
        var initcolor = component.find('Intcolor').get('v.value');
        var variant=component.find('variant').get('v.value');
        var simplerecord=component.get('v.simpleRecord');
        var painttype=component.find('Metallic').get('v.value');
        var trimtype=component.find('trimtype').get('v.value');
        var roof=component.find('rooflist').get('v.value');
        var pack=component.find('packlist').get('v.value');
        var action = component.get('c.modifysalesorderrecord'); 
        action.setParams({
            'salerecord' : simplerecord,
            'extcolour' :extcolor ,
            'variant' : variant,
            'initcolor' :initcolor,
            'metalictype' :painttype,
            'trimtypeval' : trimtype,
            'roofval' : roof,
            'packval' : pack
            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                    this.showSuccessToast(component, event, 'Sale order record updated Successfully');
                    document.getElementById("myModal").style.display = "none"; 
                	component.set('v.modify',true);
                    this.dataloading(component, event);
            }  
        });
        $A.enqueueAction(action);
       }
        
    },
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    showError : function(component, event, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
        component.set("v.spinner", false);
    },
    getmetallicList : function(component, event, model,variant,extcolor,intcolor,painttype){
        var initload=component.get('v.initload');
        var action = component.get("c.getCarMetallicColour");
        action.setParams({ 
            "selVariant" : variant,
            "selModel" : model,
            "selColour" : extcolor,
            "selIntColour" : intcolor  
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.metallicList", response.getReturnValue());
                if(initload){ 
                    component.find('Metallic').set('v.value',painttype);
                    component.set('v.initload',false);
                }
            }
        });
        $A.enqueueAction(action);	
    },
    
    gettrimtype : function(component, event, model,variant,extcolor,painttype,trimtype){
        var initload=component.get('v.initload');
        var action = component.get("c.getCarTrimType");
        action.setParams({ 
            "selVariant" : variant,
            "selModel" : model,
            "selMetallic" : painttype,
            "selColour" : extcolor  
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.trimtypeList", response.getReturnValue());
                if(initload){ 
                    component.find('trimtype').set('v.value',trimtype);
                    component.set('v.initload',false);
                }
            }
        });
        $A.enqueueAction(action);	
    },
    getroof : function(component, event, model,variant,painttype,extcolor,trimtype,intcolor,roof){
        var initload=component.get('v.initload');
        var action = component.get("c.getroofcls");
        action.setParams({ 
            "selVariant" : variant,
            "selModel" : model,
            "selMetallic" : painttype,
            "selColour" : extcolor,
            "selIntColour" : intcolor,
            "selIntTrim" : trimtype     
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.roofList", response.getReturnValue());
                if(initload){ 
                    component.find('rooflist').set('v.value',roof);
                    component.set('v.initload',false);
                }
            }
        });
        $A.enqueueAction(action);	
    },
    getpack : function(component, event, model,variant,painttype,extcolor,trimtype,intcolor,roof,pack){
        var initload=component.get('v.initload');
        var action = component.get("c.getpackcls");
        action.setParams({ 
            "selVariant" : variant,
            "selModel" : model,
            "selMetallic" : painttype,
            "selColour" : extcolor,
            "selIntColour" : intcolor,
            "selIntTrim" : trimtype,
            "selRoof" : roof
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.packList", response.getReturnValue());
                if(initload){ 
                    component.find('packlist').set('v.value',pack);
                    component.set('v.initload',false);
                }
            }
        });
        $A.enqueueAction(action);	
    },
     validationCheck : function(component,event){
         var isvalid=true;
         var extcolor= component.find('extcolor').get('v.value');
         var intcolor= component.find('Intcolor').get('v.value');
         var painttype= component.find('Metallic').get('v.value');
         var trimtype = component.find('trimtype').get('v.value');        
         var roof = component.find('rooflist').get('v.value');
         var pack = component.find('packlist').get('v.value');
            component.set("v.extcolorerrormsg",'');
            $A.util.removeClass(extcolor,"disp-block");
            $A.util.addClass(extcolor,"disp-none");
          component.set("v.intcolorerrormsg",'');
            $A.util.removeClass(intcolor,"disp-block");
            $A.util.addClass(intcolor,"disp-none");
          component.set("v.painttypeerrormsg",'');
            $A.util.removeClass(painttype,"disp-block");
            $A.util.addClass(painttype,"disp-none");
         component.set("v.trimtypeerrormsg",'');
            $A.util.removeClass(trimtype,"disp-block");
            $A.util.addClass(trimtype,"disp-none");
          component.set("v.rooftypeerrormsg",'');
            $A.util.removeClass(roof,"disp-block");
            $A.util.addClass(roof,"disp-none");
          component.set("v.packtypeerrormsg",'');
            $A.util.removeClass(pack,"disp-block");
            $A.util.addClass(pack,"disp-none");
          if(extcolor == 'undefined'|| extcolor == '' || extcolor == null || extcolor=='--None--'){
                isvalid=false;
                component.set("v.extcolorerrormsg",'This is a required field');
                $A.util.removeClass(extcolor,"disp-none");
                $A.util.addClass(extcolor,"disp-block");
            } 
            if(intcolor == 'undefined'|| intcolor == '' || intcolor == null || intcolor=='--None--'){
                isvalid=false;
                component.set("v.intcolorerrormsg",'This is a required field');
                $A.util.removeClass(intcolor,"disp-none");
                $A.util.addClass(intcolor,"disp-block");
            } 
          if(painttype == 'undefined'|| painttype == '' || painttype == null || painttype=='--None--'){
                isvalid=false;
                component.set("v.painttypeerrormsg",'This is a required field');
                $A.util.removeClass(painttype,"disp-none");
                $A.util.addClass(painttype,"disp-block");
            } 
         if(trimtype == 'undefined'|| trimtype == '' || trimtype == null || trimtype=='--None--'){
                isvalid=false;
                component.set("v.trimtypeerrormsg",'This is a required field');
                $A.util.removeClass(trimtype,"disp-none");
                $A.util.addClass(trimtype,"disp-block");
            } 
         if(roof == 'undefined'|| roof == '' || roof == null || roof=='--None--'){
                isvalid=false;
                component.set("v.rooftypeerrormsg",'This is a required field');
                $A.util.removeClass(roof,"disp-none");
                $A.util.addClass(roof,"disp-block");
            } 
         if(pack == 'undefined'|| pack == '' || pack == null || pack=='--None--'){
                isvalid=false;
                component.set("v.packtypeerrormsg",'This is a required field');
                $A.util.removeClass(pack,"disp-none");
                $A.util.addClass(pack,"disp-block");
            } 
         
        
         return isvalid;
    },
    
})
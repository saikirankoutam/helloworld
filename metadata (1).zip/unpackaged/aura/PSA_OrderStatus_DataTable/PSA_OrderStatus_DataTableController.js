({
    doInit : function(component, event, helper) {
        helper.dataloading(component, event);
        helper.wrapperdataloading(component, event, helper);
    },
    downloadCsv : function(component,event,helper){        
        var stockData = component.get("v.orderwrapper"); 
        var csv = helper.convertArrayOfObjectsToCSV(component,stockData);   
        if (csv == null){return;} 
        var hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_self'; // 
        hiddenElement.download = 'ExportData.csv';  
        document.body.appendChild(hiddenElement); 
        hiddenElement.click(); 
    }, 
    ONOrder : function(component, event, helper) {
        debugger;
        var target = event.getSource().get('v.value');
        component.set('v.modify',false);
        document.getElementById("myModal").style.display = "block";
        var action = component.get('c.getsalesorderrecord');
        action.setParams({
            'Sonumber' : target
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                console.log("Inside "+state);
                component.set("v.simpleRecord", records);
                var ecomdate=records.PSA_SO_Modification__c;
                 var salesorderlabel = $A.get("$Label.c.PSA_Sales_order_Modification_days_allowed");
                //alert(salesorderlabel)
                var variant=records.PSA_Order_Item__r.Product2.PSA_Variant__c;
                var model=records.PSA_Order_Item__r.Product2.PSA_Brand__c;
                var extcolor=records.PSA_Order_Item__r.Product2.PSA_Ext_Colour__c;
                var intcolor=records.PSA_Order_Item__r.Product2.Interior_Color__c;
                var painttype=records.PSA_Order_Item__r.Product2.Metallic_Non_Metallic__c; 
                var trimtype = records.PSA_Order_Item__r.Product2.Interior_Trim_Type__c; 
                var roof = records.PSA_Order_Item__r.Product2.Roof__c; 
                var pack = records.PSA_Order_Item__r.Product2.Pack__c; 
                var ordertype=records.PSA_Order__r.RecordType.Name;
                helper.fetchvariantvalue(component, event,variant);
                helper.getColour(component, event, variant,model,painttype,extcolor); 
                helper.getIntcolourList(component, event, model,variant,painttype,extcolor,trimtype,intcolor);
                helper.getmetallicList(component, event, model,variant,extcolor,intcolor,painttype);
                helper.gettrimtype(component, event, model,variant,extcolor,painttype,trimtype);
                helper.getroof(component, event, model,variant,painttype,extcolor,trimtype,intcolor,roof);
                helper.getpack(component, event, model,variant,painttype,extcolor,trimtype,intcolor,roof,pack);
                 if(ordertype=='Daily Order' || ecomdate>10){
                  component.set("v.modify", true); 
                  }
            }
        });
        $A.enqueueAction(action);
        
    },
    searchoption : function(component, event, helper) {
        var searchtype = component.find("searchtype").get("v.value");
        component.find("posearch").set("v.value",null);
        component.set("v.searchtype", searchtype);
       
        
    },
    getColour : function(component, event, helper) {  
        component.find('extcolor').set('v.value','--None--'); 
        component.find('trimtype').set('v.value','--None--');
        component.find('Intcolor').set('v.value','--None--');
        component.find('rooflist').set('v.value','--None--'); 
        component.find('packlist').set('v.value','--None--');
        component.set("v.intcolourList", []);
        component.set("v.ExtcolourList",[]);
        component.set("v.trimtypeList",[]);
        component.set("v.intcolourList",[]);
        component.set("v.roofList",[]);
        component.set("v.packList",[]);
        var variant=component.find('variant').get('v.value');        
        var records=component.get('v.simpleRecord');
        var model=records.PSA_Order_Item__r.Product2.PSA_Brand__c;
        var painttype=component.find('Metallic').get('v.value');
        if(painttype != '--None--'){
            component.set('v.painttypeerrormsg', '');
        	helper.getColour(component, event, variant,model,painttype,''); 
        }
        else
            component.set('v.painttypeerrormsg', 'This is a required field');
            
    }, 
    closeSoForm : function(component, event, helper){
        document.getElementById("myModal").style.display = "none";
         component.set("v.modify", false);
         component.set('v.initload',true);
         component.set('v.extcolorerrormsg', '');component.set('v.intcolorerrormsg', '');
        component.set('v.painttypeerrormsg', '');component.set('v.trimtypeerrormsg', '');
        component.set('v.rooftypeerrormsg', '');component.set('v.packtypeerrormsg', '');
    },
    posearchOrder : function(component, event, helper) {
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        var searchtype=component.get("v.searchtype");
        if(pot==null || pot=='' || pot=='undefined'){
            debugger;
           component.set('v.disableForSearch',false);
           helper.dataloading(component, event, helper);  
        }else{
        var action = component.get('c.getOrderposearch');
        action.setParams({
            'ponumber' : pot,
            'searchtype':searchtype
            
        });
        component.set("v.spinner", true);
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {
                component.set('v.disableForSearch',true);
               var records =response.getReturnValue();
                console.log("Inside "+state);
               // component.set("v.paginationList", records);
                component.set("v.spinner", false);            
                var pageSize = component.get("v.pageSize");
                component.set("v.orders", records);
                component.set("v.totalSize", component.get("v.orders").length);
                component.set("v.start",0);
                component.set("v.end",pageSize-1);
                var paginationList = [];
                if(response.getReturnValue().length < pageSize){
                    paginationList=response.getReturnValue();
                }
                else{
                    for(var i=0; i< pageSize; i++){
                        paginationList.push(response.getReturnValue()[i]); 
                    } 
                }
                
                component.set('v.paginationList', paginationList);
                helper.helperMethodPagination(component, event, '1');
                
                
            }else{
                component.set("v.spinner", false);
            }
        });
        $A.enqueueAction(action);
        }
    },
    next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        var receiptslist = component.get("v.orders");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var receiptslist = component.get("v.orders");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
        /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var accountList = component.get("v.orders");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = accountList.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    },
    
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.dataloading(component, event);
    },
    Modifysaleorder: function(component, event, helper){
        var simplerecord = component.get('v.simpleRecord');
        var prevvariant = simplerecord.PSA_Order_Item__r.Product2.PSA_Variant__c;
        var prevcolor= simplerecord.PSA_Order_Item__r.Product2.PSA_Ext_Colour__c;
        var prevIntcolor= simplerecord.PSA_Order_Item__r.Product2.Interior_Color__c;
        var modifycolor=component.find('extcolor').get('v.value');
        var modifyvariant=component.find('variant').get('v.value');
        var modifyintcolor=component.find('Intcolor').get('v.value');
        if(prevvariant == modifyvariant && prevcolor == modifycolor && prevIntcolor==modifyintcolor){
            helper.showSuccessToast(component, event, 'Sale order record updated Successfully');
             component.set('v.modify',true);
             document.getElementById("myModal").style.display = "none";
        }else{
            helper.updatesaleorder(component, event);  
        }
        
    },
    gettrimtypeList: function(component, event, helper){ 
        component.find('trimtype').set('v.value','--None--');
        component.find('Intcolor').set('v.value','--None--');
        component.find('rooflist').set('v.value','--None--'); 
        component.find('packlist').set('v.value','--None--');
        component.set("v.trimtypeList",[]);
        component.set("v.intcolourList", []);        
        component.set("v.roofList",[]);
        component.set("v.packList",[]);
        var variant=component.find('variant').get('v.value');      
        var records=component.get('v.simpleRecord');
        var model=records.PSA_Order_Item__r.Product2.PSA_Brand__c;
        var extcolor=component.find('extcolor').get('v.value');
        var painttype = component.find('Metallic').get('v.value');
        var trimtype = component.find('trimtype').get('v.value');
        if(extcolor != '--None--'){
            component.set('v.extcolorerrormsg', '');
        	helper.gettrimtype(component, event, model,variant,extcolor,painttype,'');
        }
        else
            component.set('v.extcolorerrormsg', 'This is a required field');
    },
    getIntcolourList: function(component, event, helper){        
        component.find('Intcolor').set('v.value','--None--');
        component.find('rooflist').set('v.value','--None--'); 
        component.find('packlist').set('v.value','--None--');
        component.set("v.intcolourList", []);        
        component.set("v.roofList",[]);
        component.set("v.packList",[]);
        var variant=component.find('variant').get('v.value');      
        var records=component.get('v.simpleRecord');
        var model=records.PSA_Order_Item__r.Product2.PSA_Brand__c;
        var extcolor=component.find('extcolor').get('v.value');
        var painttype = component.find('Metallic').get('v.value');
        var trimtype = component.find('trimtype').get('v.value');
        if(trimtype != '--None--'){
            component.set('v.trimtypeerrormsg', '');
        	helper.getIntcolourList(component, event, model,variant,painttype,extcolor,trimtype,'');
        }
        else
            component.set('v.trimtypeerrormsg', 'This is a required field');
    },
    getRoofList: function(component, event, helper){
        component.find('rooflist').set('v.value','--None--'); 
        component.find('packlist').set('v.value','--None--');      
        component.set("v.roofList",[]);
        component.set("v.packList",[]);
        var variant=component.find('variant').get('v.value');
        var records=component.get('v.simpleRecord');
        var model=records.PSA_Order_Item__r.Product2.PSA_Brand__c;
        var extcolor=component.find('extcolor').get('v.value');
        var painttype = component.find('Metallic').get('v.value');
        var trimtype = component.find('trimtype').get('v.value');
        var intcolor = component.find('Intcolor').get('v.value');
        if(intcolor != '--None--'){
            component.set('v.intcolorerrormsg', '');
        	helper.getroof(component, event, model,variant,painttype,extcolor,trimtype,intcolor,'');  
        }
        else
            component.set('v.intcolorerrormsg', 'This is a required field');
    },
    
    getPackList: function(component, event, helper){
        component.find('packlist').set('v.value','--None--');      
        component.set("v.packList",[]);
        var variant=component.find('variant').get('v.value');
        var records=component.get('v.simpleRecord');
        var model=records.PSA_Order_Item__r.Product2.PSA_Brand__c;
        var extcolor=component.find('extcolor').get('v.value');
        var painttype = component.find('Metallic').get('v.value');
        var trimtype = component.find('trimtype').get('v.value');
        var intcolor = component.find('Intcolor').get('v.value');
        var roof = component.find('rooflist').get('v.value');
        if(roof != '--None--'){
            component.set('v.rooftypeerrormsg', '');
        	helper.getpack(component, event, model,variant,painttype,extcolor,trimtype,intcolor,roof,'');
        }
        else
            component.set('v.rooftypeerrormsg', 'This is a required field');
    },
    
    hidepackerrmsg : function(component, event, helper){
        var pack = component.find('packlist').get('v.value');
        if(pack != '--None--')
            component.set('v.packtypeerrormsg', '');
        else
            component.set('v.packtypeerrormsg', 'This is a required field');
    },
    
    getmetallicList : function(component, event, helper){
        component.find('Intcolor').set('v.value','--None--');
        component.find('extcolor').set('v.value','--None--'); 
        component.find('Metallic').set('v.value','--None--');
        component.find('trimtype').set('v.value','--None--');
        component.find('rooflist').set('v.value','--None--'); 
        component.find('packlist').set('v.value','--None--');
        component.set("v.intcolourList", []);
        component.set("v.metallicList",[]);
        component.set("v.ExtcolourList",[]);
        component.set("v.trimtypeList",[]);
        component.set("v.intcolourList",[]);
        component.set("v.roofList",[]);
        component.set("v.packList",[]);
        var selectvariant=component.find('variant').get('v.value');
        var records=component.get('v.simpleRecord');
        var selectvalmodel=records.PSA_Order_Item__r.Product2.PSA_Brand__c;
        component.find("Metallic").set("v.value", "");
        var action = component.get("c.getCarMetallicColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel
            
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.metallicList", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);  	       
    }     
})
({
    getmaingrouppicklist :function(component,event,helper){ 
        
        var action = component.get("c.getmaingroup");
        action.setCallback(this, function(response) {
            component.set("v.maingrouplist", response.getReturnValue());
            console.log('Main Group from Case >>>>>>>'+response.getReturnValue());
            component.set("v.dissubgroup", "false");
            
        });
        $A.enqueueAction(action);	
    },
    /*    getUompicklist :function(component,event,helper){ 
      var action = component.get("c.getUomPicklistvals");
        action.setCallback(this, function(response) {
            component.set("v.uomlist", response.getReturnValue());
         });
        $A.enqueueAction(action);	
    },*/
    casedetailrecord:function(component,event){
         var caserecid=component.get('v.caseid');
         var action = component.get("c.fetchCaseInfo");
         action.setParams({
             "caseId": caserecid,  
         });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
               component.set('v.caselist',storeResponse);
            }
        });
        $A.enqueueAction(action);  
    },
    saverequest:function(component,event){
        debugger;
        // var caseobj = component.get("v.case"); //Sobject         
        //console.log(caseobj);
        
        var maingrp = component.find("maingroup").get("v.value");
        var subgrp = component.find("subgroup").get("v.value");
        var bran = component.find("brand").get("v.value");
        var partDesc = component.find("partdescription").get("v.value");
        var hsnCde = component.find("HSNcode").get("v.value");
        var Uomlst = component.find("uomlist").get("v.value");
        var igstcde = component.find("IGST").get("v.value");
        var cgstcde = component.find("CGST").get("v.value");
        //     var sgstcde = component.find("SGST").get("v.value");
        var purcpric = component.find("Purchasepri").get("v.value");
        var sellprice = component.find("Sellingpri").get("v.value");
        var ratperUni = component.find("rateperUnit").get("v.value");
        var qtyperveh = component.find("qtypervehicle").get("v.value");
        var saltype = component.find("saletype").get("v.value");
        var seasonalpar = component.find("seasonalpart").get("v.value");
        var mp = component.find("MRP").get("v.value");
        
        var action = component.get("c.insertpartrequest");
        action.setParams({
            "maingroup": maingrp,
            "Subgroup": subgrp,
            "brand" : bran,
            "UOM": Uomlst,
            "PartDesc": partDesc,
            "Hsncode": hsnCde,
            "Igst": igstcde,
            "Cgst": cgstcde,
            // "Sgst": sgstcde,
            "Purchaseprice": purcpric,
            "Sellingprice": sellprice,
            "rateperunit": ratperUni,
            "qtypervehicle": qtyperveh,
            "Saletype": saltype,
            "seasonalpart": seasonalpar,
            "MRP": mp
            
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                var Message= $A.get("$Label.c.Local_Part_Request");
                this.showSuccessToast(component,event,Message);             
            }
            else{
                var Message= $A.get("$Label.c.Local_Part_Request_Error");
                this.showerrorToast(component,event,Message);  
            }
            var eventListPage = component.getEvent("displayListPageParts");
            eventListPage.setParams({"listPage" : true });
            eventListPage.fire();
        });
        $A.enqueueAction(action);
    },
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "error"
        });
        toastEvent.fire();  
    },
     createObjectData: function(component, event) {
        var RowItemList = component.get("v.caselist");
        RowItemList.push({
            'sobjectType ': 'Case',
            'PSA_Parts_Description__c':'',
            'PSA_HSN_Code__c':'',
            'PSA_Part_Category__c':'',
            'PSA_Part_Type__c': '',
            'PSA_UOM_purchase__c':'',
            'PSA_Multiplication_Factor__c' : '',
            'PSA_UOM__c' : '',
            'PSA_MOQ_number__c': '',
            'PSA_Source__c' : '',
            'PSA_Brand__c' : '',
            'PSA_Supplier__c' : '',
            'PSA_Supplier_Name__c': '',
            'PSA_Model_Code__c' : '',
            'PSA_Location__c' :'',
            'PSA_BIN_location__c' :'',
            'PSA_GST_Part_Tax_Category__c' : '',
            'PSA_CGST__c' : '',
            'PSA_SGST__c' : '',
            'PSA_IGST__c' : '',
            'PSA_NDP__c' : '',
            'PSA_Rate_per_Unit__c' : '' ,
            'PSA_mrp__c' : '',
            'PSA_Price_Effective_From_Month__c' :'',
            'PSA_MRP_1__c' : '',
            'PSA_MRP_2__c' :'',
            'PSA_MRP_3__c' : '',
           /* 'PSA_SuperSession_Type__c' : '',
            'PSA_Preceding_part_Number__c' : '',
            'PSA_SuperSeeding_part_number__c' : '',
            'PSA_Latest_Part_Number__c' : '',
            'PSA_Alternate_Part_Number__c' : '',*/
            'PSA_ABC_category__c' : '',
            'PSA_FMS_category__c' : '',
            'PSA_Lead_Time__c' : '',
            'PSA_Seasonal_Part__c' :'',
            'PSA_Price_Effective_To_Month__c' : '',
            'PSA_MAD_3months__c' : '',
            'PSA_MAD_6_Months__c' : '',
            'PSA_MAD_12_Months__c' : '',
            'PSA_MAMD__c' : '',
            'PSA_Safety_Stock__c' :'',
            'PSA_Order_Cycle__c' : '',
            'PSA_Min_Inv_level__c' : '',
            'PSA_Max_Inv_Level__c' : '',
            'PSA_Re_Order_Level__c' : '',
            'PSA_Minimum_Order_Quantity__c' : '',
            'PSA_Current_Stock__c' : '',
            'PSA_Available_Stock__c' : '',
            'PSA_Back_Order_Quantity__c' : '',
            'PSA_In_Transist_Quanity__c' : '',
            'PSA_Total_Stock_Value__c' : '',
            /*'PSA_immobilization__c' : '',
            'PSA_Hazard_stock__c' : '',
            'PSA_Supersession_Available__c' : '',
            'PSA_Local_Part_Indicator__c' : '',
            'PSA_Approved_Part__c' : '',
            'PSA_VAS_Flag__c' : '',
            'PSA_Coded_Part__c' : '',
            'PSA_KIT_Flag__c' : '',
            'PSA_Orderable__c' : ''*/
        });
        component.set("v.caselist", RowItemList);
     },
     fetchPickLists: function(component, event) {
        
        var action = component.get("c.fetchUOMTypePicklist");
        action.setCallback(this, function(response) {
           
        component.set("v.uomType", response.getReturnValue());
    		});
        
       $A.enqueueAction(action);
       
       
     },
})
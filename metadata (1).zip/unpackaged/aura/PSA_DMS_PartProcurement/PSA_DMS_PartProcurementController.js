({
    onTabSelect : function(component, event, helper) {
        
        component.set("v.createGRN", false);
        component.set("v.PartGRN", false);
        component.set("v.OEMinvoiceDetailView", false);
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var deact = ['partsDashboard'];
        var activate = component.find("partsDashboard");
        if(['purchaseOrders', 'partsreceipt', 'OEMPurchaseReturn', 'oemInvoice'].includes(id))
            var activate = component.find("Purchase");
        else
            deact.push("Purchase");
        if(['otcsale', 'otcreturn'].includes(id))
            var activate = component.find("Sale");
        else
            deact.push("Sale");
        if(['partclaim'].includes(id))
            var activate = component.find("Claim");
        else
            deact.push("Claim");
        if(['invmgnt', 'CoDealerStockVisibility', 'BinCreation', 'cycleCount', 'BinAllocation', 'BinTransfer', 'camporder'].includes(id))
            var activate = component.find("InventoryManagement");
        else
            deact.push("InventoryManagement");
        if(['parts','VEndor','otcCustomer'].includes(id))
            var activate = component.find("Master");
        else
            deact.push("Master");
        
         if(['purchase','grn','mast','summary','transfer','sales','claim','perform','tracker','kpi'].includes(id))
            var activate = component.find("partsreport");
        else
            deact.push("partsreport");
        var x;
        for(x in deact)
            {
                var deactivate = component.find(deact[x]);
                $A.util.removeClass(deactivate, "active");
            }
        $A.util.addClass(activate, "active");
        
        
        
    },
    CreateNewGRN : function(component, event, helper) {
        // component.set("v.currentVehicleReceiptId", "");
         debugger;
        component.set("v.createGRN", true);
        component.set("v.PartGRN", true);
        component.set("v.INVGRN", true);
    },
    oemInvoiceDetailhandle :function(component,event,helper){
        var invoiceId = event.getParam("currentMonthlyOrderId");
        
    },
    handlePartReceiptIdPass : function(component, event, helper) {
        var currentVehicleReceiptId = event.getParam("Id");
        component.set("v.currentId", currentVehicleReceiptId);
        component.set("v.createGRN",false );
        component.set("v.PartGRN", true);
        component.set("v.INVGRN", false);
    },
     handleOEMinvoiceIdPass : function(component, event, helper) {    
        var Labid = event.getParam("LabourId");
        component.set("v.OEMinvoiceId", Labid);
        component.set("v.OEMinvoiceDetailView", true);
    },
     handledisplayListPage : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
         component.set("v.OEMinvoiceDetailView", false);
        component.set("v.currTab", 'oemInvoice');
        }
    },
    invoicesearch: function(component, event, helper) {
               
        console.log("" + event.getSource().get("v.value"));
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        component.set("v.invoice",pot) ;  
		 if(pot == null || pot == 'undefined' || pot==""){
            var childCmp = component.find("partsreceiptinvoicesId");
            childCmp.getinvoices();
        }
        else{        
            var action = component.get('c.Invoicenumbersearch');
            action.setParams({          
                'invoicenumber' : pot
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(""+state);
                if(state == 'SUCCESS') {               
                    var records =response.getReturnValue();               
                    component.set("v.invoicelist", records); 
                     if(records==null || records == 'undefined' || records=="")
                {
                      component.set("v.noRecords", false);
                }
                else
                    component.set("v.noRecords", true);
                
                }
            });
            $A.enqueueAction(action);
        }
    },
    oemsearch: function(component, event, helper) {
               
        console.log("" + event.getSource().get("v.value"));
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        component.set("v.invoice",pot) ;  
		 if(pot == null || pot == 'undefined' || pot==""){
            var childCmp = component.find("partsreceiptinvoices");
            childCmp.getinvoices();
        }
        else{        
            var action = component.get('c.oeminvoiceList');
            action.setParams({          
                'invoicenumber' : pot
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(""+state);
                if(state == 'SUCCESS') {               
                    var records =response.getReturnValue();               
                    component.set("v.oeminvoicelist", records); 
                     if(records==null || records == 'undefined' || records=="")
                {
                      component.set("v.noRecords", false);
                }
                else
                    component.set("v.noRecords", true);
                
                }
            });
            $A.enqueueAction(action);
        }
    },
    getPartreceiptsCount : function(component, event, helper){
        var receiptscount = event.getParam("Id");
        component.set("v.partsreceiptscount",receiptscount);
    },
    
    hidepartGRN : function(component, event, helper){
        var ispartgrn = event.getParam("ListPage");
    	component.set("v.PartGRN", ispartgrn);
        component.set("v.currTab", 'partsreceipt');
    },
      handlevalidateMenu : function(component, event, helper) {
        debugger;
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        var defaultItem = event.getParam("defaultItem");
        console.log("validationItem -- "+validationItem+"::"+defaultItem);
        if (defaultItem) {
        	component.set("v.currTab", validationItem);            
        }
    },
    
})
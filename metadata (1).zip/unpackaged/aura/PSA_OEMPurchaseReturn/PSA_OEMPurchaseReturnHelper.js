({
    getCustomeLookUpQuery : function(component, event)
    {
		var  listStatus  = component.get("v.statuslist");
        var query='select Id,Invoice__c,Invoice__r.Name,Invoice__r.PSA_Invoice_Date__c,Invoice__r.PSA_Account__r.Dealer_Code__c,Invoice__r.PSA_Account__r.Name,Invoice__r.PSA_Account__r.BillingCity,Invoice__r.PSA_oem_purchase_return_status__c,Invoice__r.Invoice_Amount__c,Invoice__r.Tax_Amount__c,Invoice__r.Material_Value__c FROM PSA_PartsReceipt__c where Invoice__c !=null AND Invoice__r.PSA_oem_purchase_return_status__c IN';
        query+=listStatus+' AND Invoice__r.RecordTypeId=';
        var action = component.get("c.getRecordTypeID");
           action.setCallback(this, function(response){
                var state = response.getState();
                var recordtypeid = response.getReturnValue();
                if (state === "SUCCESS") {
                var newString = '\''+ recordtypeid + '\'';   
                query+=newString+' AND Invoice__r.Name LIKE: searchKey order by createdDate DESC limit 5';
                component.set('v.customquery',query);                }
            });
            $A.enqueueAction(action);
        
    },
    
    createOEMPurchaseReturnNew : function(component, event,selectedlist,OEMPurchaseParams) {
        var finalvalidity=true;
        var isvalid=true;
        var selectedrec=component.get("v.invoiceRecord");
        var childCmp = component.find("oemPurchaseReturnchild");
                if(childCmp.length){
            for(var i=0; i<childCmp.length; i++){
                isvalid=childCmp[i].validationCheckMethod();
                if(!isvalid)
                finalvalidity=false;
            }
                
        } else{
            isvalid=childCmp.validationCheckMethod();
        }

        if(finalvalidity && isvalid ){
            component.set('v.reasonReturnFlag',true); 
            component.set('v.dealerRemarkFlag',true);
            var invoidid=selectedrec.Invoice__c
            var action = component.get("c.createOEMPurhaseReturn");
            action.setParams({
                "wrapperlist" : selectedlist,
                "invoiceid" : invoidid,
                "OEMPurchaseParams" : OEMPurchaseParams
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                var responseObj = response.getReturnValue();
                if (state === "SUCCESS") {
                    component.set('v.submitdisable',true);
                    component.set('v.reasonReturnFlag',true); 
                    component.set('v.dealerRemarkFlag',true);
                    component.set('v.disablefields',true);
                    component.set('v.disableChkbox',true);
                    component.find('ReturnReqDate').set('v.value',responseObj.CreatedDate);
                    component.find('returnStatus').set('v.value',responseObj.PSA_OEM_Purchase_Return__c);
                    component.find('returnInvValExGST').set('v.value',responseObj.PSA_Taxable_Value__c);
                    component.find('rettaxableValue').set('v.value',responseObj.PSA_Total_tax__c);
                    component.find('totalRetInvValue').set('v.value',responseObj.PSA_Total_Invoice_Value__c);
                    //all component stuffs set here
                    this.Suceestoast(component, event,'OEM Purchase return placed Successfully');
                }
            });
            $A.enqueueAction(action);
        }
    },
        createOEMPurchaseReturnApproved : function(component, event,selectedlist,OEMPurchaseParams) {
            var selectedrec=component.get("v.invoiceRecord");
            var invoidid=selectedrec.Invoice__c;
            var action = component.get("c.createOEMPurhaseReturn");
            action.setParams({
                "wrapperlist" : selectedlist,
                "invoiceid" :invoidid,
                "OEMPurchaseParams" : OEMPurchaseParams
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set('v.submitdisable',true);
                    this.Suceestoast(component, event,'OEM Purchase return updated Successfully');
                }    
            });
            $A.enqueueAction(action);
    },
   createOEMPurchaseReturnRejected : function(component, event,selectedlist,OEMPurchaseParams) {
        var finalvalidity=true;
        var isvalid=true;
        var selectedrec=component.get("v.invoiceRecord");
        var childCmp = component.find("oemPurchaseReturnchild");
                if(childCmp.length){
            for(var i=0; i<childCmp.length; i++){
                isvalid=childCmp[i].validationCheckMethod();
                if(!isvalid)
                finalvalidity=false;
            }
                
        } else{
            isvalid=childCmp.validationCheckMethod();
        }

        if(finalvalidity && isvalid ){
            var invoidid=selectedrec.Invoice__c
            var action = component.get("c.createOEMPurhaseReturn");
            action.setParams({
                "wrapperlist" : selectedlist,
                "invoiceid" : invoidid,
                "OEMPurchaseParams" : OEMPurchaseParams
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                var responseObj = response.getReturnValue();
                if (state === "SUCCESS") {
                    component.set('v.submitdisable',true);
                    component.set('v.dealerRemarkFlag',true);
                    component.set('v.disablefields',true);
                    component.set('v.disableChkbox',true);
                    component.find('returnInvValExGST').set('v.value',responseObj.PSA_Taxable_Value__c);
                    component.find('rettaxableValue').set('v.value',responseObj.PSA_Total_tax__c);
                    component.find('totalRetInvValue').set('v.value',responseObj.PSA_Total_Invoice_Value__c);
                    this.Suceestoast(component, event,'OEM Purchase return updated Successfully');
                }
            });
            $A.enqueueAction(action);
        }
    },
        Suceestoast : function(component, event, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "Success",
            "message": message
        });
        toastEvent.fire();
    },
    ErrorToast : function(component, event, message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "Error",
            "message": message
        });
        toastEvent.fire();
    },
        getReturnReasons : function(component, event, helper) {
            var action = component.get('c.getReturnReasons');
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(" Return Reason **** "+state);
                if(state == 'SUCCESS') {
                    var records =response.getReturnValue();            
                    component.set("v.reasonforReturn", records);
                }
            });
            $A.enqueueAction(action);
        },
 validateMandateFields : function(component){
    var isValid = true;
    var varreasonReturn=component.find('reasonReturn').get('v.value');
    component.set("v.ReturnReasonErrorMsg",'');
    $A.util.removeClass(varreasonReturn,"disp-block");
    $A.util.addClass(varreasonReturn,"disp-none");
    if(varreasonReturn === 'undefined' || varreasonReturn == '' || varreasonReturn == null){
      isValid = false;
      component.set("v.ReturnReasonErrorMsg",'This is a required field');
      $A.util.removeClass(varreasonReturn,"disp-none");
      $A.util.addClass(varreasonReturn,"disp-block");
     }
return isValid;
},
})
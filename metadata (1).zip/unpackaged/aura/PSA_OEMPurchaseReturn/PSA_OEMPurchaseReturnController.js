({
    doInit : function(component, event, helper) {
        helper.getCustomeLookUpQuery(component,event);
        helper.getReturnReasons(component,event, helper);  
    },
    
    invoiceChanges : function(component, event, helper) {
        component.set('v.submitdisable',false); 
        var selectedrec=component.get("v.invoiceRecord");
        var invoidid=selectedrec.Invoice__c;
        if(invoidid==null || invoidid== '' || invoidid== 'undefined'){
            component.find('invoiceDate').set('v.value','');
            component.find('dealerName').set('v.value','');
            component.find('dealerCode').set('v.value','');
            component.find('dealerLocation').set('v.value','');
            component.find('returnStatus').set('v.value','');
            component.find('invoiceValueExGST').set('v.value','');
            component.find('totalTaxValue').set('v.value','');
            component.find('totalInvoiceValue').set('v.value','');
            component.find('returnInvValExGST').set('v.value','');
            component.find('rettaxableValue').set('v.value','');
            component.find('totalRetInvValue').set('v.value','');
            component.find('dispatchDate').set('v.value','');
            component.find('reasonReturn').set('v.value','');
            component.find('transporter').set('v.value','');
            component.find('ShipAdvNum').set('v.value','');
            component.find('dealerRemark').set('v.value','');
            component.find('approvedBy').set('v.value','');
            component.find('approvalStatus').set('v.value','');
            component.find('approverComments').set('v.value','');
            component.set('v.submitdisable',true);
            component.set('v.invoicelist',null);
            component.set('v.reasonReturnFlag',true); 
            component.set('v.dealerRemarkFlag',true);
            component.set('v.transporterFlag',true);
            component.set('v.ShipAdvNumFlag',true);
            component.set('v.disableChkbox',false);
            component.set('v.dipatchDateFlag',true);
            component.set('v.disablefields',true);
            component.set('v.returnstatus','');
            
        }else{
            component.find('invoiceDate').set('v.value',selectedrec.Invoice__r.PSA_Invoice_Date__c);
            component.find('dealerName').set('v.value',selectedrec.Invoice__r.PSA_Account__r.Name);
            component.find('dealerCode').set('v.value',selectedrec.Invoice__r.PSA_Account__r.Dealer_Code__c);
            component.find('dealerLocation').set('v.value',selectedrec.Invoice__r.PSA_Account__r.BillingCity);
            component.find('returnStatus').set('v.value',selectedrec.Invoice__r.PSA_oem_purchase_return_status__c);
            component.find('invoiceValueExGST').set('v.value',selectedrec.Invoice__r.Material_Value__c);
            component.find('totalTaxValue').set('v.value',selectedrec.Invoice__r.Tax_Amount__c);
            component.find('totalInvoiceValue').set('v.value',selectedrec.Invoice__r.Invoice_Amount__c);
            //Rest of field data - open
            var retStatus=selectedrec.Invoice__r.PSA_oem_purchase_return_status__c;
            if(retStatus==null||retStatus==''||retStatus=='undefined')
            {
                component.set('v.reasonReturnFlag',false); 
                component.set('v.dealerRemarkFlag',false);
            }
            else if(retStatus=='Approved')
            {
                component.set('v.returnstatus',retStatus);
                component.set('v.dipatchDateFlag',false);
                component.set('v.transporterFlag',false);
                component.set('v.ShipAdvNumFlag',false);
                component.set('v.disableChkbox',true);
                component.set('v.printdisable',false);
                var action = component.get("c.fetchinvoiceOtherdetails");
                action.setParams({ 
                    "invoiceid" : invoidid
                });
                action.setCallback(this, function (response) {
                    var state = response.getState();
                    var storeResponse = response.getReturnValue();
                    if (state === "SUCCESS") {
                        component.find('returnInvValExGST').set('v.value',storeResponse.PSA_Taxable_Value__c);
                        component.find('rettaxableValue').set('v.value',storeResponse.PSA_Total_tax__c);
                        component.find('totalRetInvValue').set('v.value',storeResponse.PSA_Total_Invoice_Value__c);
                        component.find('reasonReturn').set('v.value',storeResponse.PSA_Return_Reason__c);
                        component.find('ReturnInvNum').set('v.value',storeResponse.PSA_Return_Invoice_Number__c);
                        component.find('ReturnInvDate').set('v.value',storeResponse.PSA_Return_Invoice_Date__c);
                        component.find('ReturnReqDate').set('v.value',storeResponse.PSA_Return_Request_Date__c);
                        component.find('dealerRemark').set('v.value',storeResponse.PSA_Dealer_Remarks__c);
                        component.find('approvedBy').set('v.value',storeResponse.PSA_Approved_By__r.Name);
                        component.find('approvalStatus').set('v.value',storeResponse.PSA_Approval_Status__c);
                        component.find('approverComments').set('v.value',storeResponse.PSA_Approver_Comments__c);
                        component.find('creditNoteNum').set('v.value',storeResponse.PSA_Credit_Note_Number__c);
                        component.find('creditAmount').set('v.value',storeResponse.PSA_Credit_Amount__c);
                        component.find('creditNoteDate').set('v.value',storeResponse.PSA_Credit_Note_Date__c);
                        //component.find('psaRemarks').set('v.value',storeResponse.PSA_OEM_Purchase_Remarks__c);
                    }
                });
                $A.enqueueAction(action);
            }
                else if(retStatus=='Rejected')
                {
                    component.set('v.returnstatus',retStatus);
                    component.set('v.dealerRemarkFlag',true);
                    component.set('v.disableChkbox',true);
                    component.set('v.printdisable',true);
                    component.set('v.submitdisable',true);
                    var action = component.get("c.fetchinvoiceOtherdetails");
                    action.setParams({ 
                        "invoiceid" : invoidid
                    });
                    action.setCallback(this, function (response) {
                        var state = response.getState();
                        var storeResponse = response.getReturnValue();
                        if (state === "SUCCESS") {
                            component.find('returnInvValExGST').set('v.value',storeResponse.PSA_Taxable_Value__c);
                            component.find('rettaxableValue').set('v.value',storeResponse.PSA_Total_tax__c);
                            component.find('totalRetInvValue').set('v.value',storeResponse.PSA_Total_Invoice_Value__c);
                            component.find('reasonReturn').set('v.value',storeResponse.PSA_Return_Reason__c);
                            component.find('ReturnReqDate').set('v.value',storeResponse.CreatedDate);
                            component.find('dealerRemark').set('v.value',storeResponse.PSA_Dealer_Remarks__c);
                            component.find('approvedBy').set('v.value',storeResponse.PSA_Approved_By__r.Name);
                            component.find('approvalStatus').set('v.value',storeResponse.PSA_Approval_Status__c);
                            component.find('approverComments').set('v.value',storeResponse.PSA_Approver_Comments__c);
                            //component.find('psaRemarks').set('v.value',storeResponse.PSA_OEM_Purchase_Remarks__c);
                        }
                    });
                    $A.enqueueAction(action);
                }
            var action = component.get("c.fetchinvoicedetails");
            action.setParams({ 
                "invoiceid" : invoidid,
                "returnStatus" :retStatus
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
                if (state === "SUCCESS") {
                    component.set('v.invoicelist',storeResponse);
                }
            });
            $A.enqueueAction(action);
        } 
    },
    refreshscreen : function(component, event, helper) {
        
        var selectedrec=component.get("v.invoiceRecord");
        var retStatus=selectedrec.Invoice__r.PSA_oem_purchase_return_status__c;
        if(retStatus==null || retStatus== '' || retStatus== 'undefined')
        {
            var childCmp = component.find("pillclear");
            childCmp.clearpill();
            component.find('invoiceDate').set('v.value','');
            component.find('dealerName').set('v.value','');
            component.find('dealerCode').set('v.value','');
            component.find('dealerLocation').set('v.value','');
            component.find('returnStatus').set('v.value','');
            component.find('invoiceValueExGST').set('v.value','');
            component.find('totalTaxValue').set('v.value','');
            component.find('totalInvoiceValue').set('v.value','');
            component.find('returnInvValExGST').set('v.value','');
            component.find('taxableValue').set('v.value','');
            component.find('totalRetInvValue').set('v.value','');
            component.find('dispatchDate').set('v.value','');
            component.find('reasonReturn').set('v.value','');
            component.find('transporter').set('v.value','');
            component.find('ShipAdvNum').set('v.value','');
            component.find('dealerRemark').set('v.value','');
            component.find('approvedBy').set('v.value','');
            component.find('approvalStatus').set('v.value','');
            component.find('approverComments').set('v.value','');
            component.set('v.invoicelist',null);
            component.set('v.submitdisable',true); 
            component.set('v.printdisable',true);
            component.find('creditAmount').set('v.value','');
            component.find('creditNoteNum').set('v.value','');
            component.find('creditNoteDate').set('v.value','');
        }
        else if(retStatus=='Approved')
        {
            component.find('dispatchDate').set('v.value','');
            component.find('transporter').set('v.value','');
            component.find('ShipAdvNum').set('v.value','');
        }
            else if(retStatus=='Rejected')
            {
                component.find('reasonReturn').set('v.value','');
                component.find('dealerRemark').set('v.value','');
            }
    },
    
    saveOEMPurchaseReturn : function(component, event, helper) {
        if(helper.validateMandateFields(component)){
            var selectedlist=[];
            var returnlist=component.get('v.invoicelist');
            var dealerRemark = component.find('dealerRemark').get('v.value');
            var reasonReturn = component.find('reasonReturn').get('v.value');
            var dealerRemark = component.find('dealerRemark').get('v.value');
            var reasonReturn = component.find('reasonReturn').get('v.value');
            var returnStatus = component.find('returnStatus').get('v.value');
            var dispatchDate = component.find('dispatchDate').get('v.value');
            var transporter  = component.find('transporter').get('v.value');
            var ShipAdvNum   = component.find('ShipAdvNum').get('v.value');
            var OEMPurchaseParams;
            OEMPurchaseParams = {
                'returnStatus' : returnStatus,
                'dealerRemark' : dealerRemark,
                'reasonReturn' : reasonReturn,
                'dispatchDate' : dispatchDate,
                'transporter'  : transporter,
                'ShipAdvNum'   : ShipAdvNum
            }
            if(returnStatus==null || returnStatus== '' || returnStatus== 'undefined')
            {
                var returnlist=component.get('v.invoicelist');
                for(var i=0; i<returnlist.length; i++){
                    if(returnlist[i].checked)
                        selectedlist.push(returnlist[i]);
                }
                if(selectedlist.length>0) {
                    helper.createOEMPurchaseReturnNew(component, event,selectedlist,OEMPurchaseParams);
                }else{
                    helper.ErrorToast(component, event,'Please select atleast one part number for Return');
                }
            }
            else if(returnStatus=='Approved')
            {
                component.set('v.dipatchDateFlag',true);
                component.set('v.transporterFlag',true);
                component.set('v.ShipAdvNumFlag',true);
                helper.createOEMPurchaseReturnApproved(component, event,selectedlist,OEMPurchaseParams);
            }
                else if(returnStatus=='Rejected')
                { 
                    component.set('v.dealerRemarkFlag',true);
                    var returnlist=component.get('v.invoicelist');
                    for(var i=0; i<returnlist.length; i++){
                        if(returnlist[i].checked)
                            selectedlist.push(returnlist[i]);
                    }
                    if(selectedlist.length>0) {
                        helper.createOEMPurchaseReturnRejected(component, event,selectedlist,OEMPurchaseParams);
                    }else{
                        helper.ErrorToast(component, event,'Please select atleast one part number for Return');
                    }
                }
        }
    },
    handleClearTaxes : function(component, event, helper) {
        component.find('returnInvValExGST').set('v.value','');
        component.find('rettaxableValue').set('v.value','');
        component.find('totalRetInvValue').set('v.value','');
    },
    preventalphabets : function(component, event, helper){
        var a = event.getSource();
        var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
    },
})
({
	saveRecordCntrlr : function(component, event, helper) {
 
         if(helper.validateVendorForm(component)) {
             alert('Yes');
          component.find("recordHandler").saveRecord($A.getCallback(function(saveResult) {
            if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") { 
                console.log('Result Saved');
            	component.set("v.curView", "baseView" );  
                 var Message= $A.get("$Label.c.Vendor_Update");
                  helper.showSuccessToast(component,event,Message);
               
            } else if (saveResult.state === "INCOMPLETE") {
                console.log("User is offline, device doesn't support drafts.");
            } else if (saveResult.state === "ERROR") {
                console.log('Problem saving record, error: ' + JSON.stringify(saveResult.error));
            } else {
                console.log('Unknown problem, state: ' + saveResult.state + ', error: ' + JSON.stringify(saveResult.error));
            }
        }));
         }
	},
    
 
	cancelEditRecord : function(component, event, helper){
		var eventListPage = component.getEvent("displayListPageVendorsEdit");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
	},
     validate  : function(component, event, helper) {
        var inp = component.find("Pincode2").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(inp))
            component.find("Pincode2").set("v.value", inp.substring(0, inp.length - 1));
    },
     telvalidate  : function(component, event, helper) {
        var telinp = component.find("TelephoneNo").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(telinp))
            component.find("TelephoneNo").set("v.value", telinp.substring(0, telinp.length - 1));
    },
        mobvalidate  : function(component, event, helper) {
        var mobinp = component.find("MobileNo").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(mobinp))
            component.find("MobileNo").set("v.value", mobinp.substring(0, mobinp.length - 1));
    },
    getdistrict : function(component, event, helper){
         debugger;
        var selectstate = component.find("state").get("v.value");
        var action = component.get("c.getdistrictmethod");
        action.setParams({ 
            "selState" : selectstate,
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.isStateChanged",true);
                component.set("v.districtList", response.getReturnValue());
                component.find("district").set("v.value", "--None--");
                console.log('response.getReturnValue()'+response.getReturnValue());
           }
        });
        $A.enqueueAction(action);	
    },
    doInit: function(component, event, helper) {
        var action = component.get("c.getStateval");
        action.setCallback(this, function(response) {
        component.set("v.StateList", response.getReturnValue());
    		});
        
        var action1 = component.get("c.fetchSupplierTypePicklist");
        action1.setCallback(this, function(response) {
        component.set("v.SupplierList", response.getReturnValue());
    		});
      $A.enqueueAction(action);
        $A.enqueueAction(action1);
     },  
    
    
})
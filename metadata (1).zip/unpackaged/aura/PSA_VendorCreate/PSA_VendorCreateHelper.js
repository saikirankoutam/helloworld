({
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    /*
     *   <ui:inputselect class="mydistrictbox" aura:id="supplierType" value="{!v.simpleRecord.PSA_Supplier_Type__c}">
                 
                   <aura:iteration items="{!v.SupplierList}" var="option">
                        <ui:inputSelectOption text="{!option}" label="{!option}" value="{!option}"></ui:inputSelectOption>
                    </aura:iteration>
                </ui:inputselect>
     * 
     *  validateVendorEditForm : function(component, event, helper){
        var isValid = true;
        var vendname = component.find("vendorName").get("v.value");
        var contactPerson = component.find("contactPerson").get("v.value");
        var addressline1 = component.find("addressline1").get("v.value");
        var addressline2 = component.find("addressline2").get("v.value");
        var Pincode2 = component.find("Pincode2").get("v.value");
        var TelephoneNo = component.find("TelephoneNo").get("v.value");
        var MobileNo = component.find("MobileNo").get("v.value");
        var Emailid = component.find("Emailid").get("v.value");
        var Website = component.find("Website").get("v.value");
        var cstno = component.find("cstno").get("v.value");
        var tinno = component.find("tinno").get("v.value");
        var panno = component.find("panno").get("v.value");
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/; 
        var phoneno = /^\d{10}$/;
        component.set("v.vendorErrorMsg",'');
        $A.util.removeClass(vendname,"disp-block");
        $A.util.addClass(vendname,"disp-none");
        component.set("v.CpErrorMsg",'');  
        $A.util.removeClass(contactPerson,"disp-block");
        $A.util.addClass(contactPerson,"disp-none");
        component.set("v.add1ErrorMsg",'');
        $A.util.removeClass(addressline1,"disp-block");
        $A.util.addClass(addressline1,"disp-none");
        component.set("v.add2ErrorMsg",'');
        $A.util.removeClass(addressline2,"disp-block");
        $A.util.addClass(addressline2,"disp-none");
        component.set("v.pincodeErrorMsg",'');
        $A.util.removeClass(Pincode2,"disp-block");
        $A.util.addClass(Pincode2,"disp-none");
        component.set("v.TelephoneErrorMsg",' ');
        $A.util.removeClass(TelephoneNo,"disp-block");
        $A.util.addClass(TelephoneNo,"disp-none");
        component.set("v.emailErrorMsg",'');
        $A.util.removeClass(Emailid,"disp-block");
        $A.util.addClass(Emailid,"disp-none");
        component.set("v.mobilenoErrorMsg",'');
        $A.util.removeClass(MobileNo,"disp-block");
        $A.util.addClass(MobileNo,"disp-none");
        component.set("v.websiteErrorMsg",'');
        $A.util.removeClass(Website,"disp-block");
        $A.util.addClass(Website,"disp-none");
        component.set("v.cstnoErrorMsg",'');
        $A.util.removeClass(cstno,"disp-block");
        $A.util.addClass(cstno,"disp-none");
        component.set("v.tinnoErrorMsg",'');
        $A.util.removeClass(tinno,"disp-block");
        $A.util.addClass(tinno,"disp-none");
        component.set("v.pannoErrorMsg",' ');  
        $A.util.removeClass(panno,"disp-block");
        $A.util.addClass(panno,"disp-none");
        if(Emailid != null){
            if(Emailid.match(regExpEmailformat)){
                isValid = true;
            }
            else{
                component.set("v.emailErrorMsg",'Please Enter a Valid Email Address');
                isValid = false;
            }
        }
        
        if(vendname == 'undefined'|| vendname == '' || vendname == null){
            isValid = false;
            component.set("v.vendorErrorMsg",'This is a required field');
            $A.util.removeClass(vendname,"disp-none");
            $A.util.addClass(vendname,"disp-block");
        }
        if(contactPerson == 'undefined'|| contactPerson == '' || contactPerson == null){
            component.set("v.CpErrorMsg",'This is a required field');
            $A.util.removeClass(contactPerson,"disp-none");
            $A.util.addClass(contactPerson,"disp-block");
            isValid = false;
        }
        if(addressline1 == 'undefined'|| addressline1 == '' || addressline1 == null){
            component.set("v.add1ErrorMsg",'This is a required field');
            $A.util.removeClass(addressline1,"disp-none");
            $A.util.addClass(addressline1,"disp-block");
            isValid = false;
        }
        if(addressline2 == 'undefined'|| addressline2 == '' || addressline2 == null){
            component.set("v.add2ErrorMsg",'This is a required field');
            $A.util.removeClass(addressline2,"disp-none");
            $A.util.addClass(addressline2,"disp-block");
            isValid = false;
        }
        if(Pincode2 == 'undefined'|| Pincode2 == '' || Pincode2 == null){
            component.set("v.pincodeErrorMsg",'This is a required field');
            $A.util.removeClass(Pincode2,"disp-none");
            $A.util.addClass(Pincode2,"disp-block");
            isValid = false;
        }
        if(TelephoneNo == 'undefined'|| TelephoneNo == '' || TelephoneNo == null){
            component.set("v.TelephoneErrorMsg",'This is a required field');
            $A.util.removeClass(TelephoneNo,"disp-none");
            $A.util.addClass(TelephoneNo,"disp-block");
            isValid = false;
        }
        if(Emailid == 'undefined'|| Emailid == '' || Emailid == null){
            component.set("v.emailErrorMsg",'This is a required field');
            $A.util.removeClass(Emailid,"disp-none");
            $A.util.addClass(Emailid,"disp-block");
            isValid = false;
        }
        
        if(MobileNo == 'undefined'|| MobileNo == '' || MobileNo == null ){
            component.set("v.mobilenoErrorMsg",'This is a required field');
            $A.util.removeClass(MobileNo,"disp-none");
            $A.util.addClass(MobileNo,"disp-block");
            isValid = false;
        }
        if(Website == 'undefined'|| Website == '' || Website == null){
            component.set("v.websiteErrorMsg",'This is a required field');
            $A.util.removeClass(Website,"disp-none");
            $A.util.addClass(Website,"disp-block");
            isValid = false;
        }
        if(cstno == 'undefined'|| cstno == '' || cstno == null){
            component.set("v.cstnoErrorMsg",'This is a required field');
            $A.util.removeClass(cstno,"disp-none");
            $A.util.addClass(cstno,"disp-block");
            isValid = false;
        }
        if(tinno == 'undefined'|| tinno == '' || tinno == null){
            component.set("v.tinnoErrorMsg",'This is a required field');
            $A.util.removeClass(tinno,"disp-none");
            $A.util.addClass(tinno,"disp-block");
            isValid = false;
        }
        if(panno == 'undefined'|| panno == '' || panno == null){
            component.set("v.pannoErrorMsg",'This is a required field');
            $A.util.removeClass(panno,"disp-none");
            $A.util.addClass(panno,"disp-block");
            isValid = false;
        }
        
        return isValid;
    },*/
    validateVendorForm : function(component, event, helper){
        var isValid = true;
        debugger;
        
        var supplierType = component.find("supplierType").get("v.value");
        var supplierName = component.find("supplierName").get("v.value");
        var contactPerson = component.find("contactPerson").get("v.value");
        var addressline1 = component.find("addressline1").get("v.value");
        var addressline2 = component.find("addressline2").get("v.value");
        var district = component.find("district").get("v.value");
        var state = component.find("state").get("v.value");
        var country = component.find("country").get("v.value");
        var Pincode2 = component.find("Pincode2").get("v.value");
        var MobileNo = component.find("MobileNo").get("v.value");
        var TelephoneNo = component.find("TelephoneNo").get("v.value");
        var Emailid = component.find("Emailid").get("v.value");
        var Website = component.find("Website").get("v.value");
        var bankName = component.find("bankName").get("v.value");
        var accountName = component.find("accountName").get("v.value");
        var branchcode = component.find("branchcode").get("v.value");
        var IFSCCode = component.find("IFSCCode").get("v.value");
        var cstno = component.find("GSTno").get("v.value");
        var tinno = component.find("TINno").get("v.value");
        var panno = component.find("PANno").get("v.value");
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/; 
      
       component.set("v.supplierTypeErrorMsg",'');
        $A.util.removeClass(supplierType,"disp-block");
        $A.util.addClass(supplierType,"disp-none"); 
        
        component.set("v.supplierErrorMsg",'');
        $A.util.removeClass(supplierName,"disp-block");
        $A.util.addClass(supplierName,"disp-none");
        
        component.set("v.CpErrorMsg",'');  
        $A.util.removeClass(contactPerson,"disp-block");
        $A.util.addClass(contactPerson,"disp-none");
        component.set("v.add1ErrorMsg",'');
        $A.util.removeClass(addressline1,"disp-block");
        $A.util.addClass(addressline1,"disp-none");
        component.set("v.add2ErrorMsg",'');
        $A.util.removeClass(addressline2,"disp-block");
        $A.util.addClass(addressline2,"disp-none");
        component.set("v.DistrictErrorMsg",'');
        $A.util.removeClass(district,"disp-block");
        $A.util.addClass(district,"disp-none");
        component.set("v.StateErrorMsg",'');
        $A.util.removeClass(state,"disp-block");
        $A.util.addClass(state,"disp-none");
        component.set("v.CountryErrorMsg",'');
        $A.util.removeClass(country,"disp-block");
        $A.util.addClass(country,"disp-none");
        component.set("v.pincodeErrorMsg",'');        
        $A.util.removeClass(Pincode2,"disp-block");
        $A.util.addClass(Pincode2,"disp-none");
        component.set("v.mobilenoErrorMsg",'');
        $A.util.removeClass(MobileNo,"disp-block");
        $A.util.addClass(MobileNo,"disp-none");
        component.set("v.TelephoneErrorMsg",' ');
        $A.util.removeClass(TelephoneNo,"disp-block");
        $A.util.addClass(TelephoneNo,"disp-none");
        component.set("v.emailErrorMsg",'');
        $A.util.removeClass(Emailid,"disp-block");
        $A.util.addClass(Emailid,"disp-none");
        component.set("v.websiteErrorMsg",'');
        $A.util.removeClass(Website,"disp-block");
        $A.util.addClass(Website,"disp-none");
        component.set("v.bankNameErrorMsg",'');
        $A.util.removeClass(bankName,"disp-block");
        $A.util.addClass(bankName,"disp-none");
        component.set("v.AccountErrorMsg",'');
        $A.util.removeClass(accountName,"disp-block");
        $A.util.addClass(accountName,"disp-none");
        component.set("v.BranchErrorMsg",'');
        $A.util.removeClass(branchcode,"disp-block");
        $A.util.addClass(branchcode,"disp-none");
        component.set("v.ifscErrorMsg",'');
        $A.util.removeClass(IFSCCode,"disp-block");
        $A.util.addClass(IFSCCode,"disp-none");
        component.set("v.cstnoErrorMsg",'');
        $A.util.removeClass(cstno,"disp-block");
        $A.util.addClass(cstno,"disp-none");
        component.set("v.tinnoErrorMsg",'');
        $A.util.removeClass(tinno,"disp-block");
        $A.util.addClass(tinno,"disp-none");
        component.set("v.pannoErrorMsg",' ');  
        $A.util.removeClass(panno,"disp-block");
        $A.util.addClass(panno,"disp-none");
        
       /* if( supplierType== '--Select--'){
            isValid = false;
            component.set("v.supplierTypeErrorMsg",'This is a required field');
            $A.util.removeClass(supplierType,"disp-none");
            $A.util.addClass(supplierType,"disp-block");
            
        }*/
           
        if(supplierName == 'undefined'|| supplierName == '' || supplierName == null){
            isValid = false;
            component.set("v.supplierErrorMsg",'This is a required field');
            $A.util.removeClass(supplierName,"disp-none");
            $A.util.addClass(supplierName,"disp-block");
            
        }
        if(contactPerson == 'undefined'|| contactPerson == '' || contactPerson == null){
            component.set("v.CpErrorMsg",'This is a required field');
            $A.util.removeClass(contactPerson,"disp-none");
            $A.util.addClass(contactPerson,"disp-block");
            isValid = false;
        }
        if(addressline1 == 'undefined'|| addressline1 == '' || addressline1 == null){
            component.set("v.add1ErrorMsg",'This is a required field');
            $A.util.removeClass(addressline1,"disp-none");
            $A.util.addClass(addressline1,"disp-block");
            isValid = false;
        }
        if(addressline2 == 'undefined'|| addressline2 == '' || addressline2 == null){
            component.set("v.add2ErrorMsg",'This is a required field');
            $A.util.removeClass(addressline2,"disp-none");
            $A.util.addClass(addressline2,"disp-block");
            isValid = false;
        }
         /*  if(district == "--None--"){
            component.set("v.DistrictErrorMsg",'This is a required field');
            $A.util.removeClass(district,"disp-none");
            $A.util.addClass(district,"disp-block");
            isValid = false;
        }
        if(state == "--None--"){
            component.set("v.StateErrorMsg",'This is a required field');
            $A.util.removeClass(state,"disp-none");
            $A.util.addClass(state,"disp-block");
            isValid = false;
        }
        if(country == 'undefined'|| country == '' || country == null){
            component.set("v.CountryErrorMsg",'This is a required field');
            $A.util.removeClass(country,"disp-none");
            $A.util.addClass(country,"disp-block");
            isValid = false;
        }*/
        if(Pincode2 == 'undefined'|| Pincode2 == '' || Pincode2 == null){
            component.set("v.pincodeErrorMsg",'This is a required field');
            $A.util.removeClass(Pincode2,"disp-none");
            $A.util.addClass(Pincode2,"disp-block");
            isValid = false;
        }
         if(MobileNo == 'undefined'|| MobileNo == '' || MobileNo == null){
            component.set("v.mobilenoErrorMsg",'This is a required field');
            $A.util.removeClass(MobileNo,"disp-none");
            $A.util.addClass(MobileNo,"disp-block");
            isValid = false;
        }
        if(TelephoneNo == 'undefined'|| TelephoneNo == '' || TelephoneNo == null){
            component.set("v.TelephoneErrorMsg",'This is a required field');
            $A.util.removeClass(TelephoneNo,"disp-none");
            $A.util.addClass(TelephoneNo,"disp-block");
            isValid = false;
        }
        
        if(Emailid == 'undefined'|| Emailid == '' || Emailid == null){
            component.set("v.emailErrorMsg",'This is a required field');
            $A.util.removeClass(Emailid,"disp-none");
            $A.util.addClass(Emailid,"disp-block");
            isValid = false;
        }
        if(Emailid != null){
            if(!Emailid.match(regExpEmailformat)){
                component.set("v.emailErrorMsg",'Please Enter a Valid Email Address');
                isValid = false;
            }
        }
       
        if(Website == 'undefined'|| Website == '' || Website == null){
            component.set("v.websiteErrorMsg",'This is a required field');
            $A.util.removeClass(Website,"disp-none");
            $A.util.addClass(Website,"disp-block");
            isValid = false;
        }
         if(bankName == 'undefined'|| bankName == '' || bankName == null){
            component.set("v.bankNameErrorMsg",'This is a required field');
            $A.util.removeClass(bankName,"disp-none");
            $A.util.addClass(bankName,"disp-block");
            isValid = false;
        }
          if(accountName == 'undefined'|| accountName == '' || accountName == null){
            component.set("v.AccountErrorMsg",'This is a required field');
            $A.util.removeClass(accountName,"disp-none");
            $A.util.addClass(accountName,"disp-block");
            isValid = false;
        }
         if(branchcode == 'undefined'|| branchcode == '' || branchcode == null){
            component.set("v.BranchErrorMsg",'This is a required field');
            $A.util.removeClass(branchcode,"disp-none");
            $A.util.addClass(branchcode,"disp-block");
            isValid = false;
        }
         if(IFSCCode == 'undefined'|| IFSCCode == '' || IFSCCode == null){
            component.set("v.ifscErrorMsg",'This is a required field');
            $A.util.removeClass(IFSCCode,"disp-none");
            $A.util.addClass(IFSCCode,"disp-block");
            isValid = false;
        }
        
        if(cstno == 'undefined'|| cstno == '' || cstno == null){
            component.set("v.cstnoErrorMsg",'This is a required field');
            $A.util.removeClass(cstno,"disp-none");
            $A.util.addClass(cstno,"disp-block");
            isValid = false;
        }
        if(tinno == 'undefined'|| tinno == '' || tinno == null){
            component.set("v.tinnoErrorMsg",'This is a required field');
            $A.util.removeClass(tinno,"disp-none");
            $A.util.addClass(tinno,"disp-block");
            isValid = false;
        }
        if(panno == 'undefined'|| panno == '' || panno == null){
            component.set("v.pannoErrorMsg",'This is a required field');
            $A.util.removeClass(panno,"disp-none");
            $A.util.addClass(panno,"disp-block");
            isValid = false;
        }
      
        return isValid;
    },
})
({
    /*doInit: function(component,event,helper){
      var receivedqty = component.find("recqty").get("v.value");
      var damageqty = component.find("dmgqty").get("v.value");
      var shortageqty = component.find("shortqty").get("v.value");
       
   }*/
    autoCal : function(component, event, helper) {
        // for Row level value Calculations 
        helper.hlpRowtaxCalculation(component, event, helper);
         // Data Binding not to write any logic after this statement
        helper.hlpBindderItems(component, event, helper);
    },
    autoCalinit :function(component, event, helper) {
         // for Row level value Calculations 
       // helper.hlpRowtaxCalculation(component, event, helper);
    },
})
({
    getRepairOrderDetails : function(component, event){
        
        var action = component.get("c.getBayRepairOrderMethod");
        var recid = component.get("v.repairOrderId")
        action.setParams({
            "recordId" : recid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.repairOrderDetails", storeResponse);
                
            }
        });
        $A.enqueueAction(action);
    },
    
    getpartsconsumDetails : function(component, event){
        debugger;
        var action = component.get("c.partsConsumbalemethod");
        var recid = component.get("v.repairOrderId")
        action.setParams({
            "recordId" : recid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log('rec++++'+JSON.stringify( response.getReturnValue()));
                component.set("v.wrapperList", storeResponse);
                component.set("v.GrandTota",storeResponse[0].GrndTot);
                
            }
        });
        $A.enqueueAction(action);
    },
    
    validatePartsConsumables : function(component, event){
        alert('tt');
        var isValid = true;
        var isIssueQty = true;
        var wrapList = component.get("v.wrapperList");
        console.log('wrapList'+JSON.stringify(wrapList));
        for(var i = 0; i < wrapList.length; i++){
            var wrapRec = wrapList[i];
            if(wrapRec.avlQty == '' || wrapRec.avlQty == null){
                wrapRec.avlQty = 0;
            }
           if((wrapRec.issueqty > wrapRec.avlQty) || (wrapRec.issueqty > wrapRec.requestedQty)){
                isValid =false;
            }
        if(wrapRec.issueqty == undefined || wrapRec.issueqty == null || wrapRec.issueqty == ""){
          if(wrapRec.issueqty == 0){
            component.set("v.issueerrmsg", "");
            isValid = true;
          }
          else{
            var iqty = wrapRec.issueqty;            
            component.set("v.issueerrmsg", "Required field");
            isValid = false;
          }
        }
        else{
            component.set("v.issueerrmsg", "");
            isValid = true;
        }
        }
        if(isValid ==false){
             var Message= $A.get("$Label.c.PSA_check_the_Requested_Quantity_and_Current_stock");
             this.Requestederrortoast(component,event,Message);
        }
        if(isIssueQty == false){
            var Message= $A.get("$Label.c.PSA_Issued_Quantity_should_not_Null");
             this.showErrorToast(component,event,Message);
        }
        return isValid;
    }, 
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "Success"
        });
        toastEvent.fire();  
    },
     Requestederrortoast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "Error"
        });
        toastEvent.fire();  
    },
    })
({
    doInit: function(component, event, helper) {
        helper.getRepairOrderDetails(component, event);
        helper.getpartsconsumDetails(component, event);
    },
    
    onQuantIssue: function(component,event) {
    console.log(component.get('v.QuantIssue'));
	},
    
    savePartsConsum: function(component, event, helper) {
        debugger;
        if(helper.validatePartsConsumables(component, event)) {
            var map1 = new Map([]); 
            var x = [];
            var y = [];
            var j = component.get("v.wrapperList");
            if(j)
                for(var i=0; i<j.length; i++)
                {
                    map1.set(j[i].partno,j[i].issueqty);
                    x.push(j[i].partno);
                    y.push(j[i].issueqty);
                }
            var recid = component.get("v.repairOrderId");
            var remark = component.find("Remark").get("v.value");
            var action = component.get("c.updatePartsConsumables");
            action.setParams({
                "partnumber" : x,
                "issuedvalues" : y,
                "recordId" :recid,
                "remarks":remark
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                
                if (state === "SUCCESS") {
                    var Message= $A.get("$Label.c.PSA_Parts_Issued");
                    helper.showSuccessToast(component, event,Message);
                    helper.getpartsconsumDetails(component, event);
                }
                
            });
            $A.enqueueAction(action);
        }
    },
    picklistpdf : function(component, event, helper) {
        var workorderId = component.get("v.repairOrderId");
        var action = component.get("c.getWorkorderlineitems");
        
        action.setParams({
            "workordid" : workorderId  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var lineid =''
                var storeResponse = response.getReturnValue();
                for(var i = 0; i < storeResponse.length; i++){
                    lineid =storeResponse[0].Id;
                    
                }
                var baseUrl= decodeURIComponent(window.location.hostname);
                
                var url = 'https://'+baseUrl+'/dmsindia/s/workorderlineitem/'+lineid;
                
                window.open(url,"_blank", "width=600, height=550");
                
            }
        });
        $A.enqueueAction(action);
        
    },
    
    workshoppnotepdf:function(component, event, helper) {
        debugger;
        var workorderId = component.get("v.repairOrderId");
        var action = component.get("c.getWorkorderlineitems");
        
        action.setParams({
            "workordid" : workorderId  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var lineid =''
                var storeResponse = response.getReturnValue();
                for(var i = 0; i < storeResponse.length; i++){
                    lineid =storeResponse[0].Id;
                    
                }
                if(storeResponse.length>0){
                    var recordId = event.target.id;               
                    var pdfurl ='../PSA_WorkshopNotePdf?Id='+lineid;
                    window.open(pdfurl); 
                }
                 else{
                     var Message= 'Parts not issued';
                     helper.Requestederrortoast(component,event,Message); 
            	}
            }
          
          });
         $A.enqueueAction(action);
    }
        
    })
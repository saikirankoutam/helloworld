({
    doInit : function(component, event, helper) {
        var forecastTimeline = parseInt($A.get("$Label.c.MonthlyOrder_Forecast_timeline"));
        var submitTimeline = parseInt($A.get("$Label.c.MonthlyOrder_Submit_timeline"));
        var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        var today = new Date();
        var submitDay = new Date();
        today.setDate(today.getDate() + forecastTimeline);
        var month = today.getMonth();
        var monthName = months[month];
        var year = today.getFullYear();    
        component.set("v.month", month);
        window.setTimeout($A.getCallback(function() {
            var findMonth = component.find(month);
            $A.util.removeClass(findMonth, 'disable');
            $A.util.addClass(findMonth, 'activetab'); 
        }), 2000); 
        component.set("v.year", year);
        var halfyear = year.toString();
        component.set("v.halfyear", halfyear.slice(2));
        component.set("v.monthName", monthName);
        component.set("v.monthNameHalf", monthName.slice(0,3));
        if(today.getDate() > 27)
        today.setDate(today.getDate() - 3);
        
        var f1 = today;
        f1.setMonth(f1.getMonth() + 1);
        var fmonth1 = f1.getMonth();
        var fyear1 = f1.getFullYear();
        fyear1 = fyear1.toString();
        var fmonthfull1 = months[fmonth1];
        
        var f2 = today;
        f2.setMonth(f2.getMonth() + 1);
        var fmonth2 = f2.getMonth();
        var fyear2 = f2.getFullYear();
        fyear2 = fyear2.toString();
        var fmonthfull2 = months[fmonth2];
        
        var f3 = today;
        f3.setMonth(f3.getMonth() + 1);
        var fmonth3 = f3.getMonth();
        var fyear3 = f3.getFullYear();
        fyear3 = fyear3.toString();
        var fmonthfull3 = months[fmonth3];
        
        var f4 = today;
        f4.setMonth(f4.getMonth() + 1);
        var fmonth4 = f4.getMonth();
        var fyear4 = f4.getFullYear();
        fyear4 = fyear4.toString();
        var fmonthfull4 = months[fmonth4];
        
        var f5 = today;
        f5.setMonth(f5.getMonth() + 1);
        var fmonth5 = f5.getMonth();
        var fyear5 = f5.getFullYear();
        fyear5 = fyear5.toString();
        var fmonthfull5 = months[fmonth5];
        
        var f6 = today;
        f6.setMonth(f6.getMonth() + 1);
        var fmonth6 = f6.getMonth();
        var fyear6 = f6.getFullYear();
        fyear6 = fyear6.toString();
        var fmonthfull6 = months[fmonth6];
        
        component.set("v.fMonth1", fmonthfull1);
        component.set("v.fMonth2", fmonthfull2);
        component.set("v.fMonth3", fmonthfull3);
        component.set("v.fMonth4", fmonthfull4);
        component.set("v.fMonth5", fmonthfull5);
        component.set("v.fMonth6", fmonthfull6);
        component.set("v.fMonthhalf1", fmonthfull1.slice(0,3));
        component.set("v.fMonthhalf2", fmonthfull2.slice(0,3));
        component.set("v.fMonthhalf3", fmonthfull3.slice(0,3));
        component.set("v.fMonthhalf4", fmonthfull4.slice(0,3));
        component.set("v.fMonthhalf5", fmonthfull5.slice(0,3));
        component.set("v.fMonthhalf6", fmonthfull6.slice(0,3));
        component.set("v.fyear1", fyear1);
        component.set("v.fyear2", fyear2);
        component.set("v.fyear3", fyear3);
        component.set("v.fyear4", fyear4);
        component.set("v.fyear5", fyear5);
        component.set("v.fyear6", fyear6);
        component.set("v.fyearhalf1", fyear1.slice(2));
        component.set("v.fyearhalf2", fyear2.slice(2));
        component.set("v.fyearhalf3", fyear3.slice(2));
        component.set("v.fyearhalf4", fyear4.slice(2));
        component.set("v.fyearhalf5", fyear5.slice(2));
        component.set("v.fyearhalf6", fyear6.slice(2));
        var objectivetotal=0;
        var commitmenttotal=0;
        var acheivmemttotal=0; 
        var acheivement =0;
        /* var action = component.get('c.getOrdersForPSA');
        action.setParams({
            'orderType' : orderType 
        }); */
        var searchdealer = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        var action = component.get('c.getdealerobjective');
        action.setParams({
            'searchkey' : '' 
        }); 
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue(); 
                var recsize = records.length;
                var showrecords;
                if(recsize.length >2)
                {
                    showrecords == 2;
                    
                }
                else{
                    showrecords = recsize;
                }
                var reclimit = [];
                for(var i=0; i<showrecords; i++){              
                    reclimit.push(records[i]);                    
                }         
                for(var i=0;i<records.length;i++){
                    objectivetotal=objectivetotal+records[i].objective;
                    commitmenttotal=commitmenttotal+records[i].commitment;
                }
                if(objectivetotal == 0 || commitmenttotal ==0){
                    acheivmemttotal = 0;
                }else{
                    acheivmemttotal=(commitmenttotal/objectivetotal)*100; 
                    acheivement = Math.round(acheivmemttotal);             
            	}
                component.set("v.orders", reclimit);
                component.set("v.objtotal", objectivetotal);
                component.set("v.committotal", commitmenttotal);
                component.set("v.achtotal", acheivement);
                component.set("v.totalcount",records.length);
                component.set('v.allorders',records);
            }
        });
        $A.enqueueAction(action);
        helper.totalobjectivedata(component, event);
    },
    viewall:function(component,event,helper){
        debugger;
        var allrecords = component.get('v.allorders');   
        component.set('v.orders',allrecords);
        
    },
    onclickPO : function(component, event, helper) {
        var target = event.getSource().get('v.value');  
        var compEvent = component.getEvent("monthlyOrderIdPass");        
        var compEventDaily = component.getEvent("DailyOrderIdPass");
        compEvent.setParams({"currentMonthlyOrderId" : target });
        compEventDaily.setParams({"currentMonthlyOrderId" : target });
        if(component.get("v.orderType") == 'monthly')
        {
            compEvent.fire();
        }
        if(component.get("v.orderType") == 'daily')
        {
            compEventDaily.fire();
        }
    },
    
    searchdealer : function(component, event, helper) {
        debugger;
        var searchdealer = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        
        var action = component.get('c.getdealerobjective');
        action.setParams({
            'searchkey' : searchdealer         
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {               
                var records =response.getReturnValue();
                console.log("Inside "+state);
                component.set("v.orders", records);
            }
        });
        $A.enqueueAction(action);  
    }
    
    
    //var compEvent = cmp.getEvent("sampleComponentEvent");
    // Optional: set some data for the event (also known as event shape)
    // A parameter’s name must match the name attribute
    // of one of the event’s <aura:attribute> tags
    // compEvent.setParams({"myParam" : myValue });
    //compEvent.fire();
})
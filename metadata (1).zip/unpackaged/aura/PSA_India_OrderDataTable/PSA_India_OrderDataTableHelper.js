({
	totalobjectivedata : function(component, event) {
        var action = component.get('c.gettotalmonthrecord');
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                 component.set("v.objwrap",records);          
            }
        });
        $A.enqueueAction(action);
		
	}
})
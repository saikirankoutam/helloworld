({
    doInit: function(component, event, helper) {

                 helper.contactdetails(component, event, helper);
                 helper.getregdetails(component, event, helper);
        	     helper.Insudetails(component, event, helper);
				 helper.getcustomerinfo(component, event, helper);
                 helper.allotmentdetails(component, event, helper);
                 helper.getinvoicedetails(component, event, helper);
                 helper.getorder(component, event, helper);
                 helper.getVDNcheck(component, event, helper);
                 helper.DeliveryNoteDetails(component, event, helper);
              
	}, 
  
       /*	helper.getregdetails(component, event, helper);
        helper.details(component, event, helper);
        helper.deliverynote(component, event, helper);
        helper.getcustomerinfo(component, event, helper);
        
        
    },*/
    
    generateOTP: function(component, event, helper) {
        debugger;
        var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.recievepin");
        
        action.setParams({
            "booknum" :bookingid
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state == "SUCCESS") {
                var storeResponse = response.getReturnValue();
                //var pinNo=storeResponse;
                 var message='PIN sent to Email successfully';
                 helper.showSuccessToastDel(component,event,message ); 
            }
        });
        $A.enqueueAction(action);
    },
     viewAttachment : function(component, event, helper) {
        helper.fetchdocumenturl(component, event, helper);
         
    },
    
   handleSave: function(component, event, helper) {
        debugger;
        helper.saveinformation(component,event, helper);  
      },
     handleValidatepin: function(component, event, helper) {
        debugger;
        helper.validatepin(component, event, helper);
      
      },
    DeliveryNote :  function(component, event, helper) {
        helper.vdnSavedisable(component, event, helper);
        
    },
    warrantyslip :  function(component, event, helper) {
      //  var recordId = component.get("v.repairOrderId");
           var bookingid=component.get("v.bookingorderid");
        var pdfurl ='../PSA_WarrantySlip?id='+bookingid;
        window.open(pdfurl,"_blank", "width=700, height=550"); 
    },
    
    gatepass :  function(component, event, helper) {
      //  var recordId = component.get("v.repairOrderId");
           var bookingid=component.get("v.bookingorderid");
        var pdfurl ='../PSA_DeliveryChecklistPDF?id='+bookingid;
        window.open(pdfurl,"_blank", "width=700, height=550"); 
    },
    
    handleFilesChange: function(component, event, helper) {
        debugger;
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
        if(ext == "png" || ext == "PNG" || ext == "JPEG" || ext == "jpeg" || ext == "jpg" || ext == "JPG" || ext == "pdf" || ext =="PDF" || ext =="docx"){
            component.set("v.fileName", fileName);
        }
        else{
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": "Upload png,jpg,jpeg,PDF,word Files only"
            });
            toastEvent.fire();
        }
    }, 
    
    
    handleupload: function(component, event, helper) {
        debugger;
        var fileName1 = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName1 = event.getSource().get("v.files")[0]['name'];
            
        }
        var ext = fileName1.substring(fileName1.lastIndexOf('.') + 1);
        if(ext == "png" || ext == "PNG" || ext == "JPEG" || ext == "jpeg" || ext == "jpg" || ext == "JPG" || ext == "pdf" || ext =="PDF" || ext =="docx"){
            component.set("v.secondfilename", fileName1);
        }
        else{
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": "Upload png,jpg,jpeg,pdf,word Files only"
            });
            toastEvent.fire();
        }
    }, 
    signedDeliver: function(component, event, helper) {
        debugger;
        var fileName1 = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName1 = event.getSource().get("v.files")[0]['name'];
        }
        var ext = fileName1.substring(fileName1.lastIndexOf('.') + 1);
        if(ext == "png" || ext == "PNG" || ext == "JPEG" || ext == "jpeg" || ext == "jpg" || ext == "JPG"){
            component.set("v.thirdfileName", fileName1);
        }
        else{
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": "select valid file type"
            });
            toastEvent.fire();
        }
    }, 
 
  /* enableretail: function(component, event, helper) {
    var regno=component.find("regnum").get("v.value");
        var hsrpno=component.find("refnum").get("v.value");
        //alert(regno);
        if(regno==null || regno=='' || regno=="undefined")
        {
            component.set("v.disableretail",true);
        }
        else
        {
             component.set("v.disableretail",false);
        }
    },*/
    
    
    onRetail: function(component,event,helper){
        debugger;
        var isValid = true;
        var regnum = component.find("regnum").get("v.value");
        var refnum = component.find("refnum").get("v.value");
        var validPin = component.find("validPin").get("v.value");
        var pinCheck = component.get("v.pinCheck");
         component.set("v.regnumerr",'');
         $A.util.removeClass(regnum,"disp-block");
         $A.util.addClass(regnum,"disp-none");
        component.set("v.hsrpErrorMsg",'');
         $A.util.removeClass(refnum,"disp-block");
         $A.util.addClass(refnum,"disp-none");
         component.set("v.validPinErrorMsg",'');
         $A.util.removeClass(validPin,"disp-block");
         $A.util.addClass(validPin,"disp-none");
         
            if( regnum== '--None--' || regnum==''|| regnum=='undefined'|| regnum==null){
             isValid = false;
             component.set("v.regnumerr",'This is a required field in registration tab to click retail');
             $A.util.removeClass(regnum,"disp-none");
             $A.util.addClass(regnum,"disp-block");
            component.set("v.disableretail",false);
            }
        else if(refnum== '--None--' || refnum==''|| refnum=='undefined'|| refnum==null)
        {
            isValid = false;
             component.set("v.hsrpErrorMsg",'This is a required field to click retail');
             $A.util.removeClass(refnum,"disp-none");
             $A.util.addClass(refnum,"disp-block");
            component.set("v.disableretail",false);
           
        }
        else if(validPin== '--None--' || validPin==''|| validPin=='undefined'|| validPin==null)
        {
            isValid = false;
             component.set("v.validPinErrorMsg",'This is a required field to click retail');
             $A.util.removeClass(validPin,"disp-none");
             $A.util.addClass(validPin,"disp-block");
            component.set("v.disableretail",false);
           
        }
        else if(pinCheck==''|| pinCheck=='undefined'|| pinCheck==null)
        {
           helper.showErrorToast(component,event,'Please Validate PIN');  
        }
        else if(validPin !=pinCheck)
        {
           helper.showErrorToast(component,event,'Please Enter Valid PIN');            
        }
        else
        {
           helper.enablegeneratevehnote(component, event, helper);    
        }
    },    
   cancelorder: function(component, event, helper) 
    {
    component.set("v.isModalOpen", true);
    },  
     closeInsurance :function(component, event, helper)
    {
    component.set("v.isModalOpen", false);
    },
    changeStatus: function(component, event, helper) {
        debugger;
        var orderId=  component.get("v.bookingorderid");
       
        var action = component.get("c.DeleteAllocaterecord");
          action.setParams({
            "orderid":orderId,
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state=="SUCCESS"){
                
                var values=response.getReturnValue();
                if(values=='Success')
                {
                helper.showSuccessToastDel(component,event, 'Delivery Note Successfully Cancelled');
                component.set("v.disableCancel",true);
                 component.set("v.checkgatepass",true);    
                component.set("v.checkstaus",true);
                component.set("v.nodelivrynote",true);
                component.set("v.Status",'cancelled');
                component.set("v.checkingRoStatus",true); 
                var now = $A.localizationService.formatDate(new Date(), "MM/dd/YYYY");
                component.set("v.cancelDt",now);
                component.set("v.disablesave",true);
               // component.set("v.disablebutton",true);
                
                }
                component.set("v.isModalOpen", false); 
                
            }
        });
        $A.enqueueAction(action);
        
    },
    /*var isValid = true;
        var insud=component.get("v.registration"); 
        var  regnum = component.find("regnum").get("v.value");
        component.set("v.regnumerr",'');
        $A.util.removeClass(regnum,"disp-block");
        $A.util.addClass(regnum,"disp-none");
        if(regnum == 'undefined'|| regnum == '' || regnum == null){
            component.set("v.numErrMsg",'This is a required field');
            $A.util.removeClass(regnum,"disp-none");
            $A.util.addClass(regnum,"disp-block");
            isValid = false;
        }*/
    
})
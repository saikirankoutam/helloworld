({
    getCaseDetails :function(component,event,helper){ 
        
        var caseId = component.get("v.currentCaseId");
        var action = component.get("c.fetchCaseInfo");
        console.log('caseId -- '+caseId);
        action.setParams({
            "caseId": caseId
        });        
        action.setCallback(this, function(response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            console.log('storeResponse -- '+storeResponse);
            if (state === "SUCCESS") {
                component.set("v.caseInfo", storeResponse);
            }
            
        });
        $A.enqueueAction(action);	
    },
    onSubmitCaseDetails : function(component,event) { 
        var isValid = true;
        var caseId = component.get("v.currentCaseId");
        var partnumber = component.find("partnumber").get("v.value");
        component.set("v.partsErrmsg",'');        
        $A.util.removeClass(partnumber,"disp-block");
        $A.util.addClass(partnumber,"disp-none");        
        if(partnumber == 'undefined'|| partnumber == '' || partnumber == null){
            component.set("v.partsErrmsg",'Part Number cannot be left blank');
            $A.util.removeClass(partnumber,"disp-none");
            $A.util.addClass(partnumber,"disp-block");
            isValid = false;
        }     
        if (isValid) {
            var action = component.get("c.updateCaseInfo");
            action.setParams({
                "partNumber": partnumber,
                "caseId": caseId
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
                if (state === "SUCCESS") {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": "Part Request Updated",
                        "type": "success"
                    });
                    toastEvent.fire(); 
                    component.set("v.newpartrequest", false);
                    var eventListPage = component.getEvent("displayListPageCase");
                    eventListPage.setParams({"listPage" : true });
                    eventListPage.fire();
                }
            });
            $A.enqueueAction(action);
        }
    }
})
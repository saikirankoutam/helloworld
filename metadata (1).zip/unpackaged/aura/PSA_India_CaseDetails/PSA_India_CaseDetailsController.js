({
	doInit: function (component, event,helper) {
        helper.getCaseDetails(component, event);
       
    },
    onCancel : function(component, event, helper){
        component.set("v.newpartrequest", false);
        var eventListPage = component.getEvent("displayListPageCase");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
	onSubmit: function (component, event,helper) {
        helper.onSubmitCaseDetails(component, event);
        
    },    
    
})
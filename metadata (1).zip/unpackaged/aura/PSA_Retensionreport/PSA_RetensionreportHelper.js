({
	requisitionnumberload : function(component, event) {
        var action = component.get("c.retensionreportmethod");
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set('v.retensionlist',response.getReturnValue());
                }
            });
            $A.enqueueAction(action);
	},
     getAccountRegionmet : function(component, event, helper) {
            debugger;
             component.set('v.norecords', false);
            var action = component.get('c.getAccountRegion');
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(" State Acc **** "+state);
                if(state === 'SUCCESS') {
                    var records =response.getReturnValue();  
                    console.log('states@@@'+records);
                    component.set("v.accountRegion", records);
                }
            });
            $A.enqueueAction(action);
        },
        
        getYears : function(component, event, helper)  {
            component.set('v.norecords', false);
            var action = component.get('c.getObjectiveyears');
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(" State **** "+state);
                if(state == 'SUCCESS') {
                    var records =response.getReturnValue();            
                    component.set("v.yearlist", records);
                    var selectyr = component.find("yearselect").get("v.value");
                    if(selectyr == 'option'){
                         var curryearsel = today.getFullYear();
                    component.set("v.yearSelected", curryearsel);
                }
                    else{
                         component.set("v.yearSelected", selectyr);
                    }
                  
                }
            });
            $A.enqueueAction(action);
            
        },
})
({
    getVendorName:function(component,event,helper){
          var action = component.get("c.fetchDealerInfo");
       
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                 var storeResponse = response.getReturnValue();
                component.set("v.DealerId", storeResponse[i].Id);
             }
        });
        $A.enqueueAction(action);
    },
    getpartcount:function(component,event,helper){
          var action = component.get("c.restrictPart");
       
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                 var storeResponse = response.getReturnValue();
               // alert(storeResponse);
                var staticLabel = $A.get("$Label.c.LocalPartCreationQty");
                //alert(staticLabel);
                if(storeResponse>staticLabel)
                {
                    this.showError(component, event);
                     component.set("v.newpartrequest",false);
        			component.set("v.listpartrequest", true); 
                }
                else
                {
                      	component.set("v.newpartrequest",true);
        				component.set("v.listpartrequest", false); 
                }
             }
        });
        $A.enqueueAction(action);
    },
     showError : function(component, event) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": "Part Limit exceeded"
        });
        toastEvent.fire();
       // component.set("v.spinner", false);
    },

})
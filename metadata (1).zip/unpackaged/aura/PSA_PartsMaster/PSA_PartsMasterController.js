({
    doInit: function(component, event, helper) {
      //  helper.getVendorName(component,event,helper);
       
    },
    Createpart:function(component,event,helper){
        //helper.getpartcount(component,event,helper);
        component.set("v.newpartrequest",true);
        component.set("v.listpartrequest", false); 
        
    },
    
      partsearch: function(component, event, helper) { 
           debugger;
       var tabVal = component.get("v.currTab");
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        console.log("" + event.getSource().get("v.value"));
         component.set("v.Searchstring",pot) ;
    
             if(tabVal == 'oemDetails'){
            var childCmp = component.find("partsreceiptinvoicesId2");
            childCmp.getinvoices();
        }
             if(tabVal == 'allDetails'){
            var childCmp = component.find("partsreceiptinvoicesId");
            childCmp.getinvoices();
        }
             if(tabVal == 'localDetails'){
            var childCmp = component.find("partsreceiptinvoicesId3");
            childCmp.getinvoices();
        }
         
          },
    handlemonthly:function(component, event, helper) {
  var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.showDatavalues", true);
             component.set("v.listpartrequest", true);
             component.set("v.partviewform", false);
             component.set("v.localDetails",true);
            component.set("v.allDetails",false);
             component.set("v.showData", false);
        }
        
        
    },
   
    handlemonthlyOrderIdPass : function(component, event, helper) {
        var currentpartorderid = event.getParam("currentMonthlyOrderId");   
        component.set("v.RecordId", currentpartorderid);
    	component.set("v.partviewform", true);
        component.set("v.listpartrequest", false);
       
    },
     handlemonthlyOrderIdPassoem : function(component, event, helper) {
        var currentpartorderid = event.getParam("currentMonthlyOrderIdoem");   
        component.set("v.RecordId", currentpartorderid);
    	component.set("v.partviewformoem", true);
        component.set("v.listpartrequest", false);
       
    },
        displayPartsview : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.listpartrequest", true);
            component.set("v.partviewform", false);
            
        }
    },
    displaylistview : function(component, event, helper) {
        var listPage = event.getParam("listPage");
         if(listPage){
            component.set("v.localDetails", true);
            component.set("v.partviewform", false);         
        }
       
    },
     onTabSelect : function(component, event, helper) {            
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");         
    },   
    
    showdisplayListPage :function(component,event,helper){
        var listPage = event.getParam("listPage");
          component.set("v.listpartrequest", true);
         component.set("v.newpartrequest", false);
        //if(listPage){
           // component.set("v.listpartrequest", true);
            //component.set("v.newpartrequest", false);
      //  }
    }
                                                         
})
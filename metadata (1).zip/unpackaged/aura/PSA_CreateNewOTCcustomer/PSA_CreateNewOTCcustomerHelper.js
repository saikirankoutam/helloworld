({
	 showSuccessToast : function(component, event, helper){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": "Customer Successfully created",
            "type": "success"
        });
        toastEvent.fire();  
    },
     showvalidationToast : function(component, event, helper){
        var toastEvent = $A.get("e.force:showToast");
    //    component.find("button").set("v.disabled",true);

        toastEvent.setParams({
            "title": "Error!",
            "message": "Enter Information in correct format",
            "type": "error"
        });
        toastEvent.fire();  
    },
    showError : function(component, event, msg) {
         var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": "Duplicate record",
            "type": "error"
        });
        toastEvent.fire();
      //  component.set("v.spinner", false);
    },
    
      getaccrec: function(component, event, helper) {
          var action = component.get("c.loadacc");
        action.setCallback(this, function(response) {
        component.set("v.accrecId", response.getReturnValue());
           
     // alert('recrdtypeid'+test);
       });
      $A.enqueueAction(action);
     }, 
    
    
    
  /*    getautocustId: function(component, event, helper) {
      var action = component.get("c.loadnewcustId");
      action.setCallback(this, function(response) {
      component.set("v.autocustId", response.getReturnValue());
           
     // alert('recrdtypeid'+test);
       });
      $A.enqueueAction(action);
     },  
    */
    
    
    
    
  /*  credlimitdisable: function(component, event, helper) {
        var crdLimit = component.get("v.credLimit");
        if(crdLimit=="Yes")
               {
                   component.set("v.enablecredlimit",true);
               }
               else{
                   component.set("v.enablecredlimit",false);
               }
     },  */

    validateCustomerForm : function(component, event, helper){debugger;
        var isValid = true;
        var custSeg = component.find("CustSeg").get("v.value");
        var custId = component.find("custId").get("v.value");
        var fname = component.find("Fname").get("v.value");
        var lName = component.find("Lname").get("v.value");
        var gender = component.find("gender").get("v.value");
       // var occupation = component.find("occ").get("v.value");
       // var institution = component.find("institute").get("v.value");
       // var organisation = component.find("org").get("v.value");
        var gst = component.find("gst").get("v.value");
        var uin = component.find("uin").get("v.value");
        var pan = component.find("pan").get("v.value");
        var addr1 = component.find("addressline1").get("v.value");
        var addr2 = component.find("addressline2").get("v.value");
        var district = component.find("city").get("v.value");
        var state = component.find("state").get("v.value");
        var country = component.find("country").get("v.value");
        var pincode = component.find("pin").get("v.value");
        var phone = component.find("phno").get("v.value");
          var district = component.find("district").get("v.value");                                                      
       // var alternateph = component.find("altphno").get("v.value");
        var email = component.find("email").get("v.value");
        var creditlimit = component.find("limit").get("v.value");
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        //var regExpEmailformat = /^[a-zA-Z0-9_+&*-] + (?:\\.[a-zA-Z0-9_+&*-]+ )*@(?:[a-zA-Z0-9-]+\\.) + [a-zA-Z]{2, 7}/;
        var genericvalidation=/^[a-z  A-Z]*$/;
        var panformat=/^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
        var gstformat=/^([a-zA-Z0-9]{15})*$/ ;
        var uinformat=/^([a-zA-Z0-9]{12})*$/ ;
        var crdLimit = component.get("v.credLimit");
        component.set("v.CustomerSegmentErrorMsg",'');
        $A.util.removeClass(custSeg,"disp-block");
        $A.util.addClass(custSeg,"disp-none");
        component.set("v.CustomerIdErrorMsg",'');
        $A.util.removeClass(custId,"disp-block");
        $A.util.addClass(custId,"disp-none");
        component.set("v.FirstNameErrorMsg",'');  
        $A.util.removeClass(fname,"disp-block");
        $A.util.addClass(fname,"disp-none");
        component.set("v.LastNameErrorMsg",'');
        $A.util.removeClass(lName,"disp-block");
        $A.util.addClass(lName,"disp-none");
        component.set("v.GenderErrorMsg",'');
        $A.util.removeClass(gender,"disp-block");
        $A.util.addClass(gender,"disp-none");
       /* component.set("v.OccupationErrorMsg",'');
        $A.util.removeClass(occupation,"disp-block");
        $A.util.addClass(occupation,"disp-none");
        component.set("v.InstitutionErrorMsg",'');
        $A.util.removeClass(institution,"disp-block");
        $A.util.addClass(institution,"disp-none");
        component.set("v.OrganizationErrorMsg",'');
        $A.util.removeClass(organisation,"disp-block");
        $A.util.addClass(organisation,"disp-none");*/
        component.set("v.GSTINErrorMsg",'');        
        $A.util.removeClass(gst,"disp-block");
        $A.util.addClass(gst,"disp-none");
        component.set("v.UINErrorMsg",' ');
        $A.util.removeClass(uin,"disp-block");
        $A.util.addClass(uin,"disp-none");
        component.set("v.PANErrorMsg",'');
        $A.util.removeClass(pan,"disp-block");
        $A.util.addClass(pan,"disp-none");
        component.set("v.Address1ErrorMsg",'');
        $A.util.removeClass(addr1,"disp-block");
        $A.util.addClass(addr1,"disp-none");
        component.set("v.Address2ErrorMsg",'');
        $A.util.removeClass(addr2,"disp-block");
        $A.util.addClass(addr2,"disp-none");
        component.set("v.DistrictErrorMsg",'');
        $A.util.removeClass(district,"disp-block");
        $A.util.addClass(district,"disp-none");
        component.set("v.StateErrorMsg",'');
        $A.util.removeClass(state,"disp-block");
        $A.util.addClass(state,"disp-none");
        component.set("v.CountryErrorMsg",'');
        $A.util.removeClass(country,"disp-block");
        $A.util.addClass(country,"disp-none");
        component.set("v.PincodeErrorMsg",'');
        $A.util.removeClass(pincode,"disp-block");
        $A.util.addClass(pincode,"disp-none");
        component.set("v.PhoneErrorMsg",'');
        $A.util.removeClass(phone,"disp-block");
        $A.util.addClass(phone,"disp-none");
      /*  component.set("v.AltmobileErrorMsg",'');
        $A.util.removeClass(alternateph,"disp-block");
        $A.util.addClass(alternateph,"disp-none");*/
        component.set("v.EmailErrorMsg",'');  
        $A.util.removeClass(email,"disp-block");
        $A.util.addClass(email,"disp-none");
        component.set("v.CreditlimitErrorMsg",'');  
        $A.util.removeClass(creditlimit,"disp-block");
        $A.util.addClass(creditlimit,"disp-none");
        $A.util.removeClass(district,"disp-block");
        $A.util.addClass(district,"disp-non");
        
        if(custSeg == 'undefined'|| custSeg == '' || custSeg == '--Select--'){
            isValid = false;
            component.set("v.CustomerSegmentErrorMsg",'This is a required field');
            $A.util.removeClass(custSeg,"disp-none");
            $A.util.addClass(custSeg,"disp-block");
        }
        /*  if(custId == 'undefined'|| custId == '' || custId == null){
            isValid = false;
            component.set("v.CustomerIdErrorMsg",'This is a required field');
            $A.util.removeClass(custId,"disp-none");
            $A.util.addClass(custId,"disp-block");
        }*/
         
        
       //  if(gender == 'undefined'|| gender == '' || gender == null){
            // component.set("v.GenderErrorMsg",'This is a required field');
            // $A.util.removeClass(gender,"disp-none");
           //  $A.util.addClass(gender,"disp-block");
          //   isValid = false;
        /// }
         
       /*  if(occupation == 'undefined'|| occupation == '' || occupation == null){
             component.set("v.OccupationErrorMsg",'This is a required field');
             $A.util.removeClass(occupation,"disp-none");
             $A.util.addClass(occupation,"disp-block");
             isValid = false;
         }
         
        
         
         if(institution == 'undefined'|| institution == '' || institution == null){
             component.set("v.InstitutionErrorMsg",'This is a required field');
             $A.util.removeClass(institution,"disp-none");
             $A.util.addClass(institution,"disp-block");
             isValid = false;
         }
         
      
         
         if(organisation == 'undefined'|| organisation == '' || organisation == null){
             component.set("v.OrganizationErrorMsg",'This is a required field');
             $A.util.removeClass(organisation,"disp-none");
             $A.util.addClass(organisation,"disp-block");
             isValid = false;
         }*/
         
       
         
       
         
        /* if(email == 'undefined'|| email == '' || email == null){
             component.set("v.EmailErrorMsg",'This is a required field');
             $A.util.removeClass(email,"disp-none");
             $A.util.addClass(email,"disp-block");
             isValid = false;
         }*/
         
         if(addr1 == 'undefined'|| addr1 == '' || addr1 == null){
             component.set("v.Address1ErrorMsg",'This is a required field');
             $A.util.removeClass(addr1,"disp-none");
             $A.util.addClass(addr1,"disp-block");
             isValid = false;
         }
         if(addr2 == 'undefined'|| addr2 == '' || addr2 == null){
             component.set("v.Address2ErrorMsg",'This is a required field');
             $A.util.removeClass(addr2,"disp-none");
             $A.util.addClass(addr2,"disp-block");
             isValid = false;
         }
         if(district == 'undefined'|| district == '' || district == null){
             component.set("v.DistrictErrorMsg",'This is a required field');
             $A.util.removeClass(district,"disp-none");
             $A.util.addClass(district,"disp-block");
             isValid = false;
         }
         if(state == 'undefined'|| state == '' || state == null || state == '--None--'){
             component.set("v.StateErrorMsg",'This is a required field');
             $A.util.removeClass(state,"disp-none");
             $A.util.addClass(state,"disp-block");
             isValid = false;
         }
         if(country == 'undefined'|| country == '' || country == null){
             component.set("v.CountryErrorMsg",'This is a required field');
             $A.util.removeClass(country,"disp-none");
             $A.util.addClass(country,"disp-block");
             isValid = false;
         }
         if(pincode == 'undefined'|| pincode == '' || pincode == null){
             component.set("v.PincodeErrorMsg",'This is a required field');
             $A.util.removeClass(pincode,"disp-none");
             $A.util.addClass(pincode,"disp-block");
             isValid = false;
         }
         
         if(phone == 'undefined'|| phone == '' || phone == null){
             component.set("v.PhoneErrorMsg",'This is a required field');
             $A.util.removeClass(phone,"disp-none");
             $A.util.addClass(phone,"disp-block");
             isValid = false;
         }
      /*   if(alternateph == 'undefined'|| alternateph == '' || alternateph == null){
             component.set("v.AltmobileErrorMsg",'This is a required field');
             $A.util.removeClass(alternateph,"disp-none");
             $A.util.addClass(alternateph,"disp-block");
             isValid = false;
         }*/
           if(crdLimit=="Yes")
            {
         	if(creditlimit == 'undefined'|| creditlimit == '' || creditlimit == null)
            {
                component.set("v.CreditlimitErrorMsg",'This is a required field');
                $A.util.removeClass(creditlimit,"disp-none");
                $A.util.addClass(creditlimit,"disp-block");
                isValid = false;
            }
            }
          if(fname == 'undefined'|| fname == '' || fname == null){
             component.set("v.FirstNameErrorMsg",'This is a required field');
             $A.util.removeClass(fname,"disp-none");
             $A.util.addClass(fname,"disp-block");
             isValid = false;
         }
        else if(!fname.match(genericvalidation)){
             component.set("v.FirstNameErrorMsg",'Please Enter a Valid FirstName');
             $A.util.removeClass(fname,"disp-none");
             $A.util.addClass(fname,"disp-block");
             isValid = false;
         }
          if(lName == 'undefined'|| lName == '' || lName == null){
            // component.set("v.LastNameErrorMsg",'This is a required field');
           //  $A.util.removeClass(lName,"disp-none");
           //  $A.util.addClass(lName,"disp-block");
           //  isValid = false;
         }                                                     
         else if(!lName.match(genericvalidation)){
             component.set("v.LastNameErrorMsg",'Please Enter a Valid LastName');
              $A.util.removeClass(lName,"disp-none");
             $A.util.addClass(lName,"disp-block");
             isValid = false;
         }
           /* if(!occupation.match(genericvalidation)){
             component.set("v.OccupationErrorMsg",'Please Enter a Valid Occupation');
              $A.util.removeClass(occupation,"disp-none");
             $A.util.addClass(occupation,"disp-block");
             isValid = false;
         }
            if(!institution.match(genericvalidation)){
             component.set("v.InstitutionErrorMsg",'Please Enter a valid Institution name');
               $A.util.removeClass(institution,"disp-none");
             $A.util.addClass(institution,"disp-block");
             isValid = false;
         }
            if(!organisation.match(genericvalidation)){
             component.set("v.OrganizationErrorMsg",'Please Enter a valid Organization name');
               $A.util.removeClass(organisation,"disp-none");
             $A.util.addClass(organisation,"disp-block");
             isValid = false;
         }   */
           
         if(pan == 'undefined'|| pan == '' || pan == null){
             component.set("v.PANErrorMsg",'This is a required field');
             $A.util.removeClass(pan,"disp-none");
             $A.util.addClass(pan,"disp-block");
             isValid = false;
         }
         else if(!pan.match(panformat)){
             component.set("v.PANErrorMsg",'Please Enter a Valid PAN Number');
              $A.util.removeClass(pan,"disp-none");
             $A.util.addClass(pan,"disp-block");
             isValid = false;
         }
         if(gst == 'undefined'|| gst == '' || gst == null){
             if(custSeg == 'Mechanic' ||custSeg == 'Retailer'){
             component.set("v.GSTINErrorMsg",'This is a required field');
             $A.util.removeClass(gst,"disp-none");
             $A.util.addClass(gst,"disp-block");
             isValid = false;
         }
         }
        else if(!gst.match(gstformat)){
             component.set("v.GSTINErrorMsg",'Please Enter a Valid GST Number');
              $A.util.removeClass(gst,"disp-none");
             $A.util.addClass(gst,"disp-block");
             isValid = false;
         }
           if(uin == 'undefined'|| uin == '' || uin == null){
            // component.set("v.UINErrorMsg",'This is a required field');
            // $A.util.removeClass(uin,"disp-none");
           //  $A.util.addClass(uin,"disp-block");
           //  isValid = false;
         }                                                     
         else if(!uin.match(uinformat)){
             component.set("v.UINErrorMsg",'Please Enter a Valid GST Number');
              $A.util.removeClass(uin,"disp-none");
             $A.util.addClass(uin,"disp-block");
             isValid = false;
         } 
           if(email == 'undefined'|| email == '' || email == null){
             
         }                                                  
         else if(!email.match(regExpEmailformat)){
             component.set("v.EmailErrorMsg",'Please Enter a Valid Email Address');
               $A.util.removeClass(email,"disp-none");
             $A.util.addClass(email,"disp-block");
             isValid = false;
         }  
         if(district == ''|| district == '' || district == null){
             component.set("v.districErrorMsg",'This is a required field');
             $A.util.removeClass(pan,"disp-none");
             $A.util.addClass(pan,"disp-block");
             isValid = false;
         }
         return isValid;
     },
 
    
})
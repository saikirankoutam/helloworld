({
    doInit: function(component, event, helper) {
        debugger;
       // alert(component.get('v.invoicenumber'));
         var ord=component.get('v.bookingId');
      
        if(ord=='' || ord==null|| ord=='undefined'){
       component.set("v.register", null);
       component.set("v.regBy", null);
       component.set("v.regTypeone", null);
       component.set("v.regTypeTwo", null);
       component.set("v.regStatus", null);
       component.set("v.regDeloc", null);
       component.set('v.ssmbYes',false);
       component.set('v.ssmbNo',true);
       component.set("v.custName",null);      
       component.set("v.disablePicFields",true); 
       component.set("v.disableSave",true);
       component.set("v.disableEdit",true);
       
        }else{
          helper.checkBookingStatus(component, event, helper);
          helper.checkVDNstatus(component, event, helper);
          helper.fetchPickLists(component, event);
          helper.fetchReasonChangePicklist(component, event);
          helper.fetchRegstatusPicklist(component, event);
          helper.fetchRegbyPicklist(component, event);
          helper.fetchtypePicklist(component, event);
          helper.fetchtypeUsePicklist(component, event);
          helper.fetchRegistrationdetails(component, event, helper);
          
             
        
        }
 	
    },
    invoiceChanges : function(component, event, helper) {
        var selectedrec=component.get("v.selectedLookUpRecord1");
       var invoidid=selectedrec.Id;
        component.set('v.invoidid',invoidid);
     },
    Onyes : function(component, event, helper) {
        var aurayes = component.get('v.ssmbYes');
      
        if(aurayes){
        
         component.set('v.checkname',true); 
         component.set("v.discustomer",true);
         component.set('v.ssmbNo',false);
         component.set('v.ssmbYes',true);
            
            //alert(component.get('v.checkname'));
        }else{
            
            component.set('v.checkname',false);
            component.set("v.discustomer",false);
            component.set('v.ssmbYes',false);
            component.set('v.ssmbNo',true); 
}
      
  },
     OnNo : function(component, event, helper) {
         
          var aurano = component.get('v.ssmbNo');
        if(aurano){
          component.set('v.checkname',false);
          component.set('v.ssmbYes',false);
         component.set('v.ssmbNo',true);   
        }
         else{
             component.set('v.discustomer',true);
             component.set('v.ssmbNo',false);
             component.set('v.ssmbYes',true);
             component.set('v.checkname',true);
             }

     },
 submit: function(component, event,helper){
     debugger;
     if(helper.validatePartForm(component,event, helper))     {
     var action = component.get("c.SaveRegistration");
           debugger;
             var insuId=component.get("v.InsuranceID");
             var insud=component.get("v.register");
             var bookingid    =component.get('v.bookingId');
          
             var invNum    =  component.get('v.invoicenumber');
             var resisterby      = component.find('resisterby').get('v.value');
         if(resisterby==null){
           resisterby =insud.PSA_Registration_By__c;              
          }
             var type1           = component.find('type1').get('v.value');
          if(type1==null){
           type1 =insud.PSA_Registration_Type1__c;              
          }
             var type2           = component.find('type2').get('v.value');
          if(type2==null){
           type2 =insud.PSA_Registration_Type2__c;              
          }
             var resplace        = component.find('resplace').get('v.value');
             var resstatus       = component.find('resstatus').get('v.value');
          if(resstatus==null){
           resstatus =insud.PSA_Registration_Status__c;      
              
          }var regname ;
       var custName = component.get('v.checkname');//checkname
         if(custName){
         regname = component.get('v.custName');
          }else
          {
              regname  =insud.PSA_Registration_Name__c; 
                
          } 
        
             var regdat          = component.find('regdat').get('v.value');
         if(regdat == null || regdat == 'undefined' || regdat == "")
         {
             regdat = null;
         }
             var num             = component.find('num').get('v.value'); 
             var address         = component.find('address').get('v.value');
             var remark          = component.find('remark').get('v.value');
             var location        = component.find('location').get('v.value');
         if(location==null){
           location =insud.PSA_Delivery_Location__c;           
          }
             var custCheck       = component.get('v.ssmbYes');
            
             var plan            = component.find('plan').get('v.value');
             var revise          = component.find('revise').get('v.value');
         if(revise == null || revise == 'undefined' || revise == "")
         {
             revise = null;
         }
             var change          = component.find('change').get('v.value');
            var check           = insud.PSA_Communicate_Revise_date__c;
         // var checkcom             = component.find('checkcom').get('v.value');
         
             var delivery        = component.find('delivery').get('v.value');
             var insight         = component.find('insight').get('v.value');
            
            action.setParams({
                "regid":insuId,
                "bookingid" : bookingid,
                'invoice'    :  invNum,
                'registby'   :  resisterby,
                'regname'    : regname,
                'type1'      :  type1,
                'type2'		 :  type2,
                'place'	     :  resplace,
                'status'	 :  resstatus,
                'regdat'     :  regdat,
                'num'	     :  num,
                'addres'	 :  address,
                'remark'	 :  remark,
                'location'   :  location,
                'plan'	     :  plan,
                'revised'	 :  revise,
                'change'	 :  change,
                'checkcom'   : check,
                'addlocation': delivery,
                'insight'	 : insight,
                'custCheck'  : custCheck
    
        });
          action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
              if (state === "SUCCESS") {
                    var message='Registration Details submited successfully';
                    helper.showSuccessToast(component,event,message);
                   component.set('v.disallfields',true);
                  component.set("v.disType",true);
                   component.set("v.disName",true); 
                   component.set("v.disableSave",true);
                   component.set("v.disableEdit",false); 
                 // component.set("v.disablePicFields",true);    
                   component.set("v.InsuranceID",storeResponse.Id);
                }
            });
            $A.enqueueAction(action);	
        }
    }, 
    
     foraddress : function(component, event, helper){
       var deladd= component.get("v.regDel");
       var selectadd = deladd;
       
         if(selectadd =="Customer’s Home"){
             var forcusthome= component.get("v.forcusthome");
             component.set("v.register.PSA_DeliveryAddress__c",forcusthome);
         }
         if(selectadd =="Customer’s Office"){
               var forcustoff= component.get("v.forcustoff");
              component.set("v.register.PSA_DeliveryAddress__c",forcustoff);
         }
         if(selectadd =="Dealership"){
              var fordealadd= component.get("v.fordealadd");
              component.set("v.register.PSA_DeliveryAddress__c",fordealadd);
         }
         if(selectadd =="Others"){
        component.set("v.register.PSA_DeliveryAddress__c",'');
         }
     },
    
    Edit: function(component, event, helper) {
        component.set('v.disallfields',false);
        var insud=component.get("v.register");
         var insuId=component.get("v.disName1");
         var type1 = component.find('type1').get('v.value');
         if(type1==null||type1=='undefined'||type1==''){
           type1 =insud.PSA_Registration_Type1__c;              
          } if(type1=='Permanent'){
                     component.set("v.disType",true);
                     component.set("v.disName",true); 
                                        }else
                    {
                     component.set("v.disType",false);
                     component.set("v.disName",false); 
                    }
        component.set("v.disableSave",false);
        component.set("v.disableEdit",true);
        // component.set("v.disyes",false); 
        // component.set("v.disno",false); 
        
     },
    preventalphabets : function(component, event, helper){
        var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
    }
    
       
})
({
    fetchPickLists: function(component, event) {
        
        var action = component.get("c.fetchdeliverylocationPicklist");
        action.setCallback(this, function(response) {
        component.set("v.locdel", response.getReturnValue());
    		});
        $A.enqueueAction(action);
       
     },  
    
    validatePartForm : function(component, event, helper){
        var insud=component.get("v.register");
        var isValid = true;
        var bookingdate = component.get("v.bookdate");
       var  type1  = component.find("type1").get("v.value");
          if(type1==''|| type1=='undefined'|| type1==null){
           type1 =insud.PSA_Registration_Type1__c;              
          }
       // var  registby = component.find("resisterby").get("v.value");
       /* if(registby==''|| registby=='undefined'|| registby==null)
        {
            registby =insud.PSA_Registration_By__c;              
        }*/
       // var  type1  = component.find("type1").get("v.value");
       /* if(type1==''|| type1=='undefined'|| type1==null)
        {
            type1 =insud.PSA_Registration_Type1__c;              
        }*/
       // var  type2  = component.find("type2").get("v.value");
       /* if(type2==''|| type2=='undefined'|| type2==null)
        {
            type2 =insud.PSA_Registration_Type2__c;              
        }*/
        // var  resstatus  = component.find("resstatus").get("v.value");
       // var  location  = component.find("location").get("v.value"); 
       /* if(location==''|| location=='undefined'|| location==null){
            location =insud.PSA_Delivery_Location__c;              
        }*/
        // var  place  = component.find("resplace").get("v.value");
       // var regdat = component.find("regdat").get("v.value");
        var  num = component.find("num").get("v.value");
        //var  address = component.find("address").get("v.value");
        var  plan = component.find("plan").get("v.value");
       // var   revised = component.find("revise").get("v.value");
       // var now = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD"); 
        
        
       /* component.set("v.rgstbyErrMsg",'');
        $A.util.removeClass(registby,"disp-block");
        $A.util.addClass(registby,"disp-none");
        component.set("v.type1ErrMsg",'');
        $A.util.removeClass(type1,"disp-block");
        $A.util.addClass(type1,"disp-none");
        component.set("v.type2ErrMsg",'');
        $A.util.removeClass(type2,"disp-block");
        $A.util.addClass(type2,"disp-none");*/
        /* component.set("v.statusErrMsg",'');
        $A.util.removeClass(resstatus,"disp-block");
        $A.util.addClass(resstatus,"disp-none");*/
         /*component.set("v.delocErrMsg",'');
         $A.util.removeClass(location,"disp-block");
         $A.util.addClass(location,"disp-none");*/
         /*  component.set("v.placeErrMsg",'');
        $A.util.removeClass(place,"disp-block");
        $A.util.addClass(place,"disp-none");*/
        /* component.set("v.rdErrMsg",'');
         $A.util.removeClass(regdat,"disp-block");
         $A.util.addClass(regdat,"disp-none");*/
         
         component.set("v.numErrMsg",'');
         $A.util.removeClass(num,"disp-block");
         $A.util.addClass(num,"disp-none");
         
         /* component.set("v.addErrMsg",'');
        $A.util.removeClass(address,"disp-block");
        $A.util.addClass(address,"disp-none");*/
         component.set("v.planErrMsg",'');
         $A.util.removeClass(plan,"disp-block");
         $A.util.addClass(plan,"disp-none");
       /*  component.set("v.revisedErrMsg",'');
         $A.util.removeClass(revised,"disp-block");
         $A.util.addClass(revised,"disp-none");*/
         
        /* if( registby== '--None--' || registby==''|| registby=='undefined'|| registby==null){
             isValid = false;
             component.set("v.rgstbyErrMsg",'This is a required field');
             $A.util.removeClass(registby,"disp-none");
             $A.util.addClass(registby,"disp-block");
         }
         if( type1== '--None--' || type1==''|| type1=='undefined'|| type1==null){
             isValid = false;
             component.set("v.type1ErrMsg",'This is a required field');
             $A.util.removeClass(type1,"disp-none");
             $A.util.addClass(type1,"disp-block");
         }
         if( type2== '--None--' || type2==''|| type2=='undefined'|| type2==null){
             isValid = false;
             component.set("v.type2ErrMsg",'This is a required field');
             $A.util.removeClass(type2,"disp-none");
             $A.util.addClass(type2,"disp-block");
         }*/
         /*  if( resstatus== '--None--'){
            isValid = false;
            component.set("v.statusErrMsg",'This is a required field');
            $A.util.removeClass(resstatus,"disp-none");
            $A.util.addClass(resstatus,"disp-block");
        }*/
       /*  if( location== '--None--' || location==''|| location=='undefined'|| location==null){
             isValid = false;
             component.set("v.delocErrMsg",'This is a required field');
             $A.util.removeClass(location,"disp-none");
             $A.util.addClass(location,"disp-block");
         }*/
         
         /*if(registby == 'undefined'|| registby == '' || registby == null){
            component.set("v.rgstbyErrMsg",'This is a required field');
            $A.util.removeClass(registby,"disp-none");
            $A.util.addClass(registby,"disp-block");
            isValid = false;
        }
        if(type1 == 'undefined'|| type1 == '' || type1 == null){
            component.set("v.type1ErrMsg",'This is a required field');
            $A.util.removeClass(type1,"disp-none");
            $A.util.addClass(type1,"disp-block");
            isValid = false;
        }
         
          if(type2 == 'undefined'|| type2 == '' || type2 == null){
            component.set("v.type2ErrMsg",'This is a required field');
            $A.util.removeClass(type2,"disp-none");
            $A.util.addClass(type2,"disp-block");
            isValid = false;
        }
          if(place == 'undefined'|| place == '' || place == null){
            component.set("v.placeErrMsg",'This is a required field');
            $A.util.removeClass(place,"disp-none");
            $A.util.addClass(place,"disp-block");
            isValid = false;
        }*/
        /* if( regdat =='undefined'|| regdat == '' || regdat == null){
             component.set("v.rdErrMsg",'This is a required field');
             $A.util.removeClass(regdat,"disp-none");
             $A.util.addClass(regdat,"disp-block");
             isValid = false;
         } else{*/
            /* if(regdat < bookingdate){
             component.set("v.rdErrMsg",'Registration Date should not be less than booking Date ');
             $A.util.removeClass(regdat,"disp-none");
             $A.util.addClass(regdat,"disp-block");
             isValid = false;
         }*/
        /* else{
            if(regdat<now)
             {
                 component.set("v.rdErrMsg",'Registration Date should not be less than Current Date');
                 $A.util.removeClass(regdat,"disp-none");
                 $A.util.addClass(regdat,"disp-block");
                 isValid = false;
             }
             
         }*/
         if(type1=='Permanent'){
        if(num == 'undefined'|| num == '' || num == null){
             component.set("v.numErrMsg",'This is a required field when type is permanent');
             $A.util.removeClass(num,"disp-none");
             $A.util.addClass(num,"disp-block");
             isValid = false;
         }
    }
         /*if(address == 'undefined'|| address == '' || address == null){
            component.set("v.addErrMsg",'This is a required field');
            $A.util.removeClass(address,"disp-none");
            $A.util.addClass(address,"disp-block");
            isValid = false;
        }*/
         /* if(plan == 'undefined'|| plan == '' || plan == null){
            component.set("v.planErrMsg",'This is a required field');
            $A.util.removeClass(plan,"disp-none");
            $A.util.addClass(plan,"disp-block");
            isValid = false;
        }
       
         if(revised == 'undefined'|| revised == '' || revised == null){
            component.set("v.revisedErrMsg",'This is a required field');
            $A.util.removeClass(revised,"disp-none");
            $A.util.addClass(revised,"disp-block");
            isValid = false;
        }*/
         if( plan =='undefined'|| plan == '' || plan == null){
             component.set("v.planErrMsg",'This is a required field');
             $A.util.removeClass(plan,"disp-none");
             $A.util.addClass(plan,"disp-block");
             isValid = false;
         }
        else{ if(plan < bookingdate){
             component.set("v.planErrMsg",'Planned Date  should not be less than booking Date ');
             $A.util.removeClass(plan,"disp-none");
             $A.util.addClass(plan,"disp-block");
             isValid = false;
        }}
         /*else{
             if(plan<now)
             {
                 component.set("v.planErrMsg",'Planned Date  should not be less than Current Date ');
                 $A.util.removeClass(plan,"disp-none");
                 $A.util.addClass(plan,"disp-block");
                 isValid = false;
             }}*/
        /* if( revised=='undefined'|| revised == '' || revised == null){
             component.set("v.revisedErrMsg",'This is a required field');
             $A.util.removeClass(revised,"disp-none");
             $A.util.addClass(revised,"disp-block");
             isValid = false;
         }
        else{
         if(revised < bookingdate){
             component.set("v.revisedErrMsg",'Revise Date  should not be less than booking Date ');
             $A.util.removeClass(revised,"disp-none");
             $A.util.addClass(revised,"disp-block");
             isValid = false;
         }}*/
        /* else{
             if(revised<now)
             {
                 component.set("v.revisedErrMsg",'Revised Date  should not be less than Current Date');
                 $A.util.removeClass(revised,"disp-none");
                 $A.util.addClass(revised,"disp-block");
                 
                 isValid = false;
             }
         }*/
         
         return isValid;
     },
    
    fetchRegistrationdetails : function(component, event, helper){
        debugger;
        //var recordid=component.get('v.recordId');
        var book=component.get("v.bookingId");
      
        var action = component.get("c.getRegistrationDetails");
        
        action.setParams({ 
            "recordid" : book
            
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var  values= response.getReturnValue();
            this.fetchcustomer(component, event, helper,values);
            component.set('v.register',values[0]);
            
            if(values.Id==null||values.Id==''||values.Id=='undefined'){
                //alert('hi');
                 component.set('v.ssmbNo',true);
                 component.set('v.ssmbYes',false);
                values.PSA_Communicate_Revise_date__c=false;
                //component.set("v.disableFields",false);
                component.set("v.register", values);    
                component.set("v.disablePicFields",false); 
                component.set('v.disallfields',false);
                component.set("v.disType",false);
                component.set("v.disName",false); 
            }
            else{
                component.set("v.InsuranceID",values.Id);
                
                component.set("v.register", response.getReturnValue());
                component.set("v.disablePicFields",true); 
                component.set("v.regBy", values.PSA_Registration_By__c);
                component.set("v.regTypeone", values.PSA_Registration_Type1__c);
                component.set("v.regTypeTwo", values.PSA_Registration_Type2__c);
                component.set("v.regStatus", values.PSA_Registration_Status__c);
                
                component.set("v.changeReason", values.PSA_Change_Delivery__c);
                component.set("v.regDel", values.PSA_Delivery_Location__c);
                component.set('v.checkname',true);
                component.set('v.disno',true);
                component.set('v.disyes',true);
                var chechkcust=values.PSA_customer_yes__c;
                if(chechkcust){
                    component.set('v.ssmbYes',true);
                    component.set('v.ssmbNo',false);
                    
                }
                else
                {
                    component.set('v.checkname',false);
                    component.set('v.ssmbNo',true);
                    component.set('v.ssmbYes',false);
                    
                }
                
                component.set("v.disableSave",true);
                component.set("v.disType",true);
                component.set("v.disName",true); 
            }
                  var checkUser=component.get('v.checkUser');
                  if(checkUser)
                  {
                    component.set("v.disableSave",true);   
                    component.set("v.disableEdit",true);
                  }
        });
        $A.enqueueAction(action);	
    },
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    fetchcustomer : function(component, event, helper,values){
        var action1 = component.get("c.gettinGCustomeriD");
        var book=component.get("v.bookingId");
        action1.setParams({ 
            "recordid" : book
        });
        action1.setCallback(this, function (response) {
            var state = response.getState();
            var  valuesd= response.getReturnValue();
            component.set("v.custName",valuesd.PSA_Customer_Account__r.Name);
            component.set("v.forcusthome",valuesd.PSA_Customer_Account__r.PersonMailingStreet);
            component.set("v.forcustoff",valuesd.PSA_Customer_Account__r.BillingStreet);
            var addressWrap='';
            if(valuesd.Account.BillingStreet !='undefined' && valuesd.Account.BillingStreet  !='' && valuesd.Account.BillingStreet  !=null)
                {
                    addressWrap= valuesd.Account.BillingStreet +',' ; 
                }
            if(valuesd.Account.BillingCity !='undefined' && valuesd.Account.BillingCity  !='' && valuesd.Account.BillingCity  !=null)
                {
                    addressWrap=addressWrap+valuesd.Account.BillingCity +',' ;  
                }
             if(valuesd.Account.BillingState !='undefined' && valuesd.Account.BillingState  !='' && valuesd.Account.BillingState  !=null)
                {
                    addressWrap= addressWrap+valuesd.Account.BillingState +',' ;  
                }
             
            if(valuesd.Account.BillingPostalCode !='undefined' && valuesd.Account.BillingPostalCode  !='' && valuesd.Account.BillingPostalCode  !=null)
                {
                    addressWrap=addressWrap+valuesd.Account.BillingPostalCode +','  ; 
                }
            component.set("v.fordealadd",addressWrap);
           
            
             
        });
        $A.enqueueAction(action1);
        
    },
    checkBookingStatus : function(component, event){
    debugger;
         var bookingid=component.get('v.bookingId');
         var action = component.get("c.checkBookingStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.disableEdit",true);
                component.set("v.disableSave",true);
                }
            }
        });
        $A.enqueueAction(action);	    
	 
},
    checkVDNstatus : function(component, event){
    debugger;
         var bookingid=component.get('v.bookingId');
         var action = component.get("c.checkVDNStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                 var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.disableEdit",true);
                component.set("v.disableSave",true);
                }                
            }
        });
        $A.enqueueAction(action);	    
	 
},
    fetchReasonChangePicklist: function(component, event) {
        
        var action = component.get("c.fetchReasonChangePicklist");
        action.setCallback(this, function(response) {
           
        component.set("v.reasonChangePickList", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     },  
    
    fetchRegstatusPicklist: function(component, event) {
        var action = component.get("c.fetchRegstatusPicklist");
        action.setCallback(this, function(response) {
        component.set("v.statusreg", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
     fetchRegbyPicklist: function(component, event) {
        var action = component.get("c.fetchRegbyPicklist");
        action.setCallback(this, function(response) {
        component.set("v.byreg", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
     fetchtypePicklist: function(component, event) {
        var action = component.get("c.fetchtypePicklist");
        action.setCallback(this, function(response) {
        component.set("v.typone", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
     fetchtypeUsePicklist: function(component, event) {
        var action = component.get("c.fetchtypeUsePicklist");
        action.setCallback(this, function(response) {
        component.set("v.typuse", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
    
})
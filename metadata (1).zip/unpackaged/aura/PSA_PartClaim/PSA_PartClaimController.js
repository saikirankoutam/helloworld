({
    Vehiclechanges : function(component, event, helper) {
        component.set('v.submitdiasable',true); 
        var selectedrec=component.get("v.vehiclRecord");
        var invoidid=selectedrec.Invoice__c;
        if(invoidid==null || invoidid== '' || invoidid== 'undefined'){
            component.set('v.submitdiasable',false); 
            component.find('grnnumber').set('v.value','');
            component.find('Branchcode').set('v.value','');
            component.set('v.claimtypeerrmsg','');
            component.find('dealercode').set('v.value','');
            component.find('dealerremarks').set('v.value','');
            component.find('invoicedate').set('v.value','');
            component.find('invvlaue').set('v.value','');
            component.find('grndate').set('v.value','');
            component.find('tptname').set('v.value','');
            component.find('podnumber').set('v.value','');
            component.find('dealerremarks').set('v.value','');
            component.set('v.claimrecord',null);
            component.set('v.clamdiasable',false);
            component.set('v.submitdiasable',true);
            component.set('v.enablepdf',true);
            component.set('v.invoicelist',null);
            component.set('v.fileName','');
            component.set('v.remarserrormsg','');
            component.set('v.invoicedetails',false);
            component.set('v.idforclaim','');
        }else{
            component.find('grnnumber').set('v.value',selectedrec.PSA_GRN_number__c);
            component.find('Branchcode').set('v.value',selectedrec.Invoice__r.PSA_Account__r.PSA_Branch_Code__c);
            component.find('dealercode').set('v.value',selectedrec.Invoice__r.PSA_Account__r.Dealer_Code__c);
            component.find('invoicedate').set('v.value',selectedrec.Invoice__r.PSA_Invoice_Date__c);
            component.find('grndate').set('v.value',selectedrec.CreatedDate);
            component.find('invvlaue').set('v.value',selectedrec.Invoice__r.Invoice_Amount__c);
            component.find('tptname').set('v.value',selectedrec.Invoice__r.PSA_Transporter_Name__c);
            component.find('podnumber').set('v.value',selectedrec.PSA_PODNumber__c);
            component.set('v.claimtypeerrmsg','');
            component.set('v.fileName','');
            var claimtype=component.find('claimtype').get('v.value');
            if(claimtype=='Short'){
                helper.shortclaimHelper(component, event,selectedrec);
            }
            if(claimtype=='Excess'){
                helper.excessclaimHelper(component, event,selectedrec);
            }
            if(claimtype=='Damage'){
                helper.damagetclaimHelper(component, event,selectedrec);
            }
            if(claimtype=='Wrong Supply'){
                helper.WrongclaimHelper(component, event,selectedrec);
            }
            if(claimtype=='Catalog Error'){
                helper.catalogclaimHelper(component, event,selectedrec);
            }
            
        } 
    },
    partclaim : function(component, event, helper) {
        debugger;
        var isvalid=true;
        var claimqty=false;
        var finallist=[];  
        var invlist=  component.get('v.invoicelist');
        for(var i=0;i<invlist.length;i++){
            //   if(invlist[i].Claim_quantity1__c> invlist[i].PSA_Remaing_Claim_Avilable__c ||  invlist[i].Claim_quantity1__c < 0)
            //isvalid=false;
            if(invlist[i].Claim_quantity1__c){
                claimqty=true;
                finallist.push(invlist[i]);
            } 
            
        }
        
        
        if(isvalid && claimqty)
            helper.claimrecordsave(component, event,finallist);
        else
            helper.validation(component, event); 
        
    },
    handleFilesChange: function(component, event, helper) {
        
        var fileName = 'No File Selected..'; 
        fileName = event.getSource().get("v.files")[0]['name'];   
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
        //helper.checkfilesize(component, event);
        if(ext == "png" || ext == "PNG" || ext == "JPEG" || ext == "jpeg" || ext == "jpg" || ext == "JPG"){
            helper.checkfilesize(component, event);
        } else{ 
            component.set('v.fileName','');
            var message='Upload only png or jpg files';
            helper.errorToast(component, event, message);
        } 
    },
    refreshscreen: function(component, event, helper) {
        component.set('v.invoicedetails',false);
        var childCmp = component.find("pillclear");
        childCmp.clearpill();
        component.set('v.submitdiasable',true);
        component.find('fileId').get('v.files',null);
        component.set('v.fileName','');
        component.set('v.claimtypeerrmsg','');
        component.set('v.reqTypeEpressMsg','');
        component.set('v.remarserrormsg','');
        component.set('v.clamdiasable',false);
        component.find('dealerremarks').set('v.value','');
        component.set('v.claimrecord',null);
        component.set('v.invvisible',false);
        component.find('claimtype').set('v.value','');
        
    },
    claimchange: function(component, event, helper) {
        var claimtype=component.find('claimtype').get('v.value');
        component.set('v.claimtype',claimtype);
        if(claimtype==''){
            //claimtype=='Catalog Error' || claimtype=='Damage' || claimtype=='Wrong Supply' ||
            component.set('v.invvisible',false);
        }else{
            component.set('v.invvisible',true);
            
        }
        component.set('v.invoicedetails',false);
        var childCmp = component.find("pillclear");
        childCmp.clearpill();
        component.set('v.submitdiasable',true);
        component.find('fileId').get('v.files',null);
        component.set('v.fileName','');
        component.set('v.claimtypeerrmsg','');
        component.set('v.reqTypeEpressMsg','');
        component.set('v.remarserrormsg','');
        component.set('v.clamdiasable',false);
        component.find('dealerremarks').set('v.value','');
        component.set('v.claimrecord',null);
        
        
        
    },
    generateCreditnote :function(component, event, helper) {
        var action = component.get("c.creditdat");
        var recordId = component.get("v.idforclaim");
        var pdfurl ='../PSA_CreditnotePDF?id='+recordId;
        window.open(pdfurl,"_blank", "width=600, height=550");
        action.setParams({ 
            "partclaimid" : recordId
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            //    var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
            }
        });
        $A.enqueueAction(action);
    },
    /*generateCreditnote :function(component, event, helper) {
        // var action = component.get("c.creditdat");
       var recordId = component.get("v.idforclaim");alert(recordId);
        var pdfurl ='../PSA_CreditnotePDF?id='+recordId;
        window.open(pdfurl,"_blank", "width=600, height=550");
    },*/
    /* generateDebitnote :function(component, event, helper) {
      //  var action = component.get("c.debitdat");
        var recordId = component.get("v.idforclaim");
        var pdfurl ='../PSA_DebitnotePDF?id='+recordId;
        window.open(pdfurl,"_blank", "width=600, height=550");
     }*/
    generateDebitnote :function(component, event, helper) {
        var action = component.get("c.debitdat");
        var recordId = component.get("v.idforclaim");
        var pdfurl ='../PSA_DebitnotePDF?id='+recordId;
        window.open(pdfurl,"_blank", "width=600, height=550");
        action.setParams({ 
            "partclaimid" : recordId
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            //    var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
            }
        });
        $A.enqueueAction(action);
    },
     doInit : function(component, event, helper) { 
       var query='select Id,Invoice__c,Invoice__r.Excess_claim_status__c,Invoice__r.Claim_Status__c,Invoice__r.Name,Invoice__r.PSA_Invoice_Date__c,PSA_GRN_number__c,CreatedDate,Invoice__r.PSA_Account__r.Dealer_Code__c,(select Id,Total_Claim_Amount__c,Approval_Status__c,PSA_Approval_Comments__c,PSA_Dealer_Remarks__c,PSA_Claim_type__c,Approved_By__c,Name,CreatedDate from Part_Claims__r),Invoice__r.PSA_Account__r.PSA_Branch_Code__c,Invoice__r.Invoice_Amount__c,Invoice__r.PSA_Transporter_Name__c,PSA_PODNumber__c FROM PSA_PartsReceipt__c where  Invoice__c !=null AND Claim_Available_Date__c>today AND (Invoice__r.Claim_Status__c!=';
        var status='Pending';//
       var segmentstring='\''+ status + '\'';
        query+=segmentstring+' OR  Invoice__r.Excess_claim_status__c!=';
        query+=segmentstring+' OR  Invoice__r.catalog_Error_Claim_status__c!=';
          query+=segmentstring+' OR  Invoice__r.Damage_claim_Status__c!=';
          query+=segmentstring+' OR  Invoice__r.wrong_supply_claim_status__c!=';
        query+= segmentstring+' ) AND  Invoice__r.Name LIKE: searchKey AND Invoice__r.PSA_Account__c=';
           
        var action = component.get("c.loginuserId");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var acccid=response.getReturnValue();
                 var account='\''+ acccid + '\'';
                query+=account+' order by createdDate DESC limit 5';
                component.set('v.customquery',query);
            }
            
        });
        $A.enqueueAction(action);
        
    },           
    
})
({
    MAX_FILE_SIZE: 4500000,
    CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
    uploadHelper: function(component, event,parentid) {
        debugger;
        var fileInput = component.find("fileId").get("v.files");
        var file = fileInput[0];
        var self = this;
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }
        var objFileReader = new FileReader();
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
            self.uploadProcess(component, file, fileContents,parentid);
        });
        objFileReader.readAsDataURL(file);
    },
    checkfilesize: function(component, event) {
        var fileInput = component.find("fileId").get("v.files");
        var file = fileInput[0];
        var self = this;
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }else{
            component.set('v.fileName',file.name);
        }
        var objFileReader = new FileReader();
        
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
        });
        
        objFileReader.readAsDataURL(file);
    },
    errorToast : function(component, event, Message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": Message
        });
        toastEvent.fire();
    },
    uploadProcess: function(component, file, fileContents,parentid) {
        var startPosition = 0;
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '',parentid);
    },
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId,parentid) {
        var getchunk = fileContents.substring(startPosition, endPosition);
        var action = component.get("c.saveChunk");
        action.setParams({
            parentId: parentid,
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
        action.setCallback(this, function(response) {
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.submitdiasable',true);
                this.Successmessage(component, event);
            }
            
        });
        $A.enqueueAction(action);
    },
    claimrecordsave : function(component, event, invlist) {
        var isvalid=true;
        component.set("v.claimtypeerrmsg",'');
        component.set("v.remarserrormsg",'');
        var claimtype=component.find('claimtype').get('v.value');
        var remarks= component.find('dealerremarks').get('v.value');
        var fileinput=component.find("fileId").get("v.files") ;
        $A.util.removeClass(claimtype,"disp-block");
        $A.util.addClass(claimtype,"disp-none");
        $A.util.removeClass(remarks,"disp-block");
        $A.util.addClass(remarks,"disp-none");
        if(claimtype =='' || claimtype==null || claimtype=='undefined'){
            isvalid=false;
            component.set("v.claimtypeerrmsg",'this is required field');
            $A.util.removeClass(claimtype,"disp-none");
            $A.util.addClass(claimtype,"disp-block");   
        } 
        if(remarks =='' || remarks==null || remarks=='undefined'){
            isvalid=false;
            component.set("v.remarserrormsg",'this is required field');
            $A.util.removeClass(remarks,"disp-none");
            $A.util.addClass(remarks,"disp-block"); 
        } 
        
        if(fileinput =='' || fileinput==null || fileinput=='undefined'){
            var message='Attachment Is mandatory';
            isvalid=false;
            component.set('v.fileName','No file Selected');
            this.errorToast(component, event, message);
        }
        if (isvalid) {
            var partrecord=component.get('v.vehiclRecord');
            var partid=partrecord.Id;
            var action = component.get("c.createpartclaimrecords");
            action.setParams({ 
                "invlist" : invlist,
                "partreceiptid" :partid,
                "clmtype" :claimtype,
                "delearremarks":remarks
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
                if (state === "SUCCESS") {
                    component.set('v.claimrecord',storeResponse);
                    this.uploadHelper(component, event,storeResponse.Id);
                    component.set('v.claimrecord',storeResponse); 
                    component.set('v.clamdiasable',true);
                      this.claimlistfetch(component, event,storeResponse.Id);
                 /*   var approvestatus=storeResponse.Approval_Status__c;alert(approvestatus);
          if(approvestatus=='Approved'){ 
           component.set('v.enablepdf',false);
          }else{
              component.set('v.enablepdf',true);
          } */
                    
                }
            });
            $A.enqueueAction(action);
        }   
    },
    Successmessage : function(component, event) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "Success",
            "message": "Part claim request  successfully submitted"
        });
        toastEvent.fire();
    },
    validation: function(component, event) {
        var message='Please input claim quantity at least for one part';
        this.errorToast(component, event, message);
        
    },
    Invoicedetailrecords: function(component, event,invoidid) {
        var action = component.get("c.fetchinvoicedetails");
        action.setParams({ 
            "invoiceid" : invoidid
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                component.set('v.invoicelist',storeResponse);
                /*   for(var i=0;i<storeResponse.length;i++){
                        if(storeResponse[i].PSA_Remaing_Claim_Avilable__c > 0){
                            isvalid=false;
                        }    
                    }
                    if(isvalid){
                        component.set('v.submitdiasable',true);
                        var message='No Line Items are available for Claiming';
                        helper.errorToast(component, event, message); 
                    } */
                }
            });
         $A.enqueueAction(action);
     },
    claimlistfetch : function(component, event,claimid) {
        var action = component.get("c.fetchclaimrecord");
        action.setParams({ 
            "partclaimid" : claimid
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                component.set('v.claimlist',storeResponse);  
                 var approvestatus=component.get("v.claimrecord.Approval_Status__c");
          if(approvestatus=='Approved'){ 
           component.set('v.enablepdf',false);
          }else{
              component.set('v.enablepdf',true);
          }
            }
        });
        $A.enqueueAction(action);
    },
     shortclaimHelper: function(component, event,selectedrec) {
            var claimstatus=selectedrec.Invoice__r.Claim_Status__c;
             var invoidid=selectedrec.Invoice__c;
            if(claimstatus=='Approved' || claimstatus=='Rejected'){ 
                  component.set('v.clamdiasable',true);
                var claim=selectedrec.Part_Claims__r;
                var claimrecords;
                var x;
                for(x in claim){
                    if(claim[x].PSA_Claim_type__c=='Short'){
                        claimrecords=claim[x];
                    }
                }
                component.set('v.claimrecord',claimrecords);
                var claimid=claimrecords.Id;
                component.set('v.idforclaim',claimid);
                component.set('v.submitdiasable',true); 
                component.find('dealerremarks').set('v.value',claimrecords.PSA_Dealer_Remarks__c);
                this.claimlistfetch(component, event,claimid);
                //value="{!v.claimrecord.PSA_Dealer_Remarks__c}"
                
            }else{
                  component.set('v.submitdiasable',false);  
                component.set('v.invoicedetails',true);
                this.Invoicedetailrecords(component, event,invoidid);
                
            }  
     },
     excessclaimHelper: function(component, event,selectedrec) {
         
         var claimstatus=selectedrec.Invoice__r.Excess_claim_status__c;
         var invoidid=selectedrec.Invoice__c;
            if(claimstatus=='Approved' || claimstatus=='Rejected'){ 
                  component.set('v.clamdiasable',true);
                var claim=selectedrec.Part_Claims__r;
                var claimrecords;
                var x;
                for(x in claim){
                    if(claim[x].PSA_Claim_type__c=='Excess'){
                        claimrecords=claim[x];
                    }
                }
                component.set('v.claimrecord',claimrecords);
                var claimid=claimrecords.Id;
                component.set('v.idforclaim',claimid);
                component.set('v.submitdiasable',true); 
                component.find('dealerremarks').set('v.value',claimrecords.PSA_Dealer_Remarks__c);
                this.claimlistfetch(component, event,claimid);
                //value="{!v.claimrecord.PSA_Dealer_Remarks__c}"
                
            }else{
                  component.set('v.submitdiasable',false);  
                component.set('v.invoicedetails',true);
                this.Invoicedetailrecords(component, event,invoidid);
                
            }  
     },
     damagetclaimHelper: function(component, event,selectedrec) {
         
         var claimstatus=selectedrec.Invoice__r.Damage_claim_Status__c;
         var invoidid=selectedrec.Invoice__c;
            if(claimstatus=='Approved' || claimstatus=='Rejected'){ 
                  component.set('v.clamdiasable',true);
                var claim=selectedrec.Part_Claims__r;
                var claimrecords;
                var x;
                for(x in claim){
                    if(claim[x].PSA_Claim_type__c=='Damage'){
                        claimrecords=claim[x];
                    }
                }
                component.set('v.claimrecord',claimrecords);
                var claimid=claimrecords.Id;
                component.set('v.idforclaim',claimid);
                component.set('v.submitdiasable',true); 
                component.find('dealerremarks').set('v.value',claimrecords.PSA_Dealer_Remarks__c);
                this.claimlistfetch(component, event,claimid);
                //value="{!v.claimrecord.PSA_Dealer_Remarks__c}"
                
            }else{
                  component.set('v.submitdiasable',false);  
                component.set('v.invoicedetails',true);
                this.Invoicedetailrecords(component, event,invoidid);
                
            }  
     },
     WrongclaimHelper: function(component, event,selectedrec) {
         
         var claimstatus=selectedrec.Invoice__r.wrong_supply_claim_status__c;
         var invoidid=selectedrec.Invoice__c;
            if(claimstatus=='Approved' || claimstatus=='Rejected'){ 
                  component.set('v.clamdiasable',true);
                var claim=selectedrec.Part_Claims__r;
                var claimrecords;
                var x;
                for(x in claim){
                    if(claim[x].PSA_Claim_type__c=='Wrong Supply'){
                        claimrecords=claim[x];
                    }
                }
                component.set('v.claimrecord',claimrecords);
                var claimid=claimrecords.Id;
                component.set('v.idforclaim',claimid);
                component.set('v.submitdiasable',true); 
                component.find('dealerremarks').set('v.value',claimrecords.PSA_Dealer_Remarks__c);
                this.claimlistfetch(component, event,claimid);
                //value="{!v.claimrecord.PSA_Dealer_Remarks__c}"
                
            }else{
                  component.set('v.submitdiasable',false);  
                component.set('v.invoicedetails',true);
                this.Invoicedetailrecords(component, event,invoidid);
                
            }  
     },
     catalogclaimHelper: function(component, event,selectedrec) {
         
         var claimstatus=selectedrec.Invoice__r.catalog_Error_Claim_status__c;
         var invoidid=selectedrec.Invoice__c;
            if(claimstatus=='Approved' || claimstatus=='Rejected'){ 
                  component.set('v.clamdiasable',true);
                var claim=selectedrec.Part_Claims__r;
                var claimrecords;
                var x;
                for(x in claim){
                    if(claim[x].PSA_Claim_type__c=='Catalog Error'){
                        claimrecords=claim[x];
                    }
                }
                component.set('v.claimrecord',claimrecords);
                var claimid=claimrecords.Id;
                component.set('v.idforclaim',claimid);
                component.set('v.submitdiasable',true); 
                component.find('dealerremarks').set('v.value',claimrecords.PSA_Dealer_Remarks__c);
                this.claimlistfetch(component, event,claimid);
                //value="{!v.claimrecord.PSA_Dealer_Remarks__c}"
                
            }else{
                  component.set('v.submitdiasable',false);  
                component.set('v.invoicedetails',true);
                this.Invoicedetailrecords(component, event,invoidid);
                
            }  
     }
    
})
({
	doInit : function(component, event, helper) {
		var action = component.get("c.fetchLoginUserDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var userResponse = response.getReturnValue();
                component.set("v.userInfo", userResponse);
 }
        });
        $A.enqueueAction(action);
	},	    
    onVehicleOption : function(component, event, helper) {
		component.set("v.dealerHome", false);	
        component.set("v.vehicleProcurement", true);
        component.set("v.partsProcurement", false);
        component.set("v.Aftersales", false);         
        component.set("v.Sales", false);         
	},
	onPartsOption : function(component, event, helper) {
        component.set("v.dealerHome", false);
        component.set("v.vehicleProcurement", false);
        component.set("v.partsProcurement", true);
         component.set("v.Aftersales", false); 
        component.set("v.Sales", false);         
	},
    onAftersalesOption : function(component, event, helper) {
        component.set("v.dealerHome", false);
        component.set("v.vehicleProcurement", false);
        component.set("v.partsProcurement", false); 
         component.set("v.Aftersales", true); 
        component.set("v.Sales", false);         
	},
      onSalesOption : function(component, event, helper) {
        component.set("v.dealerHome", false);
        component.set("v.vehicleProcurement", false);
        component.set("v.partsProcurement", false); 
        component.set("v.Aftersales", false); 
        component.set("v.Sales", true); 
    },
	showMyAccount : function(component, event, helper) {
        component.set("v.showMyAccount", true); 
	},
    openUserDetails : function(component, event, helper) {
        var userId = component.get("v.userInfoId"); 
        window.open('/dmsindia/s/profile/'+userId,'_top');
	},
	onTabSelect : function(component, event, helper) {
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
    },    
    handlevalidateMenu : function(component, event, helper) {
       var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
          var defaultItem = event.getParam("defaultItem");
        var Vpvalue = component.get("v.vehicleProcurement"); 
        if(validationItem == "Sales" && defaultItem == true){
            component.set("v.vehicleProcurement", false);
            component.set("v.partsProcurement",false );
            component.set("v.AfterSales", false);
            component.set("v.Sales", true);
        }
        if(validationItem == "AfterSales"  && defaultItem == true){
            component.set("v.vehicleProcurement", false);
            component.set("v.partsProcurement", false);
            component.set("v.AfterSales", true);
            component.set("v.Sales", false);
        }
        
        if(validationItem == "partsProcurement"  && defaultItem == true){
            component.set("v.vehicleProcurement", false);
            component.set("v.partsProcurement", true);
            component.set("v.AfterSales", false);
            component.set("v.Sales", false);
        }
        if(validationItem == "vehicleProcurement"  && defaultItem == true){
            component.set("v.vehicleProcurement", true);
            component.set("v.partsProcurement", false);
            component.set("v.AfterSales", false);
            component.set("v.Sales", false);
        }
 
    },
    openNav : function(component, event, helper) {
        document.getElementById("sideNavigation").style.width = "260px";
	document.getElementById("sideNavigation").style.opacity = "1";
	document.getElementById("sideNavigation").style.visibility = "visible";
	document.getElementById("content-wrapper").style.marginLeft = "260px";
	$("#sideNavigationIcons").css("display","none");
	$("#hamburger-menu").css("display","none");
    },
    closeNav : function(component, event, helper) {
        document.getElementById("sideNavigation").style.width = "0";
	document.getElementById("sideNavigation").style.opacity = "0";
	document.getElementById("sideNavigation").style.visibility = "hidden";
	document.getElementById("content-wrapper").style.marginLeft = "60px";
	$("#sideNavigationIcons").css("display","block");
	$("#hamburger-menu").css("display","block");
    },
})
({
    doInit : function(component, event, helper) {
        debugger;
		var action = component.get("c.fetchMetadataRole");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var userResponse = response.getReturnValue();
                component.set("v.currTab", userResponse);
           }
        });
        $A.enqueueAction(action);
	},
    onTabSelect : function(component, event, helper) {
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
    },
    handleCaseDetails : function(component, event, helper) {
        var currentselectedCaseId = event.getParam("currentMonthlyOrderId");
        component.set("v.currentCaseId", currentselectedCaseId);
    	component.set("v.showCaseDetails", true);
    	component.set("v.showCaseDataTable", false);        
        
    },
        showdisplayListPage :function(component,event,helper){
        var listPage = event.getParam("listPage");
          component.set("v.showCaseDataTable", true);
         component.set("v.showCaseDetails", false);
        //if(listPage){
           // component.set("v.listpartrequest", true);
            //component.set("v.newpartrequest", false);
      //  }
    },
     showCaseDetail : function(component, event, helper) {
       var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.showCaseDetails", false);
             component.set("v.showCaseDataTable", true);
            
        } 

        
    },

    
})
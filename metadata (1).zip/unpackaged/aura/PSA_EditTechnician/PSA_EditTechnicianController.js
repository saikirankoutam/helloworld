({ 
    
    doInit : function(component, event, helper) {
        
        
        helper.fetchskillvaluePicklist(component, event);
        helper.fetchteamPicklist(component, event);
        helper.fetchjobtitlePicklist(component, event);
    },   
    closeBayForm : function(component, event, helper) {
       // component.set("v.LevelErrmsg",'');
        component.set("v.TitleErrmsg",'');
        component.set("v.FirstnameErrmsg",'');
        component.set("v.LastnameErrmsg",'');
        component.set("v.mobilenoErrorMsg",'');
        component.set("v.emailErrorMsg",'');
        component.set("v.add1ErrorMsg",' ');
        component.set("v.TeamErrorMsg",'');
        component.set("v.PositionErrmsg",'');
        component.set("v.EmpIDErrorMsg",'');
        component.set("v.JobtitleErrorMsg",'');
        
       var eventListPage = component.getEvent("displayListtechnician");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();


        document.getElementById("myform").style.display = "none";
    },
    
    
    onRecordUpdated : function(component) {
    setTimeout($A.getCallback(function () { 
        console.log('reloaded');
        component.find("recordLoader").reloadRecord(true);
                                       
    })); 
}, 
    
    EditTechnician : function(component, event, helper) {debugger;
        
        
        if(helper.validateTachForm(component)) {
              
          component.find("recordHandler").saveRecord($A.getCallback(function(saveResult) {
            if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") { 
                console.log('Result Saved');
    
              var Message= $A.get("$Label.c.Technician_Updated_Successfully");
                helper.showSuccessToast(component,event,Message);
                 var eventListPage = component.getEvent("displayListtechnician");
                  eventListPage.setParams({"listPage" : true });
                  eventListPage.fire();
            } else if (saveResult.state === "INCOMPLETE") {
                console.log("User is offline, device doesn't support drafts.");
            } else if (saveResult.state === "ERROR") {
                console.log('Problem saving record, error: ' + JSON.stringify(saveResult.error));
            } else {
                console.log('Unknown problem, state: ' + saveResult.state + ', error: ' + JSON.stringify(saveResult.error));
            }
        }));
         }
    },
     onactive:function(component, event, helper){
        var active=component.find("checkbox").get("v.value");
        if(active){
            component.set("v.inactivecheckbox",true);
            component.find("inactivecheckbox").set("v.value",false);
        }
        else{
             component.set("v.inactivecheckbox",false);
        }
    },
      oninactive:function(component, event, helper){
        var active=component.find("inactivecheckbox").get("v.value");
        if(active){
            component.set("v.activecheckbox",true);
            component.find("checkbox").set("v.value",false);
        }
        else{
             component.set("v.activecheckbox",false);
        }
    }
    
})
({
    
     getloginuserInfo : function(component, event){
        var action = component.get("c.fetchLoginUserDetails");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log('user Info >>>>'+JSON.stringify(storeResponse));
                if(storeResponse.PSA_Community_Role__c =='Head Aftersales'){
                    component.set("v.RSMprofile", true);
                }
               
            }
        });
        $A.enqueueAction(action);
    },
    fetchorderitem : function(component, event) {
        var action = component.get("c.getPOtitems");
        var OrderId = component.get("v.OrderId");
        
        action.setParams({
            "orderid" : component.get("v.OrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {               
                debugger;
                var rows = response.getReturnValue();
                component.set("v.partsList", rows);
              
            }
        });
        $A.enqueueAction(action);
    },
    
    gettermsandconditions : function(component, event){
        debugger;
        var recid = component.get("v.OrderId");
        if(recid != undefined){
            var action = component.get("c.getOrderAmount");
            action.setParams({
                "recordId" : recid
            });       
            action.setCallback(this, function(response){
                var state = response.getState();              
                var storeResponse = response.getReturnValue();               
                component.set("v.termscond",storeResponse);    
              
                
            });
            $A.enqueueAction(action);
        }
    },
    
    listPageHelper : function(component, event){
        
        var eventListPage = component.getEvent("displayListPageOEM");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },    
       showErrorToast : function(component,event,Message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": Message,
            "type": "error"
        });
        toastEvent.fire(); 
    },
    
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },  
    
     resubmitrelease:function(component, event, helper){
        debugger;
         var OrderId = component.get("v.OrderId");
        
         var action = component.get("c.submitapproval");    
        action.setParams({
            "orderid" : component.get("v.OrderId")            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {   
                var Message= $A.get("$Label.c.Local_PO_Resubmit");
                helper.showSuccessToast(component,event,Message);                 
                var rows = response.getReturnValue(); 
          	    /*var eventListPage = component.getEvent("displayListPageLocal");
                eventListPage.setParams({"listPage" : true });
                eventListPage.fire();*/
             
            }
        });
        $A.enqueueAction(action);

    },
    
    
        
})
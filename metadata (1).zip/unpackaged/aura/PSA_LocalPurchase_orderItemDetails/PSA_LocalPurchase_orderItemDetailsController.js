({
    Doinit : function(component, event, helper) {
        debugger;
        var OrderRecordId = component.get("v.OrderId");        
        helper.fetchorderitem(component, event);
        helper.gettermsandconditions(component, event);
        helper.getloginuserInfo(component,event);
        
    },
    Cancel: function(component, event, helper) {
        helper.listPageHelper(component, event);
    },
    ONLOcalCancel: function(component, event, helper) {
        
        var eventListPage = component.getEvent("displayListPageLocal");
        eventListPage.setParams({"listPage" : true,"CNFStatus":'Draft' });
        eventListPage.fire();
    },
    onlocalApprove:function(component, event, helper){
        debugger;
        var OrderId = component.get("v.OrderId");
        var action = component.get("c.localpoapprove");    
        action.setParams({
            "orderid" : component.get("v.OrderId"),
            "reviewType" : "Approve"
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {       
                var Message= $A.get("$Label.c.Local_PO_Approved");
                helper.showSuccessToast(component,event,Message);               
                var rows = response.getReturnValue();
                var eventListPage = component.getEvent("displayRSMListPageLocal");
                eventListPage.setParams({"listPage" : true});
                eventListPage.fire();
                
            }
            
        });
        $A.enqueueAction(action);
    },
    OnclickBack:function(component, event, helper){
       var eventListPage = component.getEvent("displayRSMListPageLocal");
                eventListPage.setParams({"listPage" : true});
                eventListPage.fire();  
    },
    
    onlocalreject:function(component, event, helper){
        var OrderId = component.get("v.OrderId");
        var action = component.get("c.localpoapprove");    
        action.setParams({
            "orderid" : component.get("v.OrderId"),
            "reviewType" : "Reject"
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {   
                var Message= $A.get("$Label.c.Local_PO_Rejected");
                helper.showErrorToast(component,event,Message);                 
                var rows = response.getReturnValue(); 
                var eventListPage = component.getEvent("displayRSMListPageLocal");
                eventListPage.setParams({"listPage" : true});
                eventListPage.fire();
            }
        });
        $A.enqueueAction(action);
    },
    resubmit:function(component, event, helper){
        debugger;
         var OrderId = component.get("v.OrderId");
        
         var action = component.get("c.submitapproval");    
        action.setParams({
            "orderid" : component.get("v.OrderId")            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {   
                var Message= $A.get("$Label.c.Local_PO_Resubmit");
                helper.showSuccessToast(component,event,Message);                 
                var rows = response.getReturnValue(); 
          	    var eventListPage = component.getEvent("displayListPageLocal");
                eventListPage.setParams({"listPage" : true });
                eventListPage.fire();
             
            }
        });
        $A.enqueueAction(action);

    },
    editPo:function(component, event, helper){
       debugger;
      var OrderId = component.get("v.OrderId");
      var  partslist=component.get("v.partsList");
        var eventListPage = component.getEvent("EditLocalPO");
        eventListPage.setParams({"listPage" : true,"CNFStatus":'Draft',"Id" :OrderId,ordlist:partslist});
        eventListPage.fire();
    },
    localpopdf :  function(component, event, helper) {
        debugger;
        
        var recordId = component.get("v.OrderId");
        var action = component.get('c.getPOtitems');
        
        action.setParams({ "orderid" : recordId });
        action.setCallback(this, function(response){
            var state = response.getState();            
            if(state == 'SUCCESS') {   
                var records =response.getReturnValue(); 
                
                var baseUrl= decodeURIComponent(window.location.hostname);
                var url = 'https://'+baseUrl+'/dmsindia/s/order/'+recordId;       
                window.open(url,"_blank", "width=600, height=550");                    
                
            }              
            
        });
        $A.enqueueAction(action);   
        
        
    }
    
})
({
	savepartreceiptshelper : function(component, event){        
        var lstofpartreceipts = component.get("v.FinalPartreceiptrecords");
        var splant = component.get("v.supplyplant");
        var rdate = component.get("v.receiptdate");
        var invno;
        if(component.get("v.potype") == "VOR" || component.get("v.potype") == "VCO" || component.get("v.potype") == "Stock"){
            invno = component.get("v.selectedLookUpRecordINV.Name");
        }
        else{
            invno = component.get("v.invnumber");
        }
        if(lstofpartreceipts.length != 0){
            component.set("v.spinner", true);
            var mapofpartreceiptdetails;
            mapofpartreceiptdetails = {
                "supplyplant" : splant,
                "receiptdate" : rdate,
                "invoiceno" : invno,
                "invdate" : component.get("v.invdate"),
                "podnumber" : component.get("v.podnumber"),
                "invvalueexclgst" : component.get("v.invvalueexclgst"),
                "taxvalue" : component.get("v.taxvalue"),
                "totalinvoicevalue" : component.get("v.totalinvoicevalue"),
                "suppliername" : component.get("v.suppliername"),
                "Eway" : component.get("v.ewaybill"),
                "docketno" : component.get("v.docketno"),
                "GRNtype" : component.get("v.potype")                
            };
            var action = component.get('c.Createpartreceipt');
            action.setParams({
                "dealerinventoryrecs": lstofpartreceipts,                
                "mapofreceipts" : mapofpartreceiptdetails,
                "ordernumber" : component.get("v.selectedLookUpRecord.OrderNumber")                
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                    var cmpTarget = component.find('submitbtn');
                    $A.util.addClass(cmpTarget, 'disablebtn');
                    component.set("v.spinner", false);                
                    var records =response.getReturnValue();    
                    component.set("v.grnnumber", records['GRNNumber']);
                    component.set("v.grndate", records['GRNDate']);
                    component.set("v.spinner", false);
                    var message = 'Parts Receipt created successfully!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "success",
                        "message": message
                    });
                    toastEvent.fire();
                }
                else
                {
                    component.set("v.spinner", false);
                    var message = 'Parts Receipt creation Failed!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "message": message
                    });
                    toastEvent.fire();
                }
            });
            $A.enqueueAction(action);
        }
        else{
            var message = 'Please select atleast one bin record to transfer!';
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": message
            });
            toastEvent.fire(); 
        }
    },
    
    validatePartreceiptForm : function(component, event, helper){
        
        var isValid = true;
        if(component.get("v.potype") != "VOR" && component.get("v.potype") != "VCO" && component.get("v.potype") != "Stock"){
            var ponumber = component.find("partPOno").get("v.value");
            var podnumber = component.find("podnumberPO").get("v.value");
        }
        var invoicedate = component.find("invoicedate").get("v.value");
        var invoicenumber = component.find("invoicenumber").get("v.value");        
        var receiptdate = component.find("receiptdate").get("v.value");        
        
        component.set("v.ponumberErrmsg",'');
        $A.util.removeClass(ponumber,"disp-block");
        $A.util.addClass(ponumber,"disp-none");
        component.set("v.invdateErrMsg",'');
        $A.util.removeClass(invoicedate,"disp-block");
        $A.util.addClass(invoicedate,"disp-none");
        component.set("v.invnoErrmsg",'');  
        $A.util.removeClass(invoicenumber,"disp-block");
        $A.util.addClass(invoicenumber,"disp-none");
        component.set("v.podnumberErrMsg",'');
        $A.util.removeClass(podnumber,"disp-block");
        $A.util.addClass(podnumber,"disp-none");
        component.set("v.receiptdateErrmsg",'');
        $A.util.removeClass(receiptdate,"disp-block");
        $A.util.addClass(receiptdate,"disp-none");        
        if(component.get("v.potype") != "VOR" && component.get("v.potype") != "VCO" && component.get("v.potype") != "Stock"){
            if((ponumber == 'undefined' || ponumber == '' || ponumber == null) && (component.get("v.selectedLookUpRecord.OrderNumber") == null || component.get("v.selectedLookUpRecord.OrderNumber") == undefined)){
                isValid = false;
                component.set("v.ponumberErrmsg",'Required field');
                $A.util.removeClass(ponumber,"disp-none");
                $A.util.addClass(ponumber,"disp-block");
            }
            else{
                component.set("v.ponumberErrmsg",'');
                $A.util.addClass(ponumber,"disp-none");
                $A.util.removeClass(ponumber,"disp-block");
            }
        }
        if(invoicedate =='undefined'|| invoicedate == '' || invoicedate == null){
            component.set("v.invdateErrMsg",'Required field');
            $A.util.removeClass(invoicedate,"disp-none");
            $A.util.addClass(invoicedate,"disp-block");
            isValid = false;
        }
        else{
            component.set("v.invdateErrMsg",'');
            $A.util.addClass(invoicedate,"disp-none");
            $A.util.removeClass(invoicedate,"disp-block");
        }
        if(invoicenumber =='undefined'|| invoicenumber == '' || invoicenumber == null){
            component.set("v.invnoErrmsg",'Required field');
            $A.util.removeClass(invoicenumber,"disp-none");
            $A.util.addClass(invoicenumber,"disp-block");
            isValid = false;
        }
        else{
            component.set("v.invnoErrmsg",'');
            $A.util.addClass(invoicenumber,"disp-none");
            $A.util.removeClass(invoicenumber,"disp-block");
        }
        if(component.get("v.potype") != "VOR" && component.get("v.potype") != "VCO" &
           component.get("v.potype") != "Stock"){
            if(podnumber == 'undefined'|| podnumber == '' || podnumber == null){
                component.set("v.podnumberErrMsg",'Required field');
                $A.util.removeClass(podnumber,"disp-none");
                $A.util.addClass(podnumber,"disp-block");
                isValid = false;
            }
            else{
                component.set("v.podnumberErrMsg",'');
                $A.util.addClass(podnumber,"disp-none");
                $A.util.removeClass(podnumber,"disp-block");
            }
        }
        if(receiptdate == 'undefined'|| receiptdate == '' || receiptdate == null){
            component.set("v.receiptdateErrmsg",'Required field');
            $A.util.removeClass(receiptdate,"disp-none");
            $A.util.addClass(receiptdate,"disp-block");
            isValid = false;
        }
        else{
            component.set("v.receiptdateErrmsg",'');
            $A.util.addClass(receiptdate,"disp-none");
            $A.util.removeClass(receiptdate,"disp-block");
        }
        
        return isValid;
         
     },
    
    validatestockPartreceiptForm : function(component, event, helper){
        
        var isValid = true;
        var ponumber ;
        var podnumber;
        var codealerinvdate;
        var invoicenumber;
        if(component.get("v.potype") != "VOR" || component.get("v.potype") != "VCO" || component.get("v.potype") != "Stock"){
            ponumber = component.get("v.selectedLookUpRecordStock.OrderNumber");
            podnumber = component.find("podnumberPO").get("v.value");
            if(component.get("v.potype") != "StockTransfer"){
            	codealerinvdate = component.find("invoicedate").get("v.value");
            	invoicenumber = component.find("invoicenumber").get("v.value");
            }
        }       
        var receiptdate = component.find("receiptdate").get("v.value");        
        
        component.set("v.ponumberErrmsg",'');
        $A.util.removeClass(ponumber,"disp-block");
        $A.util.addClass(ponumber,"disp-none");        
        component.set("v.podnumberErrMsg",'');
        $A.util.removeClass(podnumber,"disp-block");
        $A.util.addClass(podnumber,"disp-none");
        component.set("v.invnoErrmsg",'');  
        $A.util.removeClass(invoicenumber,"disp-block");
        $A.util.addClass(invoicenumber,"disp-none");
        component.set("v.invdateErrMsg",'');
        $A.util.removeClass(codealerinvdate,"disp-block");
        $A.util.addClass(codealerinvdate,"disp-none");  
        component.set("v.receiptdateErrmsg",'');
        $A.util.removeClass(receiptdate,"disp-block");
        $A.util.addClass(receiptdate,"disp-none");        
         
        if((ponumber == 'undefined' || ponumber == '' || ponumber == null) && (component.get("v.selectedLookUpRecordStock.OrderNumber") == null || component.get("v.selectedLookUpRecordStock.OrderNumber") == undefined)){
            isValid = false;
            component.set("v.ponumberErrmsg",'Required field');
            $A.util.removeClass(ponumber,"disp-none");
            $A.util.addClass(ponumber,"disp-block");
        }
        else{
            component.set("v.ponumberErrmsg",'');
            $A.util.addClass(ponumber,"disp-none");
            $A.util.removeClass(ponumber,"disp-block");
        }        
        if(podnumber == 'undefined'|| podnumber == '' || podnumber == null){
            component.set("v.podnumberErrMsg",'Required field');
            $A.util.removeClass(podnumber,"disp-none");
            $A.util.addClass(podnumber,"disp-block");
            isValid = false;
        }
        else{
            component.set("v.podnumberErrMsg",'');
            $A.util.addClass(podnumber,"disp-none");
            $A.util.removeClass(podnumber,"disp-block");
        }
        if(component.get("v.potype") != "StockTransfer"){
            if(codealerinvdate == 'undefined'|| codealerinvdate == '' || codealerinvdate == null){
                component.set("v.invdateErrMsg",'Required field');
                $A.util.removeClass(codealerinvdate,"disp-none");
                $A.util.addClass(codealerinvdate,"disp-block");
                isValid = false;
            }
            else{
                component.set("v.invdateErrMsg",'');
                $A.util.addClass(codealerinvdate,"disp-none");
                $A.util.removeClass(codealerinvdate,"disp-block");
            }
            if(invoicenumber =='undefined'|| invoicenumber == '' || invoicenumber == null){
                component.set("v.invnoErrmsg",'Required field');
                $A.util.removeClass(invoicenumber,"disp-none");
                $A.util.addClass(invoicenumber,"disp-block");
                isValid = false;
            }
            else{
                component.set("v.invnoErrmsg",'');
                $A.util.addClass(invoicenumber,"disp-none");
                $A.util.removeClass(invoicenumber,"disp-block");
            }
        }
        if(receiptdate == 'undefined'|| receiptdate == '' || receiptdate == null){
            component.set("v.receiptdateErrmsg",'Required field');
            $A.util.removeClass(receiptdate,"disp-none");
            $A.util.addClass(receiptdate,"disp-block");
            isValid = false;
        }
        else{
            component.set("v.receiptdateErrmsg",'');
            $A.util.addClass(receiptdate,"disp-none");
            $A.util.removeClass(receiptdate,"disp-block");
        }
        
        return isValid;
         
     },
    
    savestockpartreceiptshelper : function(component, event){        
        var lstofpartreceipts = component.get("v.FinalPartreceiptrecords");
        var splant = component.get("v.supplyplant");
        var rdate = component.get("v.receiptdate");
        var invno = component.get("v.invnumber");
        if(lstofpartreceipts.length != 0){
            component.set("v.spinner", true);
            var mapofpartreceiptdetails;
            mapofpartreceiptdetails = {
                "supplyplant" : splant,
                "invoiceno" : invno,
                "invdate" : component.get("v.invdate"),
                "podnumber" : component.get("v.podnumber"),
                "invvalueexclgst" : component.get("v.invvalueexclgst"),
                "taxvalue" : component.get("v.taxvalue"),
                "totalinvoicevalue" : component.get("v.totalinvoicevalue"),
                "receiptdate" : rdate,               
                "podnumber" : component.get("v.podnumber"),                
                "suppliername" : component.get("v.suppliername"),
                "Eway" : component.get("v.ewaybill"),
                "docketno" : component.get("v.docketno"),
                "GRNtype" : component.get("v.potype")                
            };
            var action = component.get('c.Createpartreceipt');
            action.setParams({
                "dealerinventoryrecs": lstofpartreceipts,                
                "mapofreceipts" : mapofpartreceiptdetails,
                "ordernumber" : component.get("v.selectedLookUpRecordStock.OrderNumber")                
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                    var cmpTarget = component.find('submitbtnstock');
                    $A.util.addClass(cmpTarget, 'disablebtn');
                    component.set("v.spinner", false);                
                    var records =response.getReturnValue();    
                    component.set("v.grnnumber", records['GRNNumber']);
                    component.set("v.grndate", records['GRNDate']);
                    component.set("v.spinner", false);
                    var message = 'Parts Receipt created successfully!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "success",
                        "message": message
                    });
                    toastEvent.fire();
                }
                else
                {
                    component.set("v.spinner", false);
                    var message = 'Parts Receipt creation Failed!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "message": message
                    });
                    toastEvent.fire();
                }
            });
            $A.enqueueAction(action);
        }
        else{
            var message = 'Please select atleast one bin record to transfer!';
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": message
            });
            toastEvent.fire(); 
        }
    },
    
    futuredaterestriction : function(component,event,helper,dateval,msg){
        	var recptdate = dateval;
            var today = new Date();
            var dd = today.getDate();            
            var mm = today.getMonth()+1; 
            var yyyy = today.getFullYear();
            if(dd<10){dd='0'+dd;}             
            if(mm<10){mm='0'+mm;}
            today = yyyy+'-'+mm+'-'+dd;            
            if(recptdate>today){
                var message = msg;
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type": "error",
                    "message": message
                });
                toastEvent.fire();                
            }
        
    }
        
})
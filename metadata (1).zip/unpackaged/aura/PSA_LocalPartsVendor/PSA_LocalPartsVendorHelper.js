({
    getVendorName: function(component,event,helper){
          var action = component.get("c.fetchDealerInfo");
       
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                 var storeResponse = response.getReturnValue();
                component.set("v.DealerId", storeResponse[i].Id);
             }
        });
        $A.enqueueAction(action);
    },

})
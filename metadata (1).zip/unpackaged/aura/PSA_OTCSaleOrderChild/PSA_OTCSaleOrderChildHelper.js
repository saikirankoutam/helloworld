({
     showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
     showErrorToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "error"
        });
        toastEvent.fire();  
    },
     handleValidation:function(component, event, helper){
        var isvalid=true;
        var partnumber = component.find("PartNumber");
        var partnumberValue = partnumber.get("v.value");
        var invoiceqty = component.find("invqty");
        var Quantityvalue = invoiceqty.get("v.value");   
        var physicalqty = component.find("phystock").get("v.value"); 
        partnumber.set("v.errors", null);
        invoiceqty.set("v.errors", null);
        if(partnumberValue == "undefined" || partnumberValue == '' || partnumberValue == null ||partnumberValue == '--None--' ){
            partnumber.set("v.errors", [{message:"Please select the Part Number"}]);
            isvalid=false;
        }     
        
        if(Quantityvalue == 0 || Quantityvalue == "undefined" || Quantityvalue == '' || Quantityvalue == null){
            Quantityvalue.set("v.errors", [{message:"Please select the Quantity"}]);
            //component.set("v.invqtyerror",'Please enter quantity');
            isvalid=false;
        }
         if(physicalqty == 0){                   
             
             component.set("v.availablestockerror",'Stock is not available');
        }
          if(physicalqty >0){                   
             
             component.set("v.availablestockerror",'');
        }
        
        return isvalid;
    }
   
})
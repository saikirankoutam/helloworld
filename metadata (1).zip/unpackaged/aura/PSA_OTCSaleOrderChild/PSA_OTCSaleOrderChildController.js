({
    doInit : function(component, event, helper) {    
        component.set("v.ProductInstance.totalBasicValue", 0);
        component.set("v.ProductInstance.totalTax",0);
        component.set("v.ProductInstance.totalDiscountValue", 0);
        component.set("v.ProductInstance.totalInvoiceValue",0);
        component.set("v.ProductInstance.Quantity",'');
       
        
    },
    AddNewBlankRow : function(component, event, helper){
        var compEvent = component.getEvent('AddPartRowEvt');
        compEvent.fire();
    },
    removeRow: function(component, event, helper){
        var partnumber = component.find("PartNumber").get("v.value");
        if( partnumber== '--None--'){
            component.getEvent("DeletePartRowEvt").setParams({
                "indexVar" : component.get("v.rowIndex")}).fire();
            
        }else{
            
            component.getEvent("DeletePartRowEvt").setParams({
                "indexVar" : component.get("v.rowIndex")}).fire();
        }
        var compEvent = component.getEvent("calcOTC");
        compEvent.fire();
    },
    recordChanges:function(component, event, helper){    
        debugger;
        var partrecord = component.get("v.selectedLookUpRecord");   
        var partid = partrecord.prodname;
        //alert(partid);
       // component.set('v.invqtyerror','');
        if(partid == "undefined" || partid == '' || partid == null ){                   
            component.set("v.partDescription","");
            component.set("v.HSNCode", "");
            component.set("v.UOM", "");
             component.set("v.igst",'');
            component.set('v.reqTypeEpressMsg','');
            component.set("v.Binlocation", "");
            component.set("v.currentStock", "");
            component.set("v.AvailableStock", "");
            component.set("v.physicalStock", "");
            component.set("v.NetDealerPrice","");
            component.set("v.listprice", '');
            component.set("v.reqQty", "");   
            component.set("v.invqtyerror",'');
            component.find("invqty").set("v.value",'');  
            component.find("reqqty").set("v.value",'');  
            component.set("v.Basicvalue",'');            
            component.set("v.discount", '');
            component.set("v.discountvalue", '');
            component.set("v.GST", '');
            component.set("v.Totalinvoice", '');
            component.set("v.qtydisable", true);
            component.set("v.cgst",'');
            component.set("v.sgst",'');
            component.set("v.cess",'');
            component.set("v.ndp",'');
            component.set("v.ProductInstance.totalBasicValue", 0);
            component.set("v.ProductInstance.totalTax", 0);
            component.set("v.ProductInstance.totalDiscountValue", 0);
            component.set("v.ProductInstance.totalInvoiceValue", 0);
           var compEvent = component.getEvent("calcOTC");
             compEvent.fire();
            component.find('totaltax').set('v.value','');
            component.find('Totalinvoice').set('v.value','');
             
            
        }else{ 
            component.set("v.ProductInstance.PSA_Part_Number__c", partrecord.prodname);
            component.set("v.ProductInstance.Description", partrecord.ptype);
            component.set("v.ProductInstance.PSA_OEMCGST__c", partrecord.cgst);
            component.set("v.ProductInstance.PSA_OEMSGST__c", partrecord.sgst);
            component.set("v.ProductInstance.PSA_OEMIGST__c", partrecord.igst);
            component.set("v.ProductInstance.UnitPrice", partrecord.unitprice);
            component.set("v.ProductInstance.Net_Dealer_Price__c", partrecord.ndp);
            component.set("v.ProductInstance.Id", partrecord.pricebookid);
            component.set("v.ProductInstance.Product2Id", partrecord.partid);
            component.find("invqty").set("v.value",0);
            component.find("reqqty").set("v.value",0);
            component.set("v.NetDealerPrice",0);      
            component.set("v.discount",0) ; 
             component.set('v.reqTypeEpressMsg','');
            component.set("v.discountvalue",0);
            //component.find("discountper").set("v.value","0");   
            
            var partDesc = partrecord.proddesc;
            var hsnCode = partrecord.prodhsn;
            var uom = partrecord.produom;
            var unitprice = partrecord.unitprice;
            var ndp = partrecord.ndp;
            var physicalStock=partrecord.currstock; 
            var AvailableStock=partrecord.Avlstock; 
            var binlocation = partrecord.binLocation;
            var cgst = partrecord.cgst;
            var sgst = partrecord.sgst;
            var cess = partrecord.cess;
            var igst = partrecord.igst;
            component.set("v.partDescription", partDesc);        
            component.set("v.HSNCode", hsnCode);
            component.set("v.UOM", uom);
            component.set("v.listprice",unitprice);
            component.set("v.ndp",ndp);
            component.set("v.cgst",cgst);
            component.set("v.sgst",sgst);
            component.set("v.cess",cess);
            component.set("v.igst",parseInt(sgst)+parseInt(cgst));
            component.find("binloc").set("v.value",binlocation);
            component.set("v.physicalStock", physicalStock); 
            component.set("v.AvailableStock", AvailableStock); 
            component.set("v.qtydisable", false);
           
          //  helper.handleValidation(component,event,helper); 
            
        }
       
    },
    checkValidation:function(component, event, helper){
        debugger;
        var isvalid=true;
        var partnumber = component.find("PartNumber");
        var partnumberValue = component.get("v.ProductInstance.PSA_Part_Number__c");
        var invoiceqty = component.find("invqty");
        var Quantityvalue = invoiceqty.get("v.value");   
        var physicalqty = component.find("availQtyd").get("v.value"); 
        var discountpercentage = component.find("discountper").get("v.value");
        component.set("v.reqTypeEpressMsg", null);
        invoiceqty.set("v.errors", null);
        if(partnumberValue == "undefined" || partnumberValue == '' || partnumberValue == null ||partnumberValue == '--None--' ){
            component.set("v.reqTypeEpressMsg", "Please select the Part Number");
            isvalid=false;
        }     
        
        if(Quantityvalue == 0 || Quantityvalue == "undefined" || Quantityvalue == '' || Quantityvalue == null){
            //Quantityvalue.set("v.errors", [{message:"Please select the Quantity"}]);
            component.set("v.invqtyerror",'Please enter quantity');
            isvalid=false;
        }
        if(physicalqty == 0 ||physicalqty==''|| physicalqty==null || physicalqty=='undefined'){                 
           // component.set("v.availablestockerror",'Stock is not available');
        }
        if(physicalqty >0){                   
            component.set("v.availablestockerror",'');
        }
      /*  if(discountpercentage >100){                 
            component.set("v.diserror",'Discount should not be Greater than 100');
            isvalid=false;
        }
        if( discountpercentage<0){                   
            component.set("v.diserror",'Discount should not be Less than 0');
            isvalid=false;
        }*/
        if( discountpercentage>0 && discountpercentage <100){                   
            component.set("v.diserror",'');
           
        }
       
        return isvalid;
    },
    recordchange:function(component, event, helper){
        debugger;
        var invqty = component.find("invqty").get("v.value");
        var listprice = component.find("NDP").get("v.value"); 
        var physicalqty = component.find("availQtyd").get("v.value");
        var discountpercentage = component.find("discountper").get("v.value"); 
         component.set("v.invqtyerror",'');
        
        if(physicalqty=='undefined' || physicalqty=='' ||parseInt(invqty) >parseInt(physicalqty) ||physicalqty==null )
        {                   
            var Message= "Invoice Qty is Exceeded";
            helper.showErrorToast(component,event,Message);
            component.find("invqty").set("v.value",0);
        }else if(invqty >0)
        {        
            var discountval = 0;
            var netdealerprice = invqty*listprice;  
            if(discountpercentage > 0 && discountpercentage <100){
                component.set("v.ProductInstance.PSA_Discount__c",discountpercentage);
                discountval = (netdealerprice*discountpercentage)/100;
                discountval=discountval.toFixed(2);
            }
            var taxableValue = (netdealerprice - discountval);
            component.set("v.NetDealerPrice",taxableValue); 
            component.set("v.invqtyerror",'');
            
            var cgst = component.get("v.cgst");
            var sgst = component.get("v.sgst");
            var cess = 0;
            var totaltax = (taxableValue*cgst/100 + taxableValue*sgst/100 + taxableValue*cess/100);
            totaltax=totaltax.toFixed(2);
            component.set("v.totaltax", totaltax);
            component.set("v.totalinvoice", parseFloat(taxableValue)+parseFloat(totaltax));
            component.set("v.discountvalue", discountval);
            component.set("v.ProductInstance.totalBasicValue", netdealerprice);
            component.set("v.ProductInstance.totalTax", parseFloat(totaltax));
            component.set("v.ProductInstance.totalDiscountValue", discountval);
            
            component.set("v.ProductInstance.totalInvoiceValue", parseFloat(taxableValue)+parseFloat(totaltax));
        }
        if(invqty ='' ||invqty == 0 || invqty<0){  
           //  component.set("v.invqtyerror",'Please Enter Quantity Greater than Zero');
             helper.showErrorToast(component,event,'Please Enter Quantity Greater than Zero');
            component.set("v.NetDealerPrice",0) ;
            component.set("v.discount",0) ; 
            component.set("v.ProductInstance.totalBasicValue", 0);
            component.set("v.ProductInstance.totalTax", 0);
            component.set("v.ProductInstance.totalDiscountValue", 0);
            component.set("v.ProductInstance.totalInvoiceValue", 0);
            component.set("v.totaltax", 0);
            component.set("v.totalinvoice", 0);
            component.set("v.discountvalue", 0);
            component.find("invqty").set("v.value",'0');
        }
         if(discountpercentage >100){                 
           
            var Message= "Discount should not be Greater than 100 ";
            helper.showErrorToast(component,event,Message);
              component.find("discountper").set("v.value",'0');
        }
        if( discountpercentage<0){                   
        
            var Message= "Discount should not be Less than 0 ";
            helper.showErrorToast(component,event,Message);
            component.find("discountper").set("v.value",'0');
          
        }
        var compEvent = component.getEvent("calcOTC");
        compEvent.fire();
     
    },
    allocatechange:function(component, event, helper){
        var allocate= component.find("reqqty").get("v.value");
        if(allocate<0){
        var Message= "Required should not be Less than 0 ";
            helper.showErrorToast(component,event,Message);
            component.find("reqqty").set("v.value",'0');
        }
    }
    
    
})
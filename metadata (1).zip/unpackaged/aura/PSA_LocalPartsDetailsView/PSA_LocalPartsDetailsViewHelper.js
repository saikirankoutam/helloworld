({
    validatePartForm : function(component, event, helper){
        debugger;
        var isValid = true;
       // var bran = component.find("brand").get("v.value");
      //  var partDesc = component.find("partdescription").get("v.value");
       // var hsnCde = component.find("HSNcode").get("v.value");
        
        var cgst = component.find("CGST").get("v.value");
        var sgst  = component.find("SGST").get("v.value");
        var igst  = component.find("IGST").get("v.value");
        var list  = component.find("ListPrice").get("v.value");
        var mrp  = component.find("MRP").get("v.value");
      
        var ndp = component.find("NDP").get("v.value");
        component.set("v.cgstErrMsg",'');
        $A.util.removeClass(cgst,"disp-block");
        $A.util.addClass(cgst,"disp-none");
        component.set("v.sgstErrMsg",'');
        $A.util.removeClass(sgst,"disp-block");
        $A.util.addClass(sgst,"disp-none");
        component.set("v.igstErrMsg",'');
        $A.util.removeClass(igst,"disp-block");
        $A.util.addClass(igst,"disp-none");
        component.set("v.listErrMsg",'');
        $A.util.removeClass(list,"disp-block");
        $A.util.addClass(list,"disp-none");
        component.set("v.mrpErrMsg",'');
        $A.util.removeClass(mrp,"disp-block");
        $A.util.addClass(mrp,"disp-none");
        component.set("v.ndpcodeErrMsg",'');
        $A.util.removeClass(ndp,"disp-block");
        $A.util.addClass(ndp,"disp-none");
        
        if(cgst == 'undefined'|| cgst == '' || cgst == null){
            component.set("v.cgstErrMsg",'This is a required field');
            $A.util.removeClass(cgst,"disp-none");
            $A.util.addClass(cgst,"disp-block");
            isValid = false;
        }
        if(sgst == 'undefined'|| sgst == '' || sgst == null){
            component.set("v.sgstErrMsg",'This is a required field');
            $A.util.removeClass(sgst,"disp-none");
            $A.util.addClass(sgst,"disp-block");
            isValid = false;
        }
        if(igst == 'undefined'|| igst == '' || igst == null){
            component.set("v.igstErrMsg",'This is a required field');
            $A.util.removeClass(igst,"disp-none");
            $A.util.addClass(igst,"disp-block");
            isValid = false;
        }
        if(list == 'undefined'|| list == '' || list == null){
            component.set("v.listErrMsg",'This is a required field');
            $A.util.removeClass(list,"disp-none");
            $A.util.addClass(list,"disp-block");
            isValid = false;
        }
        if(mrp == 'undefined'|| mrp == '' || mrp == null){
            component.set("v.mrpErrMsg",'This is a required field');
            $A.util.removeClass(mrp,"disp-none");
            $A.util.addClass(mrp,"disp-block");
            isValid = false;
        }
       
        if(ndp == 'undefined'|| ndp == '' || ndp == null){
            component.set("v.ndpcodeErrMsg",'This is a required field');
            $A.util.removeClass(ndp,"disp-none");
            $A.util.addClass(ndp,"disp-block");
            isValid = false;
        }
         
        return isValid;
    },
       showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    showErrorToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "Error"
        });
        toastEvent.fire();  
    },
     listPageHelper : function(component, event){
        var eventListPage = component.getEvent("gotoparent");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
    getdealerinventoryinfo : function(component, event, helper){
        var recordid=component.get('v.recordId');
        var action = component.get("c.getinventroyinfo");
        action.setParams({ 
            "prodid" : recordid            
        });
        action.setCallback(this, function (response) {
            var state = response.getState();                      
            if (state === "SUCCESS") {
                component.set("v.inventoryInfo", response.getReturnValue());               
            }
        });        
        $A.enqueueAction(action);
    },
    fetchDealerPartsInfo : function(component, event, helper){
            var recordid=component.get('v.recordId');
          var action = component.get("c.getdealerpartsinfo");
            action.setParams({ 
                "recordid" : recordid
                
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
                if (state === "SUCCESS") {
                  component.set('v.partsInfo',storeResponse[0]);
                    var partsinfo=storeResponse[0];
                    component.set("v.disableSave",true);
                var stockinfo=partsinfo.Dealer_Inventory__r[0];
              component.set('v.stockinfo',stockinfo);
                    
                }
                 
            });
            $A.enqueueAction(action);	
     },
})
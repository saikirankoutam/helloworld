({
    doInit : function(component, event, helper) {
        var orderType = component.get("v.orderType");
        var action = component.get('c.getOrders');
        action.setParams({
            'orderType' : orderType 
        });
        	action.setCallback(this, function(response){
            var state = response.getState();
                console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.orders", records);
            }
        });
        $A.enqueueAction(action);
    },
    
    onclickPO : function(component, event, helper) {
        var target = event.getSource().get('v.value');
        var compEvent = component.getEvent("monthlyOrderIdPass");
       
        var compEventDaily = component.getEvent("DailyOrderIdPass");
        compEvent.setParams({"currentMonthlyOrderId" : target });
        compEventDaily.setParams({"currentMonthlyOrderId" : target });
        if(component.get("v.orderType") == 'monthly')
        {
    	compEvent.fire();
        }
         if(component.get("v.orderType") == 'daily')
        {
    	compEventDaily.fire();
        }
    },
    
    
})
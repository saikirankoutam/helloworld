({  
    showToast : function(component,event,Message,type){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": Message,
            "type": type
        });
        toastEvent.fire();  
    },
    
})
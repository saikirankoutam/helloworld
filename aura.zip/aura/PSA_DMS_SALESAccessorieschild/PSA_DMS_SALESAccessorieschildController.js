({
    doInit : function(component, event, helper) {
        var partRecord = component.get("v.ProductInstance");
        var partnumber=partRecord.PSA_Part_Number__c;
        if(partnumber!=''){
            component.set('v.Pillclear',partRecord.PSA_Part_Number__c);
            component.set('v.partDesc',partRecord.Model);
            component.set('v.HSNCode',partRecord.HSNcode);
            component.set('v.UOM',partRecord.UOM);
            component.set('v.NDP',partRecord.UnitPrice);
            component.find('cgst').set('v.value',partRecord.PSA_OEMCGST__c);
            component.find('sgst').set('v.value',partRecord.PSA_OEMSGST__c);
            component.find('igst').set('v.value',partRecord.PSA_OEMIGST__c);
            component.find('cess').set('v.value','0');
            component.find('taxval').set('v.value',partRecord.PSA_Taxable_Value__c);
            component.find('totaltax').set('v.value',partRecord.PSA_Total_Tax__c);
            component.find('Totalinvoice').set('v.value',partRecord.PSA_Total_Order_Value__c);
            component.find('discountper').set('v.value',partRecord.PSA_Discount__c);
            component.find('discountval').set('v.value',partRecord.PSA_Discount_Value__c);
        }
    },
    inputchange : function(component, event, helper){
        component.set("v.Pillclear", '');
        component.set('v.partDesc','');
        component.set('v.HSNCode','');
        component.set('v.UOM','');
        component.set('v.NDP','');
        component.find('cgst').set('v.value','');
        component.find('sgst').set('v.value','');
        component.find('igst').set('v.value','');
        component.find('cess').set('v.value','');
        component.find('taxval').set('v.value','');
        component.find('totaltax').set('v.value','');
        component.find('Totalinvoice').set('v.value','');
        component.find('invqty').set('v.value','');
        component.set("v.ProductInstance.PSA_Part_Number__c",'');
        component.find('discountper').set('v.value','');
        component.find('discountval').set('v.value','');
    },
    AddNewBlankRow : function(component, event, helper){
        component.getEvent('AddPartRowEvt').fire();
    },
    removeRow : function(component, event, helper){
        
        component.getEvent("DeletePartRowEvt").setParams({
            "indexVar" : component.get("v.rowIndex")}).fire();
        
    },
    recordChanges:function(component, event, helper){
        var isvalid=true;
         component.set('v.invqtyerror','');
         component.set('v.partnumbererror','');
        var partrecord = component.get("v.selectedLookUpRecord");   
        var partid = partrecord.prodname;
           component.set('v.descrvisible',false);
            component.set('v.PartNumbr',true);
        if(partid == "undefined" || partid == '' || partid == null ){                   
            component.set("v.partDesc","");
            component.set("v.HSNCode", "");
            component.set("v.UOM", "");
            component.set("v.NDP","");  
             component.set('v.descrvisible',true);
            component.set('v.PartNumbr',true);
            component.set('v.diserror','');
            component.set('v.currstock','');
            component.set('v.partnumbererror','');
            component.find('cgst').set('v.value','');
            component.find('sgst').set('v.value','');
            component.find('igst').set('v.value','');
            component.find('cess').set('v.value','');
            component.find('taxval').set('v.value','');
            component.find('totaltax').set('v.value','');
            component.find('Totalinvoice').set('v.value','');
            component.find('invqty').set('v.value','');
            component.find("discountper").set("v.value",''); 
            component.find("discountval").set("v.value",'');
            component.set("v.ProductInstance.PSA_Part_Number__c",'');
            component.set("v.qtydisable", true);
            
            
            
        }else{
            var x;
            var partnumberlist=component.get('v.partnumberlist');
            var PartsSelListEdit=component.get('v.PartsSelListEdit');
            for(x in partnumberlist ){
                if(partnumberlist[x].prodname==partrecord.prodname){
                    
                    isvalid=false;
                }
            }
            for(x in PartsSelListEdit ){
                if(PartsSelListEdit[x].PSA_Part_Number__c==partrecord.prodname){
                    isvalid=false;
                    
                }
            }
            var current=true;
          //  if(isvalid){
                component.set("v.ProductInstance.PSA_Part_Number__c", partrecord.prodname);
                component.set("v.ProductInstance.Description", partrecord.ptype);
                component.set("v.ProductInstance.PSA_OEMCGST__c", partrecord.cgst);
                component.set("v.ProductInstance.PSA_OEMSGST__c", partrecord.sgst);
                component.set("v.ProductInstance.PSA_OEMIGST__c", partrecord.igst);
                component.set("v.ProductInstance.UnitPrice", partrecord.unitprice);
                component.set("v.ProductInstance.Id", partrecord.pricebookid);
                component.set("v.ProductInstance.Product2Id", partrecord.partid);
                if(partrecord.currstock=='undefined' ||partrecord.currstock==null || partrecord.currstock=='')
                {
                     component.set('v.currstock',0);
                     component.set("v.qtydisable", true);
                    helper.showToast(component,event,'No Stock Available','Error');
                    current=false;
                }
                else{
                component.set('v.currstock',partrecord.currstock);
                }
                var partDesc = partrecord.proddesc;
                var hsnCode = partrecord.prodhsn;
                var uom = partrecord.produom;
                var unitprice = partrecord.unitprice;
                var physicalStock=partrecord.currstock; 
                var AvailableStock=partrecord.Avlstock; 
                var cgst = partrecord.cgst;
                var sgst = partrecord.sgst;
                var cess = partrecord.cess;
                var igst = partrecord.igst;
                component.set("v.partDesc", partDesc);        
                component.set("v.HSNCode", hsnCode);
                component.set("v.UOM", uom);
                component.set("v.NDP",unitprice);
                component.find('cgst').set('v.value',cgst);
                component.find('sgst').set('v.value',sgst);
                component.find('igst').set('v.value',igst);
                component.find('cess').set('v.value',cess);
                 if(current){
                component.set("v.qtydisable", false);
                 }
          /*  }else{
                if(current){
                helper.showToast(component,event,'this part is already added','Error');
                component.set("v.qtydisable", true);
                }
                
            }*/
        }
    },
    recordchange:function(component, event, helper){
        var invqty = component.find("invqty").get("v.value");
        var listprice = component.get('v.NDP'); 
        component.set('v.diserror','');
        component.set("v.ProductInstance.Quantity", invqty);
        var physicalqty = 5; //component.find("phystock").get("v.value"); 
        var discountpercentage = component.find("discountper").get("v.value"); 
        component.set("v.ProductInstance.PSA_Discount__c", discountpercentage);
        /* if(physicalqty=='undefined' || physicalqty=='' ||parseInt(invqty) >parseInt(physicalqty))
        {                   
            var Message= "Invoice Qty is Exceeded ";
            helper.showErrorToast(component,event,Message);
            component.find("invqty").set("v.value",0);
            component.set("v.invqtyerror",'Please enter quantity');
        }else */
        if(invqty >0)
        {        
            var discountval = 0;
            var netdealerprice = invqty*listprice;  
            if(discountpercentage > 0 && discountpercentage <100){
                discountval = (netdealerprice*discountpercentage)/100;
                discountval=Math.round(discountval);
            }
            var taxableValue = (netdealerprice - discountval).toFixed(1);
            component.find('taxval').set('v.value',taxableValue);
            component.set("v.invqtyerror",'');
            
            var cgst =  component.find('cgst').get('v.value');
            var sgst = component.find('sgst').get('v.value');
            var cess = 0;
            var totaltax = (taxableValue*cgst/100 + taxableValue*sgst/100 + taxableValue*cess/100);
            totaltax=Math.round(totaltax);
            component.find('taxval').set('v.value',taxableValue);
            component.find('totaltax').set('v.value',totaltax);
            component.find('Totalinvoice').set('v.value',parseInt(totaltax)+parseInt(taxableValue));
            component.set("v.discountvalue", discountval.toFixed(1));
            
        }
        if(invqty ='' ||invqty == 0 || invqty<0){ 
            component.set("v.invqtyerror",'Please Enter Quantity Greater than Zero');
            component.find('taxval').set('v.value','');
            component.find('totaltax').set('v.value','');
            component.find('Totalinvoice').set('v.value','');
            component.find('invqty').set('v.value','');
            component.find("discountval").set("v.value",''); 
        }
        if(discountpercentage >=100){                 
            
            var Message= "Discount should be below  100 ";
            helper.showToast(component,event,Message,'Error');
        }
        if( discountpercentage<0){                   
            
            var Message= "Discount should not be less than 0 ";
            helper.showToast(component,event,Message,'Error');
            
        }
        
    },
    checkValidation:function(component, event, helper){
        var isvalid=true;
        var partnumberValue = component.get("v.ProductInstance.PSA_Part_Number__c");
        var invoiceqty = component.find("invqty");    
        var Quantityvalue = invoiceqty.get("v.value");   
        var discountpercentage = component.find("discountper").get("v.value");
        component.set('v.partnumbererror','');
        invoiceqty.set("v.errors", null);
        if(partnumberValue == 'undefined' || partnumberValue == '' || partnumberValue == null ){
            component.set('v.partnumbererror',"Please select the Part Number");
            isvalid=false;
            
        }     
        
        if(Quantityvalue == 0 || Quantityvalue == "undefined" || Quantityvalue == '' || Quantityvalue == null){
            
            component.set("v.invqtyerror",'Please enter quantity');
            isvalid=false;
        }
        if(discountpercentage >100){                 
            component.set("v.diserror",'Discount should not be Greater than 100');
            isvalid=false;
        }
        if( discountpercentage<0){                   
            component.set("v.diserror",'Discount should not be Less than 0');
            isvalid=false;
        }
        if( discountpercentage>0 && discountpercentage <100){                   
            component.set("v.diserror",'');
            
        }
        
        return isvalid;
    },
     descChanges:function(component, event, helper){
         
        var isvalid=true;
         component.set('v.invqtyerror','');
         component.set('v.partnumbererror','');
         component.set('v.descrvisible',true);
         component.set('v.PartNumbr',false);
        var partrecord = component.get("v.selectedDescLookUpRecord");   
        var partid = partrecord.prodname;
        if(partid == "undefined" || partid == '' || partid == null ){                   
            component.set("v.partDesc","");
            component.set("v.HSNCode", "");
            component.set("v.UOM", "");
            component.set("v.NDP","");
             component.set('v.descrvisible',true);
            component.set('v.PartNumbr',true);
            component.set('v.diserror','');
            component.set('v.currstock','');
            component.set('v.partnumbererror','');
            component.find('cgst').set('v.value','');
            component.find('sgst').set('v.value','');
            component.find('igst').set('v.value','');
            component.find('cess').set('v.value','');
            component.find('taxval').set('v.value','');
            component.find('totaltax').set('v.value','');
            component.find('Totalinvoice').set('v.value','');
            component.find('invqty').set('v.value','');
            component.find("discountper").set("v.value",''); 
            component.find("discountval").set("v.value",'');
            component.set("v.ProductInstance.PSA_Part_Number__c",'');
            component.set("v.qtydisable", true);
            
            
            
        }else{
            var x;
            var partnumberlist=component.get('v.partnumberlist');
            var PartsSelListEdit=component.get('v.PartsSelListEdit');
            for(x in partnumberlist ){
                if(partnumberlist[x].prodname==partrecord.prodname){
                    
                    isvalid=false;
                }
            }
            for(x in PartsSelListEdit ){
                if(PartsSelListEdit[x].PSA_Part_Number__c==partrecord.prodname){
                    isvalid=false;
                    
                }
            }
            var current=true;
          //  if(isvalid){
                component.set("v.ProductInstance.PSA_Part_Number__c", partrecord.prodname);
                component.set("v.ProductInstance.Description", partrecord.ptype);
                component.set("v.ProductInstance.PSA_OEMCGST__c", partrecord.cgst);
                component.set("v.ProductInstance.PSA_OEMSGST__c", partrecord.sgst);
                component.set("v.ProductInstance.PSA_OEMIGST__c", partrecord.igst);
                component.set("v.ProductInstance.UnitPrice", partrecord.unitprice);
                component.set("v.ProductInstance.Id", partrecord.pricebookid);
                component.set("v.ProductInstance.Product2Id", partrecord.partid);
                if(partrecord.currstock=='undefined' ||partrecord.currstock==null || partrecord.currstock=='')
                {
                     component.set('v.currstock',0);
                     component.set("v.qtydisable", true);
                    helper.showToast(component,event,'No Stock Available','Error');
                    current=false;
                }
                else{
                component.set('v.currstock',partrecord.currstock);
                }
                var partDesc = partrecord.proddesc;
                var hsnCode = partrecord.prodhsn;
                var uom = partrecord.produom;
                var unitprice = partrecord.unitprice;
                var physicalStock=partrecord.currstock; 
                var AvailableStock=partrecord.Avlstock; 
                var cgst = partrecord.cgst;
                var sgst = partrecord.sgst;
                var cess = partrecord.cess;
                var igst = partrecord.igst;
                component.set("v.partDesc", partDesc);        
                component.set("v.HSNCode", hsnCode);
                component.set("v.UOM", uom);
                component.set("v.NDP",unitprice);
                component.find('cgst').set('v.value',cgst);
                component.find('sgst').set('v.value',sgst);
                component.find('igst').set('v.value',igst);
                component.find('cess').set('v.value',cess);
                 if(current){
                component.set("v.qtydisable", false);
                 }
          /*  }else{
                if(current){
                helper.showToast(component,event,'this part is already added','Error');
                component.set("v.qtydisable", true);
                }
                
            }*/
        }
    },
    
})
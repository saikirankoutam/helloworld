({
    hlpautoCal : function(component , event , helper){
        
        var partType = component.get("v.partType");
        var items_att =component.get("v.partItems");
        
        var material_value =0;
        var Tax_Amount =0;
        var Invoice_value =0;
        var Freight_Amount =0;
        var Received_value =0;
        var Damage_value =0;
        var Shortage_value =0;
        var GRN_value =0;
        if(partType == 'PO'){
            for(let index =0 ; index < items_att.length ; index++){
                let item = items_att[index];
                material_value = item.PSA_Rate_per_unit__c !=null &&  item.PSA_Received_Qty__c !=null ? parseInt(material_value) + ( parseInt(item.PSA_Rate_per_unit__c) * parseInt(item.PSA_Received_Qty__c)) : 0;
                Tax_Amount = ((parseInt(item.PSA_Rate_per_unit__c) * parseInt(item.PSA_GST__c)) /100 ) * parseInt(item.PSA_Quantity__c);
                Damage_value = item.PSA_Damaged_Qty__c !=null ? parseInt(Damage_value) + parseInt(item.PSA_Damaged_Qty__c) : 0;
                Shortage_value = item.PSA_Shortage_Qty__c !=null ? parseInt(Shortage_value) + parseInt(item.PSA_Shortage_Qty__c) : 0;
                Invoice_value = material_value + Tax_Amount ;
            }
            
            // assign the calculated values to the header componnet 
            component.find("material-value").set("v.value",material_value);
            component.find("Tax-value").set("v.value",Tax_Amount);
            component.find("Shortage-value").set("v.value",Shortage_value);
            component.find("Damage-value").set("v.value",Damage_value);
            component.find("inv-ammount").set("v.value",Invoice_value);
        }
        
    },
    hlpautoCalInvoice : function(component , event , helper){
        
        var partType = component.get("v.partType");
        var items_att =component.get("v.InvoiveDetailList");
        
        var material_value =0;
        var Tax_Amount =13;
        var Invoice_value =0;
        var Freight_Amount =0;
        var Received_value =0;
        var Damage_value =0;
        var Shortage_value =0;
        var GRN_value =0;
        
        for(let index =0 ; index < items_att.length ; index++){
            let item = items_att[index];
            material_value = item.Local_Parts_Order_Item__r.PSA_Rate_per_unit__c !=null &&  item.Local_Parts_Order_Item__r.PSA_Received_Qty__c !=null ? parseInt(material_value) + ( parseInt(item.Local_Parts_Order_Item__r.PSA_Rate_per_unit__c) * parseInt(item.Local_Parts_Order_Item__r.PSA_Received_Qty__c)) : 0;
            Tax_Amount = ((parseInt(item.Local_Parts_Order_Item__r.PSA_Rate_per_unit__c) * parseInt(item.Local_Parts_Order_Item__r.PSA_GST__c)) /100 ) * parseInt(item.Local_Parts_Order_Item__r.PSA_Quantity__c);
            Damage_value = item.Local_Parts_Order_Item__r.PSA_Damaged_Qty__c !=null ? parseInt(Damage_value) + parseInt(item.Local_Parts_Order_Item__r.PSA_Damaged_Qty__c) : 0;
            Shortage_value = item.Local_Parts_Order_Item__r.PSA_Shortage_Qty__c !=null ? parseInt(Shortage_value) + parseInt(item.Local_Parts_Order_Item__r.PSA_Shortage_Qty__c) : 0;
            
            
            // assign the calculated values to the header componnet 
            component.find("material-value").set("v.value",material_value);
            component.find("Tax-value").set("v.value",Tax_Amount);
            component.find("Shortage-value").set("v.value",Shortage_value);
            component.find("Damage-value").set("v.value",Damage_value);
        }
        
    },
    successToast : function(component, event, Message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();
    },
    errortoast : function(component, event, helper, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
    },
    hlpPOGRN : function(component,event,helper){
        var ord = component.get("v.selectedLookUpRecord");
        var invnum = component.find("invnum").get("v.value");
        var action = component.get("c.createPartReceiptGRN_PO");
        action.setParams({
            "ord" : ord,
            "invnumber" : invnum,
            "partItems" : component.get("v.partItems")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            //("Status : "+state);
            if (state === "SUCCESS") {
                helper.successToast(component, event, helper, "The GRN has been Created successfully.");
                component.set("v.PartGRN", false);
            }
            else{
                var errors = response.getError();
                //alert(""+errors[0].message);
            }
        });
        $A.enqueueAction(action);
    },
    getGRNNUmber : function(component,event,helper){
        var action = component.get("c.getGRNNumber");
        action.setParams({
            "id" : component.get("v.currentId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                console.log(value.Invoice_Details__r);
                component.set("v.GRNNumber", value.PartsReceipt__r[0].PSA_GRN_number__c);
            }
        });
        $A.enqueueAction(action);
    },
    hlpINVDetails : function(cmp,eve,hlp){
        var selectedLookUpRecord1 = cmp.get("v.selectedLookUpRecordINV");
        var action = cmp.get("c.srvINVDetails");
        action.setParams({ invoiceid : selectedLookUpRecord1.Id });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                    
                cmp.set("v.InvoiveDetailList", response.getReturnValue());
                hlp.hlpautoCalInvoice(cmp,eve,hlp);
            }
            else {
                console.log("Unknown error");
            }
            
        });    
        
        $A.enqueueAction(action);
    },
    
    PopulateGRNvalues: function(component,event,helper){
         var partItems = component.get("v.partItems");
        var invoiceitems = component.get("v.InvoiveDetailList");
        var invfreightvalue = component.get("v.Invoiceinfo.Frieght_Amount__c");
       
        var materialValue = 0;
        var taxValue = 0;
        var receivedValue = 0;
        var shortagevalue =0;
        var damagevalue =0;
        var freightvalue = 0;
        var grnvalue = 0;
        var invoicevalue =0;
        var invoiceqty =0;
        var calculateqty=0;
        var calqty = true;
        var partType = component.get("v.partType");
        var receivedqty;
        if(partType == "PO"){
            for(var i=0; i<partItems.length; i++)
            {
                materialValue = partItems[i].PSA_Rate_per_unit__c * partItems[i].PSA_Quantity__c+materialValue;
                // taxValue = (partItems[i].PSA_Rate_per_unit__c * partItems[i].PSA_GST__c/100* PSA_Quantity__c)+taxValue;
                taxValue = (((parseInt(partItems[i].PSA_Rate_per_unit__c) * parseInt(partItems[i].PSA_GST__c)) /100 ) * parseInt(partItems[i].PSA_Quantity__c)+taxValue);
                receivedValue = (partItems[i].PSA_Rate_per_unit__c * partItems[i].PSA_Received_Qty__c)+receivedValue;
                shortagevalue = (partItems[i].PSA_Rate_per_unit__c * partItems[i].PSA_Shortage_Qty__c)+shortagevalue;
                damagevalue = (partItems[i].PSA_Rate_per_unit__c * partItems[i].PSA_Damaged_Qty__c)+damagevalue;
                freightvalue = parseInt(partItems[i].Freight_Charges__c)+freightvalue;
                invoicevalue = freightvalue +taxValue+materialValue;
                grnvalue = receivedValue + freightvalue;
                
                invoiceqty =parseInt(partItems[i].PSA_Quantity__c);           
                calculateqty = (parseInt(partItems[i].PSA_Received_Qty__c)+parseInt(partItems[i].PSA_Shortage_Qty__c)+parseInt(partItems[i].PSA_Damaged_Qty__c));
                receivedqty = partItems[i].PSA_Received_Qty__c;         
                
                if(receivedqty =='undefined' ||receivedqty == 0){ 
                     calqty = false;
                    helper.errortoast(component, event, helper, "Please enter received Qty");
                   
                }
                if(invoiceqty<calculateqty){       
                    helper.errortoast(component, event, helper, "Received/Shortage/Damage qty not greated than Invoice qty");
                    calqty = false;
                }                 
                
            } 
            if(calqty){
                component.set("v.materialValuePO", materialValue);
                component.set("v.taxValuePO", taxValue);
                component.set("v.invoicevaluePO",invoicevalue);
                component.set("v.receivedValuePO", receivedValue);
                component.set("v.shortagevaluePO", shortagevalue);
                component.set("v.damagevaluePO", damagevalue);
                component.set("v.freightvaluePO", freightvalue);
                component.set("v.GRNvaluePO",grnvalue);
            }
        }
        if(partType == "invoice"){
            for(var i=0; i<invoiceitems.length; i++)
            {
                
                receivedValue = (invoiceitems[i].PSA_Order_Item__r.PricebookEntry.UnitPrice * invoiceitems[i].PSA_Received_Qty__c)+receivedValue;
                shortagevalue = (invoiceitems[i].PSA_Order_Item__r.PricebookEntry.UnitPrice * invoiceitems[i].PSA_Shortage_Quantity__c)+shortagevalue;
                damagevalue = (invoiceitems[i].PSA_Order_Item__r.PricebookEntry.UnitPrice * invoiceitems[i].PSA_Damaged_Quantity__c)+damagevalue;                                          
                grnvalue = receivedValue + invfreightvalue;        
                invoiceqty =parseInt(invoiceitems[i].Invoice_Quantity__c);           
                calculateqty = (parseInt(invoiceitems[i].PSA_Received_Qty__c)+parseInt(invoiceitems[i].PSA_Shortage_Quantity__c)+parseInt(invoiceitems[i].PSA_Damaged_Quantity__c));
                receivedqty = invoiceitems[i].PSA_Received_Qty__c; 
                
                if(receivedqty =='undefined' ||receivedqty == 0){ 
                     calqty = false;
                    helper.errortoast(component, event, helper, "Please enter received Qty");
                   
                }
                if(invoiceqty<calculateqty){       
                    helper.errortoast(component, event, helper, "Received/Shortage/Damaged qty not greated than Invoice qty");
                    calqty = false;
                }
                
            } 
            if(calqty){          
                component.set("v.receivedValueinv", receivedValue);
                component.set("v.shortagevalueinv", shortagevalue);
                component.set("v.damagevalueinv", damagevalue); 
                component.set("v.grnvalueinv",grnvalue);
            }
        }
        
    }
    
})
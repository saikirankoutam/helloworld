({
    demoLoading : function(component, event, helper){
        var itemInstance = component.get("v.itemInstance");
        component.set("v.disMetallic", false);
                component.set("v.disColour", false);
                component.set("v.disIntColour", false);
                component.set("v.disIntTrim", false);
                component.set("v.disRoof", false);
                component.set("v.disPack", false);
                component.set("v.demoType", itemInstance.Demo_OrderType__c);
                component.set("v.colourList", itemInstance.Product2.PSA_Ext_Colour__c);
                component.set("v.IntcolourList", itemInstance.Product2.Interior_Color__c);
                component.set("v.metallicList", itemInstance.Product2.Metallic_Non_Metallic__c);
                component.set("v.IntTrimList", itemInstance.Product2.Interior_Trim_Type__c);
                component.set("v.RoofList", itemInstance.Product2.Roof__c);
                component.set("v.PackList", itemInstance.Product2.Pack__c);
                component.set("v.productId", itemInstance.Product2.Id);
                component.find("variant").set("v.value", itemInstance.Product2.PSA_Variant__c);
                component.find("color").set("v.value", itemInstance.Product2.PSA_Ext_Colour__c);
                component.find("interiorcolor").set("v.value", itemInstance.Product2.Interior_Color__c);
                component.find("Metallic_Non_Metallic").set("v.value", itemInstance.Product2.Metallic_Non_Metallic__c);
                component.find("intTrim").set("v.value", itemInstance.Product2.Interior_Trim_Type__c);
                component.find("roof").set("v.value", itemInstance.Product2.Roof__c);
                component.find("pack").set("v.value", itemInstance.Product2.Pack__c);
                var productId = itemInstance.Product2.Id;
        		var demoType = itemInstance.Demo_OrderType__c;
        var mapFirm = component.get("v.demomapFirm");
        if(mapFirm != null)
                    for(var key in mapFirm)
                        if(mapFirm[demoType] != null)
                        {
                            var m = mapFirm[demoType];
                            for(var key in m)
                            {
                        		if(m[productId])
                                    component.set("v.quantity", m[productId]); 
                                else
                            		component.set("v.quantity", 0);
                            }
                        }
        var fmap1 = component.get("v.demofmap1");
        if(fmap1 != null)
                    for(var key in fmap1)
                        if(fmap1[demoType] != null)
                        {
                            var m = fmap1[demoType];
                            for(var key in m)
                        		if(m[productId])
                                    component.set("v.f1Quantity", m[productId]); 
                                else
                            		component.set("v.f1Quantity", 0);
                        }
        var fmap2 = component.get("v.demofmap2");
        if(fmap2 != null)
                    for(var key in fmap2)
                        if(fmap2[demoType] != null)
                        {
                            var m = fmap2[demoType];
                            for(var key in m)
                        		if(m[productId])
                                    component.set("v.f2Quantity", m[productId]); 
                                else
                            		component.set("v.f2Quantity", 0);
                        }
        
        var fmap3 = component.get("v.demofmap3");
        if(fmap3 != null)
                    for(var key in fmap3)
                        if(fmap3[demoType] != null)
                        {
                            var m = fmap3[demoType];
                            for(var key in m)
                        		if(m[productId])
                                    component.set("v.f3Quantity", m[productId]); 
                                else
                            		component.set("v.f3Quantity", 0);
                        }
        
        var fmap4 = component.get("v.demofmap4");
        if(fmap4 != null)
                    for(var key in fmap4)
                        if(fmap4[demoType] != null)
                        {
                            var m = fmap4[demoType];
                            for(var key in m)
                        		if(m[productId])
                                    component.set("v.f4Quantity", m[productId]); 
                                else
                            		component.set("v.f4Quantity", 0);
                        }        
        var fmap5 = component.get("v.demofmap5");
        if(fmap5 != null)
                    for(var key in fmap5)
                        if(fmap5[demoType] != null)
                        {
                            var m = fmap5[demoType];
                            for(var key in m)
                        		if(m[productId])
                                    component.set("v.f5Quantity", m[productId]); 
                                else
                            		component.set("v.f5Quantity", 0);
                        }
        var fmap6 = component.get("v.demofmap6");
        if(fmap6 != null)
            for(var key in fmap6)
                if(fmap6[demoType] != null)
                {
                    var m = fmap6[demoType];
                    for(var key in m)
                        if(m[productId])
                            component.set("v.f6Quantity", m[productId]); 
                        else
                            component.set("v.f6Quantity", 0);
                }
        
        component.set("v.disVariant", true);
        component.set("v.disMetallic", true);
        component.set("v.disColour", true);
        component.set("v.disIntColour", true);
        component.set("v.disIntTrim", true);
        component.set("v.disRoof", true);
        component.set("v.disPack", true);
        component.set("v.disableQuantity", true);
        component.set("v.f1disableQuantity", true);
        component.set("v.f2disableQuantity", true);
        component.set("v.f3disableQuantity", true);
        component.set("v.f4disableQuantity", true);
        component.set("v.f5disableQuantity", true);
        component.set("v.f6disableQuantity", true);
    },
    
    setvalues : function(component, event, helper){
        
        var itemInstance = component.get("v.itemInstance");
        component.set("v.spinner", false);
        if(component.get("v.orderType") != 'daily')
        {
            if(typeof itemInstance.Id !== 'undefined')
            { 
                component.set("v.disMetallic", false);
                component.set("v.disColour", false);
                component.set("v.disIntColour", false);
                component.set("v.disIntTrim", false);
                component.set("v.disRoof", false);
                component.set("v.disPack", false);
                component.set("v.colourList", itemInstance.Product2.PSA_Ext_Colour__c);
                component.set("v.IntcolourList", itemInstance.Product2.Interior_Color__c);
                component.set("v.metallicList", itemInstance.Product2.Metallic_Non_Metallic__c);
                component.set("v.IntTrimList", itemInstance.Product2.Interior_Trim_Type__c);
                component.set("v.RoofList", itemInstance.Product2.Roof__c);
                component.set("v.PackList", itemInstance.Product2.Pack__c);
                component.set("v.productId", itemInstance.Product2.Id);
                var productList = component.get("v.productList");
                var quantityList = component.get("v.quantityList");
                var index = productList.indexOf(itemInstance.Product2.Id);
                component.set("v.quantity", quantityList[index]);
                component.find("variant").set("v.value", itemInstance.Product2.PSA_Variant__c);
                component.find("color").set("v.value", itemInstance.Product2.PSA_Ext_Colour__c);
                component.find("interiorcolor").set("v.value", itemInstance.Product2.Interior_Color__c);
                component.find("Metallic_Non_Metallic").set("v.value", itemInstance.Product2.Metallic_Non_Metallic__c);
                component.find("intTrim").set("v.value", itemInstance.Product2.Interior_Trim_Type__c);
                component.find("roof").set("v.value", itemInstance.Product2.Roof__c);
                component.find("pack").set("v.value", itemInstance.Product2.Pack__c);
                var productId = itemInstance.Product2.Id;
                var fmap1 = component.get("v.fmap1");
                if(fmap1 != null)
                    for(var key in fmap1)
                        if(fmap1[productId])
                            component.set("v.f1Quantity", fmap1[productId]); 
                        else
                            component.set("v.f1Quantity", 0);
                var fmap2 = component.get("v.fmap2");
                if(fmap2 != null)
                    for(var key in fmap2)
                		if(fmap2[productId])
                            component.set("v.f2Quantity", fmap2[productId]); 
                        else
                            component.set("v.f2Quantity", 0);
                var fmap3 = component.get("v.fmap3");
                if(fmap3 != null)
                    for(var key in fmap3)
                		if(fmap3[productId])
                            component.set("v.f3Quantity", fmap3[productId]); 
                        else
                            component.set("v.f3Quantity", 0);
                var fmap4 = component.get("v.fmap4");
                if(fmap4 != null)
                    for(var key in fmap4)
                		if(fmap4[productId])
                            component.set("v.f4Quantity", fmap4[productId]); 
                        else
                            component.set("v.f4Quantity", 0);
                var fmap5 = component.get("v.fmap5");
                if(fmap5 != null)
                    for(var key in fmap5)
                		if(fmap5[productId])
                            component.set("v.f5Quantity", fmap5[productId]); 
                        else
                            component.set("v.f5Quantity", 0);
                var fmap6 = component.get("v.fmap6");
                if(fmap6 != null)
                    for(var key in fmap6)
                		if(fmap6[productId])
                            component.set("v.f6Quantity", fmap6[productId]); 
                        else
                            component.set("v.f6Quantity", 0);
            }else{                
        component.set("v.productId", "");
        component.set("v.quantity", 0);
        component.set("v.f1Quantity", 0);
        component.set("v.f2Quantity", 0);
        component.set("v.f3Quantity", 0);
        component.set("v.f4Quantity", 0);
        component.set("v.f5Quantity", 0);
        component.set("v.f6Quantity", 0);
        component.set("v.disableQuantity", true);
        component.set("v.f1disableQuantity", true);
        component.set("v.f2disableQuantity", true);
        component.set("v.f3disableQuantity", true);
        component.set("v.f4disableQuantity", true);
        component.set("v.f5disableQuantity", true);
        component.set("v.f6disableQuantity", true);
            }
        }else{
            component.set("v.disableQuantity", true);
        }
                                                   
        
    },
    
    removeProduct : function(component, event, helper){
        var productId = component.get("v.productId");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var compEvent = component.getEvent("removeProducts");
            compEvent.setParams({
                "productId": component.get("v.productId")
                
            });
            compEvent.fire();
            component.set("v.productId", "");
            component.set("v.quantity", 0);
            component.set("v.f1Quantity", 0);
            component.set("v.f2Quantity", 0);
            component.set("v.f3Quantity", 0);
            component.set("v.f4Quantity", 0);
            component.set("v.f5Quantity", 0);
            component.set("v.f6Quantity", 0);
            component.set("v.disableQuantity", true);
            component.set("v.f1disableQuantity", true);
            component.set("v.f2disableQuantity", true);
            component.set("v.f3disableQuantity", true);
            component.set("v.f4disableQuantity", true);
            component.set("v.f5disableQuantity", true);
            component.set("v.f6disableQuantity", true);
        }
    },
    
    addProducts : function(component, event, helper){
        var compEvent = component.getEvent("AddProducts");
       	compEvent.setParams({
            "productId" : component.get("v.productId"),
            "orderItemQuantity": component.get("v.quantity"),
            "f1Quantity": component.get("v.f1Quantity"),
            "f2Quantity": component.get("v.f2Quantity"),
            "f3Quantity": component.get("v.f3Quantity"),
            "f4Quantity": component.get("v.f4Quantity"),
            "f5Quantity": component.get("v.f5Quantity"),
            "f6Quantity": component.get("v.f6Quantity")
            
        });
        compEvent.fire();
    },
    
    showError : function(component, event, helper, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
    },
    
})
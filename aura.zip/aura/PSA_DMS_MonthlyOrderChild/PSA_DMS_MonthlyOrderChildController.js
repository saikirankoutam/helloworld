({
	doInit : function(component, event, helper){
        if(component.get("v.orderType") == 'monthly')
            component.set("v.spinner", true);
        var selectvalmodel = component.get("v.carType");
        var action = component.get("c.getCarVariant");
        action.setParams({ 
            "selModel" : selectvalmodel 
        });  
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.VariantList", response.getReturnValue());
            component.set("v.disVariant", "false");
            }
            
            if(component.get("v.demo"))
                helper.demoLoading(component,event,helper);
            else
                helper.setvalues(component,event,helper);
        });
        $A.enqueueAction(action);	
    },
    
    getmetallicList : function(component, event, helper){debugger;
        var selectvalmodel = component.get("v.carType");
        var selectvariant = component.find("variant").get("v.value");
        component.find("Metallic_Non_Metallic").set("v.value", "");
        component.set("v.disMetallic", "true");
        var action = component.get("c.getCarMetallicColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel
            
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.metallicList", response.getReturnValue());
            component.set("v.disMetallic", "false");
            }
        });
        $A.enqueueAction(action);	
        helper.removeProduct(component, event, helper); //Remove the product if already available
        component.find("color").set("v.value", "");
        component.find("intTrim").set("v.value", "");
        component.find("interiorcolor").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disColour", "true");
        component.set("v.disIntTrim", "true");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
    },
    
    getColour : function(component, event, helper){
        var selectvalmodel = component.get("v.carType");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("Metallic_Non_Metallic").get("v.value");
        component.find("color").set("v.value", "");
        component.set("v.disColour", "true");
        var action = component.get("c.getCarColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.colourList", response.getReturnValue());
            component.set("v.disColour", "false");
            }
        });
        $A.enqueueAction(action);	
        helper.removeProduct(component, event, helper); //Remove the product if already available
        component.find("intTrim").set("v.value", "");
        component.find("interiorcolor").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disIntTrim", "true");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
    },
    
    getIntTrimType : function(component, event, helper){
        var selectvalmodel = component.get("v.carType");
        var selectvariant = component.find("variant").get("v.value");
        var color = component.find("color").get("v.value");
        var Metallic_Non_Metallic = component.find("Metallic_Non_Metallic").get("v.value");
        component.find("intTrim").set("v.value", "");
        component.set("v.disIntTrim", "true");
        var action = component.get("c.getCarIntTrimType");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.IntTrimList", response.getReturnValue());
            component.set("v.disIntTrim", "false");
            }
        });
        $A.enqueueAction(action);	
        helper.removeProduct(component, event, helper); //Remove the product if already available
        component.find("interiorcolor").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
        
    },
    getIntcolourList : function(component, event, helper){
        var selectvalmodel = component.get("v.carType");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("Metallic_Non_Metallic").get("v.value");
        var color = component.find("color").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        component.find("interiorcolor").set("v.value", "");
        component.set("v.disIntColour", "true");
        var action = component.get("c.getCarIntColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.IntcolourList", response.getReturnValue());
            component.set("v.disIntColour", "false");
            }
        });
        $A.enqueueAction(action);	
        helper.removeProduct(component, event, helper); //Remove the product if already available
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
        
    },
        
    getRoofList : function(component, event, helper){
        var selectvalmodel = component.get("v.carType");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("Metallic_Non_Metallic").get("v.value");
        var color = component.find("color").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        var interiorcolor = component.find("interiorcolor").get("v.value");
        component.find("roof").set("v.value", "");
        component.set("v.disRoof", "true");
        var action = component.get("c.getCarRoof");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim,
            "selIntcolor" : interiorcolor
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.RoofList", response.getReturnValue());
            component.set("v.disRoof", "false");
            }
        });
        $A.enqueueAction(action);	
        helper.removeProduct(component, event, helper); //Remove the product if already available
        component.find("pack").set("v.value", "");
        component.set("v.disPack", "true");
        
    },
    getPackList : function(component, event, helper){
        var selectvalmodel = component.get("v.carType");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("Metallic_Non_Metallic").get("v.value");
        var color = component.find("color").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        var interiorcolor = component.find("interiorcolor").get("v.value");
        var roof = component.find("roof").get("v.value");
        component.find("pack").set("v.value", "");
        component.set("v.disPack", "true");
        var action = component.get("c.getCarPack");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim,
            "selIntcolor" : interiorcolor,
            "selRoof" : roof
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.PackList", response.getReturnValue());
            component.set("v.disPack", "false");
            }
        });
        $A.enqueueAction(action);	
        helper.removeProduct(component, event, helper); //Remove the product if already available
        
    },
    
    
    getId : function(component, event, helper){
        helper.removeProduct(component, event, helper); //Remove the product if already available
        component.set("v.disableQuantity", false);
        component.set("v.f1disableQuantity", false);
        component.set("v.f2disableQuantity", false);
        component.set("v.f3disableQuantity", false);
        component.set("v.f4disableQuantity", false);
        component.set("v.f5disableQuantity", false);
        component.set("v.f6disableQuantity", false);
        var itemInstance = component.get("v.itemInstance");
       	var selectvalmodel = component.get("v.carType");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("Metallic_Non_Metallic").get("v.value");
        var color = component.find("color").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        var interiorcolor = component.find("interiorcolor").get("v.value");
        var roof = component.find("roof").get("v.value");
        var pack = component.find("pack").get("v.value");
        component.set("v.quantity", "");
        component.set("v.f1Quantity", 0);
        component.set("v.f2Quantity", 0);
        component.set("v.f3Quantity", 0);
        component.set("v.f4Quantity", 0);
        component.set("v.f5Quantity", 0);
        component.set("v.f6Quantity", 0);
        var action = component.get("c.getProductId");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim,
            "selIntcolor" : interiorcolor,
            "selRoof" : roof,
            "selPack" : pack
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            var value = response.getReturnValue();
                if(value)
                {
                    var productList = component.get("v.productList");
                    if(typeof productList !== 'undefined' && productList.length > 0)
                    {
                        if(productList.indexOf(value.Id) != -1)
                        {
                            component.set("v.disableQuantity", true);
                            component.set("v.f1disableQuantity", true);
                            component.set("v.f2disableQuantity", true);
                            component.set("v.f3disableQuantity", true);
                            component.set("v.f4disableQuantity", true);
                            component.set("v.f5disableQuantity", true);
                            component.set("v.f6disableQuantity", true);
                            var msg = $A.get("$Label.c.Vehicle_Duplicate_Item_Error");
                            helper.showError(component, event, helper, msg);
                        }
                        else
                            component.set("v.productId", value.Id);
                    }else
                        component.set("v.productId", value.Id);
                    component.set("v.itemInstance.Product2.Id", value.Id);
                    component.set("v.itemInstance.Product2.PSA_Variant__c", component.find("variant").get("v.value"));
                    component.set("v.itemInstance.Product2.PSA_Ext_Colour__c", component.find("color").get("v.value"));
                    component.set("v.itemInstance.Product2.Metallic_Non_Metallic__c", component.find("Metallic_Non_Metallic").get("v.value"));
                    component.set("v.itemInstance.Product2.Interior_Trim_Type__c", component.find("intTrim").get("v.value"));
                    component.set("v.itemInstance.Product2.Interior_Color__c", component.find("interiorcolor").get("v.value"));
                    component.set("v.itemInstance.Product2.Roof__c", component.find("roof").get("v.value"));
                    component.set("v.itemInstance.Product2.Pack__c", component.find("pack").get("v.value"));
                       
                    
                }
                
            }
        });
        $A.enqueueAction(action);	
        
        
    },
    
    addRow : function(component, event, helper){
    
        var compEvent = component.getEvent("AddDeleteRows");
       	compEvent.setParams({
            "brand" : component.get("v.carType"),
            "addDelete": "add",
            "rowNumber": component.get("v.rowIndex")
            
        });
        compEvent.fire();
    },
    DeleteRow : function(component, event, helper){
        var compEvent = component.getEvent("AddDeleteRows");
       	compEvent.setParams({
            "brand" : component.get("v.carType"),
            "addDelete": "del",
            "rowNumber": component.get("v.rowIndex"),
            "productId": component.get("v.productId")
            
        });
        compEvent.fire();
    },
    
    addProductsf : function(component, event, helper){
        
        var productId = component.get("v.productId");
        if(component.get("v.orderType") == "monthly")
        {
        var quantity = component.get("v.quantity");
        var QtyMinus = 0;
        var limitQty = 0;
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var orderLimit = component.get("v.orderLimit");
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.get("v.carType"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var productList = component.get("v.productList");
            var quantityList = component.get("v.quantityList");
            var demomapFirm = component.get("v.demomapFirm");
            var index = productList.indexOf(productId);
            if(index != -1)
            {
                QtyMinus = quantityList[index];
            }
            /*var Qty = 0-QtyMinus+quantity;
            if(typeof quantityList !== 'undefined' && quantityList.length > 0)
                for(var i=0; i<quantityList.length; i++)
                    Qty = Qty+quantityList[i];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }*/
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.quantity", 0);
        }
        }
        else if(typeof productId !== 'undefined' && productId != "")
        {
            helper.addProducts(component, event, helper);
        }else{
            component.set("v.quantity", 0);
        }
        
    },

    addProductsf1 : function(component, event, helper){
        var productId = component.get("v.productId");
        var quantity = component.get("v.f1Quantity");
        var QtyMinus = 0;
        var limitQty = 0;
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var orderLimit = component.get("v.orderLimit");
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.get("v.carType"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var productList = component.get("v.productList");
            var quantityList = component.get("v.f1quantityList");
            var demomapFirm = component.get("v.demofmap1");
            var index = productList.indexOf(productId);
            if(index != -1)
            {
                QtyMinus = quantityList[index];
            }
            /*var Qty = 0-QtyMinus+quantity;
            if(typeof quantityList !== 'undefined' && quantityList.length > 0)
                for(var i=0; i<quantityList.length; i++)
                    Qty = Qty+quantityList[i];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }*/
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f1Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f1Quantity", 0);
        }
        
    },
    
    addProductsf2 : function(component, event, helper){
        var productId = component.get("v.productId");
        var quantity = component.get("v.f2Quantity");
        var QtyMinus = 0;
        var limitQty = 0;
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var orderLimit = component.get("v.orderLimit");
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.get("v.carType"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var productList = component.get("v.productList");
            var quantityList = component.get("v.f2quantityList");
            var demomapFirm = component.get("v.demofmap2");
            var index = productList.indexOf(productId);
            if(index != -1)
            {
                QtyMinus = quantityList[index];
            }
            /*var Qty = 0-QtyMinus+quantity;
            if(typeof quantityList !== 'undefined' && quantityList.length > 0)
                for(var i=0; i<quantityList.length; i++)
                    Qty = Qty+quantityList[i];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }*/
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f2Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f2Quantity", 0);
        }
        
    },
    
    addProductsf3 : function(component, event, helper){
        var productId = component.get("v.productId");
        var quantity = component.get("v.f3Quantity");
        var QtyMinus = 0;
        var limitQty = 0;
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var orderLimit = component.get("v.orderLimit");
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.get("v.carType"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var productList = component.get("v.productList");
            var quantityList = component.get("v.f3quantityList");
            var demomapFirm = component.get("v.demofmap3");
            var index = productList.indexOf(productId);
            if(index != -1)
            {
                QtyMinus = quantityList[index];
            }
            /*var Qty = 0-QtyMinus+quantity;
            if(typeof quantityList !== 'undefined' && quantityList.length > 0)
                for(var i=0; i<quantityList.length; i++)
                    Qty = Qty+quantityList[i];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }*/
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f3Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f3Quantity", 0);
        }
        
    },
    
    addProductsf4 : function(component, event, helper){
        var productId = component.get("v.productId");
        var quantity = component.get("v.f4Quantity");
        var QtyMinus = 0;
        var limitQty = 0;
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var orderLimit = component.get("v.orderLimit");
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.get("v.carType"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var productList = component.get("v.productList");
            var quantityList = component.get("v.f4quantityList");
            var demomapFirm = component.get("v.demofmap4");
            var index = productList.indexOf(productId);
            if(index != -1)
            {
                QtyMinus = quantityList[index];
            }
            /*var Qty = 0-QtyMinus+quantity;
            if(typeof quantityList !== 'undefined' && quantityList.length > 0)
                for(var i=0; i<quantityList.length; i++)
                    Qty = Qty+quantityList[i];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }*/
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f4Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f4Quantity", 0);
        }
        
    },
    
    addProductsf5 : function(component, event, helper){
        var productId = component.get("v.productId");
        var quantity = component.get("v.f5Quantity");
        var QtyMinus = 0;
        var limitQty = 0;
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var orderLimit = component.get("v.orderLimit");
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.get("v.carType"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var productList = component.get("v.productList");
            var quantityList = component.get("v.f5quantityList");
            var demomapFirm = component.get("v.demofmap5");
            var index = productList.indexOf(productId);
            if(index != -1)
            {
                QtyMinus = quantityList[index];
            }
            /*var Qty = 0-QtyMinus+quantity;
            if(typeof quantityList !== 'undefined' && quantityList.length > 0)
                for(var i=0; i<quantityList.length; i++)
                    Qty = Qty+quantityList[i];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }*/
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f5Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f5Quantity", 0);
        }
        
    },
    
    addProductsf6 : function(component, event, helper){
        var productId = component.get("v.productId");
        var quantity = component.get("v.f6Quantity");
        var QtyMinus = 0;
        var limitQty = 0;
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var orderLimit = component.get("v.orderLimit");
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.get("v.carType"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var productList = component.get("v.productList");
            var quantityList = component.get("v.f6quantityList");
            var demomapFirm = component.get("v.demofmap6");
            var index = productList.indexOf(productId);
            if(index != -1)
            {
                QtyMinus = quantityList[index];
            }
            /*var Qty = 0-QtyMinus+quantity;
            if(typeof quantityList !== 'undefined' && quantityList.length > 0)
                for(var i=0; i<quantityList.length; i++)
                    Qty = Qty+quantityList[i];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }*/
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f6Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f6Quantity", 0);
        }
        
    },
    
})
({
    doInit : function(component, event, helper){
        if(component.get("v.partdetail.Product2.PSA_Part_Number__c") != undefined){
        	helper.getavailablestockhelper(component, event, helper, component.get("v.partdetail.Product2.PSA_Part_Number__c"), 'transfer');
        }
    },
    
	AddNewBlankRow : function(component, event, helper){
        var compEvent = component.getEvent('AddPartRowEvt');
        compEvent.fire();
    },
    
    removeRow : function(component, event, helper){
        helper.reduceindentvaluehelper(component, event,helper);
        component.getEvent("DeletePartRowEvt").setParams({
            "indexVar" : component.get("v.rowIndex")}).fire();
    },
    
    calctransfervalue : function(component, event, helper) {
		var transqty = component.find("transferqty").get("v.value");   
        var indqty = component.find("indentqty").get("v.value");
        var ndp = component.find("unitndp").get("v.value");
        //var astock = component.find("availablestocktransfer").get("v.value");
        var astock = component.get("v.availabletransferstock");
        /*if(transqty != null && transqty != undefined && transqty != ""){
            component.set("v.oldstock", astock);
            if((transqty > astock) || (indqty < transqty))
                component.find("availablestock").set("v.value", component.get("v.oldstock"));
            else
            	component.find("availablestock").set("v.value", (parseInt(astock)-parseInt(transqty)));        	
        }
        else{
            if(component.get("v.oldstock") != undefined)
            	component.find("availablestock").set("v.value", component.get("v.oldstock"));
        }*/
        var tqty = component.find("transferqty");
        if(transqty != "" && transqty != null && transqty != 0){
        /*$A.util.addClass(tqty,"bordernone");
        $A.util.removeClass(tqty,"bordercolor");*/
        component.set("v.transerrmsg", "");
        }
        else{
        	/*$A.util.removeClass(tqty,"bordernone");
        	$A.util.addClass(tqty,"bordercolor"); */  
            component.set("v.transerrmsg", "Please enter transfer qty");
        }
        component.find("transfervlue").set("v.value", transqty*ndp);        
        var indqty = component.find("indentqty").get("v.value");
        var totalstock = parseInt(astock);// - parseInt(safetystock);
        if((transqty > totalstock) || (transqty > indqty)){
            var disablebtn = component.getEvent("btndisable");
            disablebtn.setParams({
                "listPage" : true
            });
            disablebtn.fire();
            var message = 'Your transfer qty should not be greater than available stock and Indent qty!';
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": message
            });
            toastEvent.fire();
        }
        else{
            var disablebtn = component.getEvent("btndisable");
            disablebtn.setParams({
                "listPage" : false
            });
            disablebtn.fire();            
        }
        
    },
    
    recordChanges : function(component, event, helper) {
        var isrender = true;
        var partname = component.get("v.selectedLookUpRecord.PSA_Product__r.PSA_Part_Number__c");
		var partdesc = component.get("v.selectedLookUpRecord.PSA_Product__r.PSA_Part_Description__c");        
        if(partname != null && partname != undefined && partname != ""){
            component.set("v.partnumbererrmsg", "");
            component.set("v.partdescerrmsg", "");
        }
        component.set("v.descrvisible", false);
        var existingparts = component.get("v.partlist");
        var size = existingparts.length;
        for(var x in existingparts ){         	
            if(existingparts[x].PSA_Product_Part_Number__c==partname){
                if(partname != null){
                    var msg = 'This part '+partname+ ' already added into lineitem!'
                    helper.showToast(component,event,msg,'Error');
                    component.getEvent("DeletePartRowEvt").setParams({
                        "indexVar" : size-1}).fire();}
            }
            else{
                if(partname == undefined && partname == null){                    
                    component.set("v.descrvisible", true);
                    var indentqty = component.find("indentqty").set("v.value", "");
                    var indentval = component.find("indentvalue").set("v.value", "");
                }                
                helper.getndpvalue(component, event,helper);  
                helper.getavailablestockhelper(component, event, helper, partname, 'pname');
            }            
        }
        component.set("v.partdetail.PSA_Product_Part_Number__c", partname); 
        component.set("v.partdetail.PSA_BinTransfer_Reason__c", partdesc);
    },
    
    descChanges : function(component, event,helper) {
        var partdesc = component.get("v.selectedLookUpRecordDesc.PSA_Product__r.PSA_Part_Description__c");
        var partname = component.get("v.selectedLookUpRecordDesc.PSA_Product__r.PSA_Part_Number__c");
        if(partdesc != null && partdesc != undefined && partdesc != ""){
            component.set("v.partnumbererrmsg", "");
            component.set("v.partdescerrmsg", "");
        }
        component.set("v.PartNumbr", false);
        var existingparts = component.get("v.partlist");
        var size = existingparts.length;
        for(var x in existingparts ){         	
            if(existingparts[x].PSA_BinTransfer_Reason__c==partdesc){
                if(partdesc != null){
                    var msg = 'This part '+partdesc+ ' already added into lineitem!'
                    helper.showToast(component,event,msg,'Error');
                    component.getEvent("DeletePartRowEvt").setParams({
                        "indexVar" : size-1}).fire();}
            }
            else{
                if(partdesc == undefined && partdesc == null){
                    component.set("v.PartNumbr", true); 
                    var indentqty = component.find("indentqty").set("v.value", "");
                    var indentval = component.find("indentvalue").set("v.value", "");
                }
                helper.getndpvalue(component, event,helper); 
                helper.getavailablestockhelper(component, event, helper, partname, 'pdesc');
            }            
        }
        component.set("v.partdetail.PSA_BinTransfer_Reason__c", partdesc);
        component.set("v.partdetail.PSA_Product_Part_Number__c", partname);
    },    
    
    calcindentvalue : function(component, event,helper) {
        helper.calcindentvaluehelper(component, event,helper);
    },
    
    clearfields : function(component, event,helper) {        
        component.getEvent("DeletePartRowEvt").setParams({
            "indexVar" : component.get("v.rowIndex")}).fire();
        component.set("v.partdetail", null);
    },
    
    Savestocktransfer : function(component, event,helper) {
        var isvalid = true;
        var indentqty = component.find("indentqty").get("v.value");
        var indentval = component.find("indentvalue").get("v.value");
        var transferqty = component.find("transferqty").get("v.value");
        var transferval;
        if(transferqty == "-"){
            transferqty = 0;
        	transferval = 0;            
        }
        else{
            if(transferqty == undefined || indentqty == null || indentqty == ""){
                var tqty = component.find("transferqty");
                /*$A.util.removeClass(tqty,"bordernone");
                $A.util.addClass(tqty,"bordercolor");*/
                component.set("v.transerrmsg", "Please enter transfer qty");
                isvalid = false;
            }
            transferqty = component.find("transferqty").get("v.value");
        	transferval = component.find("transfervlue").get("v.value");            
        }
        
        var unitpriceval = component.find("unitndp").get("v.value");
        var quantity;
        var partnumber;
        var prodid;
        if(partnumber == undefined){
        	partnumber = component.get("v.selectedLookUpRecord.PSA_Product__r.PSA_Part_Number__c");
            prodid = component.get("v.selectedLookUpRecord.PSA_Product__c");
            if(prodid == undefined || prodid == null){
                //prodid = component.get("v.productid");
                prodid=component.get("v.selectedLookUpRecordDesc.PSA_Product__c");
            }
        }
        var partnumvalidation = component.get("v.selectedLookUpRecord.PSA_Product__r.PSA_Part_Number__c");
        var partdescvalidation = component.get("v.selectedLookUpRecordDesc.PSA_Product__r.PSA_Part_Number__c");
        if(partnumvalidation == undefined || partnumvalidation == null || partnumvalidation == ""){
			component.set("v.partnumbererrmsg", "Please select partnumber");
            if(transferqty == "-" && (partdescvalidation == undefined || partdescvalidation == null || partdescvalidation == ""))
            	isvalid = false;
        }
        else{
            quantity = component.find("availablestock").get("v.value");
            component.set("v.partnumbererrmsg", "");
        }
        if(partdescvalidation == undefined || partdescvalidation == null || partdescvalidation == ""){
			component.set("v.partdescerrmsg", "Please select partdescription");
            if(transferqty == "-" && (partnumvalidation == undefined || partnumvalidation == null || partnumvalidation == ""))
                isvalid = false;
        } 
        else{
            quantity = component.find("availablestockdesc").get("v.value");
            component.set("v.partdescerrmsg", "");
        }
        if(indentqty == undefined || indentqty == null || indentqty == ""){
            var iqty = component.find("indentqty");
            /*$A.util.removeClass(iqty,"bordernone");
            $A.util.addClass(iqty,"bordercolor");*/
            component.set("v.indenterrmsg", "Please enter indent qty");
            isvalid = false;
        }
        if(prodid == null || prodid == undefined || prodid == "")
            prodid = component.get("v.partdetail.Product2Id");
        
        var singlebin = [];
        singlebin.push({
            'sobjectType': 'OrderItem',
            'PSA_Indent_Qty__c': indentqty,
            'PSA_Indent_Value__c': indentval,
            'PSA_Part_Number__c' : partnumber,
            'PSA_Transfer_Qty__c' : transferqty,
            'PSA_Transfer_Value__c' : transferval,
            'UnitPrice' : unitpriceval,
            'Quantity' : indentqty,
            'Product2Id' : prodid
        });   
        
        var transferstocksindenttoparent = component.getEvent("stockrequestevent");
        transferstocksindenttoparent.setParams({
            "ordlist" : singlebin,
            "listPage" : isvalid
        });
        transferstocksindenttoparent.fire();
    },
    
     preventnumbers : function(component, event, helper){
        var a = event.getSource();
		var id = a.getLocalId();
        var charCode = event.getParams().keyCode; 
        if ((charCode > 64 && charCode < 91) || (charCode > 8 && charCode < 27) ||  (charCode > 33 && charCode < 48) ){
            
        }    
        else{
            component.find(id).set("v.value", '');
        }           
    },
    
    preventalphabets : function(component, event, helper){
        var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
    }
})
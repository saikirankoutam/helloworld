({
    doInit : function(component, event, helper) {
        var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        var today = new Date();
        var curryear = today.getFullYear();
        var halfyear = curryear.toString().slice(2);
        component.set("v.yearSelected", curryear);
        component.set("v.fMonthhalf1", 'Jan');
        component.set("v.fMonthhalf2", 'Feb');
        component.set("v.fMonthhalf3", 'Mar');
        component.set("v.fMonthhalf4", 'Apr');
        component.set("v.fMonthhalf5", 'May');
        component.set("v.fMonthhalf6", 'Jun');
        component.set("v.fMonthhalf7", 'Jul');
        component.set("v.fMonthhalf8", 'Aug');
        component.set("v.fMonthhalf9", 'Sept');
        component.set("v.fMonthhalf10", 'Oct');
        component.set("v.fMonthhalf11", 'Nov');
        component.set("v.fMonthhalf12", 'Dec');
        component.set("v.fyearhalf1", halfyear);
        component.set("v.fyearhalf2", halfyear);
        component.set("v.fyearhalf3", halfyear);
        component.set("v.fyearhalf4", halfyear);
        component.set("v.fyearhalf5", halfyear);
        component.set("v.fyearhalf6", halfyear);
        component.set("v.fyearhalf7", halfyear);
        component.set("v.fyearhalf8", halfyear);
        component.set("v.fyearhalf9", halfyear);
        component.set("v.fyearhalf10",halfyear);
        component.set("v.fyearhalf11", halfyear);
        component.set("v.fyearhalf12", halfyear);
        helper.showObjectivedetails(component, event, helper);
        helper.getAccountRegionInfo(component,event, helper);
        helper.getYears(component,event, helper);
      
     },
    getSelectedYear : function(component, event, helper) {
      //  component.set("v.spinner", true);
        var selectyr = component.find("yearselect").get("v.value");
        component.set("v.yearSelected", selectyr);
        var halfyear = selectyr.toString().slice(2);
        component.set("v.fyearhalf1", halfyear);
        component.set("v.fyearhalf2", halfyear);
        component.set("v.fyearhalf3", halfyear);
        component.set("v.fyearhalf4", halfyear);
        component.set("v.fyearhalf5", halfyear);
        component.set("v.fyearhalf6", halfyear);
        component.set("v.fyearhalf7", halfyear);
        component.set("v.fyearhalf8", halfyear);
        component.set("v.fyearhalf9", halfyear);
        component.set("v.fyearhalf10",halfyear);
        component.set("v.fyearhalf11", halfyear);
        component.set("v.fyearhalf12", halfyear);
        helper.showObjectivedetails(component, event, helper);
        
    },

    getStatesList : function(component, event, helper) {
         component.set("v.spinner", true);
         component.set('v.norecords', false);
         component.set("v.accountCities",[]);
         component.set("v.Dealercities",[]);
        var region = component.find("regionName").get("v.value");
        if(region != 'ALL'){
        var action = component.get("c.getAccountBillingState");
        action.setParams({ 
            "region" : region
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State **** "+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();            
                component.set("v.accountStates", records);
                if(region == 'ALL'){
                    component.find("stateName").set("v.value","ALL");
                }
                component.find("cityname").set("v.value","ALL");
                component.find("dealerName").set("v.value","ALL");
            }
        });
       
        $A.enqueueAction(action);
             }else{	
                   component.set("v.accountStates","");
                   component.set("v.accountCities","");
                   component.set("v.Dealercities","");
                   
             }
        helper.showObjectivedetails(component, event, helper);  
    },
    getCitiesList : function(component, event, helper) {
         component.set("v.spinner", true);
        component.set('v.norecords', false);
        var region = component.find("regionName").get("v.value");
        var state = component.find("stateName").get("v.value");  
        var action = component.get("c.getAccountBillingCity");
        action.setParams({ 
            "region" : region,
            "state"  : state
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State **** "+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();            
                component.set("v.accountCities", records);
                component.find("dealerName").set("v.value","ALL");
            }
        });
        $A.enqueueAction(action);
        helper.showObjectivedetails(component, event, helper);  
    }, 
       
    getDealerList : function(component, event, helper) {
         component.set("v.spinner", true);
        component.set('v.norecords', false);
          var region = component.find("regionName").get("v.value");
        var state = component.find("stateName").get("v.value");  
        var city = component.find("cityname").get("v.value");
        var action = component.get("c.getAccountList");
        action.setParams({ 
            "region" :region,
            "state"  : state,
            "cityval" : city
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State **** "+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();            
                component.set("v.Dealercities", records);
            }
        });
        $A.enqueueAction(action);
          helper.showObjectivedetails(component, event, helper);
    },
    getDealerRecords: function(component, event, helper) {
     helper.showObjectivedetails(component, event, helper);
    },
    opentechForm : function(component, event, helper) {
        
         document.getElementById("myModal").style.display = "block";
    },
  
    closeform : function(component, event, helper) {
        component.set("v.errormessage","");
         document.getElementById("myModal").style.display ="none";
         var childCmp = component.find("uplaodfileattach");
         childCmp.closevalue();  
    },
    
    
     next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        debugger;
        var objectivelist = component.get("v.objectiveReclist");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = objectivelist.slice(end+1,end+pageSize+1);//Slicing List as page number
        start = start + pageSize;
        end = end + pageSize;
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, helper,parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
         /*---Pagination previous Button Click--*/
        var objectivelist = component.get("v.objectiveReclist");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = objectivelist.slice(start-pageSize,start);//Slicing List as page number
        start = start - pageSize;
        end = end - pageSize;
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, helper,parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
        debugger;
         /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var accountList = component.get("v.objectiveReclist");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+pageSize-1;
        var paginationList = accountList.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, helper,parseInt(pagenum));//Reset Pagination
    },
     closeModel: function(component, event, helper) {
        //  component.set("v.spinner", true);
         document.getElementById("myModal").style.display = "none";
         document.getElementById("forecastVolModal").style.display = "none";
       
         var selectYear = component.find("yearselect").get("v.value");
         if(selectYear == "option"){
              var today = new Date();
          selectYear =today.getFullYear();
         }
         component.set("v.yearSelected", selectYear);
         helper.showObjectivedetails(component, event, helper);
         var status = event.getParam("CNFStatus");
        if(status == "uploaded"){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Success!",
                "message": "Uploaded Successfully",
                "type": "success"
            });
            toastEvent.fire();
        }
   
    },
    
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.showObjectivedetails(component, event, helper);
    },
    
    openforecastVol: function(component, event, helper){
        document.getElementById("forecastVolModal").style.display = "block";
    },
    
    closeforecastVol : function(component, event, helper) {
        component.set("v.errormessage","");
         document.getElementById("forecastVolModal").style.display ="none";
    },
})
({
    createEmptyRow : function(component, event) {debugger;
		var RowItemList = component.get("v.paymentrowslist");
        RowItemList.push({
            'sobjectType ': 'PSA_Payment__c',
            'PSA_Particulars__c':'',
            'PSA_Mode__c':'',
            'Payment_Amount__c':'',
            'PSA_Balance_Amount__c':'',
            'Payment_Date__c':'',
            'PSA_Approved_by_Accounts__c':'',
            'PSA_Remarks__c':'',
            'PSA_PaymentSerialNo__c':''
            //'id':''
        });
        component.set("v.paymentrowslist", RowItemList);
	},
    
	paymentinfo : function(component, event){
        var action = component.get("c.fetchpayment");
        action.setParams({
            "bookingorderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();                
                console.log('payment Info >>>>'+JSON.stringify(storeResponse));
                component.set("v.PaymentList", storeResponse);
                var len = storeResponse.length;
                component.set("v.rowno", len);
                if(len == 0){
                    component.set("v.visiblechild", true); 
                    component.set("v.editbtndis", true);
                    this.createEmptyRow(component, event);  
                }
                else{
                    //component.set("v.submitbtndis", true);
                    component.set("v.disablechkbox", true);
                }
                var totalamt = 0;
                 var totalcreditAmount = 0;
                 var total=0;
                for(var i=0; i<len; i++){
                    if(storeResponse[i].PSA_Particulars__c !='Credit Note'){
                    	totalamt += storeResponse[i].Payment_Amount__c;
                    }else{
                        totalcreditAmount += storeResponse[i].Payment_Amount__c;
                        
                    }
                }
                 total=totalamt-totalcreditAmount;
                component.set("v.totalamtreceived", total);
            }
        });
        $A.enqueueAction(action);
    },        
    
    saverequest:function(component,event){
        debugger;
     /*   var sellingpriceval = component.get("v.sellingprice");
        var particular =  component.get("v.selectedparticular");
        var mode =  component.get("v.selectedmode");
        var amtrec = component.get("v.amountreceived");
        var balamt = component.get("v.balanceamount");
        var paydate = component.get("v.paymentdate");
        var apprcheckedval = component.get("v.Approvedbyaccounts");
        var remarks = component.get("v.remarks");*/
        var paymentrecords = {            
            "PSA_Approve_Vehicle_Invoice__c" : component.get("v.approvevehcile"),
            "PSA_Approve_Accessory_Invoice__c" : component.get("v.approveaccessory"),
            "PSA_Approve_for_Insurance__c" : component.get("v.approveinsurance"),
            "Approve_for_Registration__c" : component.get("v.approveregistration")
        };
        
        
         var x;
        var paymentrecords=component.get('v.paymentrowslist');
        var balanceamount=component.get('v.totalbalanceamount');
        var total=0;
        
        for(x in paymentrecords){
            if(paymentrecords[x].PSA_Particulars__c=='Booking Amount' ||paymentrecords[x].PSA_Particulars__c=='Outstanding Amount' || paymentrecords[x].PSA_Particulars__c=='Vehicle Finance' || paymentrecords[x].PSA_Particulars__c=='Down Payment' || paymentrecords[x].PSA_Particulars__c=='Trade-In Price' ){
               total+=paymentrecords[x].Payment_Amount__c;
            } 
            
        }
        if(balanceamount>total || balanceamount==total ){
        var action = component.get("c.createpaymentmethod");        
        action.setParams({
            "mapofpaymentrec" : component.get('v.paymentrowslist'),
            "oid" : component.get("v.orderId"),
            "approvevehicle" : component.get("v.approvevehcile"),
            "approveaccess" : component.get("v.approveaccessory"),
            "approveinsurence" : component.get("v.approveinsurance"),
            "approvereg" : component.get("v.approveregistration") 
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "message": "Payment Created Successfully!",
                    "type": "success"
                });
                toastEvent.fire();                               
                this.paymentinfo(component, event);
                this.Createpayment(component, event);
                component.set("v.newpaymentCreation", false);
                component.set("v.paymentlistview", true);                 
                //component.set("v.submitbtndis", true);
                component.set("v.editbtndis", false);
                component.set("v.showbackbtn", false);
                component.set("v.disablechkbox", true);
                component.set("v.paymentrowslist", []);
            }
            else{
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "message": "Payment failed!",
                    "type": "error"
                });
                toastEvent.fire();  
            }
            /*var eventListPage = component.getEvent("displayListPageParts");
            eventListPage.setParams({"listPage" : true });
            eventListPage.fire();*/
        });
        $A.enqueueAction(action);
        }else{
             var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "message": "Please enter only due amount!",
                    "type": "error"
                });
                toastEvent.fire();  
            
        }
    },
    
    Createpayment : function(component, event) {  
        debugger;
        component.set("v.selectedparticular", "Select");
        component.set("v.selectedmode", "Select");
		component.set("v.amountreceived", "");
        component.set("v.paymentdate", "");
        component.set("v.Approvedbyaccounts", false);
        component.set("v.remarks", "");
        component.set("v.newpaymentCreation", true);
        component.set("v.paymentlistview", false);
        var action = component.get("c.fetchpaymentbalance");
        action.setParams({
            "bookingorderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                var strarr = storeResponse.split(',');
                if(strarr[0] == "" || strarr[0] == undefined || strarr[0] == 0.0){
					component.set("v.sellingprice", strarr[5]);
                    var sellingprice = component.get("v.sellingprice");
					component.set("v.balanceamount", 0);
                    component.set("v.totalbalanceamount", 0);
                   // component.find("submit").set("v.disabled", true);
				}
				else{
                    component.set("v.sellingprice", strarr[5]);
                    var sellingprice = component.get("v.sellingprice");
					component.set("v.balanceamount", strarr[0]);
                    component.set("v.totalbalanceamount", strarr[0]);
				}
                if(strarr[1] == "true")
                	component.set("v.approvevehcile", true);
                if(strarr[2] == "true")
                	component.set("v.approveaccessory", true);
                if(strarr[3] == "true")
                	component.set("v.approveinsurance", true);
                if(strarr[4] == "true")
                	component.set("v.approveregistration", true);
            }
        });
        $A.enqueueAction(action);
    },
    checkBookingStatus : function(component, event){
    debugger;
         var bookingid= component.get("v.orderId");
         var action = component.get("c.checkBookingStatus");
         
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
           
            if (state === "SUCCESS") 
            {
                var storeResponse = response.getReturnValue();
                
                if(storeResponse){
                component.set("v.editbtndis",true);
                component.set("v.submitbtndis",true);
                }
            }
        });
        $A.enqueueAction(action);	    
	 
},
    checkVDNStatus : function(component, event){
    
         var bookingid= component.get("v.orderId");
         var action = component.get("c.checkStatusVDN");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.editbtndis",true);
                component.set("v.submitbtndis",true);
                }
            }
        });
        $A.enqueueAction(action);	    
	 
},
    errortoast : function(component, event, helper, msg){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": msg,
            "type": "error"
        });
        toastEvent.fire(); 
    }
})
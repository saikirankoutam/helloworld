({
    doInit : function(component, event, helper) {
        var reportid = $A.get("$Label.c.PSA_GRN_Register"); 
        var reporturl;
        reporturl = '/dmsindia/s/report/'+reportid;    
        component.set("v.reportlink",reporturl);
    }
})
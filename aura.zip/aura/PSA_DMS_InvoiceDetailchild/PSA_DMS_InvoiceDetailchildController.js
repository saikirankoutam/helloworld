({
    doInit : function(component, event, helper) {
        var rec = component.find("recqty");
        $A.util.removeClass(rec,"bordernone");
        component.find("shortqty").set("v.value", "");
        component.find("excessqty").set("v.value", "");
        if(component.get("v.type") != "Stock" && component.get("v.type") != "Co-Dealer"){
        	component.find("recqty").set("v.value", "");
        }
        else{
            var transqty = component.find("recqty").get("v.value");
            var indqty = component.find("indqty").get("v.value");  
            if(transqty == null){
                component.find("excessqty").set("v.value", "");
                component.find("shortqty").set("v.value", "");
            }
            if(transqty != undefined && transqty != null){            
                if(indqty < transqty){
                    var excessqty = transqty - indqty;
                    component.find("excessqty").set("v.value", excessqty);
                    component.find("shortqty").set("v.value", 0);
                }
                else if(indqty > transqty){
                    var shortqty = indqty - transqty;
                    component.find("shortqty").set("v.value", shortqty);  
                    component.find("excessqty").set("v.value", 0);
                }
                    else{
                        component.find("shortqty").set("v.value", 0);
                        component.find("excessqty").set("v.value", 0);
                    }
            }
            component.find("dmgqty").set("v.value", "");
        }
    },
    
	calctotalinvoice : function(component, event, helper) {
        var recqtyval = component.find("recqty").get("v.value");
        var invoiceqty = component.find("invqty").get("v.value");
        if(recqtyval == null){
            component.find("excessqty").set("v.value", "");
            component.find("shortqty").set("v.value", "");
        }
        if(recqtyval != undefined && recqtyval != null){
            /*var rec = component.find("recqty");
            $A.util.addClass(rec,"bordernone");
            $A.util.removeClass(rec,"bordercolor");*/
            component.set("v.recqtyErrmsg", "");
            if(invoiceqty < recqtyval){
                var excessqty = recqtyval - invoiceqty;
                component.find("excessqty").set("v.value", excessqty);
                component.find("shortqty").set("v.value", 0);
            }
            else if(invoiceqty > recqtyval){
                var shortqty = invoiceqty - recqtyval;
                component.find("shortqty").set("v.value", shortqty);  
                component.find("excessqty").set("v.value", 0);
            }
            else{
                component.find("shortqty").set("v.value", 0);
                component.find("excessqty").set("v.value", 0);
            }
        }
        var btndis = component.getEvent("disablesubmitbtn");   
        btndis.setParams({"listPage" : false});
        btndis.fire();
        
	},
    
    calcshortagereceiveqty : function(component, event, helper) {
		/*var recqtyval = component.find("recqty").get("v.value");       
        var shortqty = component.find("shortqty").get("v.value");
        var damageqty = component.find("dmgqty").get("v.value");
        var invoiceqty = component.find("invqty").get("v.value");        
        if(invoiceqty >= (recqtyval+damageqty)){
            var shortqty = invoiceqty - (recqtyval+damageqty);
        	component.find("shortqty").set("v.value", shortqty);
            component.find("excessqty").set("v.value", 0);
        }        
        if(invoiceqty == damageqty){
        	component.find("shortqty").set("v.value", 0);
			component.find("recqty").set("v.value", 0);
        }
        if(invoiceqty < damageqty){
        	component.find("shortqty").set("v.value", 0);
			component.find("recqty").set("v.value", 0);
            component.find("dmgqty").set("v.value", invoiceqty);
        }
        if(invoiceqty < (recqtyval+damageqty)){
            component.find("excessqty").set("v.value", ((recqtyval+damageqty)-invoiceqty));
            component.find("shortqty").set("v.value", 0); 
            component.find("dmgqty").set("v.value", (damageqty - parseInt(component.find("excessqty").get("v.value"))));
        }
        var btndis = component.getEvent("disablesubmitbtn");   
        btndis.setParams({"listPage" : false});
        btndis.fire();*/
	},
    
    SavePartreceipt : function(component, event, helper){            
        var partnum = component.find("partnum").get("v.value");
        var recqty = component.find("recqty").get("v.value");
        var shortqty = component.find("shortqty").get("v.value");
        var damageqty = component.find("dmgqty").get("v.value");
        var excessqty = component.find("excessqty").get("v.value");
        var isvalid = true;
        if(recqty == undefined || recqty == null || recqty == ""){
            var rec = component.find("recqty");
            /*$A.util.removeClass(rec,"bordernone");
            $A.util.addClass(rec,"bordercolor");*/
            component.set("v.recqtyErrmsg", "Please enter received qty");
            isvalid = false;
        }
        var singlebin = [];
        singlebin.push({
            'sobjectType': 'PSA_Dealer_Inventory__c',
            'Part_Number__c': partnum,
            'Received_Parts__c': recqty,
            'Shortage_Parts__c': shortqty,
            'Damaged_Parts__c': damageqty,
            'Excess_Parts__c': excessqty
        });   
        
        var transferPartreceipttoparent = component.getEvent("partreceiptevent");
        transferPartreceipttoparent.setParams({
            "ordlist" : singlebin,
            "listPage" : isvalid
        });
        transferPartreceipttoparent.fire();
	},
    
    clearfields : function(component, event, helper){
		component.set("v.item", null);        
    },
    
    btndisable : function(component, event, helper){
		var btndis = component.getEvent("disablesubmitbtn");   
        btndis.setParams({"listPage" : false});
        btndis.fire();
    },
    
    preventalphabets : function(component, event, helper){
        var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
    }
    
})
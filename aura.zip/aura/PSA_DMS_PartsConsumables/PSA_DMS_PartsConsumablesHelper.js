({
	getcasenumbersfunc : function(component, event) {
		var action = component.get("c.getcasenumbers");   
        action.setParams({
            "wokorderid" : component.get("v.repairOrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
               component.set('v.lstcasenumbers', response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
	},
    getwolineitemsfunc : function(component, event, caseid){
        debugger;
        var action = component.get("c.getwolineitems");
        action.setParams({
            "caseid" :  caseid,
            "workshopreturn" : false
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
               	component.set("v.lstwolineitems", response.getReturnValue());
               // var cmpTarget = component.find('issuebtn');
                var genpick = component.find('generatepicklistbtn');
                if(component.get("v.lstwolineitems[0].ispartissued") == true){
                    var issuenotevalue = component.get("v.lstwolineitems[0].issuenoteno");
                    component.set("v.remarks", component.get("v.lstwolineitems[0].remarks"));
                    component.set("v.workshopissueno", issuenotevalue);
                    component.find('remarksid').set("v.disabled", true);
                    component.find('issuebtn').set("v.disabled", true);
                     genpick.set("v.disabled", false);
                    
                    
                    //component.find().set("v.disabled", true);
                }
                else if(component.get("v.selectedrequisition") == "-- None --") {
                    component.find('remarksid').set("v.disabled", true);
                    component.find('issuebtn').set("v.disabled", true);
                     genpick.set("v.disabled", true);
                }
                else{
                   
                     component.find('remarksid').set("v.disabled", false);
                     component.find('issuebtn').set("v.disabled", false);
                   //  genpick.set("v.disabled", true);
                    component.set("v.remarks","");
                    component.set("v.workshopissueno", "");
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    Savepartsconsumablesrecords : function(component, event){        
        var lstoflineitems = component.get("v.Finalpartsconsumables");
        if(lstoflineitems.length != 0){
            component.set("v.spinner", true);
            var action = component.get('c.updaterequistionqty');
            action.setParams({
                "wolineitems": lstoflineitems,
                "casenum" : component.get("v.selectedrequisition"),
                "caseremarks" : component.get("v.remarks")
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                    //var cmpTarget = component.find('issuebtn');
                    //$A.util.addClass(cmpTarget, 'disablebtn');
                    component.find('remarksid').set("v.disabled", true);
                    component.find('issuebtn').set("v.disabled", true);
                    component.set("v.spinner", false);                
                    var workshopissueno =response.getReturnValue();
                    component.set("v.workshopissueno", workshopissueno);
                    var cid = component.find("requisitionId").get("v.value");
        			this.getwolineitemsfunc(component, event, cid);
                    var message = 'Parts Issued Successfully!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "success",
                        "message": message
                    });
                    toastEvent.fire();                
                }
                else{
                    component.set("v.spinner", false);
                    var message = 'Parts Issue Failed!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "message": message
                    });
                    toastEvent.fire();
                }
            });
            $A.enqueueAction(action);
        }
        else{
            var message = 'Please select atleast one part to issue!';
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": message
            });
            toastEvent.fire(); 
        }
    },
    
    validatepartsconsumablesForm : function(component, event, helper){
        var isValid = true;        
        var remarks = component.find("remarksid").get("v.value");
        var requistionval = component.find("requisitionId").get("v.value");
        
        component.set("v.remarksErrmsg",'');
        $A.util.removeClass(remarks,"disp-block");
        $A.util.addClass(remarks,"disp-none");  
        
        if(requistionval == '-- None --' || requistionval == 'undefined' || requistionval == '' || requistionval == null){
            isValid = false;
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": "Please select requisition no to issue"
            });
            toastEvent.fire();
        }
        else{
            isValid = true;
        }
        
        if(remarks == 'undefined' || remarks == '' || remarks == null){
            isValid = false;
            component.set("v.remarksErrmsg",'Required field');
            $A.util.removeClass(remarks,"disp-none");
            $A.util.addClass(remarks,"disp-block");
        }
        else{
            isValid = true;
            component.set("v.remarksErrmsg",'');
            $A.util.addClass(remarks,"disp-none");
            $A.util.removeClass(remarks,"disp-block");
        }
        return isValid;
         
     },
})
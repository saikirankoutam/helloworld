({
    doInit: function (component, event,helper) {
        helper.fetchPickLists(component, event);
        //  helper.getmaingrouppicklist(component, event);
        var dealerinput=component.get('v.dispartnumber');
        var RSMinput=component.get('v.disallfields');
        if(dealerinput)
            helper.createObjectData(component, event);
        if(RSMinput)
            helper.casedetailrecord(component, event);
        
    },
    redirecttolisview : function(component, event, helper){
        component.set("v.newpartrequest", false);
        var eventListPage = component.getEvent("displayListPageParts");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
    
    getGSTAmount : function(component, event, helper){
        var rpu = component.find("rateperUnit").get("v.value");
        var gstper = component.find("IGST").get("v.value");
        if(rpu != null || gstper != null){
            var gstamt = (rpu*gstper)/100;
            var finalamt = gstamt;
        }
        component.find("CGST").set("v.value", finalamt);
    },
    
    getsubgroupValues : function(component, event, helper){     
        var selmaingroup = component.find("maingroup").get("v.value");
        var action = component.get("c.getsubgroup");
        action.setParams({ 
            "selgroup" : selmaingroup,
        });
        action.setCallback(this, function(a) {
            component.set("v.subgrouplist", a.getReturnValue());           
        });
        $A.enqueueAction(action);	
    },
    
    createrequest:function(component,event,helper){
        
        var caserec=component.get('v.caselist');
        alert(caserec[0].PSA_Parts_Description__c);
        var action = component.get("c.localpartrequest");
        action.setParams({ 
            "caserecord" : caserec
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                alert('hiii');
                //   var Message= $A.get("$Label.c.Local_Part_Request");
                //    this.showSuccessToast(component,event,Message);  
            }
        });
        $A.enqueueAction(action);	
        
        // if(helper.validatePartForm(component)) {
        // helper.saverequest(component,event)  
        // }
    }
})
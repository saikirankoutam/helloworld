({
    validatePartForm : function(component, event, helper){
        debugger;
        var isValid = true;
         var  caserec=component.get('v.caseInfo');
        var cgst=caserec.PSA_CGST__c;
         var sgst=caserec.PSA_SGST__c;
         var ndp=caserec.PSA_NDP__c;
        var listprice=caserec.PSA_Rate_per_Unit__c;
         component.set("v.cgstErrMsg",'');
         component.set("v.sgstErrMsg",'');
        component.set("v.ndpErrmsg",'');
         component.set("v.listErrmsg",'');
        if(cgst==null || cgst=='' || cgst=='undefined')
        {
          isValid=false;
            component.set("v.cgstErrMsg",'This is a required field');
        } 
         if(sgst==null || sgst=='' || sgst=='undefined')
        {
          isValid=false;
            component.set("v.sgstErrMsg",'This is a required field');
        }
        if(ndp==null || ndp=='' || ndp=='undefined')
        {
          isValid=false;
            component.set("v.ndpErrmsg",'This is a required field');
        }
         if(listprice==null || listprice=='' || listprice=='undefined')
        {
          isValid=false;
            component.set("v.listErrmsg",'This is a required field');
        }
     // var  CGST =caserec.PSA_CGST__c;
        var partDesc = component.find("partdescription").get("v.value");
        
        var hsnCde = component.find("HSNcode").get("v.value");
        var catgry = component.find("partcategory").get("v.value");
        var ptype = component.find("parttype").get("v.value");
        var uomsale = component.find("UOMSale").get("v.value");
          var supname = component.find("vendorname").get("v.value");
        var moq1 = component.find("moq").get("v.value");
        var loc = component.find("Location").get("v.value");
        var UOMPurchase = component.find("UOMPurchase").get("v.value");
        
        var Multiplicationfactor = component.find("Multiplicationfactor").get("v.value");
        component.set("v.partsdescriptionErrMsg",'');
        $A.util.removeClass(partDesc,"disp-block");
        $A.util.addClass(partDesc,"disp-none");
        component.set("v.hsncodeErrMsg",'');
        $A.util.removeClass(hsnCde,"disp-block");
        $A.util.addClass(hsnCde,"disp-none");
         component.set("v.partctgryErrMsg",'');
        $A.util.removeClass(catgry,"disp-block");
        $A.util.addClass(catgry,"disp-none");
        component.set("v.parttypeErrMsg",'');
        $A.util.removeClass(ptype,"disp-block");
        $A.util.addClass(ptype,"disp-none");
        component.set("v.saleErrormsg",'');
        $A.util.removeClass(uomsale,"disp-block");
        $A.util.addClass(uomsale,"disp-none");
         component.set("v.supnameErrormsg",'');
        $A.util.removeClass(supname,"disp-block");
        $A.util.addClass(supname,"disp-none");
        component.set("v.moqErrormsg",'');
        $A.util.removeClass(moq1,"disp-block");
        $A.util.addClass(moq1,"disp-none");
        component.set("v.locationErrmsg",'');
        $A.util.removeClass(loc,"disp-block");
        $A.util.addClass(loc,"disp-none");
       component.set("v.UOMPurchaseErrmsg",'');
        $A.util.removeClass(UOMPurchase,"disp-block");
        $A.util.addClass(UOMPurchase,"disp-none");
         component.set("v.MulfactorErrmsg",'');
        $A.util.removeClass(Multiplicationfactor,"disp-block");
        $A.util.addClass(Multiplicationfactor,"disp-none");

        if(partDesc == 'undefined'|| partDesc == '' || partDesc == null){
            component.set("v.partsdescriptionErrMsg",'This is a required field');
            $A.util.removeClass(partDesc,"disp-none");
            $A.util.addClass(partDesc,"disp-block");
            isValid = false;
        }
        if(hsnCde == 'undefined'|| hsnCde == '' || hsnCde == null){
            component.set("v.hsncodeErrMsg",'This is a required field');
            $A.util.removeClass(hsnCde,"disp-none");
            $A.util.addClass(hsnCde,"disp-block");
            isValid = false;
        }
        if(catgry == 'undefined'|| catgry == '' || catgry == null){
            component.set("v.partctgryErrMsg",'This is a required field');
            $A.util.removeClass(catgry,"disp-none");
            $A.util.addClass(catgry,"disp-block");
            isValid = false;
        }
        if(ptype == '--None--'|| ptype == '' || ptype == null){
            component.set("v.parttypeErrMsg",'This is a required field');
            $A.util.removeClass(ptype,"disp-none");
            $A.util.addClass(ptype,"disp-block");
            isValid = false;
        }
         if(uomsale == '--None--'|| uomsale == '' || uomsale == null){
            component.set("v.saleErrormsg",'This is a required field');
            $A.util.removeClass(uomsale,"disp-none");
            $A.util.addClass(uomsale,"disp-block");
            isValid = false;
        }
          if(supname == '--None--'|| supname == '' || supname == null){
            component.set("v.supnameErrormsg",'This is a required field');
            $A.util.removeClass(supname,"disp-none");
            $A.util.addClass(supname,"disp-block");
            isValid = false;
        }
        if(moq1 == '--None--'|| moq1 == '' || moq1 == null){
            component.set("v.moqErrormsg",'This is a required field');
            $A.util.removeClass(moq1,"disp-none");
            $A.util.addClass(moq1,"disp-block");
            isValid = false;
        }
        if(loc == '--None--'|| loc == '' || loc == null){
            component.set("v.locationErrmsg",'This is a required field');
            $A.util.removeClass(loc,"disp-none");
            $A.util.addClass(loc,"disp-block");

        }
         if(UOMPurchase == '--None--'|| UOMPurchase == '' || UOMPurchase == null){
            component.set("v.UOMPurchaseErrmsg",'This is a required field');
            $A.util.removeClass(UOMPurchase,"disp-none");
            $A.util.addClass(UOMPurchase,"disp-block");
            isValid = false;
        }
         /* if(Multiplicationfactor == '--None--'|| Multiplicationfactor == '' || Multiplicationfactor == null){
            component.set("v.MulfactorErrmsg",'This is a required field');
            $A.util.removeClass(Multiplicationfactor,"disp-none");
            $A.util.addClass(Multiplicationfactor,"disp-block");
            isValid = false;
        }*/


        
        /*
        if(igstcde == 'undefined'|| igstcde == '' || igstcde == null){
            component.set("v.igstErrMsg",'This is a required field');
            $A.util.removeClass(igstcde,"disp-none");
            $A.util.addClass(igstcde,"disp-block");
            isValid = false;
        }
        
        /*  if(cgstcde == 'undefined'|| cgstcde == '' || cgstcde == null){
            component.set("v.cgstErrMsg",'This is a required field');
            $A.util.removeClass(cgstcde,"disp-none");
            $A.util.addClass(cgstcde,"disp-block");
            isValid = false;
        }
        if(sgstcde == 'undefined'|| sgstcde == '' || sgstcde == null){
            component.set("v.sgstErrMsg",'This is a required field');
            $A.util.removeClass(sgstcde,"disp-none");
            $A.util.addClass(sgstcde,"disp-block");
            isValid = false;
        }
        if(purcpric == 'undefined'|| purcpric == '' || purcpric == null){
            component.set("v.purchasepriceErrMsg",'This is a required field');
            $A.util.removeClass(purcpric,"disp-none");
            $A.util.addClass(purcpric,"disp-block");
            isValid = false;
        }
        if(sellprice == 'undefined'|| sellprice == '' || sellprice == null){
            component.set("v.sellPriceErrorMsg",'This is a required field');
            $A.util.removeClass(sellprice,"disp-none");
            $A.util.addClass(sellprice,"disp-block");
            isValid = false;
        }
        if(qtyperveh == 'undefined'|| qtyperveh == '' || qtyperveh == null){
            component.set("v.qtypervehicleErrmsg",'This is a required field');
            $A.util.removeClass(qtyperveh,"disp-none");
            $A.util.addClass(qtyperveh,"disp-block");
            isValid = false;
        }
        if(saltype == '--None--'|| saltype == '' || saltype == null){
            component.set("v.saletypeErrMsg",'This is a required field');
            $A.util.removeClass(saltype,"disp-none");
            $A.util.addClass(saltype,"disp-block");
            isValid = false;
        }*/
   
        return isValid;
    },
       showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
   showErrorToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "Error"
        });
        toastEvent.fire();  
    },
     getVendorNames : function(component, event){
        debugger;
        var action = component.get("c.fetchvendorAssNames");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.dealerList", storeResponse);
                //component.find("InputSelectDynamic").set("v.options", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
   
})
({
	doInit: function(component, event, helper) {
          
        helper.dealerinfo(component,event,helper);
    },
    Createvendor:function(component,event,helper){
        component.set("v.newvendor", true);
        component.set("v.listvendor", false);
        
    },
    handledisplayListPage : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.listvendor", true);
            component.set("v.newvendor", false);
            component.set("v.newvendorform", false);
        }
    },
    handledisplayListPageView : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.listvendor", true);
            component.set("v.newvendor", false);
            component.set("v.newvendorform", false);
            
        }
    },
    handlemonthlyOrderIdPass : function(component, event, helper) {
        var currentMonthlyOrderId = event.getParam("currentMonthlyOrderId");
        component.set("v.RecordId", currentMonthlyOrderId);
    	component.set("v.newvendorform", true);
        component.set("v.listvendor", false);
        component.set("v.newvendor", false);
       
    },
     vendorsearch: function(component, event, helper) { 
     
        debugger;   
        console.log("" + event.getSource().get("v.value"));
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        component.set("v.invoice",pot) ;  
		 if(pot == null || pot == 'undefined' || pot==""){
            var childCmp = component.find("partsreceiptinvoicesId");
            childCmp.getinvoices();
        }
        else{ 
      
        var action = component.get('c.insuranceSearchName');
        action.setParams({          
            'searchName' : pot
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {               
                var records =response.getReturnValue(); 
                
                component.set("v.vendorlist", records);   
                if(records==null || records == 'undefined' || records=="")
                {
                      component.set("v.noRecords", false);
                }
                else
                    component.set("v.noRecords", true);
                
            }
        });
        $A.enqueueAction(action);
        }
    }, 
        getPartreceiptsCount : function(component, event, helper){
        var receiptscount = event.getParam("Id");
        component.set("v.partSupplierCount",receiptscount);
       
    }
})
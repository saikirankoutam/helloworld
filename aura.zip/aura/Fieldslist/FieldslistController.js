({
	getRelatedFields : function(component, event, helper){
        var params = event.getParam('arguments');
        var objnameparam = params.sobjectname;
        component.set('v.selectedobjectapiname', objnameparam);
        var action = component.get("c.getRelatedFieldNames");
        action.setParams({
            "objname": objnameparam
        	});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS'){
                var list = response.getReturnValue();
                component.set('v.lstfields', list);
                component.set('v.emptylist', false);
            }            
            else if(state === 'ERROR'){
                component.set('v.emptylist', true);
            }
        })
        $A.enqueueAction(action);
    },
    
    exportexcelsheet : function(component, event, helper){       
        var objnameparam = component.get('v.selectedobjectapiname');
        //var selectedobjectname = component.find("objpicklist").get("v.value");
    	var fieldlist;
    	if(objnameparam == ""){
			fieldlist="";
			alert('Please select object from picklist');
    	}else{
    		var fieldlist = component.get("v.lstfields"); 
    	}
        var csv = helper.convertArrayOfObjectsToCSV(component,fieldlist);   
         if (csv == null){return;}         
	     var hiddenElement = document.createElement('a');
          hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
          hiddenElement.target = '_self'; // 
          hiddenElement.download = 'Exportedfields.csv';
          document.body.appendChild(hiddenElement);
    	  hiddenElement.click();        
    }
})
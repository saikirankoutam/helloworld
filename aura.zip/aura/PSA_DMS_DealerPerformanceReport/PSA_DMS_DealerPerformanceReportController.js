({
    doInit : function(component, event, helper) {
        var region = component.find("regionName").get("v.value");
        var state = component.find("stateName").get("v.value");  
        var city = component.find("cityname").get("v.value");
        var dealName = component.find("dealerName").get("v.value");
        var selectYear = component.get("v.yearSelected");
        var action = component.get("c.getrepairorderssummation");  
        action.setParams({
            "valregion": region,
            "valcity": city,
            "valstate": state,
            "varYear": selectYear,
            "varDealname" : dealName,
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.rosummations", response.getReturnValue());
                component.set("v.allro", response.getReturnValue().allro);
            }
        });
        $A.enqueueAction(action);
        
        helper.getAccountRegionmet(component,event, helper);
        helper.getYears(component,event, helper);
    },
    
    getStatesList : function(component, event, helper) {
        component.set("v.spinner", true);
        component.set('v.norecords', false);         
        component.set("v.accountCities",[]);
        component.set("v.Dealercities",[]);
        var region = component.find("regionName").get("v.value");
        if(region != 'ALL'){
            var action = component.get("c.getAccountBillingState");
            action.setParams({ 
                "region" : region
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(" State **** "+state);
                if(state == 'SUCCESS') {
                    var records =response.getReturnValue();            
                    component.set("v.accountStates", records);
                    if(region == 'ALL'){
                        component.find("stateName").set("v.value","ALL");
                    }
                    component.find("cityname").set("v.value","ALL");
                    component.find("dealerName").set("v.value","ALL");
                }
            });
            
            $A.enqueueAction(action);
        }else{	
            component.set("v.accountStates","");
            component.set("v.accountCities","");
            component.set("v.Dealercities","");
            
        }
        helper.showObjectivedetails(component, event, helper);  
    },
    getCitiesList : function(component, event, helper) {
        component.set("v.spinner", true);
        component.set('v.norecords', false);
        var region = component.find("regionName").get("v.value");
        var state = component.find("stateName").get("v.value");  
        var action = component.get("c.getAccountBillingCity");
        action.setParams({ 
            "region" : region,
            "state"  : state
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State **** "+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();            
                component.set("v.accountCities", records);
                component.find("dealerName").set("v.value","ALL");
            }
        });
        $A.enqueueAction(action);
        helper.showObjectivedetails(component, event, helper);  
    }, 
    
    getDealerList : function(component, event, helper) {
        component.set("v.spinner", true);
        component.set('v.norecords', false);
        var region = component.find("regionName").get("v.value");
        var state = component.find("stateName").get("v.value");  
        var city = component.find("cityname").get("v.value");
        var action = component.get("c.getAccountList");
        action.setParams({ 
            "region" :region,
            "state"  : state,
            "cityval" : city
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State **** "+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();            
                component.set("v.Dealercities", records);
            }
        });
        $A.enqueueAction(action);
        helper.showObjectivedetails(component, event, helper);
    },
})
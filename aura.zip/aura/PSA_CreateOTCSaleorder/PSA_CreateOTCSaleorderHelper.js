({
    createObjectData: function(component,event) {
        var RowItemList = component.get("v.PartsSelListEdit");
        RowItemList.push({
            'sobjectType ': 'orderitem',
            'PSA_Part_Number__c':'',
            'Quantity':'',
            'Product2Id':'',
            'Id':'',
            'Description': '',
            'UnitPrice' :'',
            'Net_Dealer_Price__c':'',
            'PSA_OEMCGST__c':'',
            'PSA_OEMIGST__c' :'',
            'PSA_OEMSGST__c' : '',
            'PSA_Discount__c' :'',
            'PSA_Allocated_Qty__c':''
            
        });
        component.set("v.PartsSelListEdit", RowItemList);
    },
    codelarquery: function(component,event) {
        var segment='Released';
        var query='select Id,OrderNumber,PSA_Co_Dealer__r.Name,PSA_Co_Dealer__r.BillingState,PSA_Co_Dealer__r.Dealer_Code__c,(SELECT id,Product2.PSA_Part_Number__c,PSA_Allocated_Qty__c,Product2.PSA_HSN_Code__c,Product2Id,Product2.PSA_Part_Description__c,Product2.QuantityUnitOfMeasure,Net_Dealer_Price__c,Quantity,UnitPrice,PSA_Taxable_Value__c,Product2.PSA_CGST__c,Product2.PSA_SGST__c,Product2.PSA_IGST__c,Product2.PSA_CESS__c,PSA_Total_Order_Value__c,pricebookentryid,PSA_Total_Tax__c,PSA_OEMCGST__c,PSA_OEMSGST__c  FROM OrderItems),Account.BillingCity,Account.Name  from order where co_dealer_otc__c=false and OrderNumber LIKE: searchKey AND PSA_Co_Dealer__c='; 
        var action = component.get("c.Delaerprofile");       
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                var delaerId='\''+ storeResponse + '\'';
                query+= delaerId+' AND  Status= ';
                var segmentstring='\''+ segment + '\'';
                query+=segmentstring+' order by createdDate DESC limit 5';
                component.set('v.codealerquery',query);
                
                
            }
        });
        $A.enqueueAction(action);
        
    },
    
    validateRequired: function(component, event) { 
        var isValid = true;
        var customerid=component.get('v.OTCcustomerid');
        var cusname = component.find("customername").get("v.value");
        var remarksvalue = component.find("remarks").get("v.value");
        component.set("v.customerErrorMsg",'');
        $A.util.removeClass(cusname,"disp-block");
        $A.util.addClass(cusname,"disp-none");
        component.set("v.rerarkserrmsg",'');
        $A.util.removeClass(remarksvalue,"disp-block");
        $A.util.addClass(remarksvalue,"disp-none");
        if(customerid == 'undefined'|| customerid == '' || customerid == null){       
            component.set("v.customerErrorMsg",'Customer Name is required field');
            $A.util.removeClass(cusname,"disp-none");
            $A.util.addClass(cusname,"disp-block");
            isValid = false; 
        }
        
        if(remarksvalue =='' || remarksvalue=='undefined' || remarksvalue==null){ 
            
            component.set("v.rerarkserrmsg",'This Required field');
            $A.util.removeClass(remarksvalue,"disp-none");
            $A.util.addClass(remarksvalue,"disp-block");
            Isvalid=false;
            
        }
        return isValid;     
    },
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    codealerotcsave : function(component, event){     	
        debugger;
        var partex = component.find("partexecutive").get("v.value");
        var discountauth = component.find("dicountauthorized").get("v.value");
        var remarks = component.find("remarks").get("v.value");
        var Basicvalue=component.get('v.totalBasicValue');
        var taxvalue=component.get('v.totalTax');
        var totalvalue=component.get('v.totalInvoiceValue');
        var codealer=component.get('v.selectedLookUpRecord1');
        var orderid=codealer.Id;
        var discVal=component.get('v.totalDiscountValue');
        var action = component.get("c.codealerOtcOrder");       
        action.setParams({
            "ListlocalItem" : component.get('v.codeapartsList'),
            "recTypeid" :'OTC_Sale_Order',
            "partexecutive":partex,
            "discountauth":discountauth,
            "remarks":remarks,
            "taxablevalue" :Basicvalue,
            "taxamount" : taxvalue,
            "totalamount" : totalvalue,
            "codealerid" :orderid,
            "discVal":discVal
            
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                this.showSuccessToast(component,event,"Sales Order Created ");
                var storeResponse = response.getReturnValue();
                component.set('v.sbmitdisable',true); 
                component.set('v.printinvoice',false);
                var order=storeResponse[0];
                var ordid = order.Id;
                var ordernumb=order.OrderNumber;
                var invoicedetail=order.Invoice_Details__r;
                var referencenumber=invoicedetail[0].PSA_Invoiceid__r.Name;
                var invoicedate=invoicedetail[0].PSA_Invoiceid__r.PSA_Invoice_Date__c;
                component.set("v.OrderId", ordid);
                component.find("refdocnum").set("v.value",ordernumb);
                component.set('v.Invoicenumber',referencenumber);
                component.set('v.Invoicedate',invoicedate);
                
                
            }
        });
        $A.enqueueAction(action);
        
    },
    showErrorToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "error"
        });
        toastEvent.fire();  
    },
    currentstockvalue : function(component,event,orderlist,location,dealername){
        
        var products=[];
        for(var x in orderlist){
            products.push(orderlist[x].Product2Id);
        }
        var action = component.get("c.Currentstockvalues");       
        action.setParams({
            "ListlocalItem" :products
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set('v.stocklist',storeResponse);
                component.set("v.Parttableshow",true);
                component.set("v.customerpo",false);
                component.find("store").set("v.value",location);
                component.find("dealername").set("v.value",dealername);
            }
        });
        $A.enqueueAction(action);  
    },
    delearinfo: function(component,event) {
        var action = component.get("c.dealerbillingstate");       
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set('v.dealerstate',storeResponse);
            }
        });
        $A.enqueueAction(action);  
    }
})
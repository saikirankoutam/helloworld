({
    doInit : function(component, event, helper) {
        
        var invlist=  component.get("v.OrderCampaignList");
        if(invlist.returnquanity==null || invlist.returnquanity=='undefined' || parseInt(invlist.issuequanity)< invlist.returnquanity || invlist.returnquanity<0)
                  {
                      
                  }
            
                  else{
                  component.set("v.utilizeQty",parseInt(invlist.issuequanity)-invlist.returnquanity);
                  
                  }
		
                           },
	checkvalidation: function(component, event) {
        debugger;
    
        component.set("v.cnameerrmsg",'');
        var isvalid=true;
        var invlist=  component.get("v.OrderCampaignList");
        
        
            
            if(invlist.returnquanity==null || invlist.returnquanity=='undefined' || parseInt(invlist.issuequanity)< invlist.returnquanity || invlist.returnquanity<0)
                  {
                      component.set("v.utilizeQty",null);
                  }
            
                  else{
                  component.set("v.utilizeQty",parseInt(invlist.issuequanity)-invlist.returnquanity);
                  
                  }
                  
            if(parseInt(invlist.issuequanity)< invlist.returnquanity)
            {
            
             isvalid=false;
             component.set("v.OrderCampaignList.returnquanity",null);
             // component.set("v.cnameerrmsg","");
                      
            }
            if(invlist.returnquanity==null || invlist.returnquanity=='undefined' || invlist.returnquanity <0)
            {
                
             isvalid=false;
             component.set("v.cnameerrmsg","Required Field");
             component.set("v.OrderCampaignList.returnquanity",null);
            // errorPush.push('Please enter Return Quantity Greater than Zero');
        
            }
            
            
         
          //component.set("v.cnameerrmsg",errorPush);
          
           return isvalid; 
        
       
     
        
    },
})
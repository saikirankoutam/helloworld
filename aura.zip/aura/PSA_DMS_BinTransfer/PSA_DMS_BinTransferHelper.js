({
	showErrormsg : function(component, event, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
    },
    showSuccessmsg : function(component, event) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "success",
            "message": "Bin records created successfully!"
        });
        toastEvent.fire();
    },
    
    Binchangeshelper : function(component, event, helper) {         
         var selectedrec=component.get("v.selectedBinRecord");
        
         var binid = selectedrec.Id;
         if(binid == 'undefined' || binid == null || binid == ''){
             component.set('v.partdescsearch', true);
             component.set("v.Allocatedbinlist", '');
         	 var cmpTarget = component.find('submitbtn');
        	 $A.util.addClass(cmpTarget, 'disablebtn');
             component.set('v.Isemptybins', true);
         }
         else{
             component.set('v.partdescsearch', false);
             component.set('v.Isemptybins', false);
             var cmpTarget = component.find('submitbtn');
             $A.util.removeClass(cmpTarget, 'disablebtn');}
         
         var pn='';
         if(selectedrec.PSA_Dealer_Parts_Association__c != "undefined" && selectedrec.PSA_Dealer_Parts_Association__c != "" && selectedrec.PSA_Dealer_Parts_Association__c != null)
         	pn = selectedrec.PSA_Dealer_Parts_Association__r.PSA_Part_Number__c;
         else
         	pn = selectedrec.PSA_Product__r.PSA_Part_Number__c;
        
        component.set("v.partnumber", pn);
        debugger;
        var action = component.get('c.getAllocatedBins');  
        action.setParams({
            "partnumber" : pn
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {            
                var records =response.getReturnValue();
                component.set("v.Allocatedbinlist", records); 
            }
        });
        $A.enqueueAction(action); 
        
	},
    
    Binchangeshelper1 : function(component, event, helper){
        var selectedrec=component.get("v.selectedBinRecord1"); 
        var binid = selectedrec.Id;
        if(binid == 'undefined' || binid == null || binid == ''){
             component.set('v.partnumbersearch', true);
             component.set("v.Allocatedbinlist", '');
        	 var cmpTarget = component.find('submitbtn');
        	 $A.util.addClass(cmpTarget, 'disablebtn');
             component.set('v.Isemptybins', true);
        }
        else{
             component.set('v.partnumbersearch', false);
        	 var cmpTarget = component.find('submitbtn');
        	 $A.util.removeClass(cmpTarget, 'disablebtn');
        	 component.set('v.Isemptybins', false);}
        
        var pd='';
        if(selectedrec.PSA_Dealer_Parts_Association__c != "undefined" && selectedrec.PSA_Dealer_Parts_Association__c != "" && selectedrec.PSA_Dealer_Parts_Association__c != null){
         	pd = selectedrec.PSA_Dealer_Parts_Association__r.PSA_Parts_Description__c;
            component.set("v.partnumber", selectedrec.PSA_Dealer_Parts_Association__r.PSA_Part_Number__c);
        }else{
         	pd = selectedrec.PSA_Product__r.Description;
            component.set("v.partnumber", selectedrec.PSA_Product__r.PSA_Part_Number__c);
        }
        debugger;
        var action = component.get('c.getAllocatedBinsByPartDesc');  
        action.setParams({
            "partdesc" : pd
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {            
                var records =response.getReturnValue();
                component.set("v.Allocatedbinlist", records); 
            }
        });
        $A.enqueueAction(action); 
    },
    
    savebintransfershelper : function(component, event){        
        var lstoftransfers = component.get("v.Finaltransferbins");
        var partnum = component.get("v.partnumber");
        var isvalid = true;
        if(lstoftransfers == null)
          isvalid=false;
        else if(lstoftransfers.length == 0)
          isvalid=false;
        else
        isvalid=true;
        if(isvalid){
            component.set("v.spinner", true);
            var action = component.get('c.Bintransfer');
            action.setParams({
                "TransferredBins": lstoftransfers,
                "partnumber" : partnum
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                    var cmpTarget = component.find('submitbtn');
                    $A.util.addClass(cmpTarget, 'disablebtn');
                    component.set("v.spinner", false);                
                    var records =response.getReturnValue();
                    var message = 'Bin transferred Successfully!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "success",
                        "message": message
                    });
                    toastEvent.fire(); 
                    var childCmp = component.find("bintransferrows");
                    childCmp[0].refreshbins();
                }
                else{
                    component.set("v.spinner", false);
                    var message = 'Bin transferred Failed!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "message": message
                    });
                    toastEvent.fire();
                }
            });
            $A.enqueueAction(action);
        }
        else{
            var message = 'Please select atleast one bin record to transfer!';
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": message
            });
            toastEvent.fire(); 
        }
    }
})
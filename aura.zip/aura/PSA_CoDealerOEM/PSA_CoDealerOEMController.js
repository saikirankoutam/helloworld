({
    handlemonthlyOrderIdPass : function(component, event, helper) {
        var currentMonthlyOrderId = event.getParam("currentMonthlyOrderId");
        component.set("v.currentMonthlyOrderId", currentMonthlyOrderId);
        component.set("v.orderitem", true);
        component.set("v.OEMTable", false);
    },
    handledisplayListPage : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.OEMTable", true);
            component.set("v.orderitem", false);         
        }
    },
    
    posearchOrder: function(component, event, helper) {
        debugger;   
        console.log("" + event.getSource().get("v.value"));
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        
         component.set("v.invoice",pot) ;  
		 if(pot == null || pot == 'undefined' || pot==""){
            var childCmp = component.find("partsreceiptinvoicesId");
            childCmp.getinvoices();
        }
        else{ 
        var orderType="Codealer";        
        var action = component.get('c.getOrders');
        action.setParams({
            'orderType' : orderType,
            'ponumber' : pot
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {               
                var records =response.getReturnValue();
                console.log("Inside "+state);
                component.set("v.orders", records);
            }
        });
        $A.enqueueAction(action);
        }
    },
    
    
    CreateNewPurchaseOrder: function(component, event, helper) {
        
        component.set("v.NewOEM",true);
         component.set("v.EditOEM",false);
        component.set("v.OEMTable",false);
        
    },
    EditCodealer: function(component, event, helper) {
     component.set("v.selectedStep","Edit");    
        var orderid = event.getParam("Id");
        var action = component.get("c.getitems");
        action.setParams({
            "orderid" : orderid
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var rows = response.getReturnValue();
                console.log('POT List>>>>>>'+rows);
                component.set("v.orderitemlist",rows);
                
            }
        });
         $A.enqueueAction(action);
        component.set("v.OrderId",orderid);
       component.set("v.NewOEM",false);
        component.set("v.EditOEM",true);
        component.set("v.OEMTable",false);
        component.set("v.orderitem", false);  
       
    },
    cancelNewpurchase: function(component, event, helper) {
      //  component.set("v.orderitemlist",null);
    component.set("v.selectedStep","Draft");
        component.set("v.NewOEM",false);
        component.set("v.OEMTable",true);
        component.set("v.EditOEM",false);
        
    },
     getPartreceiptsCount : function(component, event, helper){
        var receiptscount = event.getParam("Id");
        component.set("v.partSupplierCount",receiptscount);
       
    }
    
    
})
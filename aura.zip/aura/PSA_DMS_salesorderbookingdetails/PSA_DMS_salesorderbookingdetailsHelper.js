({
getbookinginfo : function(component,event,helper) {
       
        
        var action = component.get("c.getorderinfo");
        action.setParams({
            "orderId" : component.get("v.RecordId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
             
                var value = response.getReturnValue(); 
                var ordedetails=value.orderinfo;
                component.set("v.Orderinfo", ordedetails);
                component.set('v.accessoryquantity',value.quantity);
                component.set('v.accessoryvalue',value.accessvalue);
                component.set('v.fitmentstatus',value.statusoffitment);
                component.set('v.invoicenumber',value.invoicenumber);
                component.set('v.invoicedate',value.invoicedate);
                component.set('v.Allomentsatus',value.Allotmentstatus);
                if(value.tradinstatus=='No'){
                    component.set("v.tradeStatus", 'No');
                    
                }else{
                    component.set("v.tradeStatus", 'Yes');
                }
                component.set("v.bookingDateIns",ordedetails.EffectiveDate);
                var bookingdate=$A.localizationService.formatDate(ordedetails.EffectiveDate,"dd/MM/yyyy");
                component.set("v.bookingdate",bookingdate);
                ordedetails.EffectiveDate=bookingdate;
                var Finaceinfo=ordedetails.Finances__r;
                var tradeInfo=ordedetails.TradeIns__r;
                var registration=ordedetails.PSA_RegistrationDeliverys__r;
               // var Allotement=ordedetails.Allotments__r;
                
                if(Finaceinfo !='undefined' && Finaceinfo !=null){
                    if(Finaceinfo[0].PSA_Type_of_Purchase__c=='Finance'){
                        component.set("v.finanLeaseName", Finaceinfo[0].PSA_Name_of_Financier__c);
                    }
                    if(Finaceinfo[0].PSA_Type_of_Purchase__c=='Lease'){
                        component.set("v.finanLeaseName", Finaceinfo[0].PSA_Leasing_Company__c);
                    }
                     if(Finaceinfo[0].PSA_Type_of_Purchase__c=='Cash / Own fund'){
                        component.set("v.finanLeaseName",null);
                    }
                     /*if(Finaceinfo[0].PSA_Type_of_Purchase__c=='Cash'){
                        component.set("v.finanLeaseName",null);
                    }*/
                    component.set("v.Finaceinfo", Finaceinfo[0]);
                }
                if(tradeInfo !='undefined' && tradeInfo !=null){
                    if(tradeInfo[0].PSA_Trade_In_Process__c=='undefined' ||tradeInfo[0].PSA_Trade_In_Process__c=='' || tradeInfo[0].PSA_Trade_In_Process__c==null) 
                    {
                       component.set("v.process", null);  
                    }else{
                        component.set("v.process", tradeInfo[0].PSA_Trade_In_Process__c);}
                }
                
                if(registration.length>0){
                    var registration1=registration[0];
                    var wsd=$A.localizationService.formatDate(registration1.PSA_PlannedDelivery__c, "dd/MM/yyyy");
                    registration1.PSA_PlannedDelivery__c=wsd;
                    component.set("v.registration", registration1);
                    
                }
                
                var Insurence=ordedetails.Insurances__r[0];
                component.set("v.Insurenceinfo", Insurence);
            }
        });
        $A.enqueueAction(action);
        
    },
    dealerinfo : function(component,event,helper) {
        var action = component.get("c.getloginuserinfo");
        action.setCallback(this, function(response){
            var state = response.getState();
           
            if (state == "SUCCESS") {
                 var value = response.getReturnValue(); 
                
                if(value=='Dealer Community User'){
                      
                     component.set('v.dealerprofile',true);
                     component.set('v.checkUser',false);
                    
                     this.getbookinginfo(component,event,helper);
                }else{
                    component.set('v.dealerprofile',false);
                    component.set('v.checkUser',true);
                    
                }
                
            }
        });
        $A.enqueueAction(action);
        
    },
      getCustomeLookUpQuery : function(component, event)
    {
		var  listStatus  = component.get("v.statuslist");
        var query='select Id,OrderNumber from order where PSA_Status__c=';
         
            query+=listStatus+' AND RecordTypeId=';
            var action = component.get("c.getRecordTypeID");
            action.setCallback(this, function(response){
                var state = response.getState();
                 
                var recordtypeid = response.getReturnValue();
                if (state === "SUCCESS") {
                var newString = '\''+ recordtypeid + '\''; 
                query+=newString +' AND OrderNumber LIKE: searchKey  limit 5';
                   
                component.set('v.customquery',query); 
                }
               //this.getAccountLookUpQuery(component, event,query);
            });
            $A.enqueueAction(action);
           
        
                
        }  
            
   
})
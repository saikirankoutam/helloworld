({
    changeTabColor: function(component, event, helper) {
        if(component.get("v.currTab") == "orderList")
        {
            var activate = component.find("orderList");
            var deactivate = component.find("dailyOrder");
            $A.util.removeClass(deactivate, "active");
            $A.util.addClass(activate, "active");
        }
    },
    doInit: function(component, event, helper) {
        helper.getMonthsInfo(component, event);
    },
    posearchOrdermonthly : function(component, event, helper) {
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        console.log("" + event.getSource().get("v.value"));
        helper.hlpposearch(component, event, helper , "monthly",pot );
    },
    posearchOrderdaily : function(component, event, helper) {
        console.log("" + event.getSource().get("v.value"));
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        helper.hlpposearch(component, event, helper , "daily" ,pot);
    },
    
    posearchReceipt: function(component, event, helper) {
        console.log("" + event.getSource().get("v.value"));
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        var receiptType = "vehicle";
        var action = component.get('c.getVehicleReceiptsById');
        grnnumber
        action.setParams({
            'grnnumber' : pot
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.receipts", records);
            }
        });
        $A.enqueueAction(action);
    }, 
    
    onTabSelect : function(component, event, helper) {
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        if(id == "monthlyOrder"){
            component.set("v.orders", null);
            helper.hlpposearch(component, event, helper , "monthly" ,"");
        }
        if(id == "dailyOrder"){
            component.set("v.orders", null);
            helper.hlpposearch(component, event, helper , "daily" ,"");
        } 
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
        component.set("v.newMonthlyOrder", false);
        component.set("v.editMonthlyOrder", false);
        component.set("v.newDailyOrder", false);
        component.set("v.editDailyOrder", false);
        component.set("v.vehicleGRN", false);
        component.set("v.inventoryView", false);
    },
    
    monthlyOrder : function(component, event, helper) {
        component.set("v.dailyOrder", false);
        component.set("v.monthlyOrder", true);
        var dailyOrder = component.find("dailyOrder");
        $A.util.removeClass(dailyOrder, "active");
        var monthlyOrder = component.find("monthlyOrder");
        $A.util.addClass(monthlyOrder, "active");
        component.set("v.newMonthlyOrder", false);
        component.set("v.editMonthlyOrder", false);
        
    },
    
    dailyOrder : function(component, event, helper) {
        component.set("v.monthlyOrder", false);
        component.set("v.dailyOrder", true);
        var dailyOrder = component.find("dailyOrder");
        $A.util.addClass(dailyOrder, "active");
        var monthlyOrder = component.find("monthlyOrder");
        $A.util.removeClass(monthlyOrder, "active");
        
    },
    vehiclerhandle : function(component, event, helper) {
        component.set("v.vehicleGRN", false);
        
    },
    CreateNewPurchaseOrder : function(component, event, helper) {
        component.set("v.newMonthlyOrder", true);
    },
    CreateNewDailyOrder : function(component, event, helper) {
        component.set("v.newDailyOrder", true);
    },
    
    handlemonthlyOrderIdPass : function(component, event, helper) {
        var currentMonthlyOrderId = event.getParam("currentMonthlyOrderId");
        component.set("v.currentMonthlyOrderId", currentMonthlyOrderId);
        component.set("v.editMonthlyOrder", true);
    },
    handleDailyOrderIdPass : function(component, event, helper) {
        var currentMonthlyOrderId = event.getParam("currentMonthlyOrderId");
        component.set("v.currentMonthlyOrderId", currentMonthlyOrderId);
        component.set("v.editDailyOrder", true);
    },
    handledisplayListPage : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.editDailyOrder", false);
            component.set("v.newDailyOrder", false);
            component.set("v.editMonthlyOrder", false);
            component.set("v.newMonthlyOrder", false);
        }
    },
    CreateNewGRN : function(component, event, helper) {
        component.set("v.currentVehicleReceiptId", "");
        component.set("v.createGRN", true);
        component.set("v.vehicleGRN", true);
    },
    handleVehicleReceiptIdPass : function(component, event, helper) {
        var currentVehicleReceiptId = event.getParam("Id");
        var vehids = event.getParam("currentOrderId");
        component.set("v.currentVehicleReceiptId", currentVehicleReceiptId);
        component.set("v.vehicleid", vehids);
        component.set("v.createGRN", false);
        component.set("v.vehicleGRN", true);
    },
    handleVehicleInventoryIdPass : function(component, event, helper) {
        var currentInventoryId = event.getParam("Id");
        component.set("v.currentInventoryId", currentInventoryId);
        component.set("v.inventoryView", true);
    },
    handlevalidateMenu : function(component, event, helper) {
        debugger;
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        var defaultItem = event.getParam("defaultItem");
        console.log("validationItem -- "+validationItem+"::"+defaultItem);
        if (defaultItem) {
            component.set("v.currTab", validationItem);            
        }
    },
    navigatetodashboard : function(component, event, helper) {
        var id = 'vehicleDashboard';
        var prevTab = component.get("v.currTab");
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
        component.set('v.currTab','vehicleDashboard');
    }
})
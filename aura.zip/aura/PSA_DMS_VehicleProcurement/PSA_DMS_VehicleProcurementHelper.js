({
	getMonthsInfo : function(component, event){
      var action = component.get("c.getOrderedMonths");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
            var res = response.getReturnValue();
                 component.set("v.allOrdersCreated", res);
           }
        });
        $A.enqueueAction(action);
   },
     hlpposearch : function(component, event, helper,ordertype , ponum) {
         console.log(ordertype + " : testing : "+ponum);
        var action = component.get('c.getOrders');
        action.setParams({
            'orderType' : ordertype,
            'ponumber' : ponum
        });
        	action.setCallback(this, function(response){
            var state = response.getState();
                console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                 console.log("Inside "+state);
                component.set("v.orders", records);
            }
        });
        $A.enqueueAction(action);
    },
})
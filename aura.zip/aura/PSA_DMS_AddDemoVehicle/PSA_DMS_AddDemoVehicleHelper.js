({
    demoLoading : function(component, event, helper){
        var itemInstance = component.get("v.itemInstance");
        if(itemInstance.Id != null)
        {
            component.set("v.disBrand", false);
            component.set("v.disVariant", false);
            component.set("v.disMetallic", false);
            component.set("v.disColour", false);
            component.set("v.disIntColour", false);
            component.set("v.disIntTrim", false);
            component.set("v.disRoof", false);
            component.set("v.disPack", false);
            component.set("v.variantList", itemInstance.Product2.PSA_Variant__c);
            component.set("v.colourList", itemInstance.Product2.PSA_Ext_Colour__c);
            component.set("v.IntcolourList", itemInstance.Product2.Interior_Color__c);
            component.set("v.metallicList", itemInstance.Product2.Metallic_Non_Metallic__c);
            component.set("v.IntTrimList", itemInstance.Product2.Interior_Trim_Type__c);
            component.set("v.RoofList", itemInstance.Product2.Roof__c);
            component.set("v.PackList", itemInstance.Product2.Pack__c);
            component.set("v.productId", itemInstance.Product2.Id);
            component.find("demoType").set("v.value", itemInstance.Demo_OrderType__c);
            component.find("brand").set("v.value", itemInstance.Product2.PSA_Brand__c);
            component.find("variant").set("v.value", itemInstance.Product2.PSA_Variant__c);
            component.find("colour").set("v.value", itemInstance.Product2.PSA_Ext_Colour__c);
            component.find("Intcolour").set("v.value", itemInstance.Product2.Interior_Color__c);
            component.find("metallic").set("v.value", itemInstance.Product2.Metallic_Non_Metallic__c);
            component.find("intTrim").set("v.value", itemInstance.Product2.Interior_Trim_Type__c);
            component.find("roof").set("v.value", itemInstance.Product2.Roof__c);
            component.find("pack").set("v.value", itemInstance.Product2.Pack__c);
            var productId = itemInstance.Product2.Id;
            var demoType = itemInstance.Demo_OrderType__c;
            var mapFirm = component.get("v.demomapFirm");
            if(mapFirm != null)
                for(var key in mapFirm)
                    if(mapFirm[demoType] != null)
                    {
                        var m = mapFirm[demoType];
                        for(var key in m)
                            if(m[productId])
                                component.set("v.quantity", m[productId]); 
                            else
                                component.set("v.quantity", 0);
                    }
            var fmap1 = component.get("v.demofmap1");
            if(fmap1 != null)
                for(var key in fmap1)
                    if(fmap1[demoType] != null)
                    {
                        var m = fmap1[demoType];
                        for(var key in m)
                            if(m[productId])
                                component.set("v.f1Quantity", m[productId]); 
                            else
                                component.set("v.f1Quantity", 0);
                    }
            var fmap2 = component.get("v.demofmap2");
            if(fmap2 != null)
                for(var key in fmap2)
                    if(fmap2[demoType] != null)
                    {
                        var m = fmap2[demoType];
                        for(var key in m)
                            if(m[productId])
                                component.set("v.f2Quantity", m[productId]); 
                            else
                                component.set("v.f2Quantity", 0);
                    }
            
            var fmap3 = component.get("v.demofmap3");
            if(fmap3 != null)
                for(var key in fmap3)
                    if(fmap3[demoType] != null)
                    {
                        var m = fmap3[demoType];
                        for(var key in m)
                            if(m[productId])
                                component.set("v.f3Quantity", m[productId]); 
                            else
                                component.set("v.f3Quantity", 0);
                    }
            
            var fmap4 = component.get("v.demofmap4");
            if(fmap4 != null)
                for(var key in fmap4)
                    if(fmap4[demoType] != null)
                    {
                        var m = fmap4[demoType];
                        for(var key in m)
                            if(m[productId])
                                component.set("v.f4Quantity", m[productId]); 
                            else
                                component.set("v.f4Quantity", 0);
                    }        
            var fmap5 = component.get("v.demofmap5");
            if(fmap5 != null)
                for(var key in fmap5)
                    if(fmap5[demoType] != null)
                    {
                        var m = fmap5[demoType];
                        for(var key in m)
                            if(m[productId])
                                component.set("v.f5Quantity", m[productId]); 
                            else
                                component.set("v.f5Quantity", 0);
                    }
            var fmap6 = component.get("v.demofmap6");
            if(fmap6 != null)
                for(var key in fmap6)
                    if(fmap6[demoType] != null)
                    {
                        var m = fmap6[demoType];
                        for(var key in m)
                            if(m[productId])
                                component.set("v.f6Quantity", m[productId]); 
                            else
                                component.set("v.f6Quantity", 0);
                    }
        }else{
            component.set("v.disableQuantity", true);
            component.set("v.f1disableQuantity", true);
            component.set("v.f2disableQuantity", true);
            component.set("v.f3disableQuantity", true);
            component.set("v.f4disableQuantity", true);
            component.set("v.f5disableQuantity", true);
            component.set("v.f6disableQuantity", true);
        }
    },
    
    removeProduct : function(component, event, helper, demoType){
        var productId = component.get("v.productId");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var mapFirm = component.get("v.demomapFirm");
        		if(typeof mapFirm[demoType] !== 'undefined')
                {
                    var mapFirmValue = mapFirm[demoType];
                        delete mapFirmValue[productId];
                    mapFirm[demoType] = mapFirmValue;  
                }
            component.set("v.demomapFirm", mapFirm);
            
            var demofmap1 = component.get("v.demofmap1");
        		if(typeof demofmap1[demoType] !== 'undefined')
                {
                    var demofmap1Value = demofmap1[demoType];
                        delete demofmap1Value[productId];
                    demofmap1[demoType] = demofmap1Value;  
                }
            component.set("v.demofmap1", demofmap1);
            
            var demofmap2 = component.get("v.demofmap2");
        		if(typeof demofmap2[demoType] !== 'undefined')
                {
                    var demofmap2Value = demofmap2[demoType];
                        delete demofmap2Value[productId];
                    demofmap2[demoType] = demofmap2Value;  
                }
            component.set("v.demofmap2", demofmap2);
            
            var demofmap3 = component.get("v.demofmap3");
        		if(typeof demofmap3[demoType] !== 'undefined')
                {
                    var demofmap3Value = demofmap3[demoType];
                        delete demofmap3Value[productId];
                    demofmap3[demoType] = demofmap3Value;  
                }
            component.set("v.demofmap3", demofmap3);
            
            var demofmap4 = component.get("v.demofmap4");
        		if(typeof demofmap4[demoType] !== 'undefined')
                {
                    var demofmap4Value = demofmap4[demoType];
                        delete demofmap4Value[productId];
                    demofmap4[demoType] = demofmap4Value;  
                }
            component.set("v.demofmap4", demofmap4);
            
            var demofmap5 = component.get("v.demofmap5");
        		if(typeof demofmap5[demoType] !== 'undefined')
                {
                    var demofmap5Value = demofmap5[demoType];
                        delete demofmap5Value[productId];
                    demofmap5[demoType] = demofmap5Value;  
                }
            component.set("v.demofmap5", demofmap5);
            
            var demofmap6 = component.get("v.demofmap6");
        		if(typeof demofmap6[demoType] !== 'undefined')
                {
                    var demofmap6Value = demofmap6[demoType];
                        delete demofmap6Value[productId];
                    demofmap6[demoType] = demofmap6Value;  
                }
            component.set("v.demofmap6", demofmap6);
            
        }
        
        component.set("v.productId", "");
        component.set("v.quantity", 0);
        component.set("v.f1Quantity", 0);
        component.set("v.f2Quantity", 0);
        component.set("v.f3Quantity", 0);
        component.set("v.f4Quantity", 0);
        component.set("v.f5Quantity", 0);
        component.set("v.f6Quantity", 0);
        component.set("v.disableQuantity", true);
        component.set("v.f1disableQuantity", true);
        component.set("v.f2disableQuantity", true);
        component.set("v.f3disableQuantity", true);
        component.set("v.f4disableQuantity", true);
        component.set("v.f5disableQuantity", true);
        component.set("v.f6disableQuantity", true);
    },
    
    addProducts : function(component, event, helper){
        var productId = component.get("v.productId");
        var demoType = component.find("demoType").get("v.value");
        var q = component.get("v.quantity");
        var q1 = component.get("v.f1Quantity");
        var q2 = component.get("v.f2Quantity");
        var q3 = component.get("v.f3Quantity");
        var q4 = component.get("v.f4Quantity");
        var q5 = component.get("v.f5Quantity");
        var q6 = component.get("v.f6Quantity");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var mapFirm = component.get("v.demomapFirm");
        		if(typeof mapFirm[demoType] !== 'undefined')
                {
                    var mapFirmValue = mapFirm[demoType];
                    if(q == 0 || q =="")
                        delete mapFirmValue[productId];
                    else
                        mapFirmValue[productId] = q;
                    mapFirm[demoType] = mapFirmValue;  
                }
            component.set("v.demomapFirm", mapFirm);
            
            var demofmap1 = component.get("v.demofmap1");
        		if(typeof demofmap1[demoType] !== 'undefined')
                {
                    var demofmap1Value = demofmap1[demoType];
                    if(q1 == 0 || q1 =="")
                        delete demofmap1Value[productId];
                    else
                        demofmap1Value[productId] = q1;
                    demofmap1[demoType] = demofmap1Value;  
                }
            component.set("v.demofmap1", demofmap1);
            
            var demofmap2 = component.get("v.demofmap2");
        		if(typeof demofmap2[demoType] !== 'undefined')
                {
                    var demofmap2Value = demofmap2[demoType];
                    if(q2 == 0 || q2 =="")
                        delete demofmap2Value[productId];
                    else
                        demofmap2Value[productId] = q2;
                    demofmap2[demoType] = demofmap2Value;  
                }
            component.set("v.demofmap2", demofmap2);
            
            var demofmap3 = component.get("v.demofmap3");
        		if(typeof demofmap3[demoType] !== 'undefined')
                {
                    var demofmap3Value = demofmap3[demoType];
                    if(q3 == 0 || q3 =="")
                        delete demofmap3Value[productId];
                    else
                        demofmap3Value[productId] = q3;
                    demofmap3[demoType] = demofmap3Value;  
                }
            component.set("v.demofmap3", demofmap3);
            
            var demofmap4 = component.get("v.demofmap4");
        		if(typeof demofmap4[demoType] !== 'undefined')
                {
                    var demofmap4Value = demofmap4[demoType];
                    if(q4 == 0 || q4 =="")
                        delete demofmap4Value[productId];
                    else
                        demofmap4Value[productId] = q4;
                    demofmap4[demoType] = demofmap4Value;  
                }
            component.set("v.demofmap4", demofmap4);
            
            var demofmap5 = component.get("v.demofmap5");
        		if(typeof demofmap5[demoType] !== 'undefined')
                {
                    var demofmap5Value = demofmap5[demoType];
                    if(q5 == 0 || q5 =="")
                        delete demofmap5Value[productId];
                    else
                        demofmap5Value[productId] = q5;
                    demofmap5[demoType] = demofmap5Value;  
                }
            component.set("v.demofmap5", demofmap5);
            
            var demofmap6 = component.get("v.demofmap6");
        		if(typeof demofmap6[demoType] !== 'undefined')
                {
                    var demofmap6Value = demofmap6[demoType];
                    if(q6 == 0 || q6 =="")
                        delete demofmap6Value[productId];
                    else
                        demofmap6Value[productId] = q6;
                    demofmap6[demoType] = demofmap6Value;  
                }
            component.set("v.demofmap6", demofmap6);
        }
    },
    
    showError : function(component, event, helper, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
    },
})
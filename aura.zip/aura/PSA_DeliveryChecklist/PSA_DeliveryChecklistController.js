({ 
    doInit: function(component, event, helper) {
        
         var action = component.get("c.getcheckVdn");
      var booknum=component.get("v.bookingorderid");
        action.setParams({
            "booknum" : booknum,
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var orderno=value;
                //var vdnstatusdis=value.PSA_VDN_check__c;
              component.set("v.savedis",orderno);
                 }
             var satus=component.get("v.savedis");
        if(satus==true){
            component.find("123button").set("v.disabled",true);
        }
       helper.getdeliverychecklist(component, event, helper);
        });
      $A.enqueueAction(action);
       
helper.checkBookingStatus(component, event, helper);	
        
      /* var satus=component.get("v.savedis");
        
        if(satus==true){
            component.find("123button").set("v.disabled",true);
        }*/
		
	},
        deliverychecklistpdf :  function(component, event, helper) {
             debugger;
        
           var bookingid=component.get("v.bookingorderid");
        var pdfurl ='../PSA_SalesDeliverychecklist?id='+bookingid;
        window.open(pdfurl,"_blank", "width=600, height=550"); 
    },
    
     handleSave: function(component, event, helper) {
        debugger;
      
         		var accessory =component.find("fitment").get("v.value");
                var batt =component.find("batt").get("v.value");
                var duplkey =component.find("duplicate").get("v.value");
                var triangle =component.find("reflector").get("v.value");
                var firstaid =component.find("aid").get("v.value");
                var gatepass =component.find("pass").get("v.value");
                var insurance =component.find("note").get("v.value");
                var manual =component.find("omanual").get("v.value");
                var guide =component.find("warrantyguide").get("v.value");
                var challan =component.find("reciept").get("v.value");
                var saleLetter =component.find("saleltr").get("v.value");
                var headlight =component.find("headlamp").get("v.value");
                var wheel =component.find("wheel").get("v.value");
                var toolkit =component.find("kit").get("v.value");
                var vehfunc =component.find("explain").get("v.value");
                var saleinv =component.find("vehsale").get("v.value");
                var warrantyguide =component.find("warrantyguide").get("v.value");
             var delrmks =component.find("rmks").get("v.value");
         var booknum=component.get("v.bookingorderid");
         var action = component.get("c.UpdatedeliveryChecklist"); 
         action.setParams({
                   "Accessory"   	: accessory,
                   "Batt" 			: batt,
                   "Duplkey"		: duplkey,
                   "Triangle"		: triangle,
                   "Firstaid"		: firstaid,
                   "Gatepass"		: gatepass,
                   "Insurance"		: insurance,
                    "Manual"		: manual,
                   "Guide"			: guide,
                   "Challan"		: challan,
                   "SaleLetter"		: saleLetter,
                   "Headlight"   	: headlight,
                   "Wheel" 			: wheel,
                   "Toolkit"		: toolkit,
                   "Vehfunc"		: vehfunc,
                   "Saleinv"		: saleinv,
                   "Warrantyguide"	: warrantyguide,
             		"booknum"		:booknum,
             		"delvryrmks"	:delrmks,
     
               });
               action.setCallback(this, function(response) {
                   var result=response.getState();
                   console.log('save status  >>>>'+result);
                   if(result  === "SUCCESS"){
            	   var storeResponse = response.getReturnValue();
                  
                    if (component.find("fileId").get("v.files"))
                    {
                          helper.uploadHelper(component,event,storeResponse);
                    } 
                   helper.showSuccessToast(component,event,storeResponse);
                  // component.find("123button").set("v.disabled",true);
                   }
                  
                    
               });
         
               $A.enqueueAction(action); 

         
	},
     handleFilesChange: function(component, event, helper) {
        
        var fileName = 'No File Selected..'; 
        fileName = event.getSource().get("v.files")[0]['name'];   
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
        //helper.checkfilesize(component, event);
          if(ext == "png" || ext == "PNG" || ext == "JPEG" || ext == "pdf" || ext == "jpeg" || ext == "jpg" || ext == "JPG"){
            helper.checkfilesize(component, event);
        } else{ 
            component.set('v.fileName','');
        var message='Upload only png or jpg or PDF or jpg or jpeg files ';
        helper.errorToast(component, event, message);
        } 
    },
    
  
    viewAttachment : function(component, event, helper) {
        helper.fetchdocumenturl(component, event, helper);
      //  var attachment=component.get('v.attachurl');
       
        
    },   
    
    
})
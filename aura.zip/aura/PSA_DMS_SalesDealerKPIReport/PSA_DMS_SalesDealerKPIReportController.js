({
	init: function (component, event, helper) {
        var yr = 2018;
        var list = [];
        var dat = new Date();
        var currYear = dat.getFullYear();
        for(var i=currYear; i > yr; i--)
            list.push(i);
        component.set("v.optionsYear", list);
        component.set("v.selectedValueYear", currYear);
        component.set('v.columns', [
            {label: 'Month', fieldName: 'Month', type: 'text',initialWidth:80},
            {label: 'RO Opening Target', fieldName: 'roOpeningTarget', type: 'number',initialWidth:150},
            {label: 'RO Opening Actual', fieldName: 'roOpeningActual', type: 'number',initialWidth:150},
            {label: 'SameDay Delivery', fieldName: 'sameDayDelivery', type: 'text',initialWidth:150, cellAttributes: { alignment: 'right' }},
            {label: 'CPRO Target', fieldName: 'CPROTarget', type: 'number',initialWidth:100},
            {label: 'CPRO Actual', fieldName: 'CPROActual', type: 'number',initialWidth:100},
            {label: 'BPRO Target', fieldName: 'BPROTarget', type: 'number',initialWidth:100},
            {label: 'BPRO Actual', fieldName: 'BPROActual', type: 'number',initialWidth:100}
            
        ]);
        var action = component.get('c.helper1');
       action.setParams({
            "yrVal": currYear
        })
        	action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.data", records);
                
            }
        });
        $A.enqueueAction(action);
        helper.stockrecords(component,event,currYear);
    },
  getValues: function (component, event, helper) {
		var currYear=component.get("v.selectedValueYear")
        var action = component.get('c.helper1');
       action.setParams({
            "yrVal": component.get("v.selectedValueYear")
        })
        	action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.data", records);
                // helper.stockrecords(component,event,currYear);
                
            }
        });
        $A.enqueueAction(action);
        helper.stockrecords(component,event,currYear);
  },      
})
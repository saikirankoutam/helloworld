({
    doInit: function(component, event, helper) {   
        var acc = component.get("c.getfulfillmentcode");
        acc.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
            	component.set("v.fulfillmentcode", response.getReturnValue());
            }
        });
        $A.enqueueAction(acc);
        
        helper.getfulfillmentbranchcodeshelper(component, event, helper);
        var userId = $A.get("$SObjectType.CurrentUser.Id");
        component.set("v.loggedinuserid", userId);
        var todaydate = new Date();
        //var dateval = Date.Parse(todaydate.getDate() + "/"+ (todaydate.getMonth() + 1)+"/" +todaydate.getFullYear());
        component.set("v.reqdate", todaydate.getDate() + "/"+ (todaydate.getMonth() + 1)+"/" +todaydate.getFullYear());
        helper.createObjectData(component, event, helper); 
        var action = component.get('c.getbranchinfo');            
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var record = response.getReturnValue();
                component.set("v.reqbranchcode", record['code']);
                component.set("v.reqbranchlocation", record['location']);
                component.set("v.requestedby", record['name']);
            }
        });
        $A.enqueueAction(action);        
    },
    
    addNewRow : function(component, event, helper) {
        helper.createObjectData(component, event, helper);
    },
    
    gettransferquery : function(component, event, helper) {
        var query = 'SELECT Id, OrderNumber, (select Id, Product2Id, Product2.PSA_Part_Number__c, Product2.PSA_Part_Description__c, OrderId, Product2.PSA_HSN_Code__c, Product2.QuantityUnitOfMeasure, Quantity, UnitPrice, Product2.PSA_Min_Inv_Level__c, Product2.PSA_Max_Inv_Level__c, Product2.PSA_Reorder_Level__c, Product2.PSA_Safety_Stock__c, PSA_Indent_Qty__c, PSA_Transfer_Qty__c, PSA_Indent_Value__c, PSA_Transfer_Value__c from OrderItems), PSA_Request_Date__c, PSA_Transfer_Request_Number__c, PSA_Approver_Comments__c, PSA_Approval_Status__c, PSA_Approved_Date__c, PSA_Approved_By__c, PSA_Requested_By__c, PSA_Dealer_Remarks__c, PSA_Fulfilment_Branch_Location__c, PSA_Fulfilment_Branch_code__c, PSA_Total_Request_Value__c, PSA_Requested_Branch_Location__c, PSA_Requested_Branch_Code__c FROM Order where PSA_IsTransferred__c !=true AND recordtype.name=';
        var uid = component.get("v.loggedinuserid");
        var fullfillmentcode = component.get("v.fulfillmentcode");
        var rectypename = 'Stock Request/Transfer';
        var newString = '\'' + rectypename +'\'' + 'AND CreatedById!=' + '\''+ uid + '\''+ 'AND PSA_Fulfilment_Branch_code__c=' + '\''+ fullfillmentcode + '\'';
        query += newString;
        query += 'AND PSA_Transfer_Request_Number__c LIKE: searchKey order by createdDate DESC limit 5';
        component.set("v.transferquery",query);
    },
    
    getsearchquery : function(component, event, helper) {
        var query = 'SELECT Id, OrderNumber, (select Id, Product2Id, Product2.PSA_Part_Number__c, Product2.PSA_Part_Description__c, OrderId, Product2.PSA_HSN_Code__c, Product2.QuantityUnitOfMeasure, Quantity, UnitPrice, Product2.PSA_Min_Inv_Level__c, Product2.PSA_Max_Inv_Level__c, Product2.PSA_Reorder_Level__c, Product2.PSA_Safety_Stock__c, PSA_Indent_Qty__c, PSA_Transfer_Qty__c, PSA_Indent_Value__c, PSA_Transfer_Value__c from OrderItems), PSA_Request_Date__c, PSA_Transfer_Request_Number__c, PSA_Approver_Comments__c, PSA_Approval_Status__c, PSA_Approved_Date__c, PSA_Approved_By__c, PSA_Requested_By__c, PSA_Dealer_Remarks__c, PSA_Fulfilment_Branch_Location__c, PSA_Fulfilment_Branch_code__c, PSA_Total_Request_Value__c, PSA_Requested_Branch_Location__c, PSA_Requested_Branch_Code__c FROM Order where recordtype.name=';
        var uid = component.get("v.loggedinuserid");
        var rectypename = 'Stock Request/Transfer';
        var newString = '\'' + rectypename +'\'' + 'AND CreatedById=' + '\''+ uid + '\'';
        query += newString;
        query += 'AND PSA_Transfer_Request_Number__c LIKE: searchKey order by createdDate DESC limit 5';
        component.set("v.searchquery",query);
    },
    
    removeDeletedRow : function(component, event, helper) {
        var index = event.getParam("indexVar");        
        var partslist = component.get("v.partdetails");
        partslist.splice(index, 1);
        component.set("v.partdetails", partslist);
    },
    
    clearrequest : function(component, event, helper) {
        component.set("v.totalreqvalue", "");
        component.set("v.dealerremarks", "");     
        component.set("v.transreqnumber", "");
        var cmpTarget = component.find('submitbtn');
        $A.util.removeClass(cmpTarget, 'disablebtn');
        var childCmp = component.find("createstockrows");      
        if(childCmp.length > 0){
            for(var i=0; i<childCmp.length; i++){
                childCmp[i].clearchildfields();
            } 
        }  
        else{
            component.find("createstockrows").clearchildfields();        
        }
        var childCmp = component.find("fulfilmentbranchcode");
        childCmp.clearpill(); 
        component.find("fulfilmentbranchlocation").set("v.value", " ");
    },
    
    cleartransfers : function(component, event, helper) {                
        var childCmp = component.find("trnid");
        childCmp.clearpill(); 
        component.set("v.selectedLookUpRecord", null);              
    },
    
    reducetotalindentvalue : function(component, event, helper) {
        var childindentval = event.getParam("OemId");
        var totalindval = component.find("totalreqvalue").get("v.value");
        var reducedindent = totalindval - childindentval;        
        component.find("totalreqvalue").set("v.value", reducedindent);
    },
    
    calctotalindentvalue : function(component, event, helper) {        
        var lstdetail = component.get("v.partdetails");
        var totalindentval = 0;
        for(var x in lstdetail){
            totalindentval += lstdetail[x].totalindentvalue;
        }
        component.find("totalreqvalue").set("v.value", totalindentval);
    },
    
    recordfulfillmentChanges : function(component, event, helper) {
        var scity = component.get("v.selectedBranchLookUpRecord");
        helper.hiderequiredfield(component, event, helper);
        if(scity.ShippingCity == 'undefined' || scity.ShippingCity == null || scity.ShippingCity == ''){
            component.set("v.totalreqvalue", "");
            component.set("v.dealerremarks", "");   
            component.find("fulfilmentbranchlocation").set("v.value", "");
            var childCmp = component.find("createstockrows");      
            if(childCmp.length > 0){
                for(var i=0; i<childCmp.length; i++){
                    childCmp[i].clearchildfields();
                } 
            }  
            else{
                component.find("createstockrows").clearchildfields();        
            }                        
            helper.createObjectData(component, event, helper);
        }
        else{
            var fulbranchcode = component.find("fulfilmentbranchcode").get("v.value");
            component.set("v.fulbranchcodeErrmsg",'');
            $A.util.removeClass(fulbranchcode,"disp-block");
            $A.util.addClass(fulbranchcode,"disp-none");
            component.find("fulfilmentbranchlocation").set("v.value", scity.ShippingCity);
        }
    },
    
    recordChanges : function(component, event, helper) {
        var orders = component.get("v.selectedLookUpRecord");
        component.set("v.orderlineitems", orders.OrderItems); 
        helper.hiderequiredfield(component, event, helper);
        var ords = component.get("v.selectedLookUpRecord");
        if(ords.PSA_Transfer_Request_Number__c == undefined || ords.PSA_Transfer_Request_Number__c == null){
            component.set("v.pdfbuttondisable", true);  
            component.find("reqdate").set("v.value", " ");
            component.find('reqbranchcode').set('v.value', '');
            component.find("reqbranchlocation").set("v.value", " ");
            component.find("totalreqvalue").set("v.value", " ");
            component.find("fulfilmentbranchcode").set("v.value", " ");
            component.find("fulfilmentbranchlocation").set("v.value", " ");
            component.find("dealerremarks").set("v.value", " ");  
            component.set("v.totalreqvalue", " ");	          
        }
        else{ 
            if(component.get("v.rendersearchcmp") == true){
                var transreqno = component.find("trnid").get("v.value");
                component.set("v.transreqErrmsg",'');
                $A.util.removeClass(transreqno,"disp-block");
                $A.util.addClass(transreqno,"disp-none");
            }
            helper.calctotalindentvaluehelper(component, event, helper);
        }
        
        
        
    },
    
    Saverequestorders : function(component, event, helper) {   
        
        if(helper.validatecreatestockrequestForm(component, event, helper)){
            component.set("v.FinalStockrequestrecords", null);
            component.set('v.validationcheck',true);
            var childCmp = [];        
            childCmp = component.find("createstockrows");        
            if(childCmp.length > 0){
                for(var i=0; i<childCmp.length; i++){
                    childCmp[i].saverecords();
                } 
            }  
            else{
                component.find("createstockrows").saverecords();        
            }
            var isvalid=component.get('v.validationcheck');
            if(isvalid)
            {  
                component.set("v.spinner", true);
                helper.saverequestordershelper(component,event,helper);  
            }
        }
    },
    
    disabletransferbtn : function(component,event,helper){
        var bool = event.getParam("listPage");
        if(bool){
            var cmpTarget = component.find('transfersubmitbtn');
            $A.util.addClass(cmpTarget, 'disablebtn');
        }
        else{
            var cmpTarget = component.find('transfersubmitbtn');
            $A.util.removeClass(cmpTarget, 'disablebtn');
        }
    },
    
    StocksRecordmerge : function(component,event,helper){        
        var singlebinlist = event.getParam("ordlist");
        var bool = event.getParam("listPage");
        if(component.get('v.validationcheck')){
            component.set('v.validationcheck', bool);
        }
        //if(component.get("v.FinalStockrequestrecords").length > 0){
        if(component.get("v.FinalStockrequestrecords") != null){
            var arr = [];
            var existingrecord = component.get("v.FinalStockrequestrecords");
            for(var i=0; i<existingrecord.length; i++){
                arr.push(existingrecord[i]);
            }
            arr.push(singlebinlist[0]);
            component.set("v.FinalStockrequestrecords", arr);
        }
        else{
            component.set("v.FinalStockrequestrecords", singlebinlist);
        }
        
        
    },
    
    TransferRequestedorders : function(component,event,helper){
        
        if(helper.validatecreatestockrequestForm(component, event, helper)){
            component.set("v.FinalStockrequestrecords", null);
            component.set('v.validationcheck',true);
            var childCmp = [];
            
            childCmp = component.find("searchstockrows");
            
            if(childCmp.length > 0){
                for(var i=0; i<childCmp.length; i++){
                    childCmp[i].saverecords();
                } 
            } 
            else{
                component.find("searchstockrows").saverecords();
            }
            var isvalid=component.get('v.validationcheck');
            if(isvalid)
            {  
                component.set("v.spinner", true);
                helper.TransferRequestedordershelper(component,event,helper);  
            }
        }
    },
    
    printchallan :  function(component, event, helper) {
        debugger;
        var partNamerecord = component.get("v.selectedLookUpRecord");
        var partName = partNamerecord.PSA_Transfer_Request_Number__c ; 
        var action = component.get("c.getsearchdata");
        action.setParams({
            "partName" : partName  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var lineid =''
                var storeResponse = response.getReturnValue();
                lineid =storeResponse.Id;
                var pdfurl ='../StockTransferPDF?id='+lineid;
                window.open(pdfurl,"_blank", "width=600, height=550"); 
                
            }
        });
        $A.enqueueAction(action);  
    }
    
})
({
	createObjectData : function(component, event) {
		var BinRowItemList = component.get("v.BinRecordItems");
        BinRowItemList.push({
            'sobjectType': 'PSA_BinZone__c',
            'Name': ''
        });
        component.set("v.BinRecordItems", BinRowItemList);
	}
})
({
	doInit : function(component, event, helper) {        
		helper.getcasenumbers(component, event);
	},
    
    requisitionchange : function(component, event, helper){
        var caseid = component.find("requisitionid").get("v.value");
        helper.getworkshopno(component, event, caseid);
        helper.workshopnochange(component, event, helper);
	},        
    
    clearreturns : function(component, event, helper){
        component.find("requisitionid").set("v.value", "-- None --");
        component.set('v.lstworkshopno', null);
        component.set('v.lstwolineitems', null);             
    },
    
    Returnparts : function(component,event,helper){   
        if(helper.validateworkshopreturn(component, event, helper)){
            //component.set('v.validationcheck',true);
            var childCmp = component.find("workshopreturnrows");
            if(childCmp.length == undefined){
                component.find("workshopreturnrows").saverecords();
            }
            if(childCmp.length){
                for(var i=0; i<childCmp.length; i++){
                    //childCmp[i].checkvalidation(); 
                    //if(component.get('v.validationcheck'))
                    childCmp[i].saverecords();
                } 
            }
            
            //var isvalid=component.get('v.validationcheck');
            //if(isvalid)
            //{              
            helper.Savereturnedrecords(component,event);  
            //}
        }
        
    },
    
    Partsconsumablesmerge:function(component,event,helper){
        var singlebinlist = event.getParam("ordlist");
        if(component.get("v.Finalpartsconsumables").length > 0){
			var arr = [];
        	var existingrecord = component.get("v.Finalpartsconsumables");
            for(var i=0; i<existingrecord.length; i++){
                arr.push(existingrecord[i]);
            }
        	arr.push(singlebinlist[0]);
            component.set("v.Finalpartsconsumables", arr);
        }
        else{
            component.set("v.Finalpartsconsumables", singlebinlist);
        }
        
        
    },
    
    picklistpdf : function(component, event, helper) {
        var workorderId = component.get("v.repairOrderId");
        var action = component.get("c.getWorkorderlineitems");
        
        action.setParams({
            "workordid" : workorderId  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var lineid =''
                var storeResponse = response.getReturnValue();
                for(var i = 0; i < storeResponse.length; i++){
                    lineid =storeResponse[0].Id;
                    
                }
                var baseUrl= decodeURIComponent(window.location.hostname);
                
                var url = 'https://'+baseUrl+'/dmsindia/s/workorderlineitem/'+lineid;
                
                window.open(url,"_blank", "width=600, height=550");
                
            }
        });
        $A.enqueueAction(action);
        
    }
    
    
})
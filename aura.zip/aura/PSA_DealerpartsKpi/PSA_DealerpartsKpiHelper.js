({
	targetsrecords : function(component,event) {
        var action = component.get("c.targetrecords");
         action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.targets", response.getReturnValue());
                
            };
        });
        $A.enqueueAction(action);
		
	},
    stockrecords : function(component,event) {
        var action = component.get("c.stockrecords");
         action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.stocktargets", response.getReturnValue());
                
            };
        });
        $A.enqueueAction(action);
		
	},
     Vorrecords : function(component,event) {
        var action = component.get("c.Vorkpimethod");
         action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.vortargets", response.getReturnValue());
                
            };
        });
        $A.enqueueAction(action);
		
	}
})
({
    createEmptyRow : function(component, event) {
        debugger;
        var RowItemList = component.get("v.paymentrowslist");
        RowItemList.push({
            'sobjectType ': 'PSA_Payment__c',
            'PSA_Mode__c':'',
            'Payment_Amount__c':'',
            'Receipt_Number__c':'',
            'Payment_Date__c':''
            //'Createdby.Name':'',
            //'Createddate':''
        });
        component.set("v.paymentrowslist", RowItemList);
    },
    invoicePaymentinfo : function(component, event){
        var action = component.get("c.invoicepaymentrec");
        action.setParams({
            "repairOrderId" : component.get("v.repairOrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set('v.invoiceAmt',storeResponse.invoiceAmount);
                component.set('v.paymentAmt',0);
                component.set('v.balanceAmt',storeResponse.BalanceAmt);
               component.find('invoiceamt').set('v.value',storeResponse.invoiceAmount);
                component.find('balance').set('v.value',storeResponse.BalanceAmt);
                var status=component.get('v.wostatus');
                
                if(status=='Closed'){
                    //component.set('v.submitbtndis',true);
                    
                }
              if(storeResponse.BalanceAmt==0){
                     component.set('v.submitbtndis',true);
                }
                
            }
        });
        $A.enqueueAction(action);
    },
    paymentinfo : function(component, event){
        var action = component.get("c.fetchpayment");
        action.setParams({
            "repairOrderId" : component.get("v.repairOrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();                
                console.log('payment Info >>>>'+JSON.stringify(storeResponse));
                component.set("v.PaymentList", storeResponse);
                var len = storeResponse.length;
                component.set("v.rowno", len);
                 if(len==0 ||len=='' || len=='undefined' || len==null){
                    component.set('v.nopaymentrecords',true);
                }
                 else{
                component.set('v.nopaymentrecords',false);
                 }
            }
        });
        $A.enqueueAction(action);
    },        
    Createpayment : function(component, event, helper) { 
    },
    
    errortoast : function(component, event, helper, msg){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": msg,
            "type": "error"
        });
        toastEvent.fire(); 
    },
    saverequest:function(component,event){
        var action = component.get("c.createpaymentmethodNew");
        action.setParams({
            "mapofpaymentrec" : component.get('v.paymentrowslist'),
            "oid" : component.get("v.repairOrderId")         
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                var Message= $A.get("$Label.c.PSA_Payment_created_Successfully");
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "message": "Payment Created Successfully!",
                    "type": "success"
                });
                toastEvent.fire();                               
                this.paymentinfo(component, event);
                this.invoicePaymentinfo(component, event);
                component.set("v.paymentlistview", true); 
                component.set('v.visiblechild',false);
                component.set('v.visibleaddbutton',true);
                component.set("v.paymentrowslist", []);
                
            }
            else{
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "message": "Payment failed!",
                    "type": "error"
                });
                toastEvent.fire();  
            }
        });
        $A.enqueueAction(action);
    },
})
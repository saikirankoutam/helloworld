({
         doInit : function(component, event, helper) {
       var action = component.get('c.getlabourmasterdetail');
        action.setParams({
           'Opnumber' : component.get('v.LabourMasterId')
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();   
                component.set("v.simpleRecord", records);
                var action = component.get('c.getDealerRateprhr');
                action.setCallback(this, function(response){
                    var state = response.getState();
                if(state == 'SUCCESS') {
                	var records =response.getReturnValue();   
                	component.set("v.rateprhr", records);
            	}
            });
            $A.enqueueAction(action);

            }
        });
        $A.enqueueAction(action);
    },
    
    backtolistview : function(component, event, helper) {
        var compEvent = component.getEvent("displayList");
        compEvent.setParams({"listPage" : false });
        compEvent.fire();
    },

    onTabSelect : function(component, event, helper) {         
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
        
    },
})
({
    doinit : function(component, event, helper) {
        var action = component.get("c.getAcccheckVdn");
       var ordid=component.get('v.RecordId');
       action.setParams({
            "orderId" : ordid
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var orderno=value;
                //var vdnstatusdis=value.PSA_VDN_check__c;
              component.set("v.savedis",orderno);
                 }
             var satus=component.get("v.savedis");
        if(satus==true){
            component.find("123button").set("v.disabled",true);
        }
     
        });
      $A.enqueueAction(action);
        
  helper.checkBookingStatus(component, event, helper);
   helper.loadAccessoriesrecords(component, event);
         /*var satus=component.get("v.savedis");
        if(satus==true){
            component.find("123button").set("v.disabled",true);
        }*/
        
    },
    fitmentchange : function(component, event, helper) {
        var status= component.find('fitmentrecord').get('v.value');
        component.set('v.accessoryrecord.Status',status);
    },
    Submit : function(component, event, helper) {
        
        var access=component.get('v.accessoryrecord');
        var action = component.get("c.updateaccessoryrecord");
        action.setParams({
            "accessrecord" : access,
            "orderitemlist" :component.get('v.orderproducts'),
            "localitemlist" :component.get('v.localproducts')
        });
        action.setCallback(this, function(response){
            var state = response.getState();     
            if (state === "SUCCESS") {
                var responseValue=response.getReturnValue();
        
                helper.showToast(component,event,'Accessory record updated successfully','Success');
            }
        });
        $A.enqueueAction(action);
    },
     Print : function(component, event, helper) {
          var ordid=component.get('v.RecordId');
         var pdfurl ='../CitroenAccessoryfitmentrequest?Id='+ordid;
        window.open(pdfurl,"_blank","width=600, height=550"); 
     },
    preventalphabets : function(component, event, helper){
        var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
    }
    //disabled="{!v.Submitdisable}" aura:id="123button"
})
({
    doInit : function(component, event, helper) {
        component.set("v.spinner", true);
        
      //  helper.getInsuranceMaster(component,event,helper);
        helper.getJobcardStatusPicklist(component,event,helper); 
        helper.jobCardstatusSBFolderList(component,event,helper); 
        helper.getModePaymentList(component,event,helper); 
        helper.callVehicleBoughtByPicklist(component,event,helper);
        helper.getModeContactList(component,event,helper); 
        helper.getworkOrderstatusList(component,event,helper); 
        helper.getworkOrderSubstatusList(component,event,helper); 
        helper.getBreakDownList(component,event,helper); 
        helper.getsourceList(component,event,helper);  
        helper.getserviceTypeList(component,event,helper);  
        helper.getserviceCategoryList(component,event,helper);  
        helper.getVisitList(component,event,helper);
        helper.getJobCardActivities(component,event,helper);
        helper.callDealerCategoryPrice(component,event,helper);
        if(component.get("v.repairOrderId"))
        {
          //  helper.getJobLabours(component,event,helper);     
            helper.getJobParts(component,event);     
            helper.getRecentVisits(component,event,helper);   
            window.setTimeout(
                $A.getCallback(function() {
                   
                }), 1); 
        }  
        helper.getRoDetails(component,event,helper);
        component.set("v.spinner", false);
       
    },

     onRonum: function(component, event, helper){
        var selected = event.getSource().get("v.value");

          var recordId =selected;
        
        var pdfurl ='../PSA_RepairOrderPDF?id='+recordId;
        window.open(pdfurl,"_blank", "width=600, height=550");   

  
        
    },

     setTrue:function(component,event,helper)
    {
        		 //var selected = evt.getSource().get("v.label");
        component.set("v.repairOrder.PSA_Customer_Confirmation_on_Add_Job__c",true);
        //component.find("yes").set("v.value",true);
    },
     setFalse:function(component,event,helper)
    {
        		 //var selected = evt.getSource().get("v.label");
        component.set("v.repairOrder.PSA_Customer_Confirmation_on_Add_Job__c",false);
               // component.set("v.value",true);

    },
    
    sendROestimate: function(component, event, helper) {
     
        var workorderid = component.get("v.repairOrderId"); 
        var action = component.get('c.sendestimateAttachement');
       action.setParams({ 
            "recordId" : workorderid           
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            //var records =response.getReturnValue();  
            if(state == 'SUCCESS') {
                
               var toastEvent = $A.get("e.force:showToast");
        	toastEvent.setParams({
            "title": "Success!",
            "message": "Estimate Email sent Successfully",
            "type": "success"
        });
        toastEvent.fire();              
                
            }
            
        });
        $A.enqueueAction(action);
    },
    
     showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    
    
    
    
    
    onTabSelect : function(component, event, helper) {
        // component.set("v.repairOrderDetailView", true);   
        
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        if(id == 'repairOrderInfo'){
            component.set("v.tr", false);   
            component.set("v.fr", true);
        }
        else{component.set("v.tr", true);   
             component.set("v.fr", false);}
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
        if(id == 'repairOrderInfo'){
           // helper.getRoDetails(component,event,helper);
        }
        
    },
    
    savRO : function(component, event, helper) {
        debugger;
        var valid = "true";
        var jobActivities = component.get("v.jobActivities");
        var repairOrder = component.get("v.repairOrder");
        var workorderid=component.get('v.repairOrderId');
       // var insurence=component.get('v.insurancecompany');
        // var insur = component.find("insuranceComp").get("v.value");
        
         if(helper.validatePartForm(component,event, helper)) {
        if(repairOrder.Status == "Completed" || repairOrder.Status == "Closed")
            for(var i=0; i<jobActivities.length; i++)
            {
                if(jobActivities[i].PSA_Status__c != "Completed")
                    valid = "false";
            }
        if(valid == "true")
        {
            
            var action = component.get("c.saveROdetails");
            action.setParams({
                "jobActivities" : jobActivities,
                "repairOrder" : repairOrder,
              // "insurence" : insurence
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                
                if (state === "SUCCESS") {
                    helper.getRoDetails(component,event,helper);
                    helper.successToast(component, event, helper, "The details Updated successfully.");
                    helper.uploadHelper(component, event,workorderid);
                 }
            });
            $A.enqueueAction(action);
        }else{
            helper.errorToast(component, event, "Please complete all the Job activities to close the Repair order");
        }
         }
    },
    
    savfrntRO : function(component, event, helper) {
        var repairOrder = component.get("v.repairOrder");
   //   if(repairOrder.Status == "Completed" || repairOrder.Status == "Closed"){
            var action = component.get("c.saveFrontROdetails");
            action.setParams({
                    "repairOrder" : repairOrder
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                
                if (state === "SUCCESS") {
                 //   helper.getRoDetails(component,event,helper);
                    helper.successToast(component, event, helper, "The details Updated successfully.");
                   
                }
            });
           
    //  }
         $A.enqueueAction(action);
    },
     handleFilesChange: function(component, event, helper) {
        
        var fileName = 'No File Selected..'; 
        fileName = event.getSource().get("v.files")[0]['name'];   
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
          helper.checkfilesize(component, event);
      /*  if(ext == "png" || ext == "PNG" || ext == "JPEG" || ext == "jpeg" || ext == "jpg" || ext == "JPG"){
            helper.checkfilesize(component, event);
        } else{ 
            component.set('v.fileName','');
        var message='Upload only png or jpg files';
        helper.errorToast(component, event, message);
        } */
    },
    roclosedateupdate : function(cmp, event) {
        var Rocloseddate = event.getParam("roclosedate");
        
        // set the handler attributes based on event data
        cmp.set("v.Roclosedateupdate", Rocloseddate);
        
    },
    
    handleWOstatus : function(component,event,helper){
        
        helper.handleWOmainstatus(component,event,helper);
             /*   var jobactivities = component.get("v.jobActivities");
        var d=0;disRadio="{!v.disRadio}"
        for(var i=0; i<jobactivities.length; i++){
          if(jobactivities[i].PSA_Status__c == 'Completed'){
                d=d+1;
               
                  }
            
            if(jobactivities.length==parseInt(d))
            { component.set("v.disRadio", false);
 
                 }else{
                     
                     component.set("v.fileName", true);
                     component.set("v.repairOrder.PSA_Customer_Confirmation_on_Add_Job__c",false);
    
                     
                }  }*/
    },
    
    RODetailPDF:function(component,event,helper){
        var recordId = component.get("v.repairOrderId");
        
     //   alert(recordId);
        var pdfurl ='../PSA_RepairOrderPDF?id='+recordId;
        window.open(pdfurl,"_blank", "width=600, height=550");   
      
      },
    addNewRow: function(component, event, helper) {
         helper.createObjectData(component, event);
    },
    Moless: function(component, event, helper) {
   debugger;
        component.set("v.fm", false);
        component.set("v.mf", true);
    },
     lessmo: function(component, event, helper) {
        
        component.set("v.fm",true );
        component.set("v.mf", false);
    },
     Moles: function(component, event, helper) {
        
        component.set("v.fml", false);
        component.set("v.mfl", true);
    },
     lessm: function(component, event, helper) {
        
        component.set("v.fml",true );
        component.set("v.mfl", false);
     
         
       
        
    },
     Mole: function(component, event, helper) {
        component.set("v.showMore", true);
        component.set("v.fmm", false);
     
     
       
    },
     lesm: function(component, event, helper) {
        
        component.set("v.fmm",true );
        component.set("v.showMore", false);
    },
    removeDeletedRow: function(component, event, helper) {
        var index = event.getParam("indexVar");
        var AllRowsList = component.get("v.LineItemlist");
        AllRowsList.splice(index, 1);
        component.set("v.LineItemlist", AllRowsList);
    },
     removeLabourDeletedRow: function(component, event, helper) {
        var index = event.getParam("indexVar");
        var AllRowsList = component.get("v.Joblabourlist");
        AllRowsList.splice(index, 1);
        component.set("v.Joblabourlist", AllRowsList);
    },
      addLabourNewRow: function(component, event, helper) {
         helper.createjobData(component, event);
    },
    
    ModelOpen: function(component, event, helper) {
        component.set("v.disablesave",false);
         component.set('v.partsdisabled',false);
        component.set("v.totalreturnValue", 0);
         helper.createjobData(component, event);
        helper.createObjectData(component, event);
         
        document.getElementById("myModal").style.display = "block";
    }, 
    closemodel: function(component, event, helper) {
      /*  var lineitemlist=component.get('v.LineItemlist');
         var joblist=component.get('v.Joblabourlist');
        for(var i=lineitemlist.length; i>0; i--){
            lineitemlist.splice(0, 1);
        }
        component.set("v.LineItemlist", lineitemlist);
         for(var i=joblist.length; i>0; i--){
            joblist.splice(0, 1);
        }
        component.set("v.Joblabourlist", joblist);
        document.getElementById("myModal").style.display = "none";
  */
         helper.deleterow(component,event);
        
    },
    AddItems: function(component, event, helper) {
       var a = event.getSource();
		var id = a.getLocalId(); 
        var isvalid = true;
        var finalvalidity=true;
          var childCmp = component.find("partdetailchild");
        if(childCmp.length){
            
            for(var i=0; i<childCmp.length; i++){
              
                isvalid=childCmp[i].requiredfieldscheck();
                if(!isvalid)
                    finalvalidity=false;
            }
            
        } else{
            isvalid=childCmp.requiredfieldscheck();
        } 
        var validation=helper.validation(component, event);
        
        if(finalvalidity && isvalid && validation)
            helper.addlineitems(component, event,id);
    },
    mobvalidate  : function(component, event, helper) {
        var mobinp = component.find("").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(mobinp))
            component.find("MobileNo").set("v.value", mobinp.substring(0, mobinp.length - 1));
    },
     repairsview : function(component, event, helper) {
        var target = event.getSource().get('v.value');
        var repairEvent = component.getEvent("RepairOrderIdPass");
        repairEvent.setParams({"Id" : target });
    	repairEvent.fire();
        
    }, 
     combinationtotalshare : function(component, event, helper) {
         var whichOne = event.getSource().getLocalId();
         var oemshareperc = component.find('oemshare').get('v.value');
        var dealershareperc = component.find('dealershare').get('v.value');
        var customershareperc = component.find('customershare').get('v.value');
         var insuranceshareperc = component.find('insuranceshare').get('v.value');
          if(insuranceshareperc=='undefined' || insuranceshareperc==null){
             insuranceshareperc=0;
            component.find('insuranceshare').set('v.value',0);
         }

         if(customershareperc=='undefined' || customershareperc==null){
             customershareperc=0;
            component.find('customershare').set('v.value',0);
         }
         if( dealershareperc=='undefined' || dealershareperc==null){
             dealershareperc=0;
             component.find('dealershare').set('v.value',0);
             
         }
         if(oemshareperc=='undefined' || oemshareperc==null){
             oemshareperc=0;
             component.find('oemshare').set('v.value',0);
         } 
         component.set('v.sharevalue',parseInt(oemshareperc+dealershareperc+customershareperc+insuranceshareperc));
        // alert(component.get('v.sharevalue'));
        if(parseInt(oemshareperc+dealershareperc+customershareperc+insuranceshareperc) > 100 ){
            component.find(whichOne).set('v.value','');
        	helper.errorToast(component, event, 'The combination of OEM, Dealer, Customer & Insurance shares should be Equal to 100 percent');
        }
     },
     jobchange : function(component, event, helper) {
         component.set("v.rerarkserrmsg",'');
     },
    handleStatus: function(component, event, helper) {
         var listPage = event.getParam("StatusService");
       
            component.set("v.repairOrder.Status", listPage);
                 if(listPage=='Closed')
                {
                component.set("v.checkingRoStatus", true);
                component.set("v.disSerInfoFields", true); 
                }
           
        },
    handleSubStatus: function(component, event, helper) {
         var listPage = event.getParam("subStatus");
       
            component.set("v.subStatus", listPage);
            // component.set("v.repairOrder.PSA_Sub_status__c", listPage);
        },
    getdistrict : function(component, event, helper){
       var s=[];
       var d= component.get("v.repairOrder");
       var selectstate = d.PSA_Service_Category__c;
        
        
            if (selectstate == "Bodyshop")
            {
                //s.push('--None--');
                s.push('ACCIDENTAL');
                component.set("v.serviceTypestatusList",s);
            }
           if (selectstate == "Mechanical")
            {
               // s.push('--None--');
                s.push('1ST FREE SERVICE');
                s.push('2ND FREE SERVICE');
                s.push('3RD FREE SERVICE');
                s.push('CAMPAIGN');
                s.push('General Repair');
                s.push('PDI SERVICE');
                s.push('PMS SERVICE');
                s.push('PRE-SALE');
                s.push('Warranty');
                component.set("v.serviceTypestatusList",s);
                
            }
        component.set("v.repairOrder.PSA_Service_Type__c",null);
    },
     handlevalidateMenu : function(component, event, helper) {
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        var defaultItem = event.getParam("defaultItem");
        console.log("validationItem -- "+validationItem+"::"+defaultItem);
        if (defaultItem) {
        	component.set("v.currTab", validationItem);            
        }
    },
    insurencechange : function(component, event, helper) {
        var insurence=component.find('insuranceComp').get('v.value');
       // alert(insurence);
    },
    handlePrJob : function(component, event, helper) {
        var checkCmp1 =component.find("Prjob").get("v.value");
        var checkCmp1 =component.find("SeJob").get("v.value");
        var checkCmp2 =component.find("Addjob").get("v.value");
		component.find("SeJob").set("v.value", false);
        component.find("Addjob").set("v.value", false);

    },
    triggerCalc:function(component, event, helper){
        var PartsSelListEdit = component.get("v.LineItemlist");
        var jobsSelListEdit = component.get("v.Joblabourlist");
        var i;
        var x;
        var totalInvoiceValue = 0;
        for(i in PartsSelListEdit)
        {
            var rec = PartsSelListEdit[i];
            if(rec.PSA_Parts_Amounts_Exl_Tax__c=='undefined' ||rec.PSA_Parts_Amounts_Exl_Tax__c==null )
            {
                //rec.PSA_Parts_Amounts_Exl_Tax__c=0;
            }
            else {totalInvoiceValue = rec.PSA_Parts_Amounts_Exl_Tax__c+totalInvoiceValue;}
            
        }
        for(x in jobsSelListEdit)
        {
            var rec = jobsSelListEdit[x];
            if(rec.PSA_Total_Price__c=='undefined' ||rec.PSA_Total_Price__c==null ||rec.PSA_Total_Price__c=='')
            {
                //rec.PSA_Total_Price__c=0;
               
            }
            else{
            totalInvoiceValue += rec.PSA_Total_Price__c;
            }
                       
        }
        component.set("v.totalreturnValue", (Math.round(totalInvoiceValue * 100) / 100).toFixed(2));
    },

    //(Math.round(totalInvoiceValue * 100) / 100).toFixed(2);
        onprimary:function(component, event, helper){
            debugger;
           // var active=component.find("v.primaryjob").get("v.value");
            var checkvalue = component.find("primaryjob");
            var secondaryjob = component.find("secondaryjob");
            var additionaljob = component.find("additionaljob");
            var target = event.getSource().get("v.text");
            var active = event.getSource().get("v.value");
           
             for (var i = 0; i < checkvalue.length; i++) {
               
             if(checkvalue[i].get("v.text")==target)
              { 
              if(checkvalue[i].get("v.value"))
              {
               additionaljob[i].set("v.value",false);
               secondaryjob[i].set("v.value",false);
              }
        }
             }
            
            
    },
          onsecondary:function(component, event, helper){
            var checkvalue = component.find("primaryjob");
            var secondaryjob = component.find("secondaryjob");
            var additionaljob = component.find("additionaljob");
            var target = event.getSource().get("v.text");
            var active = event.getSource().get("v.value");
           
             for (var i = 0; i < secondaryjob.length; i++) {
               
             if(secondaryjob[i].get("v.text")==target)
              { 
              if(secondaryjob[i].get("v.value"))
              {
               checkvalue[i].set("v.value",false);
               additionaljob[i].set("v.value",false);
              }
        }
             }
            
        
    },
      onadditional:function(component, event, helper){
            var checkvalue = component.find("primaryjob");
            var secondaryjob = component.find("secondaryjob");
            var additionaljob = component.find("additionaljob");
            var target = event.getSource().get("v.text");
            var active = event.getSource().get("v.value");
           
             for (var i = 0; i < additionaljob.length; i++) {
               
             if(additionaljob[i].get("v.text")==target)
              { 
              if(additionaljob[i].get("v.value"))
              {
               checkvalue[i].set("v.value",false);
               secondaryjob[i].set("v.value",false);
              }
        }
             }
            
        
    },
    getShareValues:function(component, event, helper){
        debugger;
       var selectIssueType = component.find("issuetype").get("v.value");
        if(selectIssueType == "--None--")
        {
            component.set("v.oemDisabled",true);
            component.set("v.dealDisabled",true);
            component.set("v.cusDisabled",true);
            component.set("v.insDisabled",true);
            component.find("oemshare").set("v.value",0);
            component.find("dealershare").set("v.value",0);
            component.find("insuranceshare").set("v.value",0);
            component.find("customershare").set("v.value",0);
            component.set('v.sharevalue',0);
        }
        if(selectIssueType == "Customer Paid"){
            component.set("v.oemDisabled",true);
            component.set("v.dealDisabled",true);
            component.set("v.cusDisabled",true);
            component.set("v.insDisabled",true);
            component.find("oemshare").set("v.value",0);
            component.find("dealershare").set("v.value",0);
            component.find("insuranceshare").set("v.value",0);
            component.find("customershare").set("v.value",100);
            component.set('v.sharevalue',100);
        }
        if(selectIssueType == "Warranty"){
            component.set("v.oemDisabled",true);
            component.set("v.dealDisabled",true);
            component.set("v.cusDisabled",true);
            component.set("v.insDisabled",true);
            component.find("oemshare").set("v.value",100);
            component.set('v.sharevalue',100);
            component.find("dealershare").set("v.value",0);
            component.find("insuranceshare").set("v.value",0);
            component.find("customershare").set("v.value",0);
        }
         if(selectIssueType == "Internal"){
            component.set("v.oemDisabled",true);
            component.set("v.dealDisabled",true);
            component.set("v.cusDisabled",true);
            component.set("v.insDisabled",true);
            component.find("oemshare").set("v.value",0);
            component.find("dealershare").set("v.value",100);
            component.set('v.sharevalue',100);
            component.find("insuranceshare").set("v.value",0);
            component.find("customershare").set("v.value",0);
             
        }
        if(selectIssueType == "Insurance"){
            component.set("v.oemDisabled",true);
            component.set("v.dealDisabled",true);
            component.set("v.cusDisabled",false);
            component.set("v.insDisabled",false);
            component.find("oemshare").set("v.value",0);
            component.set('v.sharevalue',0);
            component.find("dealershare").set("v.value",0);
            component.find("insuranceshare").set("v.value",0);
            component.find("customershare").set("v.value",0);
        }

    },
     Pinvalidate  : function(component, event, helper) {
        var mobinp = component.get("v.repairOrder.PSA_Driver_Contact_No__c");
      if(isNaN(mobinp))
            component.set("v.repairOrder.PSA_Driver_Contact_No__c", mobinp.substring(0, mobinp.length - 1));
    },
    checkTrue:function(component,event,helper)
    {
        		 //var selected = evt.getSource().get("v.label");
        component.set("v.repairOrder.PSA_Customer_Waiting__c",true);
        //component.find("yes").set("v.value",true);
    },
   checkFalse :function(component,event,helper)
    {
        		 //var selected = evt.getSource().get("v.label");
        component.set("v.repairOrder.PSA_Customer_Waiting__c",false);
               // component.set("v.value",true);

    },
    
})
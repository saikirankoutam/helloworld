({
    getCarNames : function(component, event) {
        
        var action = component.get("c.getCarMethod");
       
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.carBrands", response.getReturnValue());
             }
        });
        $A.enqueueAction(action);
        
    },
    
    getFirmOrder : function(component, event, monthName) {
        
        var action = component.get("c.formDemoMap");
       	action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.demoMap", response.getReturnValue());
             }
        });
        $A.enqueueAction(action);
        var CitreonSE21ItemList = component.get("v.CitreonSE21ItemList");
        CitreonSE21ItemList.push({
            'sobjectType': 'orderItem',
            'Product2.PSA_Variant__c': '',
            'Product2.PSA_Ext_Colour__c': '',
            'Product2.Exterior_Color__c': '',
            'Product2.Interior_Color__c': '',
            'Product2.Metallic_Non_Metallic__c':''
            
        });
        component.set("v.CitreonSE21ItemList", CitreonSE21ItemList);
        component.set("v.CitreonC84ItemList", CitreonSE21ItemList);
        component.set("v.demoItems", CitreonSE21ItemList);
        component.set("v.spinner", false);
        
    },
    
    showError : function(component, event, helper, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
        component.set("v.spinner", false);
    },
    showSuccess : function(component, event, helper, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "success",
            "message": msg
        });
        toastEvent.fire();
        component.set("v.spinner", false);
        
    }, 
    
    getPlantItems : function(component, event, helper) {
        var action = component.get("c.fetchPlantValues");
       	action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var val = response.getReturnValue();
                component.set("v.plantItems", response.getReturnValue());
             }
        });
        $A.enqueueAction(action);
    },
})
({
    preventalphabets : function(component, event, helper){
        var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
        
    },
    
    calctotalvalue : function(component, event, helper){        
        if(component.get("v.prevstockvalue") == null || component.get("v.prevstockvalue") == undefined){
            var stockqty = component.find("astock").get('v.value');
            component.set("v.prevstockvalue", stockqty);
        }                
        if(component.find("returnqty").get('v.value') > component.find("issueqty").get('v.value')){
            helper.showtoast(component, event, 'Return qty should not be greater than Issued qty!');
            component.find("returnqty").set("v.value", "");
            component.find("totalval").set("v.value", "");
        }
        else{
            var rqty = component.find("returnqty").get('v.value');
            var availqty = component.find("astock").get('v.value');
            if(rqty != null && rqty != "")
            	component.find("astock").set("v.value", parseInt(component.get("v.prevstockvalue"))+parseInt(rqty));
            else
                component.find("astock").set("v.value", component.get("v.prevstockvalue"));
            
            var mrp = component.find("mrp").get('v.value');
            var tval = parseInt(rqty)*parseInt(mrp);
            component.find("totalval").set("v.value", tval);            
        }
    },
    
    combinationtotalshare : function(component, event, helper){        
        var oemshareperc = component.get('v.wolineitem.oemshare');
        var dealershareperc = component.get('v.wolineitem.dealershare');
        var customershareperc = component.get('v.wolineitem.customershare');
        var insuranceshareperc = component.get('v.wolineitem.insuranceshare');
        if(parseInt(oemshareperc+dealershareperc+customershareperc+insuranceshareperc) > 100){
        	helper.showtoast(component, event, 'The combination of OEM, Dealer, Customer & Insurance shares should not be greater than 100 percent');
        }
    },
        
    Savepartsconsumables : function(component, event, helper){        
        var wolineitemrecid = component.get('v.woid');
        var partnum = component.get('v.wolineitem.partno');
        var issuedqty = component.get('v.wolineitem.issueqty');
        var returnqty = component.get('v.wolineitem.returnqty');
        var oemshareperc = component.get('v.wolineitem.oemshare');
        var dealershareperc = component.get('v.wolineitem.dealershare');
        var customershareperc = component.get('v.wolineitem.customershare');
        var insuranceshareperc = component.get('v.wolineitem.insuranceshare');
        var totalvalueprice = component.get('v.wolineitem.totalvalue');
        var singlequantityissued = [];
        if(returnqty==null || returnqty == '' || returnqty == undefined)
            returnqty = 0;
         if(totalvalueprice==null || totalvalueprice == '' || totalvalueprice == undefined)
            totalvalueprice = 0;

        singlequantityissued.push({
            'sobjectType': 'WorkOrderLineItem',
            'Id': wolineitemrecid,
            'PSA_Part_Number__c' : partnum,
            'PSA_Issued_Quantity__c': issuedqty,
            'PSA_OEM_Sharing__c': oemshareperc,
            'PSA_Dealer_Sharing__c': dealershareperc,
            'PSA_Customer_Sharing__c' : customershareperc,
            'PSA_Insurance_Sharing__c' : insuranceshareperc,
            'PSA_Return_Quantity__c' : returnqty,
            'TotalPrice' : totalvalueprice
        });   
        
        var astock = component.find("astock").get('v.value');
        var rqty = component.find("returnqty").get('v.value');
        var iqty = component.find("issueqty").get('v.value');
        //component.find("issueqty").set("v.value", (parseInt(iqty)-parseInt(rqty)));
        //component.find("astock").set("v.value", (parseInt(astock) + parseInt(rqty)));
        
        var returnqtytoparent = component.getEvent("partsconsumablesevent");
        returnqtytoparent.setParams({"ordlist" : singlequantityissued});
        returnqtytoparent.fire();
    }
})
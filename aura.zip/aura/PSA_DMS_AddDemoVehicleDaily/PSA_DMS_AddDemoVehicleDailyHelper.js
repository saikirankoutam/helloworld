({
	removeProduct : function(component, event, helper, demoType){
        var productId = component.get("v.productId");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var mapFirm = component.get("v.demoMap");
        		if(typeof mapFirm[demoType] !== 'undefined')
                {
                    var mapFirmValue = mapFirm[demoType];
                        delete mapFirmValue[productId];
                    mapFirm[demoType] = mapFirmValue;  
                }
            component.set("v.demoMap", mapFirm);
        }
        component.set("v.productId", "");
        component.set("v.quantity", 0);
        component.set("v.disableQuantity", true);
	},
})
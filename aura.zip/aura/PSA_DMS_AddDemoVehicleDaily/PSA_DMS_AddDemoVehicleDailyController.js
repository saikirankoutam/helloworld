({
	doInit : function(component, event, helper){
        var action = component.get("c.getInitalDemoDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.brandList", value['brand']);
                component.set("v.ordertypeList", value['orderType']);
                component.set("v.disableQuantity", true);
            }
        });
        $A.enqueueAction(action);	
    },
    
    savePreviousTypeValue : function(component, event, helper){
        component.set("v.previousdemoType", component.find("demoType").get("v.value"));
    },
    
    enableRow : function(component, event, helper){
        var demoType = component.get("v.previousdemoType");
        helper.removeProduct(component, event, helper, demoType);
        component.find("brand").set("v.value", "");  
        component.find("variant").set("v.value", "");
        component.find("metallic").set("v.value", "");
        component.find("colour").set("v.value", "");
        component.find("intTrim").set("v.value", "");
        component.find("Intcolour").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disBrand", "false");
        component.set("v.disVariant", "true");
        component.set("v.disMetallic", "true");
        component.set("v.disColour", "true");
        component.set("v.disIntTrim", "true");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");            
    },
    
    getVariant : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        component.find("variant").set("v.value", "");
        component.set("v.disVariant", "true");
        var action = component.get("c.getCarVariant");
        action.setParams({ 
            "selModel" : selectvalmodel
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.variantList", response.getReturnValue());
            component.set("v.disVariant", "false");
            }
        });
        $A.enqueueAction(action);
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        component.find("metallic").set("v.value", "");
        component.find("colour").set("v.value", "");
        component.find("intTrim").set("v.value", "");
        component.find("Intcolour").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disMetallic", "true");
        component.set("v.disColour", "true");
        component.set("v.disIntTrim", "true");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
    },
    
    getmetallicList : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        component.find("metallic").set("v.value", "");
        component.set("v.disMetallic", "true");
        var action = component.get("c.getCarMetallicColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel            
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.metallicList", response.getReturnValue());
            component.set("v.disMetallic", "false");
            }
        });
        $A.enqueueAction(action);
        var demoType = component.find("demoType").get("v.value");	
        helper.removeProduct(component, event, helper, demoType);
        component.find("colour").set("v.value", "");
        component.find("intTrim").set("v.value", "");
        component.find("Intcolour").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disColour", "true");
        component.set("v.disIntTrim", "true");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");        
    },
    
    getColour : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        component.find("colour").set("v.value", "");
        component.set("v.disColour", "true");
        var action = component.get("c.getCarColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.colourList", response.getReturnValue());
            component.set("v.disColour", "false");
            }
        });
        $A.enqueueAction(action);	
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        component.find("intTrim").set("v.value", "");
        component.find("Intcolour").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disIntTrim", "true");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
    },
    
    getIntTrimType : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        var color = component.find("colour").get("v.value");
        component.find("intTrim").set("v.value", "");
        component.set("v.disIntTrim", "true");
        var action = component.get("c.getCarIntTrimType");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.IntTrimList", response.getReturnValue());
            component.set("v.disIntTrim", "false");
            }
        });
        $A.enqueueAction(action);	
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        
        component.find("Intcolour").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
        
    },
    
    getIntcolourList : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        var color = component.find("colour").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        component.find("Intcolour").set("v.value", "");
        component.set("v.disIntColour", "true");
        var action = component.get("c.getCarIntColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.IntcolourList", response.getReturnValue());
            component.set("v.disIntColour", "false");
            }
        });
        $A.enqueueAction(action);	
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
        
    },
    
    getRoofList : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        var color = component.find("colour").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        var interiorcolor = component.find("Intcolour").get("v.value");
        component.find("roof").set("v.value", "");
        component.set("v.disRoof", "true");
        var action = component.get("c.getCarRoof");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim,
            "selIntcolor" : interiorcolor
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.RoofList", response.getReturnValue());
            component.set("v.disRoof", "false");
            }
        });
        $A.enqueueAction(action);	
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        component.find("pack").set("v.value", "");
        component.set("v.disPack", "true");
        
    },
    
    getPackList : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        var color = component.find("colour").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        var interiorcolor = component.find("Intcolour").get("v.value");
        var roof = component.find("roof").get("v.value");
        component.find("pack").set("v.value", "");
        component.set("v.disPack", "true");
        var action = component.get("c.getCarPack");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim,
            "selIntcolor" : interiorcolor,
            "selRoof" : roof
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.PackList", response.getReturnValue());
            component.set("v.disPack", "false");
            }
        });
        $A.enqueueAction(action);	
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        
    },
    
    getId : function(component, event, helper){
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        component.set("v.disableQuantity", false);
        var itemInstance = component.get("v.itemInstance");
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        var color = component.find("colour").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        var interiorcolor = component.find("Intcolour").get("v.value");
        var roof = component.find("roof").get("v.value");
        var pack = component.find("pack").get("v.value");
        component.set("v.quantity", "");
        var action = component.get("c.getProductId");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim,
            "selIntcolor" : interiorcolor,
            "selRoof" : roof,
            "selPack" : pack     
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                if(value)
                {
                    component.set("v.productId", value.Id);
                }
            }
        });
        $A.enqueueAction(action);	
        
        
    },
    
    
    addRow : function(component, event, helper){
        var compEvent = component.getEvent("AddDeleteRowsDemoDaily");
       	compEvent.setParams({
            "addDelete": "add",
            "rowNumber": component.get("v.rowIndex")
            
        });
        compEvent.fire();
    },
    
    DeleteRow : function(component, event, helper){
        
        var productId = component.get("v.productId");
        var demoType = component.find("demoType").get("v.value");
        var demoMap = component.get("v.demoMap");
        
        var compEvent = component.getEvent("AddDeleteRowsDemoDaily");
       	compEvent.setParams({
            "addDelete": "del",
            "rowNumber": component.get("v.rowIndex")
            
        });
        compEvent.fire();
        if(typeof productId !== 'undefined' && productId != "")
        {
            if(typeof demoMap[demoType] !== 'undefined')
            {
                var mapFirmValue = demoMap[demoType];
                delete mapFirmValue[productId];
                demoMap[demoType] = mapFirmValue;  
            }
            component.set("v.demoMap", demoMap);
        }
    },
    
    addProducts : function(component, event, helper){
        var productId = component.get("v.productId");
        var q = component.get("v.quantity");
        var demoType = component.find("demoType").get("v.value");
        var demoMap = component.get("v.demoMap");
        if(typeof productId !== 'undefined' && productId != "")
        {
            if(typeof demoMap[demoType] !== 'undefined')
            {
                var mapFirmValue = demoMap[demoType];
                if(q == 0 || q =="")
                    delete mapFirmValue[productId];
                else
                    mapFirmValue[productId] = q;
                demoMap[demoType] = mapFirmValue;  
            }
            component.set("v.demoMap", demoMap);
        }else{
            component.set("v.quantity", 0);
        }
    },
})
({
    buildChart : function(component, records) {
        
        var regular = 0;
        var irregular = 0;
        var sporadic = 0;
        
        if(records)
            for(var i=0; i<records.length; i++)
            {
                if(records[i].RIS == "Regular")
                    regular = regular+1;
                if(records[i].RIS == "Irregular")
                    irregular = irregular+1;
                if(records[i].RIS == "Sporadic")
                    sporadic = sporadic+1;
            }
        var label = ["Regular","Irregular","Sporadic"];
        var color = ["#8B0000","#e69500","#696969"];
        var quantity = [regular,irregular,sporadic];
        var el = component.find('partStockChart').getElement();
        var ctx = el.getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: label,
                datasets: [
                    {
                        label: "Payments History",
                        backgroundColor: color,
                        data: quantity
                    }
                ]
            },
            options: {
                legend: {
                    display: true,
                    position: 'bottom'
                }
            },
            });
        
    },
      
   getSupplierlist : function(component, event) {        
    var action = component.get('c.getCurrentStockDetails');
       
        	action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.data", records);
                component.set("v.reportlist", records);
                 component.set("v.orderwrapper", records);
             
				component.set("v.invoicescount", records.length);                
                var pageSize = component.get("v.pageSize");
                component.set("v.receipts", records);
                component.set("v.totalSize", component.get("v.receipts").length);
                    component.set("v.start",0);
                    component.set("v.end",pageSize-1);
                    var paginationList = [];
                    if(response.getReturnValue().length < pageSize){
                        paginationList=response.getReturnValue();
                    }
                    else{
                        for(var i=0; i< pageSize; i++){
                            paginationList.push(response.getReturnValue()[i]); 
                        } 
                    }
                    
                    component.set('v.paginationList', paginationList);
                	this.helperMethodPagination(component, event, '1');
     
                
            }
        });
        $A.enqueueAction(action);
    },
        helperMethodPagination : function(component, event, pageNumber){
        var pageSize = component.get("v.pageSize");//Number Of Row Per Page
        var totalpage=Math.ceil(component.get("v.receipts").length/pageSize);//Number Of Total Pages
        var   paginationPageNumb=[];
        var cont=1;
        /*---Pagination Logic Start--*/
        if(pageNumber<=7){ 
            
            for(var i=1; i<= totalpage; i++){
              
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
                  paginationPageNumb.push(i);
            }
            
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
               paginationPageNumb.push(i);
           
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }
        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    },
     convertArrayOfObjectsToCSV : function(component,objectRecords){
         debugger;
        // declare variables
        var csvStringResult, counter, keys, columnDivider, lineDivider;
        
        // check if "objectRecords" parameter is null, then return from function
        if (objectRecords == null || !objectRecords.length) {
            return null;
        }
        // store ,[comma] in columnDivider variabel for sparate CSV values and 
        // for start next line use '\n' [new line] in lineDivider varaible  
        columnDivider = ',';
        lineDivider =  '\n'; 
        // in the keys valirable store fields API Names as a key 
        // this labels use in CSV file header  
        //   keys = ['PSA_SO_Status__c','PSA_VIN_Number__c','PSA_Truck_Number__c','PSA_Lorry_Receipt_Number__c','PSA_Planned_Invoice_Date__c','PSA_Invoice_Date__c','PSA_Order_Item__r.PSA_Variant__c'];
        keys = ['region','DealerCode','Name','partNumber','partDescription','HSN','Active','gstTaxCategory','partCategory',
               'OEMpartIdentification','NDP','sellingPrice','currency','openQuantity','receiptQuantity','invoicedQuantity',
               'closingQuantity','openingValue','receiptValue','issueValue','closingValue','ABC','HML'];
        
        csvStringResult = '';
        //csvStringResult += keys.join(columnDivider);
            csvStringResult += ['Region','DealerCode','Name','PartNumber','PartDescription','HSN','Active','GstTaxCategory','PartCategory',
               'OEMPartIdentification','NDP','SellingPrice','Currency','OpenQuantity','ReceiptQuantity','InvoicedQuantity',
               'ClosingQuantity','OpeningValue','ReceiptValue','IssueValue','ClosingValue','ABC','HML'];
        
        csvStringResult += lineDivider;
        
        for(var i=0; i < objectRecords.length; i++){   
            counter = 0;           
            for(var sTempkey in keys) {
                var skey = keys[sTempkey] ;  
             
                if(counter > 0){ 
                    csvStringResult += columnDivider; 
                }                  
                 if(objectRecords[i][skey] != undefined ){
                         csvStringResult += '"'+ objectRecords[i][skey]+'"';
                }else{
                    csvStringResult += '"'+ '' +'"';
                }              

                counter++;
                
            } 
            csvStringResult += lineDivider;
        }       
        // return the CSV formate String 
        return csvStringResult;        
    },
      wrapperdataloading: function (component, event, helper) {  
        var action = component.get('c.getCurrentStockDetails');      
        
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.orderwrapper", records);
                
                // helper.sortData(component, component.get("v.sortedBy"), component.get("v.sortedDirection"));
            }else{
                //  component.set("v.spinner", false);
            }  
        });
        $A.enqueueAction(action);
    },
    

})
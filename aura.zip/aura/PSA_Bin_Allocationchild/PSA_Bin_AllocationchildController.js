({
    Binchange:function(component,event,helper){ 
        var binselect = component.find("binc").get("v.value");
        if(binselect.includes("--None--")){
            var previousvalue=component.get("v.binselected");
            component.set("v.binselected",'');
            var eventListPage = component.getEvent("removeselectedvalues");
            eventListPage.setParams({"CNFStatus" : previousvalue});
            eventListPage.fire(); 
        }else{
            var binslist=component.get('v.Binlist');
            var index=component.get('v.rowIndex');
            component.set("v.binselected",binselect);
            var eventListPage = component.getEvent("Addselectedvalues");
            eventListPage.setParams({"CNFStatus" : binselect,"Id" : index});
            eventListPage.fire();   
        }
        
    },
    doInit:function(component,event,helper){  
    helper.Binlistmethod(component,event);
    },
    validationmethod:function(component,event,helper){
        var binselect = component.find("binc").set("v.value",'--None--');
        component.set("v.binselected",'');
        component.set('v.binselectedid','');
    },
    checknonevaluesmethod:function(component,event,helper){
        var binvalue = component.find("binc").get("v.value");
        if(binvalue=='--None--' || binvalue=='' || binvalue=='undefined'){
            var eventListPage = component.getEvent("nonvaluescheck");  
            eventListPage.fire();
        }
    },
    saverecordsmethod:function(component,event,helper){
        var partsids = component.get('v.partid');
        var partrecord = component.get('v.Binrecord');
        var selectedbins = component.get('v.binselected');
        var binitems= [];
        binitems.push({
                    'sobjectType': 'PSA_BinPosition__c',
                    'Id': partsids,
                    'PSA_BinName__c': selectedbins,
                     'Name' : partrecord.PSA_Part_Number__c
            
                    
                });
        var binmapsent = component.getEvent("binsmap");
        binmapsent.setParams({"ordlist" : binitems});
       binmapsent.fire();
    },
})
({
    Binlistmethod:function(component,event){
        var action = component.get('c.getbinlist');
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.Binlist", records); 
            }
        });
        $A.enqueueAction(action); 
    },
})
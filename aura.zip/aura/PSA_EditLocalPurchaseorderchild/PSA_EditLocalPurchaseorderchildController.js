({
    doInit: function(component, event, helper) {
       
        helper.getPartsList(component, event, helper);
        helper.getPartDetails123(component, event, helper);  
    },
    partDetails : function(component, event){
        debugger;
        component.set("v.Hsn",false);
        component.set("v.descrvisible",false);
        var partNamerecord = component.get("v.selectedLookUpRecord");
        var partName = partNamerecord.PSA_Part_Number__c;
               var partid=partNamerecord.Id;
       var mf=partNamerecord.PSA_Multiplication_Factor__c;
        component.set("v.multnfactr",mf);
        var partList = component.get("v.PartsList");
        var responsevalue = partList;
        console.log('partList>>>>>>>>>>>>'+JSON.stringify(partList));
        if(partName == "undefined" || partName == '' || partName == null){ 
          
            var Quantity = component.find("Quantity").get("v.value");
            var ratePerUnit = component.get("v.partRateperUnit");
            var TotalAmount = Quantity* ratePerUnit;
          
            //var GST = component.find("GST").get("v.value");
            var CGST = component.find("CGST").get("v.value");
            var SGST = component.find("SGST").get("v.value");
            var IGST = component.find("IGST").get("v.value");
            var CESS =component.find("cess").get("v.value");
            if(CGST === undefined){
            	CGST = 0;
        	}
         	if(SGST === undefined){
            	SGST = 0;
        	}
         	if(IGST === undefined){
            	IGST = 0;
        	}
 			if(CESS === undefined){
            	CESS = 0;
        	}
        
     	 var GST =parseInt(CGST)+parseInt(SGST)+parseInt(CESS);
           // var GSTamt =(TotalAmount/100)*GST;
            var GSTamt =(TotalAmount/100)*GST;
            if(Quantity=='undefined' || Quantity==''||Quantity==null){
                TotalAmount=0;
                GSTamt=0;
                
            }
            component.set("v.qyvisiable",true);
            component.set("v.partDescription","");
            component.set("v.HSNCode", "");
            component.set("v.UOM", "");
            component.set("v.PackQty", "");
            component.set("v.partRateperUnit", "");
            component.set("v.partTax", "");
            component.set("v.MinOrderQty", "");
           // component.set("v.GST","");
           	component.set("v.CGST","");
            component.set("v.IGST","");
            component.set("v.SGST","");
            component.set("v.CESS","");
            //component.set("v.BackOrderQty", "");
            component.set("v.VehicleQty", "");
            component.set("v.OrderQty", "");
            component.set("v.partTotalAmount",'0');
            component.set("v.partGSTAmount",'0');
              component.set("v.totalordervalue",'');
             component.set("v.taxable",'');
             component.set("v.totaltax",'');
            component.set("v.AvailableStock", "");
            component.set("v.disVariant", "false");
            component.set("v.assocIdval", "");
            component.find("Quantity").set("v.value", "");
             component.find("AvailableStock").set("v.value", "");
            component.set("v.NetDealerPrice", ''); 
            component.set("v.Hsn",true);
            component.set("v.descrvisible",true);
            component.getEvent("partnumempty").setParams({
                "deleteAmount" : TotalAmount,"deleteGSTAmount" :GSTamt}).fire();
            var partnumber = component.find("PartNumber").set("v.value",partName);
            
        }else{
            
            
            for(var i=0;i<responsevalue.length;i++){
                if(partName == responsevalue[i].PSA_Part_Number__c){
                    var partDesc = responsevalue[i].PSA_Parts_Description__c;
                    var partRte = responsevalue[i].PSA_Rate_per_Unit__c;
                    var partTx = responsevalue[i].PSA_Tax__c;
                    var igstval = responsevalue[i].PSA_IGST__c;
                    var cgstval = responsevalue[i].PSA_CGST__c;
                    var sgstval = responsevalue[i].PSA_SGST__c;
                    var cess = responsevalue[i].PSA_CESS__c;
                    var hsnCode = responsevalue[i].PSA_HSN_Code__c;
                    var uom = responsevalue[i].PSA_UOM__c;
                    var packQty = responsevalue[i].PSA_Pack_Quantity__c;
                    var qty=responsevalue[i].PSA_Quantity_Per_Vehicle__c;
                    var stock =  responsevalue[i].PSA_Quantity__c;
                    var partAssId = responsevalue[i].Id;
                    var qty=responsevalue[i].PSA_Quantity_Per_Vehicle__c;  
                    var moqi=responsevalue[i].PSA_Minimum_Order_Quantity__c;
                     if(moqi == 'undefined'|| moqi == "--None--" || moqi == null)
                     {
                         var moq='-';
                     }
                    else
                    {
                        var moq=responsevalue[i].PSA_Minimum_Order_Quantity__c;
                    }
                }
            }
            component.set("v.partDescription", partDesc);
            component.set("v.HSNCode", hsnCode);
            component.set("v.UOM", uom);
             component.set("v.qyvisiable",false);
            component.set("v.PackQty", packQty);
            component.set("v.VehicleQty", qty);
            component.set("v.partRateperUnit", partRte);
            component.set("v.partTax", partTx); 
            component.set("v.MinOrderQty", moq);
           // component.set("v.GST", igstval);
             component.set("v.CGST", cgstval);
             component.set("v.IGST", igstval);
             component.set("v.SGST", sgstval);
            component.set("v.CESS", cess);
            //component.set("v.BackOrderQty", "0");
            component.set("v.OrderQty", "-");
             component.find("AvailableStock").set("v.value", stock);
            //component.set("v.AvailableStock", stock);
            component.set("v.disVariant", "false");
            component.set("v.assocIdval", partAssId);
            component.set("v.Prdname", partName);
            component.set("v.NetDealerPrice",partRte); 
            var partnumber = component.find("PartNumber").set("v.value",partName);
          
              var partnumber =partid;
                
            component.find("Quantity").set("v.value", "");
           var stockrecord= partNamerecord.Dealer_Inventory__r;
                var stock=stockrecord[0].PSA_Current_Stock__c;
               
                 component.find("AvailableStock").set("v.value", stock);
        }
    },
    hsnchanges : function(component, event){
        component.set("v.PartNumbr",false);
        component.set("v.descrvisible",false);
        var partNamerecord = component.get("v.selectedLookUpRecordcode");
        var partName = partNamerecord.PSA_Part_Number__c;
        var partList = component.get("v.PartsList");
        component.set("v.partnumber1",partName);
        var responsevalue = partList;
        console.log('partList>>>>>>>>>>>>'+JSON.stringify(partList));
        if(partName == "undefined" || partName == '' || partName == null){ 
            
            var Quantity = component.find("Quantity").get("v.value");
            var ratePerUnit = component.get("v.partRateperUnit");
            var TotalAmount = Quantity* ratePerUnit;
            var CGST = component.find("CGST").get("v.value");
            var SGST = component.find("SGST").get("v.value");
            var IGST = component.find("IGST").get("v.value");
            var CESS =component.find("cess").get("v.value");
             if(CGST === undefined){
            	CGST = 0;
        	}
         	if(SGST === undefined){
            	SGST = 0;
        	}
         	if(IGST === undefined){
            	IGST = 0;
        	}
			
     	 	if(CESS === undefined){
            	CESS = 0;
        	}
        
     	 var GST =parseInt(CGST)+parseInt(SGST)+parseInt(IGST)+parseInt(CESS);
            //var GST = component.find("GST").get("v.value");
            var GSTamt =(TotalAmount/100)*GST;
            if(Quantity=='undefined' || Quantity==''||Quantity==null){
                TotalAmount=0;
                GSTamt=0;
                
            }
             component.set("v.qyvisiable",true);
            component.set("v.partDescription","");
            component.set("v.HSNCode", "");
            component.set("v.UOM", "");
            component.set("v.PackQty", "");
            component.set("v.partRateperUnit", "");
            component.set("v.partTax", "");
            component.set("v.MinOrderQty", "");
            //component.set("v.GST","");
            component.set("v.CGST","");
            component.set("v.IGST","");
            component.set("v.SGST","");
            component.set("v.CESS","");
            component.set("v.partnumber1",'');
            //component.set("v.BackOrderQty", "");
            component.set("v.OrderQty", "");
            component.set("v.partTotalAmount",'0');
            component.set("v.partGSTAmount",'0');
             component.find("AvailableStock").set("v.value", "");
           // component.set("v.AvailableStock", "");
            component.set("v.VehicleQty",'');
            component.set("v.disVariant", "false");
            component.set("v.assocIdval", "");
            component.find("Quantity").set("v.value", "");
            component.set("v.NetDealerPrice", ''); 
            component.set("v.PartNumbr",true);
            component.set("v.descrvisible",true); 
            component.getEvent("partnumempty").setParams({
                "deleteAmount" : TotalAmount,"deleteGSTAmount" :GSTamt}).fire();
            var partnumber = component.find("PartNumber").set("v.value",'');
             var quant =component.find("qty1").set("toastEvent",false);
            
        }else{
            
            
            for(var i=0;i<responsevalue.length;i++){
                if(partName == responsevalue[i].PSA_Part_Number__c){
                    var partDesc = responsevalue[i].PSA_Parts_Description__c;
                    var partRte = responsevalue[i].PSA_Rate_per_Unit__c;
                    var partTx = responsevalue[i].PSA_Tax__c;
                    var igstval = responsevalue[i].PSA_IGST__c;
                    var cgstval = responsevalue[i].PSA_CGST__c;
                    var sgstval = responsevalue[i].PSA_SGST__c;
                    var cess = responsevalue[i].PSA_CESS__c;
                    var hsnCode = responsevalue[i].PSA_HSN_Code__c;
                    var uom = responsevalue[i].PSA_UOM__c;
                    var packQty = responsevalue[i].PSA_Pack_Quantity__c;
                    var qty=responsevalue[i].PSA_Quantity_Per_Vehicle__c;
                    var stock =  responsevalue[i].PSA_Quantity__c;
                    var partAssId = responsevalue[i].Id;
                    var qty=responsevalue[i].PSA_Quantity_Per_Vehicle__c;
                    component.find("assocIdval").set("v.value",partAssId);
                    
                }
            }
            component.set("v.partDescription", partDesc);
            component.set("v.HSNCode", hsnCode);
            component.set("v.UOM", uom);
            component.set("v.PackQty", packQty);
             component.set("v.qyvisiable",false);
            component.set("v.VehicleQty",qty);
            component.set("v.partRateperUnit", partRte);
            component.set("v.partTax", partTx); 
            component.set("v.MinOrderQty", "0");
            //component.set("v.GST", igstval);
            component.set("v.CGST", cgstval);
             component.set("v.IGST", igstval);
             component.set("v.SGST", sgstval);
            component.set("v.CESS", cess);
            //component.set("v.BackOrderQty", "0");
            component.set("v.OrderQty", "-");
             component.find("AvailableStock").set("v.value", stock);
            //component.set("v.AvailableStock", stock);
            component.set("v.disVariant", "false");
            component.set("v.assocIdval", partAssId);
            component.set("v.Prdname", partName);
            component.find("Quantity").set("v.value", "");
            var partnumber = component.find("PartNumber").set("v.value",partName);
               var action=component.get('c.fetchCurrentStock');
                    action.setParams({
                        "partNum" : partName
                        
                    }); 
            action.setCallback(this, function(response){
             
                var responsevalue = response.getReturnValue();
                 component.find("AvailableStock").set("v.value", responsevalue);
             // component.set("v.AvailableStock",  responsevalue);
        });
                    $A.enqueueAction(action);
            
        }
    },
    descChanges : function(component, event){
       
        component.set("v.Hsn",false);
        component.set("v.PartNumbr",false);
        var partNamerecord = component.get("v.selectedLookUpRecordDesc");
        var partName = partNamerecord.PSA_Part_Number__c;
         var partid=partNamerecord.Id;
        var multifct=partNamerecord.PSA_Multiplication_Factor__c;
        component.set("v.multnfactr",multifct);
        component.set("v.partnumber1",partName);
        var partList = component.get("v.PartsList");
        var responsevalue = partList;
        console.log('partList>>>>>>>>>>>>'+JSON.stringify(partList));
        if(partName == "undefined" || partName == '' || partName == null){ 
            var Quantity = component.find("Quantity").get("v.value");
            var ratePerUnit = component.get("v.partRateperUnit");
            var TotalAmount = Quantity* ratePerUnit;
            var CGST = component.find("CGST").get("v.value");
            var SGST = component.find("SGST").get("v.value");
            var IGST = component.find("IGST").get("v.value");
            var CESS =component.find("cess").get("v.value");
            if(CGST === undefined){
            	CGST = 0;
        	}
         	if(SGST === undefined){
            	SGST = 0;
        	}
         	if(IGST === undefined){
            	IGST = 0;
        	}
	if(CESS === undefined){
            	CESS = 0;
        	}
        
     	 var GST =parseInt(CGST)+parseInt(SGST)+parseInt(CESS);
           // var GST = component.find("GST").get("v.value");
            var GSTamt =(TotalAmount/100)*GST;
            if(Quantity=='undefined' || Quantity=='' || Quantity==null){
                TotalAmount=0;
                GSTamt=0;
                
            }
            component.set("v.partDescription","");
            component.set("v.HSNCode", "");
            component.set("v.UOM", "");
            component.set("v.PackQty", "");
            component.set("v.partRateperUnit", "");
            component.set("v.partTax", "");
            component.set("v.MinOrderQty", "");
            //component.set("v.GST","");
             component.set("v.CGST","");
            component.set("v.IGST","");
            component.set("v.SGST","");
             component.set("v.CESS","");
            component.set("v.VehicleQty",'');
            //component.set("v.BackOrderQty", "");
            component.set("v.OrderQty", "");
            component.set("v.partTotalAmount",'0');
            component.set("v.partGSTAmount",'0');
             component.set("v.totalordervalue",'');
             component.set("v.taxable",'');
             component.set("v.totaltax",'');
             component.find("AvailableStock").set("v.value", "");
            //component.set("v.AvailableStock", "");
            component.set("v.disVariant", "false");
            component.set("v.assocIdval", "");
            component.find("Quantity").set("v.value", "");
            component.set("v.NetDealerPrice", ''); 
            component.set("v.Hsn",true);
            component.set("v.PartNumbr",true);
             component.set("v.qyvisiable",true); 
            component.getEvent("partnumempty").setParams({
                "deleteAmount" : TotalAmount,"deleteGSTAmount" :GSTamt}).fire();
            var partnumber = component.find("PartNumber").set("v.value",'');
             var quant =component.find("qty1").set("toastEvent",false);
            
        }else{
            
            
            for(var i=0;i<responsevalue.length;i++){
                if(partName == responsevalue[i].PSA_Part_Number__c){
                    var partDesc = responsevalue[i].PSA_Parts_Description__c;
                    var partRte = responsevalue[i].PSA_Rate_per_Unit__c;
                    var partTx = responsevalue[i].PSA_Tax__c;
                    var igstval = responsevalue[i].PSA_IGST__c;
                    var cgstval = responsevalue[i].PSA_CGST__c;
                    var sgstval = responsevalue[i].PSA_SGST__c;
                       var cess = responsevalue[i].PSA_CESS__c;
                    var hsnCode = responsevalue[i].PSA_HSN_Code__c;
                    var uom = responsevalue[i].PSA_UOM__c;
                    var packQty = responsevalue[i].PSA_Pack_Quantity__c;
                    var qty=responsevalue[i].PSA_Quantity_Per_Vehicle__c;
                     var stock =  responsevalue[i].PSA_Quantity__c;
                    var partAssId = responsevalue[i].Id;
                    var qty=responsevalue[i].PSA_Quantity_Per_Vehicle__c;
                    var moqi=responsevalue[i].PSA_Minimum_Order_Quantity__c;
                     if(moqi == 'undefined' || moqi == null)
                     {
                         var moq='-';
                     }
                    else
                    {
                        var moq=responsevalue[i].PSA_Minimum_Order_Quantity__c;
                    }
                    
                    component.find("assocIdval").set("v.value",partAssId);
                    
                }
            }
            component.set("v.NetDealerPrice",partRte); 
            component.set("v.partDescription", partDesc);
            component.set("v.HSNCode", hsnCode);
            component.set("v.UOM", uom);
            component.set("v.PackQty", packQty);
            component.set("v.VehicleQty",qty);
            component.set("v.qyvisiable",false);
            component.set("v.partRateperUnit", partRte);
            component.set("v.partTax", partTx); 
            component.set("v.MinOrderQty", moq);
            component.set("v.CGST", cgstval);
             component.set("v.IGST", igstval);
             component.set("v.SGST", sgstval);
             component.set("v.CESS", cess);
            //component.set("v.GST", igstval);
            //component.set("v.BackOrderQty", "0");
            component.set("v.OrderQty", "-");
             component.find("AvailableStock").set("v.value", stock);
         //   component.set("v.AvailableStock", stock);
            component.set("v.disVariant", "false");
            component.set("v.assocIdval", partAssId);
            component.set("v.Prdname", partName);
            component.find("Quantity").set("v.value", "");
            var partnumber = component.find("PartNumber").set("v.value",partName);
                  var partnumber =partid;
                
             var stockrecord= partNamerecord.Dealer_Inventory__r;
                var stock=stockrecord[0].PSA_Current_Stock__c;
               
                 component.find("AvailableStock").set("v.value", stock); 
           
        
        }
    },
    
    getVendorPartsList : function(component, event) {
        var action=component.get('c.getVendorParts');
        action.setParams({
            "vendorId" : component.get("v.selectedVendor")
        });
        action.setCallback(this, function(response) {
            var responsevalue=response.getReturnValue();
            component.set('v.PartsList',responsevalue);
        });
        $A.enqueueAction(action);
    },
    getTotalAmount : function(component, event) {
        debugger;
        var rowindex = component.get("v.rowIndex");
        var Quantity = component.find("Quantity").get("v.value");
        
        if(Quantity==''||Quantity==null||Quantity=='undefined'){
            var qun=0; 
        }else{
            
            qun=Quantity;   
        }
        var ratePerUnit = component.get("v.partRateperUnit");
        var TotalAmount = qun* ratePerUnit;
            var CGST = component.find("CGST").get("v.value");
            var SGST = component.find("SGST").get("v.value");
            var IGST = component.find("IGST").get("v.value");
          	var CESS =component.find("cess").get("v.value");
             if(CGST === undefined){
            	CGST = 0;
        	}
         	if(SGST === undefined){
            	SGST = 0;
        	}
         	if(IGST === undefined){
            	IGST = 0;
        	}

     	 if(CESS === undefined){
            	CESS = 0;
        	}
        
     	 var GST =parseInt(CGST)+parseInt(SGST)+parseInt(CESS);
        //var GST = component.find("GST").get("v.value");
        var GSTamt =(TotalAmount/100)*GST;
         var totalordervalue=TotalAmount+GSTamt;
        //var curr = component.get("v.partTotalAmount");
        var curr = component.get('v.ProductInstance.PSA_Total_Amount__c');
        if(curr != ""){
            var currGST =(curr/100)*GST;
        }
        if(curr == ""){
            curr=0;
            var currGST = 0;
        }
        //var currGST = component.get("v.partGSTAmount");
        var Diffamnt = TotalAmount- curr;
        if(Diffamnt != "0" && curr != "0"){
            var eventListPage = component.getEvent("deleteOrderAmount");
            eventListPage.setParams({"OrderAmountcurr" : curr,"excludingAmountcurr" : currGST});
            eventListPage.fire();
            component.set('v.partTotalAmount',TotalAmount);
            component.set("v.partGSTAmount",GSTamt);
            component.set('v.taxable',TotalAmount);
            component.set("v.totaltax",GSTamt);
            component.set("v.totalordervalue",totalordervalue);

            var eventListPage = component.getEvent("getOrderAmount");
            eventListPage.setParams({"OrderAmountcurr" : TotalAmount,"excludingAmountcurr" : GSTamt});
            eventListPage.fire();
        }
        if(curr == "0"){
            component.set('v.partTotalAmount',TotalAmount);
            component.set('v.partGSTAmount',GSTamt);
            component.set('v.taxable',TotalAmount);
            component.set("v.totaltax",GSTamt);
            component.set("v.totalordervalue",totalordervalue);

            var eventListPage = component.getEvent("getOrderAmount");
            eventListPage.setParams({"OrderAmountcurr" : TotalAmount,"excludingAmountcurr" : GSTamt});
            eventListPage.fire();
        }
        component.set("v.NetDealerPrice",ratePerUnit);
        if((Quantity <= 0)&&(Quantity != null)){
           /* var Quantity = component.find("Quantity").set("v.value",'');
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": 'Quantity should be greater than Zero '
            });
            toastEvent.fire();*/
        }
        
    },
            validateprice : function(component, event, helper) {
         
         var charCode = event.getParams().keyCode;
             if ((charCode >= 1 && charCode <= 32)||(charCode >= 48 && charCode <= 57) || (charCode >= 96 && charCode <= 105)) { 
           return true;
          } 
        else{
             var message= 'Quantity should be greater than Zero';
            helper.showErrorToast(component,event,message);
             //component.find("MRP").set("v.value",'');
        }
        
    },
    AddNewBlankRow : function(component, event, helper){
        var compEvent = component.getEvent('AddPartRowEvt');
        compEvent.fire();
         var quant1 =component.find("qty1").set("toastEvent",false);
    },
    removeRow : function(component, event, helper){
        debugger;  
        var Quantity = component.find("Quantity").get("v.value");
        var partnumber = component.find("PartNumber").get("v.value");
        var ratePerUnit = component.get("v.partRateperUnit");
        var TotalAmount = Quantity* ratePerUnit;
         var CGST = component.find("CGST").get("v.value");
            var SGST = component.find("SGST").get("v.value");
            var IGST = component.find("IGST").get("v.value");
          var CESS =component.find("cess").get("v.value");
             if(CGST === undefined){
            	CGST = 0;
        	}
         	if(SGST === undefined){
            	SGST = 0;
        	}
         	if(IGST === undefined){
            	IGST = 0;
        	}
 			if(CESS === undefined){
            	CESS = 0;
        	}
        
     	 var GST =parseInt(CGST)+parseInt(SGST)+parseInt(CESS);
       // var GST = component.find("GST").get("v.value");
        var GSTamt =(TotalAmount/100)*GST;
        if(Quantity == '' || partnumber== ''){
            component.getEvent("DeletePartRowEvt").setParams({
                "indexVar" : component.get("v.rowIndex"),
                "deleteAmount" : 0,"deleteGSTAmount" :0}).fire();
            
        }else{
            
            component.getEvent("DeletePartRowEvt").setParams({
                "indexVar" : component.get("v.rowIndex"),
                "deleteAmount" : TotalAmount,"deleteGSTAmount" :GSTamt}).fire();
        }
        var quant =component.find("qty1").set("toastEvent",false);
    }, 
    onfocusPO : function(component, event, helper) {
        var cssevent = component.getEvent("cssevent");
        cssevent.fire();
    },
    
    handleValidation : function(component, event, helper){
        debugger;
        var isvalid=true;
        var moqty=component.find("MinOrd").get("v.value");
        var partname = component.find("PartNumber").get("v.value");
        var Quantityval = component.find("Quantity").get("v.value");
                  if((partname == 'undefined' || partname == '' || partname == null )&&((Quantityval == ''||Quantityval=='undefined'||Quantityval==null))){
            var Message = 'please select the PartNumber and Quantity';
            helper.showError(component,event,Message);
            isvalid=false;    
        }  
           if((partname == 'undefined' || partname == '' || partname == null )&&(Quantityval!='')){
            var Message = 'please select the PartNumber';
            helper.showError(component,event,Message);
            isvalid=false;
            // isvalidparDetails = false;
        }
             if((Quantityval == ''||Quantityval=='undefined'||Quantityval==null)&&(partname != '')){
            var Message=' Please Enter the Quantity' ;
            helper.showError(component,event,Message);  
            isvalid=false;
            //  isvalidparDetails = false;
        }
            /* if(Quantityvalue > factor){
                var multires = Quantityvalue%factor;
                if(multires != 0){
               	  var Message=' Quantity should be in Mutliplication factor' ;
                	helper.showError(component,event,Message);
                  isvalid=false;
                }
       		 }
                if(Quantityvalue < factor){
                    var multires = factor%Quantityvalue;
                    if(multires != 0){
                      var Message=' Quantity should be in Mutliplication factor' ;
                            helper.showError(component,event,Message);
                          isvalid=false;
                    }
                }*/

        return isvalid;
    },
    inputchange : function(component, event, helper){
        debugger;
        var Quantity = component.find("Quantity").get("v.value");
        var partnumber = component.find("PartNumber").get("v.value"); 
        var ratePerUnit = component.get("v.partRateperUnit"); 
        var TotalAmount = Quantity* ratePerUnit;
         var CGST = component.find("CGST").get("v.value");
            var SGST = component.find("SGST").get("v.value");
            var IGST = component.find("IGST").get("v.value");
          var CESS =component.find("cess").get("v.value");
             if(CGST === undefined){
            	CGST = 0;
        	}
         	if(SGST === undefined){
            	SGST = 0;
        	}
         	if(IGST === undefined){
            	IGST = 0;
        	}
 			if(CESS === undefined){
            	CESS = 0;
        	}
        
     	 var GST =parseInt(CGST)+parseInt(SGST)+parseInt(CESS);
       // var GST = component.find("GST").get("v.value");
        var GSTamt =(TotalAmount/100)*GST;
        component.set("v.Prdname",'');
        component.find("PartNumber").set("v.value",'');
        component.find("Quantity").set("v.value",'');
        component.set("v.partDescription", '');
        component.set("v.UOM", '');
        component.set("v.HSNCode", '');
       // component.set("v.GST", '');
       	component.set("v.CGST","");
        component.set("v.IGST","");
        component.set("v.SGST","");
        component.set("v.CESS","");
        component.find("Quantity").set("v.value",'');
        component.find("AvailableStock").set("v.value",'');
        component.set("v.partRateperUnit",'');
        component.set("v.qyvisiable", true);
        //component.set("v.BackOrderQty", '');
        component.set("v.OrderQty", "");
        component.set("v.VehicleQty",'');
        component.set("v.AvailableStock",'');
        component.set("v.MinOrderQty", "");
        component.set("v.PackQty", " ");
        component.set("v.NetDealerPrice","");
        component.set("v.Pillclear", ''); 
        component.set("v.taxable",'');
        component.set("v.totaltax",'');
        component.set("v.totalordervalue",'');
       
      //  var quant = component.find("qty1").set("toastEvent",false);
        component.getEvent("partamount").setParams({
            "OrderAmountcurr" : TotalAmount,"excludingAmountcurr" :GSTamt}).fire();
    },
})
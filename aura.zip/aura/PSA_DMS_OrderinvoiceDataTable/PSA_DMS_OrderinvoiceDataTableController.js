({
    doInit : function(component, event, helper) {
       
        
        var action = component.get('c.fetchorders');
       
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.orders", records);
            }
        });
        $A.enqueueAction(action);
    },
    
    onclickPO : function(component, event, helper) {
        
        var target = event.getSource().get('v.value');
        var compEvent = component.getEvent("monthlyOrderIdPass");
        compEvent.setParams({"currentMonthlyOrderId" : target });
          compEvent.fire();
        
       
    },
    
    
    //var compEvent = cmp.getEvent("sampleComponentEvent");
    // Optional: set some data for the event (also known as event shape)
    // A parameter’s name must match the name attribute
    // of one of the event’s <aura:attribute> tags
    // compEvent.setParams({"myParam" : myValue });
    //compEvent.fire();
})
({
    helperMethodPagination : function(component, event, pageNumber){
        var pageSize = component.get("v.pageSize");//Number Of Row Per Page
        var totalpage=Math.ceil(component.get("v.receipts").length/pageSize);//Number Of Total Pages
        var   paginationPageNumb=[];
        var cont=1;
        /*---Pagination Logic Start--*/
        if(pageNumber<=7){
            for(var i=1; i<= totalpage; i++){
              //  paginationPageNumb.push(i);
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
                paginationPageNumb.push(i);
            }
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
                paginationPageNumb.push(i);
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }
        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    },
    
    getbookinglist : function(component, event, sortoption,sSoql,fromdate,todate,filter) {      
        
        var action = component.get('c.getbookingorderList');
        action.setParams({
            "sortField" :sortoption,
            "sSoql":sSoql,
            "fromdate"  :fromdate,
             "todate"    :todate,
            "filter"    :filter,
            
        })
        action.setCallback(this, function(response){
            var state = response.getState();
            
            if(state == 'SUCCESS') {
                
                var c=component.get("v.counting");
                if(parseInt(c)==2){
                    component.set("v.counting", parseInt(1));
                } if(parseInt(c)==1) {
                    component.set("v.counting", parseInt(2));
                }
                var c=component.get("v.counting1");
                if(parseInt(c)==2){
                    component.set("v.counting1", parseInt(1));
                } if(parseInt(c)==1) {
                    component.set("v.counting1", parseInt(2));
                }
                var c=component.get("v.counting2");
                if(parseInt(c)==2){
                    component.set("v.counting2", parseInt(1));
                } if(parseInt(c)==1) {
                    component.set("v.counting2", parseInt(2));
                }
                var c=component.get("v.counting3");
                if(parseInt(c)==2){
                    component.set("v.counting3", parseInt(1));
                } if(parseInt(c)==1) {
                    component.set("v.counting3", parseInt(2));
                }
                var records =response.getReturnValue();               
                var pageSize = component.get("v.pageSize");
               
                component.set("v.receipts", records);
                component.set("v.totalSize", component.get("v.receipts").length);
                component.set("v.start",0);
                component.set("v.end",pageSize-1);
                var paginationList = [];
                if(response.getReturnValue().length < pageSize){
                    paginationList=response.getReturnValue();
                }
                else{
                    for(var i=0; i< pageSize; i++){
                        paginationList.push(response.getReturnValue()[i]); 
                    } 
                }
                
                component.set('v.paginationList', paginationList);
                if(response.getReturnValue().length==0){
                        component.set('v.norecords', true);
                }	else{
                    component.set('v.norecords', false);
                }
                this.helperMethodPagination(component, event, '1');
                //var icount = component.get("v.invoicescount");
                //var compEvent = component.getEvent("PartreceiptsCount");        
                //compEvent.setParams({"Id" : icount });        
                //compEvent.fire();
            }
        });
        $A.enqueueAction(action);
        
    }
    
})
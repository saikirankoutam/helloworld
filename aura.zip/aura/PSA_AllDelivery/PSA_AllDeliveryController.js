({
	 doInit : function(component, event, helper) {
	
          var Searchstring=component.get('v.Searchstring');

        if(Searchstring == null || Searchstring == 'undefined' || Searchstring==""){
            helper.partstable(component, event,'PSA_Booking_ID__r.OrderNumber',null,null,null); 
        }else{
            var x;
            var pagination=[];
            var deliverylist=component.get('v.alldeliverylist');
            for(x in deliverylist){
                var ordernumber=deliverylist[x].bookNum;
                if (ordernumber.match(Searchstring))   
                { 
                   // alert("hello");
                    pagination.push(deliverylist[x]);
                    
                }
            }
            component.set('v.paginationList',pagination);
            if(pagination.length==0){
                        component.set('v.norecords', true);
                }	else{
                    component.set('v.norecords', false);
                }
                
        }
        
	},
                       
  sort: function(component, event, helper) {
       helper.partstable(component, event, 'PSA_Booking_ID__r.OrderNumber');
      
    },
     sort1: function(component, event, helper) {
       helper.partstable(component, event, 'PSA_Registration_Status__c');
      
    },
    sort2: function(component, event, helper) {
       helper.partstable(component, event, 'PSA_PlannedDelivery__c');
      
    },
    sort3: function(component, event, helper) {
       helper.partstable(component, event, 'PSA_Booking_ID__r.OrderNumber');
      
    },
    onCheck:function(component, event, helper) {
        debugger;
        var ff=  component.get("v.alldeliverylist");
        
        var checkvalue = component.find("checkContact");
        var target = event.getSource().get("v.text");
        var value = event.getSource().get("v.value");
       
         var action = component.get('c.checkUpdate');
         action.setParams({
             "bookId":target,
             "value":value
             
        })
        action.setCallback(this, function(response){
            var state = response.getState();
          
           if(state == 'SUCCESS') {
               
              }
         });
        $A.enqueueAction(action); 
          
    
},
       Search:function(component, event, helper) {
           
     var fromdate=component.find("fromdate").get("v.value");
     var todate=component.find("todate").get("v.value");
           if((fromdate==''||fromdate==null || fromdate=='undefined')&&(todate=='' || todate==null || todate=='undefined'))
           {
         helper.partstable(component, event,'PSA_Booking_ID__r.OrderNumber',null,null,null);
           }
    else if(todate <fromdate)
        {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Warning!",
            "message": "Todate should not be less than From Date",
            "type": "Error"
        });
        toastEvent.fire();  
        }
        else
        {    
            helper.partstable(component, event,'PSA_Booking_ID__r.OrderNumber',fromdate,todate,'sample'); 
        }  
         
       },
    getListsearch:function(component, event, helper) {
           
     var fromdate=component.find("fromdate").get("v.value");
     var todate=component.find("todate").get("v.value");
           if((fromdate==''||fromdate==null || fromdate=='undefined')&&(todate=='' || todate==null || todate=='undefined'))
           {
         helper.partstable(component, event,'PSA_Booking_ID__r.OrderNumber',null,null,null);
           }  
       },
    next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        var receiptslist = component.get("v.alldeliverylist");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var receiptslist = component.get("v.alldeliverylist");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
        debugger;
         /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var accountList = component.get("v.alldeliverylist");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = accountList.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    }, 
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.partstable(component, event);
    },
   
  bookingview : function(component, event, helper) {
        var target = event.getSource().get('v.value');
       var target1 = event.getSource().get('v.label');
         var compEvent = component.getEvent("deliverydetailsIdPas");
        compEvent.setParams({"currentMonthlyOrderIdoem" : target });
       compEvent.setParams({"alldeliveryregisterId" : target1});
        compEvent.fire();        
    },
   preventalphabets : function(component, event, helper){
        var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
    }
    
})
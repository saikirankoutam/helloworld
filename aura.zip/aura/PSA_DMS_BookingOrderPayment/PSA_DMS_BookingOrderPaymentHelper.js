({
	paymentinfo : function(component, event){
        var action = component.get("c.fetchpayment");
        action.setParams({
            "bookingorderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();                
                console.log('payment Info >>>>'+JSON.stringify(storeResponse));
                component.set("v.PaymentList", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    
    getpaymentmodevalues : function(component, event, helper){
        var action = component.get("c.getPickListValuespaymentmode");        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();                
                component.set("v.PaymentmodeList", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    
    getpaymentparticularvalues : function(component, event, helper){
        var action = component.get("c.getPickListValuespaymentparticulars");        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();                
                component.set("v.PaymentparticularsList", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    
    Createpayment : function(component, event, helper) {  debugger;   
        component.set("v.selectedparticular", "Select");
        component.set("v.selectedmode", "Select");
		component.set("v.amountreceived", "");
        component.set("v.paymentdate", "");
        component.set("v.Approvedbyaccounts", false);
        component.set("v.remarks", "");
        component.set("v.newpaymentCreation", true);
        component.set("v.paymentlistview", false);
        var action = component.get("c.fetchpaymentbalance");
        action.setParams({
            "bookingorderId" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                var strarr = storeResponse.split(',');
                if(strarr[0] == "" || strarr[0] == undefined || strarr[0] == 0.0){
					component.set("v.sellingprice", strarr[5])
                    var sellingprice = component.get("v.sellingprice");
					component.set("v.balanceamount", 0);
                    component.find("submit").set("v.disabled", true);
				}
				else{
                    component.set("v.sellingprice", strarr[5])
                    var sellingprice = component.get("v.sellingprice");
					component.set("v.balanceamount", strarr[0]);
				}
                if(strarr[1] == "true")
                	component.set("v.approvevehcile", true);
                if(strarr[2] == "true")
                	component.set("v.approveaccessory", true);
                if(strarr[3] == "true")
                	component.set("v.approveinsurance", true);
                if(strarr[4] == "true")
                	component.set("v.approveregistration", true);
            }
        });
        $A.enqueueAction(action);
    },
    
    saverequest:function(component,event){
        var sellingpriceval = component.get("v.sellingprice");
        var particular =  component.get("v.selectedparticular");
        var mode =  component.get("v.selectedmode");
        var amtrec = component.get("v.amountreceived");
        var balamt = component.get("v.balanceamount");
        var paydate = component.get("v.paymentdate");
        var apprcheckedval = component.get("v.Approvedbyaccounts");
        var remarks = component.get("v.remarks");
        var paymentrecords = {
            "vehiclesellingprice" : sellingpriceval,
            "PSA_Particulars__c" : particular,
            "PSA_Mode__c": mode,
            "Payment_Amount__c": amtrec,
            "PSA_Balance_Amount__c" : balamt,
            "Payment_Date__c": paydate,
            "PSA_Approved_by_Accounts__c": apprcheckedval,
            "PSA_Remarks__c" : remarks,
            "PSA_Approve_Vehicle_Invoice__c" : component.get("v.approvevehcile"),
            "PSA_Approve_Accessory_Invoice__c" : component.get("v.approveaccessory"),
            "PSA_Approve_for_Insurance__c" : component.get("v.approveinsurance"),
            "Approve_for_Registration__c" : component.get("v.approveregistration")
        };
        var action = component.get("c.createpaymentmethod");        
        action.setParams({
            "mapofpaymentrec" : paymentrecords,
            "oid" : component.get("v.orderId")            
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                var Message= $A.get("$Label.c.PSA_Payment_created_Successfully");
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "message": "Payment Created Successfully!",
                    "type": "success"
                });
                toastEvent.fire();                               
                this.paymentinfo(component, event);
                component.set("v.newpaymentCreation", false);
                component.set("v.paymentlistview", true); 
            }
            else{
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "message": "Payment failed!",
                    "type": "error"
                });
                toastEvent.fire();  
            }
            /*var eventListPage = component.getEvent("displayListPageParts");
            eventListPage.setParams({"listPage" : true });
            eventListPage.fire();*/
        });
        $A.enqueueAction(action);
    },
    
    errortoast : function(component, event, helper, msg){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": msg,
            "type": "error"
        });
        toastEvent.fire(); 
    }
})
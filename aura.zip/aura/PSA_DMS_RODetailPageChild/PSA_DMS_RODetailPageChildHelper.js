({
	 showErrorToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "Error"
        });
        toastEvent.fire();  
    },
})
({
	doInit : function(component, event, helper) {
	
	},
    
        handleApplicationEvent: function(component, event, helper) {        
        var Id = event.getParam("currentMonthlyOrderIdoem");
           
        component.set("v.orderid", Id);  
            var custname = event.getParam("name");
             component.set("v.custname", custname);  
             var variant = event.getParam("variant");
             component.set("v.variant", variant);  
             var color = event.getParam("color");
             component.set("v.color", color);  
             var mod = event.getParam("mod");
             component.set("v.mod", mod);  
             var planDate = event.getParam("dat");
             component.set("v.planDate", planDate);  
       // component.set("v.BookingOrderDetailView", true);
            
    },
     handleApplication: function(component, event, helper) {        
        var Id = event.getParam("currentMonthlyOrderIdoem");
         
        component.set("v.orderid", Id);  
            var custname = event.getParam("name");
             component.set("v.custname", custname);  
             var variant = event.getParam("variant");
             component.set("v.variant", variant);  
             var color = event.getParam("color");
             component.set("v.color", color);  
             var mod = event.getParam("mod");
             component.set("v.mod", mod);  
             var planDate = event.getParam("dat");
             component.set("v.planDate", planDate);  
       // component.set("v.BookingOrderDetailView", true);
            
    },
    
      handleDeliveryOrderIdPass : function(component, event, helper) {        
        var Id = event.getParam("currentMonthlyOrderIdoem");
       var alldelId = event.getParam("alldeliveryregisterId");
        component.set("v.BookingorderId", Id);  
           component.set("v.alldelId", alldelId);  
        component.set("v.BookingOrderDetailView", true)
        component.set("v.showtabs",false);
          
    },
    
        
    fordisplayIdpass :function(component, event, helper) {
    var Id = event.getParam("currentMonthlyOrderIdoem");
        component.set("v.BookingorderId", Id);  
    },
    onTabSelect : function(component, event, helper) {
        
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
         if(id=='allDeliveries' || id=='todaydeliveries'){
            
            component.set('v.custname','');
             component.set('v.variant','');
             component.set('v.color','');
             component.set('v.mod','');
             component.set('v.planDate','');
            
        } 
        
    },
     partsearch: function(component, event, helper) { 
           debugger;
       var tabVal = component.get("v.currTab");
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        console.log("" + event.getSource().get("v.value"));
        component.set("v.Searchstring",pot) ;
        
     
             if(tabVal == 'allDeliveries'){
        		 var childCmp = component.find("partsreceiptinvoicesId");
                  childCmp.getinvoices();
             }
            if(tabVal == 'todaydeliveries'){
        		var childCmp = component.find("partsreceiptinvoicesId2");
            childCmp.getinvoices();
             }
           
        } ,
      handlevalidateMenu : function(component, event, helper) {
        debugger;
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        var defaultItem = event.getParam("defaultItem");
        console.log("validationItem -- "+validationItem+"::"+defaultItem);
        if (defaultItem) {
        	component.set("v.currTab", validationItem);            
        }
    },
   
          
   
    
    
    
})
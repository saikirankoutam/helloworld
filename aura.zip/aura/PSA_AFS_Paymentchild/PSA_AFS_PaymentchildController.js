({
	doInit : function(component, event, helper) {
        component.find("sno").set("v.value", component.get("v.rowno")+component.get("v.rowIndex")+1);
        helper.getpaymentmodevalues(component, event, helper);
	},
    
    AddNewBlankRow : function(component, event, helper){   
        var compEvent = component.getEvent('AddPaymentRowEvt');        
        compEvent.fire();
    },
    
    removeRow : function(component, event, helper){        
        component.getEvent("DeletePaymentRowEvt").setParams({
            "indexVar" : component.get("v.rowIndex")}).fire();
    },
    
        handleValidation : function(component, event, helper) {
        var isvalid = true;
        var mode =  component.find("modeid").get("v.value");
        var amtrec = component.find("PayAmtid").get("v.value");
        var recNum =component.find("ReceiptNum").get("v.value");
        var paydate = component.find("paymentdateid").get("v.value");
        if(mode == "Select"){
            var Message = 'Please select mode of payment!';
            helper.showError(component,event,Message);
            isvalid = false;
        }
            else if(amtrec == undefined || amtrec == "" || amtrec == null){
                var Message =  'Please enter Payment amount!';
                helper.showError(component,event,Message); 
                isvalid = false;
            }
          else if(recNum == undefined || recNum == "" || recNum == null){
                    var Message = 'Please enter Receipt Number!';
                    helper.showError(component,event,Message);
                    isvalid = false;
          }
                else if(paydate == undefined || paydate == "" || paydate == null){
                    var Message = 'Please enter payment date!';
                    helper.showError(component,event,Message);
                    isvalid = false;
                }
        return isvalid;
    },
    
    futuredaterestriction : function(component,event,helper){
        	var paymentdate = component.find("paymentdateid").get("v.value");
            var today = new Date();
            var dd = today.getDate();            
            var mm = today.getMonth()+1; 
            var yyyy = today.getFullYear();
            if(dd<10){dd='0'+dd;}             
            if(mm<10){mm='0'+mm;}
            today = yyyy+'-'+mm+'-'+dd;            
            if(paymentdate>today){
                component.find("paymentdateid").set("v.value", "");
                helper.showError(component, event, 'Payment date should not be in future!');
                var message = msg;
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type": "error",
                    "message": message
                });
                toastEvent.fire();                
            }
        
    }

})
({
	CampaignRecord : function(component, event) {
        var rid=component.get("v.RecordId");
        var action = component.get('c.getCampOrderslist');
        action.setParams({
            rid:rid
            });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
              
                var records =response.getReturnValue();
				component.set("v.OrderCampaignList", records); 
                component.set("v.disableSubmit", records[0].PSA_DisableSubmit__c);
                if(records[0].PSA_DisableSubmit__c)
                {
                    
                component.set("v.disableutility", records[0].PSA_DisableSubmit__c);
                }
	}
        }); $A.enqueueAction(action);
		
	},
    CampaignRecordList : function(component, event) {
        var rid=component.get("v.RecordId");
        var action = component.get('c.getCampRecordslist');
        var return1=[];
        action.setParams({
            rid:rid
            });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
             
                var records =response.getReturnValue();
				component.set("v.OrderCampaignpartslist", records);
            /*  for(var i=0;i<records.length;i++){
                  
               
                  if(records[i].returnquanity==null || records[i].returnquanity=='undefined')
                  {
                      return1.push('');
                  }
                else if(records[i].returnquanity>0)
                 {
               records[i].disableutility=true;
               //component.set("v.disableutility",true);
               return1.push(parseInt(records[i].issuequanity)- records[i].returnquanity);
                }
                else{
                  return1.push(parseInt(records[i].issuequanity)- records[i].returnquanity);
                    }
                   component.set("v.return1",return1);
            } */
               
                
                             
	}
        }); $A.enqueueAction(action);
		
    },
    listPageHelper : function(component, event){
        var eventListPage = component.getEvent("displayListPageVendors");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
        
    },    
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": "Campaign Order Updated successfully",
            "type": "success"
        });
        toastEvent.fire();  
    },
    showError : function(component, event, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
        component.set("v.spinner", false);
      //   component.set("v.Potyperrormsg",'This is a required field');
   
    },
    validatePartForm: function(component, event) {
        var isvalid=true;
        var invlist=  component.get("v.OrderCampaignpartslist");
        for(var i=0;i<invlist.length;i++){
             
            if(parseInt(invlist[i].issuequanity)< invlist[i].returnquanity)
            {
             isvalid=false;
             var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
            "title": "Error",
            "message": "Please enter Return Quantity less than Issued Quantity value",
            "type": "Error"
          });
          toastEvent.fire();  
                       
            }
            if(invlist[i].returnquanity==null || invlist[i].returnquanity=='undefined' || invlist[i].returnquanity<0)
            {
             isvalid=false;
             var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
            "title": "Error",
            "message": "Please enter Return Quantity Greater than or Equal to Zero",
            "type": "Error"
          });
          toastEvent.fire();  
            }
            
       }
       return isvalid;
    
    }
})
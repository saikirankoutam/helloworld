({
    autoCal : function(component, event, helper) {
        // for Row level value Calculations 
        helper.hlpRowtaxCalculation(component, event, helper);
         // Data Binding not to write any logic after this statement
        helper.hlpBindderItems(component, event, helper);
    },
    autoCalinit :function(component, event, helper) {
         // for Row level value Calculations 
         helper.hlpRowtaxCalculation(component, event, helper);
    },
    afterRender: function (component, event, helper) {
    this.superAfterRender();

    //disable up, down, right, left arrow keys
    window.addEventListener("keydown", function(e) {
        if([37, 38, 39, 40].indexOf(e.keyCode) > -1) {
            e.preventDefault();
        }
    }, false);

    //disable mousewheel
    window.addEventListener("mousewheel", function(e) {
        e.preventDefault();
    }, false);

    window.addEventListener("DOMMouseScroll", function(e) {
        e.preventDefault();
    }, false);

},
})
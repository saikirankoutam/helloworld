({
	scriptsLoaded : function (component, event, helper) {
        helper.scriptsHelperLoaded(component, event, helper);
    },
	scriptsLoaded2 : function (component, event, helper) {
        alert('Inside1');
        var ctx = component.find("chart").getElement();
        var chart = new CanvasJS.Chart(ctx, {
            animationEnabled: true,
            theme: "light2", // "light1", "light2", "dark1", "dark2"
            title:{
                text: "Top Oil Reserves"
            },
            axisY: {
                title: "Reserves(MMbbl)"
            },
            data: [{        
                type: "column",  
                showInLegend: true, 
                legendMarkerColor: "grey",
                legendText: "MMbbl = one million barrels",
                dataPoints: [      
                    { y: 300878, label: "Venezuela" },
                    { y: 266455,  label: "Saudi" },
                    { y: 169709,  label: "Canada" },
                    { y: 158400,  label: "Iran" },
                    { y: 142503,  label: "Iraq" },
                    { y: 101500, label: "Kuwait" },
                    { y: 97800,  label: "UAE" },
                    { y: 80000,  label: "Russia" }
                ]
            }]
        });
        alert('Inside1 - '+chart.theme);
        //component.find("chart").set(chart);
    }    
})
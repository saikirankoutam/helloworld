({
    validatePartForm : function(component, event, helper){
        debugger;
        var isValid = true;
        var BayNum = component.find("BayNum").get("v.value");
      //  var BayName = component.find("BayName").get("v.value");
        var Baydesc = component.find("Baydesc").get("v.value");
        var Baytype = component.find("Baytype").get("v.value");
         var active =component.find("checkbox").get("v.value");
        
        
        component.set("v.baynumberErrmsg",'');
        $A.util.removeClass(BayNum,"disp-block");
        $A.util.addClass(BayNum,"disp-none");
      /*  component.set("v.BaynameErrmsg",'');
        $A.util.removeClass(BayName,"disp-block");
        $A.util.addClass(BayName,"disp-none");*/
        component.set("v.BaydescErrorMsg",'');  
        $A.util.removeClass(Baydesc,"disp-block");
        $A.util.addClass(Baydesc,"disp-none");
        component.set("v.BaytypeErrmsg",'');
        $A.util.removeClass(Baytype,"disp-block");
        $A.util.addClass(Baytype,"disp-none");
        
        if(BayNum == 'undefined'|| BayNum == '' || BayNum == null){
            isValid = false;
            component.set("v.baynumberErrmsg",'This is a required field');
            $A.util.removeClass(BayNum,"disp-none");
            $A.util.addClass(BayNum,"disp-block");
        }
       /* if(BayName =='undefined'|| BayName == '' || BayName == null){
            component.set("v.BaynameErrmsg",'This is a required field');
            $A.util.removeClass(BayName,"disp-none");
            $A.util.addClass(BayName,"disp-block");
            isValid = false;
        }*/
        if(Baydesc =='undefined'|| Baydesc == '' || Baydesc == null){
            component.set("v.BaydescErrorMsg",'This is a required field');
            $A.util.removeClass(Baydesc,"disp-none");
            $A.util.addClass(Baydesc,"disp-block");
            isValid = false;
        }
        if(Baytype == '--None--'|| Baytype == '' || Baytype == null){
            component.set("v.BaytypeErrmsg",'This is a required field');
            $A.util.removeClass(Baytype,"disp-none");
            $A.util.addClass(Baytype,"disp-block");
            isValid = false;
        }
        
        return isValid;
    },           
    mastertable:function(component,event){
         
          var action = component.get('c.getBaymasterlist');
        	action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.Baylist", records);
               
            }
        });
        $A.enqueueAction(action);
         
     },
     BayImage:function(component,event){
         var bayimag = component.get("v.BayId");
          var action = component.get('c.getbayImage');
         action.setParams({
            "bayid" : bayimag 
        });
        	action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                
                var storeResponse = response.getReturnValue();
                for(var i=0;i<storeResponse.length;i++){
                    var baytype = storeResponse[i].PSA_Bay_Type__c;
                }
                
                component.set("v.bayviewImage", baytype);
                 
            }
        });
        $A.enqueueAction(action);
         
     }, 
     showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
})
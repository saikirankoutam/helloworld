({
    doInit : function(component, event, helper) {
        helper.mastertable(component,event);
        helper.BayImage(component,event);
    },
   
     closeEditBayForm : function(component, event, helper) {
        component.set("v.baynumberErrmsg",'');
        component.set("v.BaydescErrorMsg",'');
        component.set("v.BaytypeErrmsg",'');
      //  component.set("v.BaynameErrmsg",'');
       var eventListPage = component.getEvent("displaycreatepage");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
       
        document.getElementById("EditModal").style.display = "none";
        
    },
     onactive:function(component, event, helper){
        var active=component.find("checkbox").get("v.value");
        if(active){
            component.set("v.inactivecheckbox",true);
            component.find("inactivecheckbox").set("v.value",false);
        }
        else{
             component.set("v.inactivecheckbox",false);
        }
    },
      oninactive:function(component, event, helper){
        var active=component.find("inactivecheckbox").get("v.value");
        if(active){
            component.set("v.activecheckbox",true);
            component.find("checkbox").set("v.value",false);
        }
        else{
             component.set("v.activecheckbox",false);
        }
    },
    
    bayview:function(component,event,helper){ 
        debugger;
        var Baytype = component.find("Baytype").get("v.value");
             component.set("v.bayviewImage", Baytype);
           },
    
    SaveEditBayForm : function(component, event, helper) {
       
        if(helper.validatePartForm(component)) {
              
          component.find("recordHandler").saveRecord($A.getCallback(function(saveResult) {
            if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") { 
                console.log('Result Saved');
    
              var Message= $A.get("$Label.c.Bay_Updated_Successfully");
                helper.showSuccessToast(component,event,Message);
                 var eventListPage = component.getEvent("displaycreatepage");
                  eventListPage.setParams({"listPage" : true });
                  eventListPage.fire();
            } else if (saveResult.state === "INCOMPLETE") {
                console.log("User is offline, device doesn't support drafts.");
            } else if (saveResult.state === "ERROR") {
                console.log('Problem saving record, error: ' + JSON.stringify(saveResult.error));
            } else {
                console.log('Unknown problem, state: ' + saveResult.state + ', error: ' + JSON.stringify(saveResult.error));
            }
        }));
         }
    },
    
    
})
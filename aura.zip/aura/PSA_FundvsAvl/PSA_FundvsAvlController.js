({
    doInit : function(component, event, helper) {
        var reportid = $A.get("$Label.c.PSA_Fund_Req_vs_Avl"); 
        var reporturl;
        reporturl = '/dmsindia/s/report/'+reportid;    
        component.set("v.reportlink",reporturl);
    }
})